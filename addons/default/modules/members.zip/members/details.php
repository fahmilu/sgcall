<?php defined('BASEPATH') or exit('No direct script access allowed');

class Module_Members extends Module {

	public $version = '2.29';
	public $language_file = array('members/members', 'public_consultations/public_consultations');

	public function __construct()
	{
		$this->lang->load($this->language_file);
	}

	public function info()
	{
		return array(
			'name' => array(
				'en' => 'Membership',
			),
			'description' => array(
				'en' => 'Manage RSPO Members.',
			),
			'frontend'	=> TRUE,
			'backend'	=> TRUE,
			'skip_xss'	=> TRUE,
			//'menu'		=> 'membership',
			'roles' => array(
				'approve_member', 'edit_member', 'delete_member', 'add_member', 'view_member',
				// scc
				'edit_scc', //'add_scc', 'edit_scc', 'delete_scc',
				// pnc
				'edit_pnc', //'add_pnc', 'edit_pnc', 'delete_pnc',
				// complaints
				'edit_complaints', //'add_complaints', 'edit_complaints', 'delete_complaints',
				// certification bodies
				'edit_cb',//'add_cb', 'edit_cb', 'delete_cb',
			),
			'sections' => array(
			    'members' => array(
				    'name' => 'members:members_label',
				    'uri' => 'admin/members',
				    'shortcuts' => array(
						array(
					 	   'name' => 'members:members_add_label',
						    'uri' => 'admin/members/create',
						    'class' => 'add'
						),
					),
				),
			    'pnc' => array(
				    'name' => 'members:nav_pnc_assessment',
				    'uri' => 'admin/members/pncassessment',
				    'shortcuts' => array(
						array(
					 	   'name' => 'members:pnc_add_label',
						    'uri' => 'admin/members/pncassessment/create',
						    'class' => 'add'
						),
					),
				),
				'pnc_type' => array(
				    'name' => 'members:nav_pnc_assessment_type',
				    'uri' => 'admin/members/pncassessment_type',
				    'shortcuts' => array(
						array(
							'name' => 'members:pnctype_add_label',
						    'uri' => 'admin/members/pncassessment_type/create',
						    'class' => 'add'
						),
					),
				),
			    'scc' => array(
				    'name' => 'members:nav_scc',
				    'uri' => 'admin/members/scc',
				    'shortcuts' => array(
						array(
					 	   'name' => 'members:scc_add_label',
						    'uri' => 'admin/members/scc/create',
						    'class' => 'add'
						),
					),
				),
			    'cb' => array(
				    'name' => 'members:nav_cb',
				    'uri' => 'admin/members/cb',
				    'shortcuts' => array(
						array(
					 	   'name' => 'members:cb_add_label',
						    'uri' => 'admin/members/cb/create',
						    'class' => 'add'
						),
					),
				),
			    'gm' => array(
				    'name' => 'members:nav_gm',
				    'uri' => 'admin/members/gm',
				    'shortcuts' => array(
						array(
					 	   'name' => 'members:gm_add_label',
						    'uri' => 'admin/members/gm/create',
						    'class' => 'display-none'
						),
					),
				),
                'score' => array(
                    'name' => 'members:nav_score',
                    'uri' => 'admin/members/score',
                    'shortcuts' => array(
                        array(
                            'name' => 'members:score_add_label',
                            'uri' => 'admin/members/score/create',
                            'class' => 'add'
                        ),
                    ),
                )
		    ),
		);
	}

	public function install()
	{
/*
		$settings = "
			INSERT INTO " . $this->db->dbprefix('settings') . "
				(`slug`, `title`, `description`, `type`, `default`, `value`, `options`, `is_required`, `is_gui`, `module`, `order`) VALUES
			('slideshow_width', 'Slideshow Width', 'Width of slideshow image', 'text', '1440', '1440', '', 0, 1, 'images', 1010),
			('slideshow_height', 'Slideshow Height', 'Height of slideshow image', 'text', '700', '700', '', 0, 1, 'images', 1009);
		";

		if($this->db->query($settings) )
		{
			return TRUE;
		}
*/
		return TRUE;
	}

	public function uninstall()
	{
		return TRUE;
	}

	public function upgrade($old_version)
	{
		// $sql = "
		// 	CREATE TABLE IF NOT EXISTS `" . $this->db->dbprefix('member_scc_facilities') . "` (
		// 	  `scc_id` int(11) NOT NULL,
		// 	  `facility` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
		// 	  `facility_country` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL
		// 	) ENGINE=MyISAM;
		// ";
		// $sql2 = "
		// 		INSERT INTO `" . $this->db->dbprefix('member_scc_facilities') . "` (scc_id, facility)
		// 		SELECT id, facility FROM `" . $this->db->dbprefix('member_scc') . "` WHERE facility IS NOT NULL ;
		// ";

//		$sql_1 = "ALTER TABLE `default_member_pnc` ADD `notification_end` INT(11) NULL DEFAULT NULL AFTER `notification_date`";
//
//		$sql_2 = "ALTER TABLE `default_member_pnc` ADD `assessment_end` INT(11) NULL DEFAULT NULL AFTER `assessment_date`";
		$sql_1 = "ALTER TABLE `default_membership` ADD `acop_score_card` VARCHAR (255) NULL DEFAULT NULL";
		$sql_2 = "ALTER TABLE `default_membership` ADD `acop_score_card_addDate` INT(11) NULL DEFAULT 0";
		$sql_3 = "ALTER TABLE `default_membership` ADD `acop_score_card_modifiedDate`INT(11) NULL DEFAULT 0";

		if ( $this->db->query($sql_1) && $this->db->query($sql_2) && $this->db->query($sql_3) )
			return TRUE;

		return FALSE;
	}

	public function help()
	{
		/**
		 * Either return a string containing help info
		 * return "Some help info";
		 *
		 * Or add a language/help_lang.php file and
		 * return TRUE;
		 *
		 * help_lang.php contents
		 * $lang['help_body'] = "Some help info";
		*/
		return TRUE;
	}

	public function XYZadmin_menu(&$menu)
	{
		add_admin_menu_place('lang:members:nav_membership', 2);
		$menu['lang:members:nav_membership']['lang:members:nav_membership_submenu']	= 'admin/members';
		$menu['lang:members:nav_membership']['lang:members:nav_call_for_comments']	= 'admin/call_for_comments';
		$menu['lang:members:nav_membership']['lang:members:nav_sh_certification_inquiries']	= 'admin/contact';
		$menu['lang:members:nav_membership']['lang:members:nav_trademark']		= 'admin/trademark_application';
		$menu['lang:members:nav_membership']['lang:members:nav_complaints']		= 'admin/complaints';
		$menu['lang:members:nav_membership']['lang:members:nav_survey']		= 'admin/members/survey';

		//$menu['lang:members:nav_membership']['lang:members:nav_cb']					= 'admin/members/cb';
		//$menu['lang:members:nav_membership']['lang:members:nav_pnc_assessment']		= 'admin/members/pncassessment';
		//$menu['lang:members:nav_membership']['lang:members:nav_pnc_assessment_type']= 'admin/members/pncassessment_type';
		//$menu['lang:members:nav_membership']['lang:members:nav_pcc'] 	= 'admin/public_consultation_comments';
		//$menu['lang:members:nav_membership']['lang:members:nav_scc']	= 'admin/members/scc';

		add_admin_menu_place('lang:public_consultations:nav_certification', 3);
		$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_pncassessment']	= 'admin/members/pncassessment';
		$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_sccholder']		= 'admin/members/scc';
		$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_ni_npp_public_consultations']	= 'admin/public_consultations';
		$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_ni_npp_comments']		= 'admin/public_consultation_comments';
		$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_certifications_bodies']	= 'admin/members/cb';
		$menu['lang:growers:top_menu']['lang:growers:growers_title']	= 'admin/growers';
		$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_license_holders']	= 'admin/license_holders';
	}

	public function admin_menu(&$menu)
	{
		add_admin_menu_place('lang:members:nav_membership', 2);
		if (function_exists('group_has_role'))
		{
			if(group_has_role('members', 'edit_member'))
			{
				$menu['lang:members:nav_membership']['lang:members:nav_membership_submenu']	= 'admin/members';
				$menu['lang:members:nav_membership']['lang:members:nav_survey']		= 'admin/members/survey';
			}

			if(group_has_role('call_for_comments', 'delete_comment'))
			{
				$menu['lang:members:nav_membership']['lang:members:nav_call_for_comments']	= 'admin/call_for_comments';
			}

			if(group_has_role('trademark_application', 'edit_post'))
			{
				$menu['lang:members:nav_membership']['lang:members:nav_trademark']		= 'admin/trademark_application';
			}

			if(group_has_role('complaints', 'edit_complaints'))
			{
				$menu['lang:members:nav_membership']['lang:members:nav_complaints']		= 'admin/complaints';
			}



			//$menu['lang:members:nav_membership']['lang:members:nav_membership_submenu']	= 'admin/members';
			//$menu['lang:members:nav_membership']['lang:members:nav_call_for_comments']	= 'admin/call_for_comments';
			$menu['lang:members:nav_membership']['lang:members:nav_sh_certification_inquiries']	= 'admin/contact';
			//$menu['lang:members:nav_membership']['lang:members:nav_trademark']		= 'admin/trademark_application';
			//$menu['lang:members:nav_membership']['lang:members:nav_complaints']		= 'admin/complaints';
			//$menu['lang:members:nav_membership']['lang:members:nav_survey']		= 'admin/members/survey';
		}

		//$menu['lang:members:nav_membership']['lang:members:nav_cb']					= 'admin/members/cb';
		//$menu['lang:members:nav_membership']['lang:members:nav_pnc_assessment']		= 'admin/members/pncassessment';
		//$menu['lang:members:nav_membership']['lang:members:nav_pnc_assessment_type']= 'admin/members/pncassessment_type';
		//$menu['lang:members:nav_membership']['lang:members:nav_pcc'] 	= 'admin/public_consultation_comments';
		//$menu['lang:members:nav_membership']['lang:members:nav_scc']	= 'admin/members/scc';

		add_admin_menu_place('lang:public_consultations:nav_certification', 3);
		if (function_exists('group_has_role'))
		{
			if(group_has_role('members', 'edit_pnc'))
			{
				$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_pncassessment']	= 'admin/members/pncassessment';
			}

			if(group_has_role('members', 'edit_cb'))
			{
				$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_certifications_bodies']	= 'admin/members/cb';
			}

			if(group_has_role('members', 'edit_scc'))
			{
				$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_sccholder']		= 'admin/members/scc';
			}

			if(group_has_role('license_holders', 'edit_live'))
			{
				$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_license_holders']	= 'admin/license_holders';
			}

			if(group_has_role('growers', 'import_data'))
			{
				$menu['lang:growers:top_menu']['lang:growers:growers_title']	= 'admin/growers';
			}

			if(group_has_role('public_consultations', 'edit_live'))
			{
				$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_ni_npp_public_consultations']	= 'admin/public_consultations';
			}

			if(group_has_role('public_consultation_comments', 'edit_comment'))
			{
				$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_ni_npp_comments']		= 'admin/public_consultation_comments';
			}


		}

		//$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_ni_npp_public_consultations']	= 'admin/public_consultations';
		//$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_ni_npp_comments']		= 'admin/public_consultation_comments';
		//$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_certifications_bodies']	= 'admin/members/cb';
		//$menu['lang:growers:top_menu']['lang:growers:growers_title']	= 'admin/growers';
		//$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_license_holders']	= 'admin/license_holders';
	}

}

/* End of file details.php */
