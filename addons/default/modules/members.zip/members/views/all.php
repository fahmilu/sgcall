﻿<?php if(SITE_REF == "bcn"): ?>
	<header>
		<div class="row">
			<div class="container text-center" id="header-white">
				<h1 style="padding-top:0px; margin-top:0px;">查找会员</h1>
			</div>
		</div>
	</header>

	<?php 
	if(!empty($this->uri->segment(1))){ $segment1 = $this->uri->segment(1); } else{ $segment1 = '';}
	if(!empty($this->uri->segment(2))){ $segment2 = '/' .$this->uri->segment(2); } else{ $segment2 = '';}
	if(!empty($this->uri->segment(3))){ $segment3 = '/' .$this->uri->segment(3); } else{ $segment3 = '';}
	if(!empty($this->uri->segment(4))){ $segment4 = '/' .$this->uri->segment(4); } else{ $segment4 = '';}
	if(!empty($this->uri->segment(5))){ $segment5 = '/' .$this->uri->segment(5); } else{ $segment5 = '';}
	
	$urlredirect = $segment1.$segment2.$segment3.$segment4.$segment5 ;
	?>
	
	<section style="border:none;">
		<div class="container">
			<div class="contain-redirect">
				<div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
						<p class="text-redirect">{{ widgets:instance id="22"}}</p>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6 col-md-6 col-lg-6 button-back-redirect">
						<button onclick="goBack()" type="submit" class="btn btn-redirect-white">{{ widgets:instance id="23"}}</button>
					</div>
					<div class="col-sm-6 col-md-6 col-lg-6 button-continue-redirect">
						<a href="http://rspo.org/<?php echo $urlredirect?>" class="btn btn-lg btn-redirect-orange" target="_blank">{{ widgets:instance id="24"}}</a>
					</div>
                </div>
            </div>
        </div>
    </section>
	
	<script>
	function goBack() {
		window.history.go(-1);
	}
	</script>

<?php else: ?>
	
<!-- Full Page Image Background Carousel Header -->
<header>
	<div class="row">
		<div class="container text-center" id="header-white" style="padding-bottom:15px;">
			<h1 class="margin-top-12">Search members</h1>
		</div>
	</div>
</header>

<?php $this->load->view('partials/search-bar'); ?>

<?php if (!empty($members)): ?>
<section class="pad-top-30">
	<div class="container-1080">	
		<div class="row">
			<div class="">
				<div class="table-responsive table_search_member">
					<div class="table_head">
						<div class="table_head_col_lists">
							<div class="col_1">
								<p>Name</p>
							</div>
							<div class="col_2">
								<p>Country/Region</p>
							</div>
							<div class="col_3">
								<p>Status</p>
							</div>
							<div class="col_4">
								<p>Member Since</p>
							</div>
							<div class="col_5">
								<p>Membership Type</p>
							</div>
						</div>
					</div>
					<div class="table_body">
						<?php $i=0; foreach ($members as $m) { ?>
                            <?php if (!empty($m->subsidiaries)): ?>
							<div id="list_table<?php echo $i ?>" class="<?php echo ($m->subsidiaries) ? 'check_subsidiary' : ''; ?> accordion_heading panel-group s_list_table" role="tablist" aria-multiselectable="true">
								<div class="panel panel-default">
									<div id="heading_list_table<?php echo $i ?>" class="panel-heading" role="tab">
										<a href="#list_table_in<?php echo $i ?>" class="accordion_toggle <?php echo (!empty($m->subsidiaries)) ? 'collapse' : 'collapsed'; ?>" role="button" data-toggle="collapse" data-parent="#list_table<?php echo $i; ?>" aria-expanded="true" aria-controls="list_table_in<?php echo $i; ?>">
										</a>
										<div class="head_table_t">
											<div class="col_1">
												<a href="<?php echo site_url( 'members/'.$m->intID.'/'.url_title($m->title) ); ?>">
													<p class="target_m_profile" data-option=""><?php echo str_ireplace("\\", "", stripslashes($m->title) ) ?></p>
												</a>
											</div>
											<div class="col_2">
												<p><?php echo $m->country ?></p>
											</div>
											<div class="col_3">
												<p><?php echo $m->status ?></p>
											</div>
											<div class="col_4">
												<p><?php echo date("j M Y", $m->approved_date); ?></p>
											</div>
											<div class="col_5">
												<p><?php echo $m->type ?></p>
											</div>
										</div>
									</div>

									<div id="list_table_in<?php echo $i ?>" class="panel-collapse collapse <?php echo (!empty($m->subsidiaries)) ? 'in' : ''; ?>" role="tabpanel" aria-labelledby="heading_list_table<?php echo $i; ?>">
										<div class="panel-body">
                                            <?php foreach ($m->subsidiaries as $subs): ?>
											<div class="list_table_subs">
												<div class="col_1">
													<a href="<?php echo site_url( 'members/'.$m->intID.'/'.url_title($m->title) ).'/group-member'; ?>">
														<p class="target_m_profile_gm" data-option=""><?php echo $subs->name; ?></p>
													</a>
												</div>
												<div class="col_2">
													<p></p>
												</div>
												<div class="col_3">
													<p></p>
												</div>
												<div class="col_4">
													<p></p>
												</div>
												<div class="col_5">
													<p></p>
												</div>
											</div>
                                            <?php endforeach; ?>
										</div>
									</div>
								</div>
							</div>
                        <?php else: ?>
							<div id="list_table<?php echo $i ?>" class="accordion_heading panel-group s_list_table" role="tablist" aria-multiselectable="true">
								<div class="panel panel-default">
									<div id="heading_list_table<?php echo $i ?>" class="panel-heading" role="tab">
										<a href="<?php echo (isset($query->member_subsidiary) && $query->member_subsidiary == 'Subsidiary Only') ? site_url( 'members/'.$m->intID.'/'.url_title($m->title).'/group-member' ) : site_url( 'members/'.$m->intID.'/'.url_title($m->title) ) ; ?>" class="accordion_toggle collapsed">
											<div class="head_table_t">
												<div class="col_1">
													<p class="target_m_profile" data-option=""><?php echo str_ireplace("\\", "", stripslashes($m->title) ) ?></p>
												</div>
												<div class="col_2">
													<p><?php echo $m->country ?></p>
												</div>
												<div class="col_3">
													<p><?php echo $m->status ?></p>
												</div>
												<div class="col_4">
													<p><?php echo !empty($m->approved_date) ? date("j M Y", $m->approved_date) : ''; ?></p>
												</div>
												<div class="col_5">
													<p><?php echo $m->type ?></p>
												</div>
											</div>
										</a>
									</div>
								</div>
							</div>
						<?php endif; ?>

                        <?php $i++; } ?>
					</div>
				</div>

				<div class="text-right" style="margin-top:-8px;">
					<?php echo $pagination['links']; ?>
				</div>
			</div>
		</div>
	</div>
</section>

<?php else: ?>

<section class="pad-top-30">
	<div class="container text-center">
		<div class="contain800">
			<p>Sorry, there are no results for your search query.</p>
		</div>
	</div>
</section>

<?php endif; ?>
<?php endif; ?>

<script type="text/javascript">
/* for animate accordion gray active */
$(document).ready(function(){
    window.onpageshow = function(event) {
        if (event.persisted) {
            window.location.reload()
        }
    };

	$('div.check_subsidiary a.accordion_toggle').click(function(e){
		e.preventDefault();
		var a = $(this).parent();			
		
		if ($(a).hasClass("active")){
			a.removeClass('active');
			a.next('div.panel-collapse').removeClass('active');
		}else{
			a.addClass('active');
			a.next('div.panel-collapse').addClass('active');
		}
	});
});
</script>