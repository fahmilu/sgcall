<style>
a.editreg:hover {
	color: #000;
}
</style>
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading">EXISTING MEMBER REGISTRATION</h3>

	</div>
	<div class="container">
		<div class="row">
		<div class="col-lg-3 col-md-3 col-sm-3"></div>
		<?php echo form_open('', 'id="frmExisting"') ?>
		<div class="col-lg-6 col-md-6 col-sm-6">

<?php if(!empty($error_string)): ?>
<div class="alert alert-danger">
	<?php echo $error_string ?>
</div>
<?php elseif(!empty($success_string)): ?>
<div class="alert alert-success">
	<?php echo $success_string ?>
</div>
<?php endif;?>

<div class="div_overlay">
	<div class="div_spin">
		<p><b>Please wait&hellip;</b></p>
		<div class="clearfix"></div>
		<p class="fa fa-cog fa-spin fa-2x"></p>
	</div>
</div>


			<div class="box-contact-form organisation">

				<p class="text-primary">Please register here if you are existing member and do not have a username to access our website.</p>

				<label>Email</label>
				<div class="clearfix"></div>
				<div class="input-group">
					<?php $disabled = ( form_error('email') OR form_error('company_id') ) ? '' : 'disabled="disabled"' ?>
					<input <?php echo $disabled ?> type="text" class="form-control" value="<?php echo set_value('email') ?>" name="email" placeholder="Your email" id="email_field" aria-describedby="edit-email">
					<span class="input-group-addon" id="edit-email"><a class="editreg" title="Edit email" href="#" id="edit_email"><i class="fa fa-lg fa-edit"></i></a></span>
				</div>
				<input type="hidden" name="email_h" id="email_h" value="<?php echo set_value('email') ?>" />

				<div class="clearfix"><br /></div>

				<label>Company/Organisation</label>

				<div class="input-group" id="country-dropdown">
					<?php $disabled = form_error('company_id') ? '' : 'disabled="disabled"' ?>
					<input <?php echo $disabled ?> type="text" class="form-control" value="<?php echo htmlspecialchars_decode( set_value('company_name') ) ?>" name="company_name" id="company_name" placeholder="Type your company or organisation name" aria-describedby="edit-company">
					<div class="input-group-addon" id="edit-company"><a class="editreg" title="Edit company" href="#" id="edit_company"><i class="fa fa-lg fa-edit"></i></a></div>
				</div>
				<input type="hidden" name="company_name_h" id="company_name_h" value="<?php echo htmlspecialchars_decode( set_value('company_name') ) ?>" />
				<input type="hidden" name="company_id" id="company_id" value="<?php echo set_value('company_id') ?>" />

				<div class="clearfix"><br /></div>


				<div class="form-group" style="display: block;">
					<label>Password</label>
					<input type="password" class="form-control" value="" name="password" placeholder="Your password" />
				</div>

				<div class="form-group" style="display: block;">
					<label>Reconfirm Password</label>
					<input type="password" class="form-control" value="" name="password2" placeholder="Confirm your password" />
				</div>

				<div class="form-group text-right" style="margin-bottom:0px; display: block;">
					<input type="hidden" name="redirect_to" value="members/application" />
					<input type="submit" value="REGISTER" class="btn btn-lg btn-orange" style="border-radius:3px; margin-right:10px;">
					<a href="<?php echo site_url('members/forget'); ?>">Forgot your password?</a>
				</div>

			</div>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-3"></div>
		<?php if (isset($step3)): ?>
			<input type="hidden" name="step3" value="" />
		<?php else: ?>
			<input type="hidden" name="step2" value="" />
		<?php endif; ?>
		</form>
	</div>
</section>

<?php $this->load->view('member/old-member-static'); ?>

