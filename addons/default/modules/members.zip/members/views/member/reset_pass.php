<style>
	.border-top-gray {
		border-top: none;
	}
	.btn {
		border-radius: 0px;
		padding: 11.4px 12px;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
	.alert-success {
		border-radius: 3px;
		font-size: 14px;
		text-align: center;
		margin: 0px auto 23px;
		border: 1px solid transparent;
	}
	.alert-warning{
		border-color: tranparent;
		border-radius: 3px;
		font-size: 14px;
		width: 400px;
		text-align:center;
		margin: 0 auto;
	}
	.alert-danger{
		border:none;
		border-radius: 3px;
		font-size: 14px;
		margin: 0 auto;
	}
	.alert-success a, .alert-danger a, .alert-warning a{
		color:#000!important;
	}
</style>
<section id="contact_detail">
	<div class="container text-center">
		<h1 style="font-weight: bold; margin-top:24px; margin-bottom:25px; font-size: 25px; padding-top:3px; text-transform:uppercase;">PASSWORD RECOVERY</h1>	
	</div>
	<div class="container">
		<div class="row">

		<?php echo form_open('members/forget', array('id'=>'reset-pass')) ?>
		<div class="col-md-offset-3 col-md-6 col-sm-12 col-xs-12">

<?php if(!empty($error_string)):?>
	<div class="alert alert-danger margin-bottom-20">
		<?php echo $error_string;?>
	</div>
<?php endif;?>

<div class="box-contact-form organisation">

<?php if(!empty($success_string)): ?>

	<div class="alert alert-success">
		<?php echo $success_string ?>
	</div>

<!--
<p>Please enter the code we emailed you below and click the submit button.</p>

                            <div class="form-group">
                            	<label>Code</label>
                                <input type="text" class="form-control" name="code" maxlength="100" value="" placeholder="" />
                            </div>

				<div class="form-group text-right" style="margin-bottom:0px;">
					<input type="submit" value="SUBMIT" class="btn btn-lg btn-orange" style="border-radius:3px;">
				</div>
-->

<div class="clearfix"><br /></div>

<?php else: ?>

<p>Having trouble logging in? No problem -- you'll just have to create a new password. Please enter the email address you used, and we will send you a verification email</p>

                            <div class="form-group">
                            	<label>Email</label>
                                <input type="text" class="form-control" name="email" maxlength="100" value="<?php echo set_value('email') ?>" placeholder="Your email" />
                            </div>

				<div class="form-group text-right" style="margin-bottom:0px;">
					<input type="submit" value="SUBMIT" class="btn btn-lg btn-orange" style="border-radius:3px;">
				</div>

<div class="clearfix"><br /></div>
<p class="text-center" style="font-size:13px;">Can't remember which email address you used? <a href="mailto:membership@rspo.org">Send us an email</a></p>


<?php endif ?>
</div> <!-- end .box-contact-form -->

		</div>
		</form>
	</div>
</section>

