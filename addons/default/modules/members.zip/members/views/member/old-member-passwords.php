
				<div class="form-group" style="display: block;">
					<label>Password</label>
					<input type="password" class="form-control" value="" name="password" placeholder="Your password" />
				</div>

				<div class="form-group" style="display: block;">
					<label>Reconfirm Password</label>
					<input type="password" class="form-control" value="" name="password2" placeholder="Confirm your password" />
				</div>

