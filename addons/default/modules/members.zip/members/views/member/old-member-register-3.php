
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading">EXISTING MEMBER REGISTRATION</h3>

	</div>
	<div class="container">
		<div class="row">
		<div class="col-lg-3 col-md-3 col-sm-3"></div>
		<?php echo form_open('', 'id="frmExisting"') ?>
		<div class="col-lg-6 col-md-6 col-sm-6">

<?php if(!empty($error_string)): ?>
<div class="alert alert-danger">
	<?php echo $error_string ?>
</div>
<?php elseif(!empty($success_string)): ?>
<div class="alert alert-success">
	<?php echo $success_string ?>
</div>
<?php endif;?>

<div class="div_overlay">
	<div class="div_spin">
		<p><b>Please wait&hellip;</b></p>
		<div class="clearfix"></div>
		<p class="fa fa-cog fa-spin fa-2x"></p>
	</div>
</div>


			<div class="box-contact-form organisation">

				<h2>old-member-register-3.php</h2>

				<p class="text-primary">Please register here if you are existing member and do not have a username to access our website.</p>

				<div class="form-group" style="display: block;">
					<label>Email</label>
					<input type="text" class="form-control" value="<?php echo set_value('email') ?>" name="email" placeholder="Your email" />
				</div>
				
				<div class="form-group" id="country-dropdown" style="display: block;">
					<label>Company/Organisation</label>
					<input value="<?php echo htmlspecialchars_decode( set_value('company_name') ) ?>" id="company_name" type="text" class="form-control" name="company_name" placeholder="Type your company or organisation name" />
					<input type="hidden" name="company_id" id="company_id" value="<?php echo set_value('company_id') ?>" />
				</div>

				<div class="form-group" style="display: block;">
					<label>Password</label>
					<input type="password" class="form-control" value="" name="password" placeholder="Your password" />
				</div>

				<div class="form-group" style="display: block;">
					<label>Reconfirm Password</label>
					<input type="password" class="form-control" value="" name="password2" placeholder="Confirm your password" />
				</div>

				<div class="form-group text-right" style="margin-bottom:0px; display: block;">
					<input type="hidden" name="redirect_to" value="members/application" />
					<input type="submit" value="REGISTER" class="btn btn-lg btn-orange" style="border-radius:3px; margin-right:10px;">
					<a href="<?php echo site_url('members/forget'); ?>">Forgot your password?</a>
				</div>

			</div>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-3"></div>
		<?php if (isset($step3)): ?>
			<input type="hidden" name="step3" value="" />
		<?php else: ?>
			<input type="hidden" name="step2" value="" />
		<?php endif; ?>
		</form>
	</div>
</section>

<?php $this->load->view('member/old-member-static'); ?>
