<?php if (!empty($activated)): ?>
<style>
	.btn {
		border-radius: 0px;
		padding: 11.4px 12px;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
</style>
<section id="contact_detail">
	<div class="container text-center">
		<h3 class="subsection-heading">ACCOUNT SUCCESSFULLY ACTIVATED</h3>	
	</div>
	
	<div class="container">
		<div class="row">
		<?php echo form_open('members/login/members/apply', 'id="activate-user"') ?>
		<div class="col-md-offset-3 col-md-6 col-sm-12 col-xs-12">
			<div class="box-contact-form organisation">

				<div class="form-group">
					<label>Email</label>
					<input type="text" class="form-control" name="email" placeholder="Your email" />
				</div>

				<div class="form-group">
					<label>Password</label>
					<input type="password" class="form-control" name="password" placeholder="Password" />
				</div>

				<div class="form-group text-right" style="margin-bottom:0px;">
					<input type="submit" value="LOGIN" class="btn btn-lg btn-orange" style="border-radius:3px;">
				</div>

			</div>
		</div>
		</div>
		</form>
	</div>
</section>

<?php else: ?>

<style>
	.btn {
		border-radius: 0px;
		padding: 11.4px 12px;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
</style>
<section id="contact_detail">
	<div class="container text-center">
		<h1 style="font-weight: bold; margin-top:24px; margin-bottom:25px; font-size: 25px; padding-top:3px; text-transform:uppercase;">ACCOUNT ACTIVATION</h1>	
	</div>
	
	<div class="container">
		<div class="row">

		<?php echo form_open('members/activate', 'id="activate-user"') ?>
		<div class="col-md-offset-3 col-md-6 col-sm-12 col-xs-12">

		<?php if(!empty($error_string)): ?>
		<div class="alert alert-danger margin-bottom-20">
			<?php echo $error_string ?>
		</div>
		<?php endif;?>

		{{ session:messages success="alert alert-success" notice="alert alert-info" error="alert alert-danger" }}

			<div class="box-contact-form organisation">
					<p>Activate your account by entering your email address and the verification code you received.</p>

                            <div class="form-group">
                            	<label>Email</label>
                                <input type="text" class="form-control" name="email" placeholder="Your email" />
                            </div>

                            <div class="form-group">
                            	<label>Verification code</label>
                                <input type="text" class="form-control" name="activation_code" placeholder="Verification code" />
                            </div>

				<div class="form-group text-right" style="margin-bottom:0px;">
					<a href="<?php echo site_url('members/resend') ?>" class="btn btn-lg btn-orange" style="border-radius:3px;">Resend Code</a>
					<input type="submit" value="ACTIVATE" class="btn btn-lg btn-orange" style="border-radius:3px;">
				</div>

			</div>
		</div>
		</form>
	</div>
</section>
<?php endif; ?>