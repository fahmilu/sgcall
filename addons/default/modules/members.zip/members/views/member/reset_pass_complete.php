<style>
	.btn {
		border-radius: 0px;
		padding: 11.4px 12px;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
</style>
<section id="contact_detail">
	<div class="container text-center">
		<h1 style="font-weight: bold; margin-top:24px; margin-bottom:25px; font-size: 25px; padding-top:3px; text-transform:uppercase;"><?php echo strtoupper(lang('user:password_reset_title'))?></h1>		
	</div>
	<div class="container">
		<div class="row">

		<div class="alert alert-success contain300 margin-bottom-20">
			<?php echo lang('user:password_reset_message') ?>
		</div>
			
		<?php echo form_open('members/login', 'id="member-login"') ?>
			<div class="contain300">
				<div class="box-contact-form organisation">

					<p>Please login by entering your email and the new password at the prompt below:</p>

					<div class="form-group">
						<label>Email</label>
						<input type="text" class="form-control" name="email" placeholder="Your email" />
					</div>

					<div class="form-group">
						<label>Password</label>
						<input type="password" class="form-control" name="password" placeholder="Password" />
					</div>

				<div class="form-group text-right" style="margin-bottom:0px;">
					<input type="hidden" name="redirect_to" value="/members/application" />
					<input type="submit" value="LOGIN" class="btn btn-lg btn-orange" style="border-radius:3px;">
				</div>
				</div>
			</div>
		</form>
		</div>
	</div>
</section>