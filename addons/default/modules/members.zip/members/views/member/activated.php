<style>
	.btn {
		border-radius: 0px;
		padding: 11.4px 12px;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
	.alert-success{
		width:100%;
	}
</style>
<section id="contact_detail">
	<div class="container text-center">
		<h1 style="font-weight: bold; margin-top:24px; margin-bottom:25px; font-size: 25px; padding-top:3px; text-transform:uppercase;">ACCOUNT SUCCESSFULLY ACTIVATED</h1>	
	</div>
	<div class="container">
		<div class="row">
		<div class="contain300">
			<div class="box-contact-form organisation">
			<div class="row step0 registerarea" style="" id="ulogin">
				<div style="display:none;" id="loginAlert" style="margin-top:30px;"></div>
				
				<form method="post" name="memLogin" id="memLogin2" action="{{url:site}}members/login" accept-charset="utf-8">
					
					<p>Your account was activated successfully. To continue, please enter your email and password below:</p>
					
					<div class="form-group">
						<label>Email</label>
						<input type="text" placeholder="Email address" name="email" id="loginEmail2" class="form-control input-sm height43"/>
					</div>
					
					<div class="form-group">
						<label>Password</label>
						<input type="password" placeholder="Password" class="form-control input-sm height43" name="password" id="loginPass2" />
					</div>
					<div class="form-group text-right" style="margin-bottom:0px;">
						<button type="submit" class="btn btn-primary" id="btnLogin" style="border-radius:3px;">LOG IN</button>
					</div>
				</form>
			</div>
			</div>
		</div>
		</div>
	</div>
</section>
