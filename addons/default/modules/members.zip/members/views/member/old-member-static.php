<style>
	.btn {
		border-radius: 0px;
		padding: 11.4px 12px;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
	#company_name {
		width: 100%;
	}
	.ui-autocomplete {
		position: absolute;
		z-index: 9999;
		padding-left: 0px;
		padding-right: 0px;
		max-height: 190px;
		width: 100%;
		overflow-y: auto;
		/* prevent horizontal scrollbar */
		overflow-x: hidden;
		border: 1px solid #ccc;
		background: #fff;
	}
	.ui-autocomplete ul {
		margin-left: 0;
		padding: 1px;
	}
	.ui-autocomplete li {
		margin-left: 0;
		padding: 2px 5px;
		border-bottom: 1px solid #dedeee;
		list-style-type: none;
		cursor: pointer;
	}
	.ui-autocomplete li:hover {
		background: #ed7b1c;
		color: white;
	}
	.div_overlay {
		display: none;
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		margin: 0 auto;
		text-align: center;
		vertical-align: middle;
		background-color: rgba(255,255,255,0.75);
		z-index: 9999;
	}
	.div_spin {
		position: absolute;
		top: 40%;
		left: 0;
		right: 0;
		font-size: 20px;
		color: #ed7b1c;
	}
	.green {
		color: green;
	}
	.red {
		color: red;
	}
	.ui-autocomplete-loading {
    	background: white url("{{ theme:image_path file="loading.gif" }}") right center no-repeat;
	}
	#formfeedback {
		display: none;
		z-index: 1000;
		/* margin: 0 -30px -35px -30px; */
		padding: 0;
		vertical-align: middle;
		position: absolute;
		top: 0;
		left: 0;
		bottom: 0;
		right: 0;
		background: #F2F2F2;
	}
	#form_element .input-group input:focus {
		box-shadow: none;
	}
	#form_element .text-danger p {
		font-size: 0.9em;
	}
	#formfeedback .alert-danger {
		z-index: 999;
/*
		margin: 0 -30px -35px -30px;
		position: absolute;
		vertical-align: middle;
		top: 0;
		left: 0;
		bottom: 0;
		right: 0;
*/
	}
	.input-group.has-error .input-group-addon {
		border-color: #a94442;
	}
	.bordered-tb {
		border-top: 2px solid #f2f2f2;
		border-bottom: 2px solid #f2f2f2;
		padding: 30px;
		margin-right: 20px;
		line-height: 1.4;
	}
	#email_field_error{
		text-transform: lowercase;
	}
	#email_field_error p::first-letter{
		text-transform: uppercase;
	}
</style>

<script>
$(document).ready(function(){

	$('input[class=form-control]').on('blur', function(){
		if ($(this).val())
		{
			$(this).parent().removeClass('has-error');
			//$(this).parent().next('.text-danger').fadeTo('fast', 0);
			//$(this).parent().next('.text-danger').css('display', 'none');
		}
	});

	$('a.editreg').click(function(e){
		e.preventDefault();
		$(this).parent().prev().prop('disabled', false).focus();
		$("#company_name").autocomplete({
			minLength: 2,
			appendTo: '#country-dropdown',
		    source: "<?php echo site_url('members/pickactive') ?>",
		    select: function (event, ui) {
		    	$('#company_id').val(ui.item.id);
		    	$('#company_name').val(ui.item.value);
			},
			search: function() {
				$('#company_id').val('');
			}
		});
	});

	var m = '<?php echo set_value('member') ?>';
	if (m)
		$("#company_name").val(m);

	$("#company_name").autocomplete({
		minLength: 2,
		appendTo: '#country-dropdown',
	    source: "<?php echo site_url('members/pickactive') ?>",
	    select: function (event, ui) {
	    	$('#company_id').val(ui.item.id);
	    	$('#company_name').val(ui.item.value);
	    	process_register();
		},
		search: function() {
			var e = $('#email_field').val();
	    	if (e=='')
	    	{
				$('#formfeedback').fadeOut(function(){
					$(this).css('margin-bottom', '-35px').html('<div class="alert alert-danger">Please enter your email address before selecting the company/organisation</div>').slideDown();
					
					//$(this).html('<div class="alert alert-danger">Please enter your email address before selecting the company/organisation</div>').slideDown();
				});
		    	$('#email_field').focus();
		    	$('#company_id, #company_name').val('');
	    		return false;
	    	}
	    	$('#company_id').val('');
		}
	});

	$("#company_name").on('blur', function(){
		if ($("#company_name").val()=='')
		{
			$('#company_id').val('');
			$('#company_error').css('display', 'block');
			
			$('#formfeedback').css('position', 'unset').css('display', 'none');
		}else{
			$('#company_error').css('display', 'none');
		}
	});

	$("#email_field").on('blur', function(){
		
		if ($("#email_field").val()=='')
		{
			$('.email_field_error').css('display', 'block');
		}else{
			$('.email_field_error').css('display', 'none');
		}	
		
		if ($("#company_id").val()!='' && $("#company_name").val()!='')
		{
			process_register();
		}
		
	});

	$("#frmExisting").on('submit', function(e){
		$('.alert').fadeTo('fast', 0);
		$('.div_overlay').fadeIn('fast');
	});

	$('a.cbox').colorbox();

	function process_register()
	{
				var post_data = $('#frmExisting').serialize();
				$.ajax({
					url: "<?php echo site_url('members/companymatch'); ?>",
					method: "POST",
					data: post_data,
					beforeSend: function(){
						$('#edit-company').html('<i class="fa fa-lg fa-fw fa-cog fa-spin"></i>').fadeIn();
						$('#formfeedback').fadeOut();
					},
					type: "json",
					success: function(obj){
						if (obj.status == 'ok')
						{
							$('#company_error').prev('.has-error').removeClass('has-error');
							$('#company_error').fadeTo('fast', 0); //fadeOut();

							$('.pwdfield').prop('disabled', false);
							$('#edit-company').html('<i class="fa fa-lg fa-fw fa-check green"></i>').fadeIn();
							$('#formfeedback').fadeOut(function(){
								$(this).css('position', 'relative').css('margin-bottom', '30px').html('<div class="alert alert-success">'+obj.msg+'</div>').slideDown();
							});
						}
						else
						{
							$('#edit-company').html('<i class="fa fa-lg fa-fw fa-exclamation red"></i>').fadeIn();
							
							var $email = $("#email_field").val();
							var cekvalid_mail = /[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}/igm;
							
							
							if($email == ''){
								$('.email_field_error').css('display', 'none');
								$('#company_error').css('display', 'none');
								
								$('#formfeedback').fadeOut(function(){
									$(this).css('position', 'absolute').css('margin-bottom', '-35px').html("<div class='alert alert-danger'> The Email address field is required. </div>").slideDown();
								});
								
								return false;
							}
							else if ($email == '' || !cekvalid_mail.test($email))
							{
								$('.email_field_error').css('display', 'none');
								$('#company_error').css('display', 'none');
								
								$('#formfeedback').fadeOut(function(){
									$(this).css('position', 'absolute').css('margin-bottom', '-35px').html("<div class='alert alert-danger'> The Email address field must contain a valid email address. </div>").slideDown();
								});
								
								return false;
							} else{
							
								$('#company_error').css('display', 'none');
								$('.email_field_error').css('display', 'none');
								$('#formfeedback').fadeOut(function(){
									//$(this).css('position', 'absolute').css('margin-bottom', '-35px').html('<div class="alert alert-danger">'+obj.msg+'</div>').slideDown();

									$(this).css('position', 'absolute').css('margin-bottom', '-35px').html("<div class='alert alert-danger'> We're sorry, we could not find a match for that email address and the company/organization name you have entered. Please try a different combination, or contact the <a href='mailto:membership@rspo.org' style='color:white; text-decoration:underline;'>RSPO Membership Department</a> for assistance. </div>").slideDown();
								});
							
							}
							
						}
						//$('#form_element').append(obj);
						//$('.div_overlay').fadeOut('fast');
					}
				});
}

});
</script>