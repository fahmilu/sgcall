<h1>OTOKOWOK</h1>
<!--
<p style="font-size: 14px; line-height: 1.5; color: rgb(67, 55, 44);">​​Thank you - you have successfully registered to begin editing your RSPO membership profile.</p>

<p style="font-size: 14px; line-height: 1.5; color: rgb(67, 55, 44);">But before you do, please activate your account first by clicking here:&nbsp;<a href="{{ url:site }}members/activate/{{ user:id }}/{{ activation_code }}">{{ url:site }}members/activate/{{ user:id }}/{{ activation_code }}</a></p>

<p style="font-size: 14px; line-height: 1.5; color: rgb(67, 55, 44);">In case your email program does not recognize the above link, please direct your browser to the following URL and enter your email and the activation code:</p>

<p style="font-size: 14px; line-height: 1.5; color: rgb(67, 55, 44);"><a href="{{ url:site }}members/activate">{{ url:site }}members/activate</a></p>

<p style="font-size: 14px; line-height: 1.5; color: rgb(67, 55, 44);"><span style="font-weight: 700;">Email:</span>&nbsp;{{ user:email }}<br />
<span style="font-weight: 700;">Activation Code:</span>&nbsp;{{ activation_code }}</p>

<p style="font-size: 14px; line-height: 1.5; color: rgb(67, 55, 44);">You can edit your membership profile, upload your log at any time by logging in with the same email address at: http://www.rspo.org/members/profile.</p>

<p style="font-size: 14px; line-height: 1.5; color: rgb(67, 55, 44);">For any enquiries, please email us at membership@rspo.org.</p>

<p style="font-size: 14px; line-height: 1.5; color: rgb(67, 55, 44);">- RSPO Membership team</p>

<p style="font-size: 14px; line-height: 1.5; color: rgb(67, 55, 44);"><small style="font-size: 12px;">This email was sent by the Roundtable on Sustainable Palm Oil (RSPO), Unit A-37-1, Menara UOA Bangsar, No.5 Jalan Bangsar Utama 1,59000 Kuala Lumpur, Malaysia.</small></p>
-->