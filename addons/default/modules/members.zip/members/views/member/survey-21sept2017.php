<style>
    .member-selected {
        color: #ee7813 !important;
    }
	.notes-div {
		margin-top:5px;
        margin-bottom:0px;
		padding-left: 30px;
		padding-right: 30px;
    }
	
	/* responsive only this page */
	@media only screen and (max-width: 1099px) {
		#colorbox, #cboxOverlay{
			display:none !important;
		}
	}
</style>
<section class="contain800 member_survey_notify_screen_size" style="display:none;">
	<p>The RSPO membership database update is not supported for this screen size. If you are seeing this message, please open the form on devices with screens larger than 1280 pixels (desktops, laptops or larger tablets).</p>
</section>

<?php
$attributes = array('id' => 'myForm');
echo form_open('members/validate_submit_survey', $attributes);
?>
<input type="hidden" name="intID" value="<?php echo $member->intID ?>" />
<section class="member_survey">
	<div class="container-1080">
		<div class="left_container_survey">
			<div class="row">
				<?php if ($member->logo) { ?>
				<div class="logo-members text-center" alt="">
                    <?php
                        if (strstr($member->logo, '/sites/default/files/'))
                        {
                            echo '<img class="img-responsive" src="http://www.rspo.org'.$member->logo.'" />'.PHP_EOL;
                        }
                        elseif(strstr($member->logo, 'ma/logo/'))
                        {
                            echo '<img class="img-responsive" src="http://www.rspo.org/'.$member->logo.'" />'.PHP_EOL;
                        }
                        else
                        {
                            if ( file_exists(UPLOAD_PATH.'/memberlogos/'.thumbnail($member->logo)) )
                                echo '<img class="img-responsive" src="'.site_url(UPLOAD_PATH).'/memberlogos/'.thumbnail($member->logo).'" />'.PHP_EOL;
                            else
                                echo '<img style="width:150px;" src="'.site_url(UPLOAD_PATH).'/memberlogos/'.($member->logo).'" />'.PHP_EOL;
                        }
                    ?>
				</div>
				<?php } ?>
				<div class="descr-profile">
					<div class="i_title">
						<h2><?php echo $member->title ?></h2>
                        <?php if (count($member_list) > 1) { ?>
                            <p class="member_profile">You are currently logged in<br/>as <b><?php echo ucfirst($this->current_user->first_name).' '.ucfirst($this->current_user->last_name); ?></b></p>
                        <?php } ?>
					</div>
                    <?php if (count($member_list) > 1) { ?>
                        <a class="btn btn-lg btn-orange list_of_organizations margin-bottom-22" onclick="changeOrganizationsColorboxConfirm();" style="height:auto;">Change<br/>membership profile</a>
                    <?php } ?>
					<div class="info1">
						<span>Membership No.</span> 
						<p class="member_profile"><?php echo $member->member_num ?></p>
					</div>
					<div class="info2">
						<span>Category</span> 
						<p class="member_profile"><?php echo $member->type ?></p>
					</div>
					<div class="info3">
						<span>Sector</span>
						<p class="member_profile"><?php echo $member->category ?></p>
					</div>
				</div>
			</div>
		</div>
	
		<div class="right_container_survey">
			<div class="row title_c_right">
				<h1>MyRSPO Membership Database Update</h1>
				<p>Greetings! As part of RSPO’s periodic membership database update, we require members to participate in the following 3-step survey. You will be asked to confirm or update your organization and contact details, and disclose your group membership.</p>
				<p>You can jump between steps, but you have to complete the entire survey before you can proceed to ACOP 2016 or your MyRSPO profile page. We will automatically save your work whenever you move between steps.</p>
				<p>Thank you in advance for your participation.</p>
			</div>
			
		<?php if ($member->category == 'Environmental or Nature Conservation Organisations (Non Governmental Organisations)' || $member->category == 'Social or Development Organisations (Non Governmental Organisations)') { ?>
				<div id="line-steps" class="row tml-contact m_parent id-line-2 text-center">
		<?php } else { ?>
			
			<?php if ($is_parent){ ?>
			<div id="line-steps" class="row tml-contact m_parent id-line-2 text-center">
			<?php } else { ?>
			<div id="line-steps" class="row tml-contact id-line text-center">
			<?php } ?>
			
		<?php } ?>
		
				<div class="nav-tabs" id="myTab">
				
			<?php if ($member->category == 'Environmental or Nature Conservation Organisations (Non Governmental Organisations)' || $member->category == 'Social or Development Organisations (Non Governmental Organisations)') { ?>
				
					<div class="col-lg-2 col-md-2 col-sm-2 first_steps">
						<a href="#1" id="step1" class="active" disabled="disabled">
							<div class="bullets-zero"></div>
							<label class="membershipstep">Preliminary<br/>questions<br/>(not applicable)</label>
						</a>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-2">
						<a href="#2" id="step2" class="active">
							<div class="bullets-zero"></div>
							<label class="membershipstep">Organization<br/>details</label>
						</a>
					</div>
					
			<?php } else { ?>
				
				<?php if ($is_parent){ ?>
					<div class="col-lg-2 col-md-2 col-sm-2 first_steps">
						<a href="#1" id="step1" class="active" disabled="disabled">
							<div class="bullets-zero"></div>
							<label class="membershipstep">Preliminary<br/>questions<br/>(not applicable)</label>
						</a>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-2">
						<a href="#2" id="step2" class="active">
							<div class="bullets-zero"></div>
							<label class="membershipstep">Organization<br/>details</label>
						</a>
					</div>
				<?php } else { ?>	
					<div class="col-lg-2 col-md-2 col-sm-2 first_steps">
						<a href="#1" id="step1" class="active">
							<div class="bullets-zero"></div>
							<label class="membershipstep">Preliminary<br/>questions</label>
						</a>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-2">
						<a href="#2" id="step2">
							<div class="bullets-zero"></div>
							<label class="membershipstep">Organization<br/>details</label>
						</a>
					</div>
				<?php } ?>
				
			<?php } ?>
			
					<div class="col-lg-2 col-md-2 col-sm-2">
						<a href="#3" id="step3">
							<div class="bullets-zero"></div>
							<label class="membershipstep">Contact<br/>details</label>
						</a>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-2 last_steps">
						<a href="#4" id="step4">
							<div class="bullets-zero"></div>
							<label class="membershipstep">Group<br/>membership</label>
						</a>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-2 last_steps">
						<a href="#5" id="step5">
							<div class="bullets-zero"></div>
							<label class="membershipstep">Submit</label>
						</a>
					</div>
				</div>
			</div>
			
			<div class="tab-content responsive">
			<?php if ($member->category == 'Environmental or Nature Conservation Organisations (Non Governmental Organisations)' || $member->category == 'Social or Development Organisations (Non Governmental Organisations)') { ?>
				
				<div class="tab-pane" id="1">
			
			<?php } else { ?>
			
				<?php if ($is_parent){ ?>
				<div class="tab-pane" id="1">
				<?php } else { ?>
				<div class="tab-pane active" id="1">
				<?php } ?>
				
			<?php } ?>

					<section class="border-top-gray">
						<div class="r_container_full">
							<h2 class="subsection-heading">Preliminary questions</h2>
							<p>Please first answer the questions below to proceed with next steps. Mouseover the highlighted words to learn more about the terminology.</p>
							
                                <div class="bg-f5f5f5 c_form f_form_step before_we_start">
									<!-- Q1 -->
                                    <label class="t_radio">Is your organization 
									<a class="highlight_tooltip control">controlled
										<div class="tooltip_am">
											<div class="content_more">
												<p>Control means:</p>
												<ul>
													<li>having management control which includes the ability to direct, instruct or manage business activity or administration of an Entity whether by having the ability to influence the board, management of an Entity through shareholding, stock ownership or by contractual or operational arrangement.</li>
													<li>in accordance with whose directions, instructions or wishes an Entity is accustomed or is under an obligation, whether formal or informal, to act in relation to a Parent’s direction, instructions or wishes.</li>
												</ul>
											</div>
										</div>
									</a>									
									by a 
									<a class="highlight_tooltip parent">parent
										<div class="tooltip_am">
											<div class="content">
												<p>Entity which has Control over other Entities within its Group.</p>
											</div>
										</div>
									</a>
									?*</label>
                                    <div class="radio_custom_by_am margin-top-5">
                                        <div class="yn_left">
                                            <input id="is_your_controller_by_a_parent-y" name="is_your_controller_by_a_parent" value="yes" type="radio" onclick="org_controlled_by_parent(this.value); org_controlled_by_parent_Uncheck();" <?php echo (isset($survey_questions['is_your_controller_by_a_parent']) && $survey_questions['is_your_controller_by_a_parent'] == 'yes') ? 'checked="checked"' : '';  ?>>
											<label for="is_your_controller_by_a_parent-y"><span><span></span></span>Yes</label>
                                        </div>
                                        <div class="yn_right">
                                            <input id="is_your_controller_by_a_parent-n" name="is_your_controller_by_a_parent" value="no" type="radio" onclick="org_controlled_by_parent(this.value);  org_controlled_by_parent_Uncheck();" <?php echo (isset($survey_questions['is_your_controller_by_a_parent']) && $survey_questions['is_your_controller_by_a_parent'] == 'no') ? 'checked="checked"' : '';  ?>>
											<label for="is_your_controller_by_a_parent-n"><span><span></span></span>No</label>
                                        </div>
                                    </div>

									<!-- Q1 answer yes -->
									<div class="before_we_start_yes">
										<label class="t_radio margin-top-15">Is your parent a  
										<a class="highlight_tooltip related_entities">member
											<div class="tooltip_am">
												<div class="content">
													<p>An RSPO Member shall be as described in Article 4 of the RSPO Statutes and composed of the following category of members:</p>
													<ul class="disc">
														<li>Ordinary Members</li>
														<li>Affiliate Members</li>
														<li>Supply Chain Associates</li>
														<li>Honorary Members</li>
													</ul>
												</div>
											</div>
										</a>
										of the RSPO?*</label>
										<div class="radio_custom_by_am margin-top-5">
											<div class="yn_left">
												<input id="your_parent_member_of_rspo-y" name="your_parent_member_of_rspo" value="yes" type="radio" class="event_before_we_start_yes" onclick="event_before_we_start_yes(this.value); event_before_we_start_yes_Uncheck();" <?php echo (isset($survey_questions['your_parent_member_of_rspo']) && $survey_questions['your_parent_member_of_rspo'] == 'yes') ? 'checked="checked"' : '';  ?>>
												<label for="your_parent_member_of_rspo-y"><span><span></span></span>Yes</label>
											</div>
											<div class="yn_right">
												<input id="your_parent_member_of_rspo-n" name="your_parent_member_of_rspo" value="no" type="radio" class="event_before_we_start_yes" onclick="event_before_we_start_yes(this.value); event_before_we_start_yes_Uncheck();" <?php echo (isset($survey_questions['your_parent_member_of_rspo']) && $survey_questions['your_parent_member_of_rspo'] == 'no') ? 'checked="checked"' : '';  ?>>
												<label for="your_parent_member_of_rspo-n"><span><span></span></span>No</label>
											</div>
										</div>
                                    </div>
									
									<!-- Q1 answer yes yes please show message and form -->
									<div class="before_we_start_yes_yes">
										<label class="t_radio margin-top-15">Your parent is deemed to be in compliance with RSPO new 
										<a class="highlight_tooltip group_membership" style="color:#252525;">group membership
											<div class="tooltip_am">
												<div class="content">
													<p class="no-margin">The compulsory requirement for registration of corporate groups under one RSPO membership.</p>
												</div>
											</div>
										</a>
										rule, please provide your parent company's contact detail for our membership team to assist you with the group membership process (optional).</label>
										
										<label>Parent name*</label>
										<div class="input-group" style="max-width:585px;">
											<input id="deemed_complience_rspo_new_gm_parent_name" autocomplete="off" class="form-control" value="<?php echo (isset($survey_questions['deemed_complience_rspo_new_gm_parent_name'])) ? $survey_questions['deemed_complience_rspo_new_gm_parent_name'] : ''; ?>" name="deemed_complience_rspo_new_gm_parent_name" type="text"  style="max-width:585px;">
                                            <div id="err_deemed_complience_rspo_new_gm_parent_name" class="alert alert-danger" style="display:none"></div>
										</div>
										
										<label>Parent RSPO membership number*</label>
										<div class="input-group">
											<!-- <input id="deemed_complience_rspo_new_gm_parent_rspo_membership_number" autocomplete="off" class="form-control" value="<?php echo (isset($survey_questions['deemed_complience_rspo_new_gm_parent_rspo_membership_number'])) ? $survey_questions['deemed_complience_rspo_new_gm_parent_rspo_membership_number'] : ''; ?>" name="deemed_complience_rspo_new_gm_parent_rspo_membership_number" type="text" style="max-width:585px;"> -->
                                            <?php
                                            $nums = ['0','0000','00','000','00'];
                                            if (!empty($survey_questions['deemed_complience_rspo_new_gm_parent_rspo_membership_number'])) {
                                                $strs = explode('-',$survey_questions['deemed_complience_rspo_new_gm_parent_rspo_membership_number']);
                                                for ($j = 0; $j < 5; $j++) {
                                                    if (isset($strs[$j])) {
                                                        $nums[$j] = $strs[$j];
                                                    }
                                                }

                                            } ?>
											<div class="input-group membership_number">
                                                <input autocomplete="off" class="form-control membership_number1" value="<?php echo $nums[0] ?>"
                                                       id="num1a"
                                                       onkeyup="implodeNumberQuestion('a');"
                                                       name="num1a"
                                                       placeholder="" maxlength="1" type="text">
                                                <span>−</span>
                                                <input autocomplete="off" class="form-control membership_number2" value="<?php echo $nums[1] ?>"
                                                       id="num2a"
                                                       onkeyup="implodeNumberQuestion('a');"
                                                       name="num2a"
                                                       placeholder="" maxlength="4" type="text">
                                                <span>−</span>
                                                <input autocomplete="off" class="form-control membership_number3" value="<?php echo $nums[2] ?>"
                                                       id="num3a"
                                                       onkeyup="implodeNumberQuestion('a');"
                                                       name="num3a"
                                                       placeholder="" maxlength="2" type="text">
                                                <span>−</span>
                                                <input autocomplete="off" class="form-control membership_number4" value="<?php echo $nums[3] ?>"
                                                       id="num4a"
                                                       onkeyup="implodeNumberQuestion('a');"
                                                       name="num4a"
                                                       placeholder="" maxlength="3" type="text">
                                                <span>−</span>
                                                <input autocomplete="off" class="form-control membership_number5" value="<?php echo $nums[4] ?>"
                                                       id="num5a"
                                                       onkeyup="implodeNumberQuestion('a');"
                                                       name="num5a"
                                                       placeholder="" maxlength="2" type="text">

												<input name="deemed_complience_rspo_new_gm_parent_rspo_membership_number"
													id="deemed_complience_rspo_new_gm_parent_rspo_membership_number"
													value="" type="hidden">
													
												<div id="err_deemed_complience_rspo_new_gm_parent_rspo_membership_number"  
												class="alert alert-danger" style="display:none"></div>
											</div>
										</div>
									</div>
									
									<!-- Q1 answer yes no -->
									<div class="before_we_start_yes_no">
										<label class="t_radio margin-top-15">Is your parent involved in activities related to palm oil supply chain?*</label>
										<div class="radio_custom_by_am margin-top-5">
											<div class="yn_left">
												<input id="is_your_parent_involved_activi_related_po_sc-y" name="is_your_parent_involved_activi_related_po_sc" value="yes" type="radio" class="event_before_we_start_yes_no" onclick="event_before_we_start_yes_no(this.value);" <?php echo (isset($survey_questions['is_your_parent_involved_activi_related_po_sc']) && $survey_questions['is_your_parent_involved_activi_related_po_sc'] == 'yes') ? 'checked="checked"' : '';  ?>>
												<label for="is_your_parent_involved_activi_related_po_sc-y"><span><span></span></span>Yes</label>
											</div>
											<div class="yn_right">
												<input id="is_your_parent_involved_activi_related_po_sc-n" name="is_your_parent_involved_activi_related_po_sc" value="no" type="radio" class="event_before_we_start_yes_no" onclick="event_before_we_start_yes_no(this.value);" <?php echo (isset($survey_questions['is_your_parent_involved_activi_related_po_sc']) && $survey_questions['is_your_parent_involved_activi_related_po_sc'] == 'no') ? 'checked="checked"' : '';  ?>>
												<label for="is_your_parent_involved_activi_related_po_sc-n"><span><span></span></span>No</label>
											</div>
										</div>
									</div>
									
									<!-- Q1 answer yes no yes please show message and form -->
									<div class="before_we_start_yes_no_yes">
										<label class="t_radio margin-top-15">Your parent is deemed to be in compliance with RSPO new group membership rule. We will contact your parent company separately for group member details. Please proceed to the next step.</label>
										
										<label>Parent name*</label>
										<div class="input-group" style="max-width:585px;">
											<input id="deemed_complience_parent_name" autocomplete="off" class="form-control" value="<?php echo (isset($survey_questions['deemed_complience_parent_name'])) ? $survey_questions['deemed_complience_parent_name'] : ''; ?>" name="deemed_complience_parent_name" placeholder="" onblur="" type="text" style="max-width:585px;">
                                            <div id="err_deemed_complience_parent_name" class="alert alert-danger" style="display:none"></div>
										</div>
										
										<label>Contact person name*</label>
										<div class="input-group" style="max-width:585px;">
											<input id="deemed_complience_rspo_contact_name" autocomplete="off" class="form-control" value="<?php echo (isset($survey_questions['deemed_complience_rspo_contact_name'])) ? $survey_questions['deemed_complience_rspo_contact_name'] : ''; ?>" name="deemed_complience_rspo_contact_name" placeholder="" onblur="" type="text" style="max-width:585px;">
                                            <div id="err_deemed_complience_rspo_contact_name" class="alert alert-danger" style="display:none"></div>
										</div>
										
										<label>Email*</label>
										<div class="input-group" style="max-width:585px;">
											<input id="deemed_complience_rspo_email" autocomplete="off" class="form-control" value="<?php echo (isset($survey_questions['deemed_complience_rspo_email'])) ? $survey_questions['deemed_complience_rspo_email'] : ''; ?>" name="deemed_complience_rspo_email" placeholder="" onblur="" type="text" style="max-width:585px;">
                                            <div id="err_deemed_complience_rspo_email" class="alert alert-danger" style="display:none"></div>
										</div>
										
										<label class="add-pad-am">Phone number*</label>
										<div class="input-group no-margin" style="max-width:585px;">
											<div class="input-group-addon no-padding">
												<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo (isset($survey_questions['deemed_complience_rspo_phone'])) ? $survey_questions['deemed_complience_rspo_phone'] : ''; ?>" name="deemed_complience_rspo_phone" id="deemed_complience_rspo_phone" style="max-width:585px;">
											<div id="err_deemed_complience_rspo_phone" class="alert alert-danger" style="display:none"></div>
											</div>
										</div>
										
										<label class="t_radio margin-top-15">Comment</label>
										<div class="input-group" style="max-width:585px;">
											<textarea autocomplete="off" type="text" class="form-control" name="deemed_complience_rspo_comment" id="deemed_complience_rspo_comment" style="max-width:585px; height:100px;"><?php echo (isset($survey_questions['deemed_complience_rspo_comment'])) ? $survey_questions['deemed_complience_rspo_comment'] : ''; ?></textarea>
										</div>
									</div>		
<!-- #Q1 answer yes,end -->				
<!-- #Q1 answer no -->							
									<!-- Q1 answer no -->
									<div class="before_we_start_no">
										<label class="t_radio margin-top-15">Is your organization a parent of a group of 
										<a class="highlight_tooltip entities">entities
											<div class="tooltip_am">
												<div class="content">
													<p>A body corporate or organisation, which is incorporated or registered under the laws of the country, in which the Entity is incorporated or registered.</p>
												</div>
											</div>
										</a>
										?*</label>
										<div class="radio_custom_by_am margin-top-5">
											<div class="yn_left">
												<input id="org_parent_gr_enti-y" name="org_parent_gr_enti" value="yes" type="radio" class="org_parent_gr_enti" onclick="parent_group_entities(this.value); parent_group_entities_Uncheck();" <?php echo (isset($survey_questions['org_parent_gr_enti']) && $survey_questions['org_parent_gr_enti'] == 'yes') ? 'checked="checked"' : '';  ?>>
												<label for="org_parent_gr_enti-y"><span><span></span></span>Yes</label>
											</div>
											<div class="yn_right">
												<input id="org_parent_gr_enti-n" name="org_parent_gr_enti" value="no" type="radio" class="org_parent_gr_enti" onclick="parent_group_entities(this.value); parent_group_entities_Uncheck();" <?php echo (isset($survey_questions['org_parent_gr_enti']) && $survey_questions['org_parent_gr_enti'] == 'no') ? 'checked="checked"' : '';  ?>>
												<label for="org_parent_gr_enti-n"><span><span></span></span>No</label>
												<!-- show in GM -->
												<!-- Thank you. Please proceed to the next step. -->
											</div>
										</div>
                                    </div>
									
									<!-- Q1 answer no yes -->
									<div class="before_we_start_no_yes">
										<label class="t_radio margin-top-15">Are the group of entities under your organization involved in activities related to the palm oil supply chain?*</label>
										<div class="radio_custom_by_am margin-top-5">
											<div class="yn_left">
												<input id="are_group_enti_under_y_orga_involved_rel_sc-y" name="are_group_enti_under_y_orga_involved_rel_sc" value="yes" type="radio" class="are_group_enti_under_y_orga_involved_rel_sc" onclick="group_enti_under_org_rel_sc(this.value);" <?php echo (isset($survey_questions['are_group_enti_under_y_orga_involved_rel_sc']) && $survey_questions['are_group_enti_under_y_orga_involved_rel_sc'] == 'yes') ? 'checked="checked"' : '';  ?>>
												<label for="are_group_enti_under_y_orga_involved_rel_sc-y"><span><span></span></span>Yes</label>
												<!-- show in GM -->
												<!-- Thank you. We will ask you to disclose your group members in the final step of the survey. -->
											</div>
											<div class="yn_right">
												<input id="are_group_enti_under_y_orga_involved_rel_sc-n" name="are_group_enti_under_y_orga_involved_rel_sc" value="no" type="radio" class="are_group_enti_under_y_orga_involved_rel_sc" onclick="group_enti_under_org_rel_sc(this.value);" <?php echo (isset($survey_questions['are_group_enti_under_y_orga_involved_rel_sc']) && $survey_questions['are_group_enti_under_y_orga_involved_rel_sc'] == 'no') ? 'checked="checked"' : '';  ?>>
												<label for="are_group_enti_under_y_orga_involved_rel_sc-n"><span><span></span></span>No</label>
												<!-- show in GM -->
												<!-- Thank you. Please proceed to the next step. -->
											</div>
										</div>
                                    </div>
									
									<!-- Q1 answer no yes yes please show message -->
									<div class="condition message_of_no_yes_yes">
										<label style="line-height:24px; margin:15px 0px 0px 0px; font-size:14px; font-family:Open Sans; color:#636363; font-weight:normal;">We have identified you to be eligible for group membership. Please fill in the 
										<a class="highlight_tooltip group_membership" style="color:#636363;">group membership
											<div class="tooltip_am">
												<div class="content">
													<p class="no-margin">The compulsory requirement for registration of corporate groups under one RSPO membership.</p>
												</div>
											</div>
										</a> details to proceed.</label>
									</div>
<!-- #Q1 answer no, end -->		
									
									<!-- Q1 answer yes no no please show message -->
									<!-- Q1 answer no yes no please show message -->
									<!-- Q1 answer no no please show message -->
									<div class="condition there_are_3_condition">
										<p>Thank you. Please proceed to the next step.</p>
									</div>	
                                </div>
							
							<div class="bg-f5f5f5 a_form">
								<div class="align-right">
									<input id="next_1" type="button" value="Save & continue" class="btn btn-lg btn-black">
								</div>
							</div>
						</div>
					</section>
				</div>
				
			<?php if ($member->category == 'Environmental or Nature Conservation Organisations (Non Governmental Organisations)' || $member->category == 'Social or Development Organisations (Non Governmental Organisations)') { ?>
				
				<div class="tab-pane active" id="2">
				
			<?php } else{?>
				
				<?php if ($is_parent) { ?>
				<div class="tab-pane active" id="2">
				<?php } else{?>
				<div class="tab-pane" id="2">
				<?php } ?>
				
			<?php } ?>
				
					<section class="border-top-gray">
						<div class="r_container_full">
							<h2 class="subsection-heading">Organization details</h2>
							<p>Please go through your organization details and click “save and continue” when you have finished editing.</p>
							<div class="bg-f5f5f5 c_form">
								<div class="c_form_in">
									<label>Organization name*</label>
									<div class="input-group">
										<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->title; ?>" placeholder="" readonly="readonly">
									</div>
									
									<label>Website</label>
									<div class="input-group">
										<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->website; ?>" name="website" id="website" placeholder="">
                                        <div id="err_website" class="alert alert-danger" style="display:none"></div>
                                    </div>
									
									<label>Primary activity*</label>
									<div class="input-group">
										<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->category; ?>" placeholder="" readonly="readonly">
									</div>
									<?php // @todo disable Primary activity  ?>
									<label class="t_radio activities_all_sector">Do you have secondary business activities?*</label>
									<div class="radio_custom_by_am margin-top-7">
										<div class="yn_left">
											<input id="radio-y" name="have_secondary_activities" value="yes" type="radio" <?php echo (!empty($member->have_secondary_activities) && $member->have_secondary_activities == 'yes') ? 'checked="checked"' : ''; ?> onclick="s_secondary_org(this.value);"><label for="radio-y"><span><span></span></span>Yes</label>
										</div>
										<div class="yn_right">
											<input id="radio-n" name="have_secondary_activities" value="no" type="radio" <?php echo (empty($member->have_secondary_activities) || $member->have_secondary_activities == 'no') ? 'checked="checked"' : ''; ?> onclick="s_secondary_org(this.value);"><label for="radio-n"><span><span></span></span>No</label>
										</div>
                                        <div id="err_secondary_activity" class="alert alert-danger" style="display:none"></div>
									</div>
									<p class="message_if_yes_secondary_act" style="display:none;">Mouse over the sectors below to learn more about them.</p>
									<div id="sector_secondary">
										<div class="radio_custom_by_am media_type margin-top-3">
											<ul class="listnone">
												<li class="grower">
													<div class="checkbox checkbox-warning">
														<input id="grower" name="secondary_activity" value="Grower" <?php echo (in_array('Grower', $secondary_activities)) ? 'checked="checked"' : ''; ?> type="checkbox" <?php echo ($member->category == 'Oil Palm Growers') ? 'disabled=""' : ''; ?>>
														<label for="grower">Grower
															<div class="tooltip_am content_more">
																<div class="">
																	<p>Entities that own and/or manage oil palm developments.</p>
																	<ul class="lev2">
																		<li><i>Grower</i> – Grower of oil palm where the total land area managed for oil palm cultivation is more than 500 hectares.</li>
																		<li><i>Smallholder</i> – Farmer growing oil palm where the total planted area of oil palm is below 50 hectares in size. Smallholders must form a group and assign a manager. For the purpose of admission to RSPO membership, where the manager is:</li>
																			<ul class="lev3">
																				<li><i>An individual</i> – the smallholder group must register itself as a legal entity before</li>
																				<li><i>An entity</i> – the group manager as an entity shall apply for membership.</li>
																			</ul>
																		<li><i>Small Grower</i> – Grower of oil palm where the total land area managed for oil palm cultivation is more than 50 hectares but less than 500 hectares.</li>
																	</ul>
																</div>
															</div>
														</label>
													</div>
												</li>
												<li class="pnt">
													<div class="checkbox checkbox-warning">
														<input id="processor_and_or_trader" name="secondary_activity" <?php echo (in_array('Processor and/or Trader', $secondary_activities)) ? 'checked="checked"' : ''; ?> value="Processor and/or Trader" type="checkbox" <?php echo ($member->category == 'Processor and/or Trader' || $member->category == 'Palm Oil Processors and/or Traders') ? 'disabled=""' : ''; ?>>
														<label for="processor_and_or_trader">Processor and/or Trader
															<div class="tooltip_am content">
																<div class="">
																	<p>Entities who are involved in the processing, producing, purchasing and/or selling of palm oil and/or oil palm products. This sector also include distributors or wholesalers involved in the distribution of products for supply to end product manufacturers or resellers.</p>
																</div>
															</div>
														</label>
													</div>
												</li>
												<li class="cgm">
													<div class="checkbox checkbox-warning">
														<input id="consumer_goods_manufacturer" name="secondary_activity" <?php echo (in_array('Consumer Goods Manufacturer', $secondary_activities)) ? 'checked="checked"' : ''; ?> value="Consumer Goods Manufacturer" type="checkbox" <?php echo ($member->category == 'Consumer Goods Manufacturers') ? 'disabled=""' : ''; ?>>
														<label for="consumer_goods_manufacturer">Consumer Goods Manufacturer
															<div class="tooltip_am content">
																<div class="">
																	<p>Entities that use oil palm products in the manufacturing of goods designed and intended for consumption or end use without requiring further repackaging or processing.</p>
																</div>
															</div>
														</label>
													</div>
												</li>
												<li class="retailer">
													<div class="checkbox checkbox-warning">
														<input id="retailer_and_or_wholesaler" name="secondary_activity" <?php echo (in_array('Retailer and/or Wholesaler', $secondary_activities)) ? 'checked="checked"' : ''; ?> value="Retailer and/or Wholesaler" type="checkbox" <?php echo ($member->category == 'Retailer and/or Wholesaler') ? 'disabled=""' : ''; ?>>
														<label for="retailer_and_or_wholesaler">Retailer and/or Wholesaler
															<div class="tooltip_am content">
																<div class="">
																	<p>Entities that buy products from a manufacturer or wholesaler, or produce own label products and selling the products directly to consumers or end users.</p>
																</div>
															</div>
														</label>
													</div>
												</li>
												<li class="BankandInvestor">
													<div class="checkbox checkbox-warning">
														<input id="bank_and_or_investor" name="secondary_activity" <?php echo (in_array('Bank and/or Investor', $secondary_activities)) ? 'checked="checked"' : ''; ?> value="Bank and/or Investor" type="checkbox" <?php echo ($member->category == 'Banks and Investors') ? 'disabled=""' : ''; ?>>
														<label for="bank_and_or_investor">Bank and/or Investor
															<div class="tooltip_am content">
																<div class="">
																	<p>Licensed financial institutions that provide financial services which include commercial/retail banking and investment banking.</p>
																</div>
															</div>
														</label>
													</div>
												</li>
												<li class="sngo">
													<div class="checkbox checkbox-warning">
														<input id="social_and_or_development_NGO" name="secondary_activity" <?php echo (in_array('Social and/or Development NGO', $secondary_activities)) ? 'checked="checked"' : ''; ?> value="Social and/or Development NGO" type="checkbox" <?php echo ($member->category == 'Social or Development Organisations (Non Governmental Organisations') ? 'disabled=""' : ''; ?>>
														<label for="social_and_or_development_NGO">Social and/or Development NGO
															<div class="tooltip_am content">
																<div class="">
																	<p>Any non-for-profit organisation that are independent from governmental organisations that focuses on areas that may include social justice, human and labour rights, poverty alleviation and social development.</p>
																</div>
															</div>
														</label>
													</div>
												</li>
												<li class="engo">
													<div class="checkbox checkbox-warning">
														<input id="environmental_and_or_conservation_NGO" name="secondary_activity" <?php echo (in_array('Environmental and/or Conservation NGO', $secondary_activities)) ? 'checked="checked"' : ''; ?> value="Environmental and/or Conservation NGO" type="checkbox" <?php echo ($member->category == 'Environmental or Nature Conservation Organisations (Non Governmental Organisations)') ? 'disabled=""' : ''; ?>>
														<label for="environmental_and_or_conservation_NGO">Environmental and/or Conservation NGO
															<div class="tooltip_am content">
																<div class="">
																	<p>Any not-for-profit organisation that are independent from governmental organisations with objectives concerning environmental protection and improvement of the health of the environment.</p>
																</div>
															</div>
														</label>
													</div>
												</li>
												<li class="sca">
													<div class="checkbox checkbox-warning">
														<input id="supply_chain_associate" name="secondary_activity" <?php echo (in_array('Supply Chain Associate', $secondary_activities)) ? 'checked="checked"' : ''; ?> value="Supply Chain Associate" type="checkbox" <?php echo ($member->category == 'Supply Chain Associate') ? 'disabled=""' : ''; ?>>
														<label for="supply_chain_associate">Supply Chain Associate
															<div class="tooltip_am content">
																<div class="">
																	<p>Supply chain associates are any organisations that are active in the supply chain of RSPO certified palm oil and purchase less than 500 metric tons of oil palm products per year.</p>
																</div>
															</div>
														</label>
													</div>
												</li>
												<li class="affiliate" style="overflow:initial;">
													<div class="checkbox checkbox-warning">
														<input id="affiliate" name="secondary_activity" <?php echo (in_array('Affiliate', $secondary_activities)) ? 'checked="checked"' : ''; ?> value="Affiliate" type="checkbox" <?php echo ($member->category == 'Affiliate') ? 'disabled=""' : ''; ?>>
														<label for="affiliate">Affiliate
															<div class="tooltip_am content">
																<div class="">
																	<p>Affiliate Members are any individuals or organisations that have indirect involvement or interest in the palm oil supply chain.</p>
																</div>
															</div>
														</label>
													</div>
												</li>
											</ul>
										</div>
									</div>
									
									<label>In which country/countries does your company operate in?*</label>
									<div>
										<div class="radio_custom_by_am media_type margin-bottom-16 margin-top-10">
											<ul class="listnone">
												<li class="organization_operates_globally">
													<div class="checkbox checkbox-warning">
														<input id="organization_operates_globally" name="organization_operates_globally" value="yes" type="checkbox" <?php echo ($member->organization_operates_globally == 'yes') ? 'checked="checked"' : ''; ?>>
														<label for="organization_operates_globally">My organization operates globally</label>
													</div>
												</li>
											</ul>
										</div>
									</div>
									<div class="dropdown_multiple_country_operate_in">
										<div class="input-group">
											<select id="country" class="selectpicker show-tick form-control" title="Select one or more countries" name="country" multiple>
												<?php foreach($countries as $country) { ?>
													<option value="<?php echo $country; ?>" <?php echo (in_array($country, $operate_countries)) ? 'selected' : ''; ?>><?php echo $country; ?></option>
												<?php } ?>
											</select>
											<div id="err_country" class="alert alert-danger" style="display:none"></div>
										</div>
									</div>
								</div>
							</div>
							<div class="bg-f5f5f5 a_form">
								<div class="align-left a_form_b" style="height:45px;">
								<?php if ($member->category == 'Environmental or Nature Conservation Organisations (Non Governmental Organisations)' || $member->category == 'Social or Development Organisations (Non Governmental Organisations)') { ?>
								<?php } else { ?>
									<?php if ($is_parent){ ?>
									<?php } else { ?>	
									
									<input id="prev_1" type="button" value="Back" class="btn btn-lg btn-black">
									
									<?php } ?>
								<?php } ?>
								</div>
								<div class="align-right a_form_b">
									<input id="next_2" type="button" value="Save & continue" class="btn btn-lg btn-black">
								</div>
							</div>
						</div>
					</section>
				</div>
				
				<div class="tab-pane" id="3">
					<section class="border-top-gray">
						<div class="r_container_full">
							<!-- check if user login -->
							<?php 
							if($this->current_user->email == $member->email_p){
								$readonly_email_p = 'readonly="readonly"';
							} else{
								$readonly_email_p = '';
							}
							
							if($this->current_user->email == $member->email_f){
								$readonly_email_f = 'readonly="readonly"';
							} else{
								$readonly_email_f = '';
							}
							
							if($this->current_user->email == $member->email_s){
								$readonly_email_s = 'readonly="readonly"';
							} else{
								$readonly_email_s = '';
							}
							?>
						
							<h2 class="subsection-heading">Contact details</h2>
							<p>Review and/or update the following contact details and click “save and continue”. Contact Person is not editable as it is the active username for MyRSPO and ACOP single sign-on system.</p>
							<div class="bg-f5f5f5 c_form c_form_contact">
								<div class="s_contact contact_1">
									<div class="t_i_contact">
										<p class="margin-bottom-20">Primary contact</p>
									</div>
									<div class="fl_name">
										<label for="" class="block">First name*</label>
										<div class="input-group no-margin">
											<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->name_p; ?>" name="name_p" id="name_p" placeholder="" style="border-right:none;">
											<div id="err_name_p" class="alert alert-danger" style="display:none"></div>
										</div>
									</div>
									<div class="fl_name">
										<label for="" class="block">Last name</label>
										<div class="input-group no-margin">
											<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->name_last_p; ?>" name="name_last_p" id="name_last_p" placeholder="">
											<div id="err_name_last_p" class="alert alert-danger" style="display:none"></div>
										</div>
									</div>
									
									<label for="" class="block">Position*</label>
									<div class="input-group no-margin">
										<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->designation_p; ?>" name="designation_p" id="designation_p" placeholder="">
										<div id="err_designation_p" class="alert alert-danger" style="display:none"></div>
									</div>
									
									<label class="add-pad-am">Telephone*</label>
									<div class="input-group no-margin">
										<div id="err_telephone_p" class="alert alert-danger" style="display:none"></div>
										<div class="input-group-addon no-padding">
											<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->telephone_p; ?>" name="telephone_p" id="telephone_p">
										</div>
									</div>
									
									<label for="" class="block">Email*</label>
									<div class="input-group no-margin">
										<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->email_p; ?>" name="email_p" id="email_p" placeholder="" <?php echo $readonly_email_p; ?>>
										
										<?php echo form_error('email_p')  ?>
										<div id="err_telephone_p" class="alert alert-danger" style="display:none"></div>
									</div>
								</div>
								<div class="s_contact contact_2">
									<div class="t_i_contact">
										<p>Secondary contact</p>
										<small>Primary and Secondary contact details must not be the same.</small>
									</div>
									<div class="fl_name">
										<label for="" class="block">First name*</label>
										<div class="input-group no-margin">
											<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->name_s; ?>" name="name_s" id="name_s" placeholder="" style="border-right:none;">
											<div id="err_name_s" class="alert alert-danger" style="display:none"></div>
										</div>
									</div>
									<div class="fl_name">
										<label for="" class="block">Last name</label>
										<div class="input-group no-margin">
											<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->name_last_s; ?>" name="name_last_s" id="name_last_s" placeholder="">
											<?php echo form_error('name_last_s')? '<div class="alert alert-danger">' . form_error('name_last_s') . '</div>' : ''; ?>
											<div id="err_name_last_s" class="alert alert-danger" style="display:none"></div>
										</div>
									</div>
									
									<label for="" class="block">Position*</label>
									<div class="input-group no-margin">
										<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->designation_s; ?>" name="designation_s" id="designation_s" placeholder="">
										<?php echo form_error('designation_s'); ?>
										<div id="err_designation_s" class="alert alert-danger" style="display:none"></div>
									</div>
                                    
									
									<label class="add-pad-am">Telephone*</label>
									<div class="input-group no-margin">
										<div id="err_telephone_s" class="alert alert-danger" style="display:none"></div>
										<div class="input-group-addon no-padding">
											<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->telephone_s; ?>" name="telephone_s" id="telephone_s">
										</div>
									</div>
									
									<label for="" class="block">Email*</label>
									<div class="input-group no-margin">
										<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->email_s; ?>" name="email_s" id="email_s" placeholder="" <?php echo $readonly_email_s; ?>>
                                    <?php echo form_error('email_s'); ?>
                                    <div id="err_email_s" class="alert alert-danger" style="display:none"></div>
									</div>
								</div>
								<div class="s_contact contact_3">
									<div class="t_i_contact">
										<p>Finance contact</p>
									</div>
									<div class="fl_name">
										<label for="" class="block">First name*</label>
										<div class="input-group no-margin">
											<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->name_f; ?>" name="name_f" id="name_f" placeholder="" style="border-right:none;">
                                        <div id="err_name_f" class="alert alert-danger" style="display:none"></div>
										</div>
									</div>
									<div class="fl_name">
										<label for="" class="block">Last name</label>
										<div class="input-group no-margin">
											<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->name_last_f; ?>" name="name_last_f" id="name_last_f" placeholder="">
                                        <div id="err_name_last_f" class="alert alert-danger" style="display:none"></div>
										</div>
									</div>
									
									<label for="" class="block">Position*</label>
									<div class="input-group no-margin">
										<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->designation_f; ?>" name="designation_f" id="designation_f" placeholder="">
                                    <div id="err_designation_f" class="alert alert-danger" style="display:none"></div>
									</div>
									
									<label class="add-pad-am">Telephone*</label>
									<div class="input-group no-margin">
										<div id="err_telephone_f" class="alert alert-danger" style="display:none"></div>
										<div class="input-group-addon no-padding">
											<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->telephone_f; ?>" name="telephone_f" id="telephone_f">
										</div>
									</div>
									
									<label for="" class="block">Email*</label>
									<div class="input-group no-margin">
										<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->email_f; ?>" name="email_f" id="email_f" placeholder="" <?php echo $readonly_email_f; ?>>
                                <div id="err_email_f" class="alert alert-danger" style="display:none"></div>
									</div>
								</div>
								<div class="s_contact contact_4">
									<div class="t_i_contact">
										<p>Contact person</p>
									</div>
									<div class="fl_name">
										<label for="" class="block">First Name</label>
										<div class="input-group no-margin">
											<input autocomplete="off" type="text" class="form-control b-r-fff" value="<?php echo (!empty($member->contact_fname)) ? $member->contact_fname : $member->contact_person ; ?>" name="contact_fname" id="" placeholder="" style="border-right:1px solid #F5F5F5!important;" readonly="readonly">
										</div>
									</div>
									<div class="fl_name">
										<label for="" class="block">Last Name</label>
										<div class="input-group no-margin">
											<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->contact_lname; ?>" name="contact_lname" id="" placeholder="" readonly="readonly">
										</div>
									</div>
									
									<label for="" class="block">Position</label>
									<div class="input-group no-margin">
										<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->designation; ?>" name="designtaion" id="" placeholder="" readonly="readonly">
									</div>
									
									<label class="add-pad-am">Telephone</label>
									<div class="input-group no-margin">
										<div class="input-group-addon no-padding">
											<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->contact_tel; ?>" name="contact_tel" readonly="readonly">
										</div>
									</div>
									
									<label for="" class="block">Email</label>
									<div class="input-group no-margin">
										<input autocomplete="off" type="text" class="form-control" value="<?php echo $member->contact_email; ?>" name="contact_email" id="" placeholder="" readonly="readonly">
									</div>
								</div>
							</div>
							<div class="bg-f5f5f5 a_form a_form_full">
								<div class="align-left a_form_b">
									<input id="prev_2" type="button" value="Back" class="btn btn-lg btn-black">
								</div>
								<div class="align-right a_form_b">
									<input id="next_3" type="button" value="Save & continue" class="btn btn-lg btn-black">
								</div>
							</div>
						</div>
					</section>
				</div>
				
				<div class="tab-pane s_tab_4" id="4" data-spy="scroll" data-target="#list_gm_left">
					<section class="border-top-gray">
						<div class="r_container_full s_group_membership">
							<h2 class="subsection-heading">Group membership</h2>
							
							<!-- left menu -->
							<div id="list_gm_left">
								<div id="nav" class="nav left_m_group_memberships mCustomScrollbar affix-top" data-spy="affix">
									<ul class="GM_right">
										<?php
                                            if (!empty($subsidiaries)) {
                                                $i = 0;
                                                foreach ($subsidiaries as $subsidiary) { ?>
													<li id="cAsyncGMlist<?php echo $i; ?>">
														<a id="Agm_name<?php echo $i; ?>" href="#gm<?php echo $i; ?>"><?php echo $subsidiary->name?$subsidiary->name:'New Group Membership'; ?></a>
													</li>
												<?php
												$i++;
                                                }
                                            } else { ?>
												<?php if ($is_parent) { ?>
													<?php if (!empty($subsidiaries)) { ?>
														<li id="cAsyncGMlist0">
															<a id="Agm_name0" href="#gm0">New Group Membership</a>
														</li>
													<?php } else{ ?>
														
													<?php } ?>
												<?php } else{ ?>
													<?php if (!empty($subsidiaries)) { ?>
														<li id="cAsyncGMlist0">
															<a id="Agm_name0" href="#gm0">New Group Membership</a>
														</li>
													<?php } else{ ?>
													<?php } ?>
												<?php } ?>
										<?php }?>
									</ul>
								</div>
							</div>
							
							<!-- Q1 answer yes no no please show message -->
							<!-- Q1 answer no yes no please show message -->
							<!-- Q1 answer no no please show message -->
							<div class="complete_the_survey_when_ready">
								<p class="margin-bottom-24">Based on your answers in “Preliminary questions”, you do not have group members to disclose. You may complete this survey when ready.</p>
							</div>
							
							<!-- answer no yes yes with members in map declare not as parent -->
							<div class="message_of_no_yes_yes_delete_all_GM">
								<p>Based on your answers in “Preliminary questions”, you are required to disclose group member(s). If this does not apply to your organization, please amend your answers in the first step.</p>
								<p class="margin-bottom-24">If you still want to disclose group members, please <a onclick="add_more(); AnimateScroll();">click here</a></p>
							</div>
							
							<!-- message sector SNGO & ENGO -->
							<div class="message_sngo_engo margin-bottom-34">
								<p>Based on your RSPO membership sector, this section is not applicable to your organization.</p>
							</div>
							
							<!-- SKENARIO 1 -->
							<div class="skenario_1_g_membership">
								<div id="skenario_no_yes_yes">
									<p>The organizations below were listed as <?php echo $member->title ?> group members during the membership application process. Please review the list and complete their details or add/delete if applicable. Save your work at anytime and resume the survey by logging into MyRSPO.</p>
								</div>
							</div>

							<!-- SKENARIO 1 -->
							<div class="skenario_1_g_membership">
                                <input type="hidden" value="<?php echo $total_subs + 1; ?>" name="total" id="total" />
								<div class="c_form list_of_gm">
                                    <?php
                                    if (!empty($subsidiaries)) {
                                        $i = 0;
                                        foreach ($subsidiaries as $subsidiary) { ?>
                                            <?php // @todo c_form_list untuk counting GM pas delete ?>
                                            <div id="gm<?php echo $i; ?>" class="bg-f5f5f5 c_form_list">
                                                <a class="g_m_add" onClick="g_m_add(this); AnimateAddTarget(this);"><i class="fa fa-plus"></i> Add new group member</a>
                                                <a class="g_m_del delete" onclick="delGM('<?php echo $i; ?>', event)"><i class="fa fa-times"></i> Delete this group member</a>
                                                <div class="c_form_in">
                                                    <label>Group member name*</label>
                                                    <div class="input-group">
                                                        <input id="gm_name<?php echo $i; ?>"
                                                               autocomplete="off" type="text" class="form-control"
                                                               value="<?php echo $subsidiary->name; ?>" name="gm_name<?php echo $i; ?>"
                                                               placeholder="" onblur="syncGMlist(this);" onchange="syncGMlist(this);">
                                                        <input type="hidden" value="<?php echo $subsidiary->id; ?>"
                                                               name="gm_id<?php echo $i; ?>"
                                                               id="gm_id<?php echo $i; ?>">
                                                        <div id="err_gm_name<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
                                                    </div>

                                                    <label class="t_radio l_group_membership type_membership">
														<?php if ($member->category == 'Supply Chain Associate') { ?>
														Type* <i style="opacity:0; width:0px;"></i>
														<?php } else { ?>
														Type* <i></i>
														<div class="tooltip_am">
															<div class="content_more">
																<p><span>Subsidiary</span> - An Entity where the Parent:</p>
																<ul>
																	<li>holds (whether as a legal owner or as a beneficiary) more than half of the issued share capital of that Entity (excluding any part thereof which consists of preference shares); or</li>
																	<li>controls more than half of the voting power of that Entity; or</li>
																	<li>controls the composition of the board of directors of that Entity.</li>
																</ul>
																<hr/>
																<p><span>Management unit</span> - A unit/office managing a plantation(s) operations</p>
															</div>
														</div>
														<?php } ?>
                                                    </label>
                                                    <?php // @todo id sama dengan for (kasi pembeda kalo ada other) ?>
                                                    <div class="radio_custom_by_am t_group_membership">
                                                        <?php if ($member->category == 'Supply Chain Associate') { ?>
                                                            <div class="yn_left">
                                                                <input id="gm_type<?php echo $i; ?>-r"
                                                                       name="gm_type<?php echo $i; ?>"
                                                                       value="supply_chain_group_manager" type="radio" <?php echo ($subsidiary->type == 'supply_chain_group_manager') ? 'checked="checked"' : ''; ?>
                                                                       checked="checked" class="type_sector_s3">
                                                                <label for="gm_type<?php echo $i; ?>-r"><span><span></span></span>Supply
                                                                    Chain Group Manager</label>
                                                            </div>
                                                            <div class="yn_right">
                                                                <input id="gm_type<?php echo $i; ?>-o"
                                                                       name="gm_type<?php echo $i; ?>"
                                                                       value="other" type="radio" <?php echo ($subsidiary->type == 'other') ? 'checked="checked"' : ''; ?>
                                                                       class="type_sector_s3">
                                                                <label for="gm_type<?php echo $i; ?>-o"><span><span></span></span>Other...</label>
                                                            </div>
                                                        <?php } else { ?>
                                                            <div class="yn_left">
                                                                <input id="gm_type<?php echo $i; ?>-r"
                                                                       name="gm_type<?php echo $i; ?>"
                                                                       value="subsidiary" type="radio" <?php echo ($subsidiary->type == 'subsidiary') ? 'checked="checked"' : ''; ?>
                                                                       class="type_sector_s3">
                                                                <label for="gm_type<?php echo $i; ?>-r"><span><span></span></span>Subsidiary</label>
                                                            </div>
                                                            <div class="yn_right">
                                                                <input id="gm_type<?php echo $i; ?>-o"
                                                                       name="gm_type<?php echo $i; ?>"
                                                                       value="management_unit" type="radio" <?php echo ($subsidiary->type == 'management_unit') ? 'checked="checked"' : ''; ?>
                                                                       class="type_sector_s3">
                                                                <label for="gm_type<?php echo $i; ?>-o"><span><span></span></span>Management
                                                                    unit</label>
                                                            </div>
                                                        <?php } ?>
                                                    </div>

                                                    <div class="free_text_other_type" id="free_text_other_type<?php echo $i; ?>" >
                                                        <div class="input-group pad-top-17 pad-bottom-10">
                                                            <input autocomplete="off" type="text" class="form-control"
                                                                   value="<?php echo $subsidiary->other_type; ?>"
                                                                   name="gm_other_type<?php echo $i; ?>"
                                                                   id="gm_other_type<?php echo $i; ?>"
                                                                   placeholder="Enter custom group membership type">
                                                        </div>
                                                        <div id="err_gm_other_type<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
                                                    </div>

													<label class="margin-top-12" style="width:100%;">Nature of business*</label>
                                                    <div class="input-group">
                                                        <select class="selectpicker show-tick form-control" title="Select nature of business"
                                                                name="gm_nature_of_business<?php echo $i; ?>"
                                                                id="gm_nature_of_business<?php echo $i; ?>">
                                                            <option value="Growers" <?php echo ($subsidiary->nature_of_business == 'Growers') ? 'selected="selected"' : ''; ?>>Growers</option>
                                                            <option value="Processors and Traders" <?php echo ($subsidiary->nature_of_business == 'Processors and Traders') ? 'selected="selected"' : ''; ?>>Processors and Traders</option>
                                                            <option value="Retailers" <?php echo ($subsidiary->nature_of_business == 'Retailers') ? 'selected="selected"' : ''; ?>>Retailers</option>
                                                            <option value="Consumer Goods Manufacturers" <?php echo ($subsidiary->nature_of_business == 'Consumer Goods Manufacturers') ? 'selected="selected"' : ''; ?>>Consumer Goods Manufacturers</option>
                                                        </select>
														<div id="err_gm_nature_of_business<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
                                                    </div>

                                                    <div class="c2_left">
                                                        <label>Country*</label>
                                                        <div class="input-group">
                                                            <select class="selectpicker show-tick form-control" title="Select country"
                                                                    onchange="getRegion(<?php echo $i; ?>)"
                                                                    name="gm_country<?php echo $i; ?>"
                                                                    id="gm_country<?php echo $i; ?>">
                                                                <?php foreach ($new_country_arrays as $country => $region) { ?>
                                                                    <option value="<?php echo $country; ?>" <?php echo ($country == $subsidiary->country) ? 'selected' : ''; ?>><?php echo $country; ?></option>
                                                                <?php } ?>
                                                            </select>
														</div>
														<i style="position:absolute; margin-top:0px; font-size:11px; width:500px;">(The list of countries and regions are in accordance with the <a href="https://unstats.un.org/unsd/methodology/m49/" target="_blank">UN M49</a> standard)</i>
														<div style="display:none; margin-bottom:5px; margin-left:-1px; margin-top:14px;" id="err_gm_country<?php echo $i; ?>" class="alert alert-danger"></div>
                                                    </div>		
                                                    <div class="c2_right">
                                                        <label>Region*</label>
                                                        <div class="input-group">
                                                            <input autocomplete="off" type="text" class="form-control"
                                                                   value="<?php echo $subsidiary->region; ?>"
                                                                   name="gm_region<?php echo $i; ?>"
                                                                   id="gm_region<?php echo $i; ?>"
                                                                   placeholder="" readonly="readonly"
                                                                   style="border-left:1px solid transparent!important;">
                                                        </div>
                                                    </div>

                                                    <div style="display:inline-block; margin-top:18px;">
														<label class="t_radio l_group_membership">Is this group member an RSPO member?*</label>
														<div class="radio_custom_by_am t_group_membership_y_n">
															<div class="yn_left">
																<input id="gm_is_rspo_num<?php echo $i; ?>-y" name="gm_is_rspo_num<?php echo $i; ?>" value="yes" <?php echo (!empty($subsidiary->is_rspo_num) && $subsidiary->is_rspo_num == 'yes') ? 'checked="checked"' : ''; ?>
																	   type="radio" class="this_group_membership"><label
																		for="gm_is_rspo_num<?php echo $i; ?>-y"><span><span></span></span>Yes</label>
															</div>
															<div class="yn_right">
																<input id="gm_is_rspo_num<?php echo $i; ?>-n" name="gm_is_rspo_num<?php echo $i; ?>" value="no" <?php echo (empty($subsidiary->is_rspo_num) || $subsidiary->is_rspo_num == 'no') ? 'checked="checked"' : ''; ?>
																	   type="radio" class="this_group_membership"><label
																		for="gm_is_rspo_num<?php echo $i; ?>-n"><span><span></span></span>No</label>
															</div>
														</div>
                                                    </div>

                                                    <div class="show_rspo_membership_number" id="show_rspo_membership_number<?php echo $i; ?>">
                                                        <label class="margin-top-12">Please enter its RSPO membership number</label>
                                                        <?php
                                                        $num = ['0','0000','00','000','00'];
                                                        if (!empty($subsidiary->rspo_membership_num)) {
                                                            $str = explode('-',$subsidiary->rspo_membership_num);
                                                            for ($j = 0; $j < 5; $j++) {
                                                                if (isset($str[$j])) {
                                                                    $num[$j] = $str[$j];
                                                                }
                                                            }

                                                         } ?>
                                                        <div class="input-group membership_number">
                                                            <input autocomplete="off" class="form-control membership_number1" value="<?php echo $num[0]; ?>"
                                                                   id="num1<?php echo $i; ?>"
                                                                   onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                   name="num1<?php echo $i; ?>"
                                                                   placeholder="" maxlength="1" type="text">
                                                            <span>−</span>
                                                            <input autocomplete="off" class="form-control membership_number2" value="<?php echo $num[1]; ?>"
                                                                   id="num2<?php echo $i; ?>"
                                                                   onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                   name="num2<?php echo $i; ?>"
                                                                   placeholder="" maxlength="4" type="text">
                                                            <span>−</span>
                                                            <input autocomplete="off" class="form-control membership_number3" value="<?php echo $num[2]; ?>"
                                                                   id="num3<?php echo $i; ?>"
                                                                   onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                   name="num3<?php echo $i; ?>"
                                                                   placeholder="" maxlength="2" type="text">
                                                            <span>−</span>
                                                            <input autocomplete="off" class="form-control membership_number4" value="<?php echo $num[3]; ?>"
                                                                   id="num4<?php echo $i; ?>"
                                                                   onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                   name="num4<?php echo $i; ?>"
                                                                   placeholder="" maxlength="3" type="text">
                                                            <span>−</span>
                                                            <input autocomplete="off" class="form-control membership_number5" value="<?php echo $num[4]; ?>"
                                                                   id="num5<?php echo $i; ?>"
                                                                   onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                   name="num5<?php echo $i; ?>"
                                                                   placeholder="" maxlength="2" type="text">

                                                            <input name="gm_rspo_membership_num<?php echo $i; ?>"
                                                                   id="gm_rspo_membership_num<?php echo $i; ?>"
                                                                   value="<?php echo $subsidiary->rspo_membership_num; ?>" type="hidden">
                                                            <div id="err_gm_rspo_membership_num<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
                                                        </div>
                                                    </div>

                                                    <h2>Group member contact information</h2>
													<div id="gm_AUF_<?php echo $i; ?>" class="input-group">
														<div class="fl_name">
															<label for="" class="block">First name</label>
															<div class="input-group no-margin">
																<input autocomplete="off" type="text" class="form-control gm_firstname_add"
																	   value="<?php echo $subsidiary->firstname; ?>"
																	   name="gm_firstname<?php echo $i; ?>"
																	   id="gm_firstname<?php echo $i; ?>"
																	   placeholder="" style="border-right:none;">
                                                            <div id="err_gm_firstname<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
															</div>
														</div>
														<div class="fl_name">
															<label for="" class="block">Last name</label>
															<div class="input-group no-margin">
																<input autocomplete="off" type="text" class="form-control gm_lastname_add"
																	   value="<?php echo $subsidiary->lastname; ?>"
																	   name="gm_lastname<?php echo $i; ?>"
																	   id="gm_lastname<?php echo $i; ?>"
																	   placeholder="">
                                                            <div id="err_gm_lastname<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
															</div>
														</div>

														<div class="c2_left c2_e_p">
															<label for="" class="block">Email address</label>
															<div class="input-group no-margin">
																<input autocomplete="off" type="text" class="form-control gm_email_add"
																	   value="<?php echo $subsidiary->email; ?>"
																	   name="gm_email<?php echo $i; ?>"
																	   id="gm_email<?php echo $i; ?>"
																	   placeholder="">
                                                            <div id="err_gm_email<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
															</div>
														</div>
														<div class="c2_right">
															<label class="add-pad-am">Phone number</label>
															<div class="input-group no-margin">
																<div id="err_gm_phone<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
																<div class="input-group-addon no-padding">
																	<input class="mobile-number tlp-code form-control gm_phone_add"
																		   type="tel" value="<?php echo $subsidiary->phone; ?>"
																		   name="gm_phone<?php echo $i; ?>"
																		   id="gm_phone<?php echo $i; ?>">
																</div>
															</div>
														</div>
													</div>

                                                    <div class="align-right margin-top-20 g_membership_button">
                                                        <button onclick="silentDelGM('<?php echo $i; ?>')" id="silentDelGM<?php echo $i; ?>" class='btn btn-lg btn-gray margin-right-8'>Cancel</button>
                                                        <button onclick="saveGM(event)" id="saveGM<?php echo $i; ?>" class='btn btn-lg btn-black'>Save</button>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php $i++; }
                                    } else { ?>
										<?php if ($is_parent) { ?>
											<?php if (!empty($subsidiaries)) { ?>
												<div id="gm0" class="bg-f5f5f5 c_form_list">
													<a class="g_m_add" onClick="g_m_add(this); AnimateAddTarget(this);"><i class="fa fa-plus"></i> New group member name</a>
													<a class="g_m_del delete" onclick="delGM('0', event)"><i class="fa fa-times"></i> Delete this group member</a>
													<div class="c_form_in">
														<label>Group member name*</label>
														<div class="input-group">
															<input id="gm_name0"
																   autocomplete="off" type="text" class="form-control"
																   value="" name="gm_name0"
																   placeholder="" onkeyup="syncGMlist(this)">
															<input type="hidden" value="new"
																   name="gm_id0"
																   id="gm_id0">
															<div id="err_gm_name0" class="alert alert-danger" style="display:none"></div>
														</div>

														<label class="t_radio l_group_membership type_membership">
															<?php if ($member->category == 'Supply Chain Associate') { ?>
															Type* <i style="opacity:0; width:0px;"></i>
															<?php } else { ?>
															Type* <i></i>
																<div class="tooltip_am">
																	<div class="content_more">
																		<p><span>Subsidiary</span> - An Entity where the Parent:</p>
																		<ul>
																			<li>holds (whether as a legal owner or as a beneficiary) more than half of the issued share capital of that Entity (excluding any part thereof which consists of preference shares); or</li>
																			<li>controls more than half of the voting power of that Entity; or</li>
																			<li>controls the composition of the board of directors of that Entity.</li>
																		</ul>
																		<hr/>
																		<p><span>Management unit</span> - A unit/office managing a plantation(s) operations</p>
																	</div>
																</div>
															<?php } ?>
														</label>
														<div class="radio_custom_by_am t_group_membership">
															<?php if ($member->category == 'Supply Chain Associate') { ?>
																<div class="yn_left">
																	<input id="gm_type0-r"
																		   name="gm_type0"
																		   value="supply_chain_group_manager" type="radio" 
																		   checked="checked" class="type_sector_s3">
																	<label for="gm_type0-r"><span><span></span></span>Supply
																		Chain Group Manager</label>
																</div>
																<div class="yn_right">
																	<input id="gm_type0-o"
																		   name="gm_type0"
																		   value="other" type="radio" 
																		   class="type_sector_s3">
																	<label for="gm_type0-o"><span><span></span></span>Other...</label>
																</div>
															<?php } else { ?>
																<div class="yn_left">
																	<input id="gm_type0-r"
																		   name="gm_type0"
																		   value="subsidiary" type="radio" 
																		   checked="checked" 
																		   class="type_sector_s3">
																	<label for="gm_type0-r"><span><span></span></span>Subsidiary</label>
																</div>
																<div class="yn_right">
																	<input id="gm_type0-o"
																		   name="gm_type0"
																		   value="management_unit" type="radio" 
																		   class="type_sector_s3">
																	<label for="gm_type0-o"><span><span></span></span>Management
																		unit</label>
																</div>
															<?php } ?>
														</div>

														<div class="free_text_other_type" id="free_text_other_type0" style="display: none;">
															<div class="input-group pad-top-17 pad-bottom-10">
																<input autocomplete="off" type="text" class="form-control"
																	   value=""
																	   name="gm_other_type0"
																	   id="gm_other_type0"
																	   placeholder="Enter custom group membership type">
															</div>
															<div id="err_gm_other_type0" class="alert alert-danger" style="display:none"></div>
														</div>

														<label class="margin-top-12" style="width:100%;">Nature of business*</label>
														<div class="input-group">
															<select class="selectpicker show-tick form-control" title="Select nature of business"
																	name="gm_nature_of_business0"
																	id="gm_nature_of_business0">
																<option value="Growers">Growers</option>
																<option value="Processors and Traders">Processors and Traders</option>
																<option value="Retailers">Retailers</option>
																<option value="Consumer Goods Manufacturers">Consumer Goods Manufacturers</option>
															</select>
															<div id="err_gm_nature_of_business0" class="alert alert-danger" style="display:none"></div>
														</div>

														<div class="c2_left">
															<label>Country*</label>
															<div class="input-group">
																<select class="selectpicker show-tick form-control" title="Select country"
																		onchange="getRegion(0)"
																		name="gm_country0"
																		id="gm_country0">
																	<?php foreach ($new_country_arrays as $country => $region) { ?>
																		<option value="<?php echo $country; ?>"><?php echo $country; ?></option>
																	<?php } ?>
																</select>
															</div>
															<i style="position:absolute; margin-top:0px; font-size:11px; width:500px;">(The list of countries and regions are in accordance with the <a href="https://unstats.un.org/unsd/methodology/m49/" target="_blank">UN M49</a> standard)</i>
															<div style="display:none; margin-bottom:5px; margin-left:-1px; margin-top:14px;" id="err_gm_country0" class="alert alert-danger"></div>
														</div>
														<div class="c2_right">
															<label>Region*</label>
															<div class="input-group">
																<input autocomplete="off" type="text" class="form-control"
																	   value=""
																	   name="gm_region0"
																	   id="gm_region0"
																	   placeholder="" readonly="readonly"
																	   style="border-left:1px solid transparent!important;">
															</div>
														</div>

														<div style="display:inline-block; margin-top:18px;">
															<label class="t_radio l_group_membership">Is this group member an RSPO member?*</label>
															<div class="radio_custom_by_am t_group_membership_y_n">
																<div class="yn_left">
																	<input id="gm_is_rspo_num0-y" name="gm_is_rspo_num0" value="yes"
																		   type="radio" class="this_group_membership"><label
																			for="gm_is_rspo_num0-y"><span><span></span></span>Yes</label>
																</div>
																<div class="yn_right">
																	<input id="gm_is_rspo_num0-n" name="gm_is_rspo_num0" value="no" checked="checked"
																		   type="radio" class="this_group_membership"><label
																			for="gm_is_rspo_num0-n"><span><span></span></span>No</label>
																</div>
															</div>
														</div>

														<div class="show_rspo_membership_number" id="show_rspo_membership_number0">
															<label class="margin-top-12">Please enter its RSPO membership
																number</label>
															<div class="input-group membership_number">
																<input autocomplete="off" class="form-control membership_number1" value="0"
																	   id="num10"
																	   onkeyup="implodeNumber(0);"
																	   name="num10"
																	   placeholder="" maxlength="1" type="text">
																<span>−</span>
																<input autocomplete="off" class="form-control membership_number2" value="0000"
																	   id="num20"
																	   onkeyup="implodeNumber(0);"
																	   name="num20"
																	   placeholder="" maxlength="4" type="text">
																<span>−</span>
																<input autocomplete="off" class="form-control membership_number3" value="00"
																	   id="num30"
																	   onkeyup="implodeNumber(0);"
																	   name="num30"
																	   placeholder="" maxlength="2" type="text">
																<span>−</span>
																<input autocomplete="off" class="form-control membership_number4" value="000"
																	   id="num40"
																	   onkeyup="implodeNumber(0);"
																	   name="num40"
																	   placeholder="" maxlength="3" type="text">
																<span>−</span>
																<input autocomplete="off" class="form-control membership_number5" value="00"
																	   id="num50"
																	   onkeyup="implodeNumber(0);"
																	   name="num50"
																	   placeholder="" maxlength="2" type="text">

																<input name="gm_rspo_membership_num0"
																	   id="gm_rspo_membership_num0"
																	   value="" type="hidden">
															</div>

															<div id="err_gm_rspo_membership_num0" class="alert alert-danger" style="display:none"></div>
														</div>

														<h2>Group member contact information</h2>
														<div id="gm_AUF_0" class="input-group">
															<div class="fl_name">
																<label for="" class="block">First name</label>
																<div class="input-group no-margin">
																	<input autocomplete="off" type="text" class="form-control gm_firstname_add"
																		   value=""
																		   name="gm_firstname0"
																		   id="gm_firstname0"
																		   placeholder="" style="border-right:none;">
																		   <div id="err_gm_firstname0" class="alert alert-danger" style="display:none"></div>
																</div>
															</div>
															<div class="fl_name">
																<label for="" class="block">Last name</label>
																<div class="input-group no-margin">
																	<input autocomplete="off" type="text" class="form-control gm_lastname_add"
																		   value=""
																		   name="gm_lastname0"
																		   id="gm_lastname0"
																		   placeholder="">
																	<div id="err_gm_lastname0" class="alert alert-danger" style="display:none"></div>
																</div>
															</div>

															<div class="c2_left c2_e_p">
																<label for="" class="block">Email address</label>
																<div class="input-group no-margin">
																	<input autocomplete="off" type="text" class="form-control gm_email_add"
																		   value=""
																		   name="gm_email0"
																		   id="gm_email0"
																		   placeholder="">
																	<div id="err_gm_email0" class="alert alert-danger" style="display:none"></div>
																</div>
															</div>
															<div class="c2_right">
																<label class="add-pad-am">Phone number</label>
																<div class="input-group no-margin">
																	<div id="err_gm_phone0" class="alert alert-danger" style="display:none"></div>
																	<div class="input-group-addon no-padding">
																		<input class="mobile-number tlp-code form-control gm_phone_add"
																			   type="tel" value=""
																			   name="gm_phone0"
																			   id="gm_phone0">
																	</div>
																</div>
															</div>
														</div>

														<div class="align-right margin-top-20 g_membership_button">
															<button onclick="silentDelGM('0')" id="silentDelGM0" class='btn btn-lg btn-gray margin-right-8'>Cancel</button>
															<button onclick="saveGM(event)" id="saveGM0" class='btn btn-lg btn-black'>Save</button>
														</div>
													</div>
												</div>
											<?php } else{ ?>
												
											<?php } ?>
										<?php } else { ?>
											<?php if (!empty($subsidiaries)) { ?>
												<div id="gm0" class="bg-f5f5f5 c_form_list">
													<a class="g_m_add" onClick="g_m_add(this); AnimateAddTarget(this);"><i class="fa fa-plus"></i> New group member name</a>
													<a class="g_m_del delete" onclick="delGM('0', event)"><i class="fa fa-times"></i> Delete this group member</a>
													<div class="c_form_in">
														<label>Group member name*</label>
														<div class="input-group">
															<input id="gm_name0"
																   autocomplete="off" type="text" class="form-control"
																   value="" name="gm_name0"
																   placeholder="" onkeyup="syncGMlist(this)">
															<input type="hidden" value="new"
																   name="gm_id0"
																   id="gm_id0">
															<div id="err_gm_name0" class="alert alert-danger" style="display:none"></div>
														</div>

														<label class="t_radio l_group_membership type_membership">
															<?php if ($member->category == 'Supply Chain Associate') { ?>
															Type* <i style="opacity:0; width:0px;"></i>
															<?php } else { ?>
															Type* <i></i>
																<div class="tooltip_am">
																	<div class="content_more">
																		<p><span>Subsidiary</span> - An Entity where the Parent:</p>
																		<ul>
																			<li>holds (whether as a legal owner or as a beneficiary) more than half of the issued share capital of that Entity (excluding any part thereof which consists of preference shares); or</li>
																			<li>controls more than half of the voting power of that Entity; or</li>
																			<li>controls the composition of the board of directors of that Entity.</li>
																		</ul>
																		<hr/>
																		<p><span>Management unit</span> - A unit/office managing a plantation(s) operations</p>
																	</div>
																</div>
															<?php } ?>
														</label>
														<div class="radio_custom_by_am t_group_membership">
															<?php if ($member->category == 'Supply Chain Associate') { ?>
																<div class="yn_left">
																	<input id="gm_type0-r"
																		   name="gm_type0"
																		   value="supply_chain_group_manager" type="radio" 
																		   checked="checked" class="type_sector_s3">
																	<label for="gm_type0-r"><span><span></span></span>Supply
																		Chain Group Manager</label>
																</div>
																<div class="yn_right">
																	<input id="gm_type0-o"
																		   name="gm_type0"
																		   value="other" type="radio" 
																		   class="type_sector_s3">
																	<label for="gm_type0-o"><span><span></span></span>Other...</label>
																</div>
															<?php } else { ?>
																<div class="yn_left">
																	<input id="gm_type0-r"
																		   name="gm_type0"
																		   value="subsidiary" type="radio" 
																		   class="type_sector_s3">
																	<label for="gm_type0-r"><span><span></span></span>Subsidiary</label>
																</div>
																<div class="yn_right">
																	<input id="gm_type0-o"
																		   name="gm_type0"
																		   value="management_unit" type="radio" 
																		   class="type_sector_s3">
																	<label for="gm_type0-o"><span><span></span></span>Management
																		unit</label>
																</div>
															<?php } ?>
														</div>

														<div class="free_text_other_type" id="free_text_other_type0" style="display: none;">
															<div class="input-group pad-top-17 pad-bottom-10">
																<input autocomplete="off" type="text" class="form-control"
																	   value=""
																	   name="gm_other_type0"
																	   id="gm_other_type0"
																	   placeholder="Enter custom group membership type">
															</div>
															<div id="err_gm_other_type0" class="alert alert-danger" style="display:none"></div>
														</div>

														<label class="margin-top-12" style="width:100%;">Nature of business*</label>
														<div class="input-group">
															<select class="selectpicker show-tick form-control" title="Select nature of business"
																	name="gm_nature_of_business0"
																	id="gm_nature_of_business0">
																<option value="Growers">Growers</option>
																<option value="Processors and Traders">Processors and Traders</option>
																<option value="Retailers">Retailers</option>
																<option value="Consumer Goods Manufacturers">Consumer Goods Manufacturers</option>
															</select>
															<div id="err_gm_nature_of_business0" class="alert alert-danger" style="display:none"></div>
														</div>

														<div class="c2_left">
															<label>Country*</label>
															<div class="input-group">
																<select class="selectpicker show-tick form-control" title="Select country"
																		onchange="getRegion(0)"
																		name="gm_country0"
																		id="gm_country0">
																	<?php foreach ($new_country_arrays as $country => $region) { ?>
																		<option value="<?php echo $country; ?>"><?php echo $country; ?></option>
																	<?php } ?>
																</select>
															</div>
															<i style="position:absolute; margin-top:0px; font-size:11px; width:500px;">(The list of countries and regions are in accordance with the <a href="https://unstats.un.org/unsd/methodology/m49/" target="_blank">UN M49</a> standard)</i>
															<div style="display:none; margin-bottom:5px; margin-left:-1px; margin-top:14px;" id="err_gm_country0" class="alert alert-danger"></div>
														</div>
														<div class="c2_right">
															<label>Region*</label>
															<div class="input-group">
																<input autocomplete="off" type="text" class="form-control"
																	   value=""
																	   name="gm_region0"
																	   id="gm_region0"
																	   placeholder="" readonly="readonly"
																	   style="border-left:1px solid transparent!important;">
															</div>
														</div>

														<div style="display:inline-block; margin-top:18px;">
															<label class="t_radio l_group_membership">Is this group member an RSPO member?*</label>
															<div class="radio_custom_by_am t_group_membership_y_n">
																<div class="yn_left">
																	<input id="gm_is_rspo_num0-y" name="gm_is_rspo_num0" value="yes"
																		   type="radio" class="this_group_membership"><label
																			for="gm_is_rspo_num0-y"><span><span></span></span>Yes</label>
																</div>
																<div class="yn_right">
																	<input id="gm_is_rspo_num0-n" name="gm_is_rspo_num0" value="no" checked="checked"
																		   type="radio" class="this_group_membership"><label
																			for="gm_is_rspo_num0-n"><span><span></span></span>No</label>
																</div>
															</div>
														</div>

														<div class="show_rspo_membership_number" id="show_rspo_membership_number0">
															<label class="margin-top-12">Please enter its RSPO membership
																number</label>
															<div class="input-group membership_number">
																<input autocomplete="off" class="form-control membership_number1" value="0"
																	   id="num10"
																	   onkeyup="implodeNumber(0);"
																	   name="num10"
																	   placeholder="" maxlength="1" type="text">
																<span>−</span>
																<input autocomplete="off" class="form-control membership_number2" value="0000"
																	   id="num20"
																	   onkeyup="implodeNumber(0);"
																	   name="num20"
																	   placeholder="" maxlength="4" type="text">
																<span>−</span>
																<input autocomplete="off" class="form-control membership_number3" value="00"
																	   id="num30"
																	   onkeyup="implodeNumber(0);"
																	   name="num30"
																	   placeholder="" maxlength="2" type="text">
																<span>−</span>
																<input autocomplete="off" class="form-control membership_number4" value="000"
																	   id="num40"
																	   onkeyup="implodeNumber(0);"
																	   name="num40"
																	   placeholder="" maxlength="3" type="text">
																<span>−</span>
																<input autocomplete="off" class="form-control membership_number5" value="00"
																	   id="num50"
																	   onkeyup="implodeNumber(0);"
																	   name="num50"
																	   placeholder="" maxlength="2" type="text">

																<input name="gm_rspo_membership_num0"
																	   id="gm_rspo_membership_num0"
																	   value="" type="hidden">
															</div>

															<div id="err_gm_rspo_membership_num0" class="alert alert-danger" style="display:none"></div>
														</div>

														<h2>Group member contact information</h2>
														<div id="gm_AUF_0" class="input-group">
															<div class="fl_name">
																<label for="" class="block">First name</label>
																<div class="input-group no-margin">
																	<input autocomplete="off" type="text" class="form-control gm_firstname_add"
																		   value=""
																		   name="gm_firstname0"
																		   id="gm_firstname0"
																		   placeholder="" style="border-right:none;">
																		   <div id="err_gm_firstname0" class="alert alert-danger" style="display:none"></div>
																</div>
															</div>
															<div class="fl_name">
																<label for="" class="block">Last name</label>
																<div class="input-group no-margin">
																	<input autocomplete="off" type="text" class="form-control gm_lastname_add"
																		   value=""
																		   name="gm_lastname0"
																		   id="gm_lastname0"
																		   placeholder="">
																	<div id="err_gm_lastname0" class="alert alert-danger" style="display:none"></div>
																</div>
															</div>

															<div class="c2_left c2_e_p">
																<label for="" class="block">Email address</label>
																<div class="input-group no-margin">
																	<input autocomplete="off" type="text" class="form-control gm_email_add"
																		   value=""
																		   name="gm_email0"
																		   id="gm_email0"
																		   placeholder="">
																	<div id="err_gm_email0" class="alert alert-danger" style="display:none"></div>
																</div>
															</div>
															<div class="c2_right">
																<label class="add-pad-am">Phone number</label>
																<div class="input-group no-margin">
																	<div id="err_gm_phone0" class="alert alert-danger" style="display:none"></div>
																	<div class="input-group-addon no-padding">
																		<input class="mobile-number tlp-code form-control gm_phone_add"
																			   type="tel" value=""
																			   name="gm_phone0"
																			   id="gm_phone0">
																	</div>
																</div>
															</div>
														</div>

														<div class="align-right margin-top-20 g_membership_button">
															<button onclick="silentDelGM('0')" id="silentDelGM0" class='btn btn-lg btn-gray margin-right-8'>Cancel</button>
															<button onclick="saveGM(event)" id="saveGM0" class='btn btn-lg btn-black'>Save</button>
														</div>
													</div>
												</div>
											<?php } else { ?>
											<?php } ?>
										<?php } ?>
									<?php }?>
								</div>
								
								<div class="backtoTop" style="display:none;">
									<a class="btn btn-lg btn-gray">Back to top <i class="fa fa-arrow-up" aria-hidden="true"></i></a>
								</div>
							</div>
							
							<!-- SKENARIO 2 -->
							<div class="skenario_2_g_membership" style="float:left;">
								<div class="bg-f5f5f5 c_form f_form_step pad-bottom-20">
									<label class="t_radio">You have removed all group members. Please confirm:</label>
									<div class="radio_custom_by_am margin-top-7">
										<div class="">
											<input id="gm_do_not_have_member-y" name="gm_do_not_have_member" value="yes" type="radio" checked="checked" class="disclose_gm disclose_gm_we_dont" >
											<label for="gm_do_not_have_member-y"><span><span></span></span>We are no longer a parent organization</label>
										</div>
										<div class="">
											<input id="gm_do_not_have_member-n" name="gm_do_not_have_member" value="no" type="radio" class="disclose_gm" >
											<label for="gm_do_not_have_member-n"><span><span></span></span>We still want to disclose group member(s)</label>
										</div>
									</div>
									
									<label class="t_radio margin-top-15">Please elaborate why you are no longer a parent organization:</label>
									<div class="input-group" style="max-width:585px;">
										<textarea autocomplete="off" type="text" class="form-control" name="gm_do_not_have_member_comment" id="gm_do_not_have_member_comment" style="max-width:585px; height:100px;"><?php echo ($member->do_not_have_member_comment !== null) ? $member->do_not_have_member_comment : ''; ?></textarea>
									</div>
								</div>	
							</div>	
							
							<!-- SKENARIO 3 -->
							<div class="skenario_3_g_membership">
								<p style="margin-bottom:22px;">This step is reserved only for members who claimed they are parent companies (and thus have group members to disclose). Since you are not one, you may skip Step 3 and proceed with submitting the survey. You may revise your answer to “yes” in the first part of the survey if you wish to disclose group members.</p>
							</div>
							
							<!-- save and continue -->
							<div class="bg-f5f5f5 a_form save_and_continue" style="float:right;">
								<div class="align-left a_form_b">
									<input id="prev_3" value="Back" class="btn btn-lg btn-black" type="button">
								</div>
								<div class="align-right a_form_b">
									<input id="next_4" value="Save &amp; continue" class="btn btn-lg btn-black" type="button">
								</div>
							</div>
						</div>
					</section>
				</div>
			
				<div class="tab-pane s_tab_5" id="5">
					<section class="border-top-gray">
						<div class="r_container_full s_group_membership">
							<h2 class="subsection-heading">Declaration by Member for Group Membership</h2>
							
							<!-- declaration -->
							<div class="declaration_step4 bg-f5f5f5 a_form">
								<p>We, <b><?php echo $member->title ?></b> hereby declare and confirm that:</p>
								<ul>
									<li>We are:
										<div class="radio_custom_by_am margin-top-5">
											<div class="" style="height:55px; margin-top:-10px;">
												<input id="sole_corporate_involved_palm_oil_sc" name="declaration" value="sole_corporate_involved_palm_oil_sc" class="declare_we_are" type="radio" <?php echo ($member->declaration == 'sole_corporate_involved_palm_oil_sc') ? 'checked="checked"' : ''; ?>>
												<label for="sole_corporate_involved_palm_oil_sc">
													<span><span></span></span>
													<p>A sole body corporate or organization involved in the palm oil supply chain.</p>
												</label>
											</div>
											<div class="" style="height:70px;">
                                                <input id="parent_representing_having_control_entities" name="declaration" value="parent_representing_having_control_entities" class="declare_we_are" type="radio" <?php echo ($member->declaration == 'parent_representing_having_control_entities') ? 'checked="checked"' : ''; ?>>
												<label for="parent_representing_having_control_entities">
													<span><span></span></span>
													<p>A Parent representing and having Control over a group of Entities (as defined under the RSPO Group Membership Rules).</p>
												</label>
											</div>
										</div>
									And
									</li>
									<li>We shall, if we are or if we become a Parent, provide and shall continue to provide and update, all information pertaining to all Entities under our Control and involved in activities in the palm oil supply chain and shall inform RSPO of any changes in our status as Parent and/or the Entities over which we have control; and</li>
								</ul>
								<p>We understand that any failure to comply with the aforesaid declaration shall be considered as a breach of the RSPO Code of Conduct.</p>
							</div>
							
							<!-- ALL SKENARIO USE THIS -->
							<div class="go_next_step_and_submit">
								<div class="bg-f5f5f5 a_form">
									<small class="f_note_m">Once you have completed all steps of the survey, please tick the disclaimer checkbox and click the “submit” button.</small>
									
									<div class="left_pos">
										<div class="radio_custom_by_am media_type margin-top-14">
											<ul class="listnone">
												<li>
													<div class="checkbox checkbox-warning c_f_agree">
														<input id="c_f_n" name="media_type[]" value="" type="checkbox">
														<label for="c_f_n">I hereby verify that all information on this form is true and correct to the best of my knowledge.</label>
													</div>
												</li>
											</ul>
										</div>
									</div>
									<div class="right_pos margin-top-14">
										<input type="submit" id="btnSubmit" class='btn btn-lg btn-black success_message' disabled="disabled" value="Submit"/>
									</div>
								</div>
							</div>
						</div>
					</section>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- success message -->
<div style='display:none'>
	<div id='success_messages' class="popup_custom_by_am">
		<div class="t_popup">
			<h2>Thank you for updating your membership data. You can now proceed to ACOP 2016 and have full access to your MyRSPO profile.</h2>
		</div>
		<div class="c_popup">
			
			<p>Your membership data has been saved</p>
			
			<a class="btn btn-lg btn-black margin-right-8" href="http://acop-rspo.org/">Go to ACOP 2016</a>
			<a class="btn btn-lg btn-black" href="<?php echo base_url('members/profile') ?>">MyRSPO profile</a>
		</div>
	</div>
</div>
<div style='display:none'>
	<div id='success_messages_save' class="popup_custom_by_am">
		<div class="c_popup">
			<p class="no-margin">Your form has been successfully saved</p>
			<i class="fa fa-check" aria-hidden="true"></i>
		</div>
	</div>
</div>

<!-- delete confirm -->
<div style='display:none'>
	<div id='delete_confirm' class="popup_custom_by_am p_delete">
		<div class="c_popup">
			<p>Are you sure you want to delete this group member permanently?</p>
			
			<a class="btn btn-lg btn-gray margin-right-8 cancel_delete">Cancel</a>
			<a class="btn btn-lg btn-black process_delete">Yes, save all progress and delete</a>
		</div>
	</div>
</div>

<!-- change organization -->
<div style='display:none'>
	<div id='change_organization' class="popup_custom_by_am p_c_organizations no-pad-l-r">
        <div class="t_popup mar-left-right-30">
            <h2><?php echo count($member_list); ?> Membership(s)</h2>
        </div>
        <div class="c_popup">
            <div class="container_list_line mCustomScrollbar">
                <ul class="list_line">
                    <?php foreach ($member_list as $mem) { ?>
                        <li><a id="member-<?php echo $mem->intID; ?>" class="member-list <?php echo ($this->session->userdata('intID') == $mem->intID) ? 'member-selected' : ''; ?>" onclick="changeCurrentMemberID(<?php echo $mem->intID; ?>);" ><?php echo $mem->title ?></a></li>
                    <?php } ?>
                </ul>
            </div>
            <input id="current_member" name="current_member" type="hidden" value="<?php echo $this->session->userdata('intID'); ?>" />
            <a id="cancel_change" class="btn btn-lg btn-gray margin-right-8 margin-left-30">Cancel</a>
            <a id="default-changes" class="btn btn-lg btn-black margin-right-8" onclick="change_member();" style="display:none;">Change</a>
            <a id="ignore-changes" class="btn btn-lg btn-black margin-right-8" onclick="change_member();" style="display:none;">Ignore changes</a>
            <a id="save-changes" class="btn btn-lg btn-black margin-right-8" style="display:none;">Save and change</a>
			
			<div id="warning-before-changes" class="notes-div" style="display:none;">
				<small>You have unsaved changes. Are you sure you want to change?</small>
			</div>
        </div>
	</div>
</div>

<div style="display:none">
    <div id="componentGM1">
				<label>Group member name*</label>
				<div class="input-group">
					<input id="new_name"
						   autocomplete="off" type="text" class="form-control"
						   value="" name="new_name"
						   placeholder="" onblur="syncGMlist(this);" onchange="syncGMlist(this);">
					<input type="hidden" value="new"
						   name="new_id"
						   id="new_id">
                    <div id="err_new_name" class="alert alert-danger" style="display:none"></div>
				</div>

				<label class="t_radio l_group_membership type_membership">
					<?php if ($member->category == 'Supply Chain Associate') { ?>
					Type* <i style="opacity:0; width:0px;"></i>
					<!-- <div class="tooltip_am">
						<div class="content">
							<p><span>Supply chain group manager</span> - Lorem ipsum dolor sit amet!</p>
						</div>
					</div> -->
					<?php } else { ?>
					Type* <i></i>
						<div class="tooltip_am">
							<div class="content_more">
								<p><span>Subsidiary</span> - An Entity where the Parent:</p>
								<ul>
									<li>holds (whether as a legal owner or as a beneficiary) more than half of the issued share capital of that Entity (excluding any part thereof which consists of preference shares); or</li>
									<li>controls more than half of the voting power of that Entity; or</li>
									<li>controls the composition of the board of directors of that Entity.</li>
								</ul>
								<hr/>
								<p><span>Management unit</span> - A unit/office managing a plantation(s) operations</p>
							</div>
						</div>
					<?php } ?>
				</label>
				<div class="radio_custom_by_am t_group_membership">
					<?php if ($member->category == 'Supply Chain Associate') { ?>
						<div class="yn_left">
							<input id="new_type_r"
								   name="new_type"
								   value="supply_chain_group_manager" type="radio" checked="checked" class="type_sector_s3">
							<label id="new_label_r" for="new_type"><span><span></span></span>Supply
								Chain Group Manager</label>
						</div>
						<div class="yn_right">
							<input id="new_type_o"
								   name="new_type"
								   value="other" type="radio"
								   class="type_sector_s3">
							<label id="new_label_o" for="new_type"><span><span></span></span>Other...</label>
						</div>
					<?php } else { ?>
						<div class="yn_left">
							<input id="new_type_r"
								   name="new_type"
								   value="subsidiary" type="radio" checked="checked"
								   class="type_sector_s3">
							<label id="new_label_r" for="new_type"><span><span></span></span>Subsidiary</label>
						</div>
						<div class="yn_right">
							<input id="new_type_o"
								   name="new_type"
								   value="management_unit" type="radio"
								   class="type_sector_s3">
							<label id="new_label_o" for="new_type"><span><span></span></span>Management
								unit</label>
						</div>
					<?php } ?>
                    <div id="err_new_type" class="alert alert-danger" style="display:none"></div>
				</div>

				<div class="free_text_other_type" id="new_free_text_other_type" style="display:none;">
					<div class="input-group pad-top-17 pad-bottom-10">
						<input autocomplete="off" type="text" class="form-control"
							   value=""
							   name="new_other_type"
							   id="new_other_type"
							   placeholder="Enter custom group membership type">
                        <div id="err_new_other_type" class="alert alert-danger" style="display:none"></div>
					</div>
				</div>
	</div>
	<div id="componentGM2">
						<option value="Growers">Growers</option>
						<option value="Processors and Traders">Processors and Traders</option>
						<option value="Retailers">Retailers</option>
						<option value="Consumer Goods Manufacturers">Consumer Goods Manufacturers</option>	
	</div>
	<div id="componentGM3">
							<?php foreach ($new_country_arrays as $country => $region) { ?>
								<option value="<?php echo $country; ?>"><?php echo $country; ?></option>
							<?php } ?>
	</div>
	<div id="componentGM4">
				<div class="c2_right">
					<label>Region*</label>
					<div class="input-group">
						<input autocomplete="off" type="text" class="form-control"
							   value=""
							   name="new_region"
							   id="new_region"
							   placeholder="" readonly="readonly"
							   style="border-left:1px solid transparent!important;">
					</div>
				</div>

				<div style="display:inline-block; margin-top:18px;">
					<label class="t_radio l_group_membership">Is this group member an RSPO member?*</label>
					<div class="radio_custom_by_am t_group_membership_y_n">
						<div class="yn_left">
							<input id="new_is_rspo_num-y" name="new_is_rspo_num" value="yes"
								   type="radio" class="this_group_membership"><label
									id="new_label_y"
									for="new_is_rspo_num-y"><span><span></span></span>Yes</label>
						</div>
						<div class="yn_right">
							<input id="new_is_rspo_num-n" name="new_is_rspo_num" value="no" checked="checked"
								   type="radio" class="this_group_membership"><label
									id="new_label_n"
									for="new_is_rspo_num-n"><span><span></span></span>No</label>
						</div>
					</div>
				</div>

				<div class="show_rspo_membership_number" id="new_show_rspo_membership_number" style="display:none;">
					<label class="margin-top-12">Please enter its RSPO membership
						number</label>
					<div class="input-group membership_number">
						<input autocomplete="off" class="form-control membership_number1" value="0"
							   id="new_num1"
							   name="new_num1"
							   placeholder="" maxlength="1" type="text">
						<span>−</span>
						<input autocomplete="off" class="form-control membership_number2" value="0000"
							   id="new_num2"
							   name="new_num2"
							   placeholder="" maxlength="4" type="text">
						<span>−</span>
						<input autocomplete="off" class="form-control membership_number3" value="00"
							   id="new_num3"
							   name="new_num3"
							   placeholder="" maxlength="2" type="text">
						<span>−</span>
						<input autocomplete="off" class="form-control membership_number4" value="000"
							   id="new_num4"
							   name="new_num4"
							   placeholder="" maxlength="3" type="text">
						<span>−</span>
						<input autocomplete="off" class="form-control membership_number5" value="00"
							   id="new_num5"
							   name="new_num5"
							   placeholder="" maxlength="2" type="text">

						<input name="new_rspo_membership_num"
							   id="new_rspo_membership_num"
							   value="" type="hidden">
                        <div id="err_new_rspo_membership_num" class="alert alert-danger" style="display:none"></div>
					</div>
				</div>
	</div>
	<div id="componentGM5">
					<h2>Group member contact information</h2>
	</div>
	<div id="componentGM6">
					<div class="fl_name">
						<label for="" class="block">First name</label>
						<div class="input-group no-margin">
							<input autocomplete="off" type="text" class="form-control gm_firstname_add"
								   value=""
								   name="new_firstname"
								   id="new_firstname"
								   placeholder="" style="border-right:none;">
                            <div id="err_new_firstname" class="alert alert-danger" style="display:none"></div>
						</div>
					</div>
					<div class="fl_name">
						<label for="" class="block">Last name</label>
						<div class="input-group no-margin">
							<input autocomplete="off" type="text" class="form-control gm_lastname_add"
								   value=""
								   name="new_lastname"
								   id="new_lastname"
								   placeholder="">
                            <div id="err_new_lastname" class="alert alert-danger" style="display:none"></div>
						</div>
					</div>

					<div class="c2_left c2_e_p">
						<label for="" class="block">Email address</label>
						<div class="input-group no-margin">
							<input autocomplete="off" type="text" class="form-control gm_email_add"
								   value=""
								   name="new_email"
								   id="new_email"
								   placeholder="">
                            <div id="err_new_email" class="alert alert-danger" style="display:none"></div>
						</div>
					</div>
					<div class="c2_right">
						<label class="add-pad-am">Phone number</label>
						<div class="input-group no-margin">
							<div id="err_new_phone" class="alert alert-danger" style="display:none"></div>
							<div class="input-group-addon no-padding">
								<input class="mobile-number tlp-code form-control gm_phone_add"
									   type="tel" value=""
									   name="new_phone"
									   id="new_phone">
							</div>
						</div>
					</div>
	</div>
	<div id="componentGM7">
				<div class="align-right margin-top-20 g_membership_button">
                    <button id="silentDelGM_new" class='btn btn-lg btn-gray margin-right-8'>Cancel</button>
					<button onclick="saveGM(event)" id="saveGM_new" class='btn btn-lg btn-black'>Save</button>
				</div>
	</div>
</div>
<?php echo form_close(); ?>
<script type="text/javascript">
	var form = document.getElementById("myForm");
    var formEdited = false;

    function DetectChanges() {
        var f = FormChanges(form);
        var msg = "";
        for (var e = 0, el = f.length; e < el; e++) {
            if((f[e].id === 'new_phone' || f[e].id === 'deemed_complience_rspo_phone' || f[e].id === 'parent_representing_having_control_entities') && (f[e].value === '+62 ' || f[e].value === 'parent_representing_having_control_entities')) {

            } else {
                msg += "\n    #" + f[e].id + ' : ' + f[e].value;
                formEdited = true;
            }

        }
        console.log((msg ? "Elements changed:" : "No changes made.") + msg);
    }
	/* Change membership */
    function changeCurrentMemberID(intID)
    {
        $("#current_member").val(intID);
        $(".member-list").removeClass('member-selected');
        $("#member-"+intID).addClass('member-list member-selected');
    }

    $("#cancel_change").click(function() {
        changeCurrentMemberID(<?php echo $this->session->userdata('intID'); ?>);
        parent.$.colorbox.close();
        return false;
    });

    function change_member(){
        var post_data = {intID:$("#current_member").val()};
        $.ajax({
            url: "<?php echo site_url('members/change_default_member_user'); ?>",
            method: "POST",
            data: post_data,
            type: "json",
            success: function(obj){
                var data = JSON.parse(obj);
                if (data.status == false) {
                    alert(data.message);
                }
                location.reload();
            }
        });
    }
	
	$('#save-changes').on('click', function(e){
        switch(currentStep) {
            case 1:next1();break;
            case 2:next2();break;
            case 3:next3();break;
            case 4:next4(e);break;
            case 5:next5(e);break;
        }
        var post_data = {intID:$("#current_member").val()};
        $.ajax({
            url: "<?php echo site_url('members/change_default_member_user'); ?>",
            method: "POST",
            data: post_data,
            type: "json",
            success: function(obj){
                var data = JSON.parse(obj);
                if (data.status == false) {
                    alert(data.message);
                }
                setTimeout(function(){
                    location = ''
                },1200)
            }
        });
    });
	
	/* shortcut dropdown donot display */
	$('.contact_d_s, .sel_fill').css({"display":"none"});
	
	/* add class active */
	$('.nav-tabs a').click(function() {
		$('.nav-tabs a.active').removeClass('active');
		$(this).addClass('active');
	});
	
	/* steps */
	$('#step5').click(function(event) {
		$('#step1, #step2, #step3, #step4, #step5').addClass('active');
		
		$('#line-steps').addClass('id-line-5');
		$('#line-steps').removeClass('id-line').removeClass('id-line-2').removeClass('id-line-3').removeClass('id-line-4');
        saveByPass(event, 5);
	});
	
	$('#step4').click(function(event) {
		$('#step1, #step2, #step3, #step4').addClass('active');
		
		$('#line-steps').addClass('id-line-4');
		$('#line-steps').removeClass('id-line').removeClass('id-line-2').removeClass('id-line-3').removeClass('id-line-5');
        saveByPass(event, 4);
	});
	
	$('#step3').click(function(event) {
		$('#step1, #step2, #step3').addClass('active');
		$('#step4').removeClass('active');
		
		$('#line-steps').addClass('id-line-3');
		$('#line-steps').removeClass('id-line').removeClass('id-line-2').removeClass('id-line-4').removeClass('id-line-5');
        saveByPass(event, 3);
    });
	
	$('#step2').click(function(event) {
		$('#step1, #step2').addClass('active');
		$('#step3, #step4').removeClass('active');
		
		$('#line-steps').addClass('id-line-2');
		$('#line-steps').removeClass('id-line').removeClass('id-line-3').removeClass('id-line-4').removeClass('id-line-5');
        saveByPass(event, 2);
    });
	
	$('#step1').click(function(event) {
		$('#step1').addClass('active');
		$('#step2, #step3, #step4').removeClass('active');
		
		$('#line-steps').addClass('id-line');
		$('#line-steps').removeClass('id-line-2').removeClass('id-line-3').removeClass('id-line-4').removeClass('id-line-5');
        saveByPass(event, 1);
	});
	
	/* next and prev */
	$('#next_1').click(function(event){
	    event.preventDefault();
            next1();
            $('#step2').trigger('click');
            $('html, body').animate({
                scrollTop: ($("#myTab").offset().top * 1) - 150
            }, 200);
	});

	function saveByPass(event, nextStep){
        switch(currentStep) {
            case 1:
                next1();
                currentStep = nextStep;
                break;
            case 2:
                next2();
                currentStep = nextStep;
                break;
            case 3:
                next3();
                currentStep = nextStep;
                break;
            case 4:
                next4(event);
                currentStep = nextStep;
                break;
            case 5:
            	next5(event);
                currentStep = nextStep;
                break;
        }
    }

	function next1() {
        var input = [
            "is_your_controller_by_a_parent",
            "your_parent_member_of_rspo",
            "is_your_parent_involved_activi_related_po_sc",
            "org_parent_gr_enti",
            "are_group_enti_under_y_orga_involved_rel_sc",
            "deemed_complience_parent_name",
            "deemed_complience_rspo_contact_name",
            "deemed_complience_rspo_email",
            "deemed_complience_rspo_phone",
            "deemed_complience_rspo_new_gm_parent_name"
        ];

        var post_data = {intID:<?php echo $member->intID ?>};
        post_data['is_parent_map'] = '<?php echo ($is_parent) ? 'yes' : 'no'; ?>';

        $.each(input, function( index, value ) {
            if ($("input[id^='"+value+"']").is(':visible')) {
                if ($("input[id^='" + value + "']").attr("type") == 'radio') {
                    if ($("input[id^='" + value + "']").is(':checked')) {
                        post_data[value] = $("input[id^='" + value + "']:checked").val();
                    }
                } else {
                    post_data[value] = $("input[id^='" + value + "']").val();
                }
            }
        });

        if ($("textarea[id='deemed_complience_rspo_comment']").is(':visible')) {
            post_data['deemed_complience_rspo_comment'] = $("textarea[id='deemed_complience_rspo_comment']").val();
        }

        if ($("input[id='deemed_complience_rspo_new_gm_parent_rspo_membership_number']").length > 0) {
            post_data['deemed_complience_rspo_new_gm_parent_rspo_membership_number'] = $("input[id='deemed_complience_rspo_new_gm_parent_rspo_membership_number']").val();
        }

        $.each(post_data, function( index, value ) {
            $("#err_"+index).hide();
            if($("input[id='"+index+"']").is(':visible') && value.length < 1) {
                $("#err_"+index).text('Required');
                $("#err_"+index).show();
            }
        });

            $.ajax({
                url: "<?php echo site_url('members/save_question_survey'); ?>",
                method: "POST",
                data: post_data,
                type: "json",
                success: function(obj){
                    var data = JSON.parse(obj);
                    if (data.status == false) {
                        alert(data.message);
                    } else {
                        SuccessColorboxConfirmSave();
                        setTimeout(parent.$.colorbox.close, 1200);
                    }
                }
            });


    }

    function collect() {
        var ret = {};
        var len = arguments.length;
        for (var i=0; i<len; i++) {
            for (p in arguments[i]) {
                if (arguments[i].hasOwnProperty(p)) {
                    ret[p] = arguments[i][p];
                }
            }
        }
        return ret;
    }

    $("#btnSubmit").click(function (event) {
        event.preventDefault();
        
        next5(event);
        
        var input0 = [
            "is_your_controller_by_a_parent",
            "your_parent_member_of_rspo",
            "is_your_parent_involved_activi_related_po_sc",
            "org_parent_gr_enti",
            "are_group_enti_under_y_orga_involved_rel_sc",
            "deemed_complience_parent_name",
            "deemed_complience_rspo_contact_name",
            "deemed_complience_rspo_email",
            "deemed_complience_rspo_phone",
            "deemed_complience_rspo_new_gm_parent_name",
            "deemed_complience_rspo_new_gm_parent_rspo_membership_number"
        ];

        var post_data_0 = {intID:<?php echo $member->intID ?>};

        $.each(input0, function( index, value ) {
                if ($("input[id^='" + value + "']").attr("type") == 'radio') {
                    if ($("input[id^='" + value + "']").is(':checked')) {
                        post_data_0[value] = $("input[id^='" + value + "']:checked").val();
                    }
                } else {
                    post_data_0[value] = $("input[id^='" + value + "']").val();
                }
        });

        var post_data_gm = {};
        $("[id^='gm_']").each(function(data){
            temp = this.id.replace("-y", "");
            temp = temp.replace("-n", "");
            temp = temp.replace("-r", "");
            temp = temp.replace("-o", "");
            if (this.type == 'radio') {
                if (this.checked) {
                    post_data_gm[temp] = this.value;
                }
            } else {
                post_data_gm[temp] = this.value;
            }
        });

        var input_2 = ["website", "country"];

        var post_data_company = {};

        $.each(input_2, function( index, value ) {
            post_data_company[value] = $("#"+value).val();
        });

        post_data_company['have_secondary_activities'] = $("input[name='have_secondary_activities']:checked").val();

        if ($("input[name='organization_operates_globally']:checked").val() == 'yes') {
            post_data_company['organization_operates_globally'] = 'yes';
        } else {
            post_data_company['organization_operates_globally'] = 'no';
        }

        if ($("input[name='gm_do_not_have_member']:checked").val() == 'yes') {
            post_data_company['gm_do_not_have_member'] = 'yes';
        } else {
            post_data_company['gm_do_not_have_member'] = 'no';
        }

        var secondary_activity = [];
        $.each($("input[name='secondary_activity']:checked"), function(){
            secondary_activity.push($(this).val());
        });

        post_data_company['secondary_activity'] = secondary_activity;
        console.log(post_data_company);

        var input_3 = [
            "email_p",
            "name_p",
            "name_last_p",
            "telephone_p",
            "designation_p",
            "email_s",
            "name_s",
            "name_last_s",
            "telephone_s",
            "designation_s",
            "email_f",
            "name_f",
            "name_last_f",
            "telephone_f",
            "designation_f"
        ];

        var post_data_contacts = {};

        $.each(input_3, function( index, value ) {
            post_data_contacts[value] = $("#"+value).val();
        });

        var post_data = collect(post_data_0, post_data_gm, post_data_company, post_data_contacts);
        post_data['is_parent_map'] = '<?php echo ($is_parent) ? 'yes' : 'no'; ?>';
        console.log(post_data);
//
//        var $inputs = $('#myForm :input');
//
//        // not sure if you wanted this, but I thought I'd add it.
//        // get an associative array of just the values.
//        var post_data = {};
//        $inputs.each(function() {
//            post_data[this.name] = $(this).val();
//        });

        $.ajax({
            url: "<?php echo site_url('members/validate_submit_survey'); ?>",
            method: "POST",
            data: post_data,
            type: "json",
            success: function(obj){
                var data = JSON.parse(obj);
                if(data.status == false) {
                    $.each(data.error, function( index, value ) {
                        $("#err_"+index).hide();
                        if(value !== '') {
//                            var form = $("#"+index);
//                            console.log(index);
//                            console.log(form.attr('type'));
//                            form.on('blur', function(){
//                                if ($(this).val().length > 0) {
//                                    $('#err_'+index).fadeOut();
//                                }
//                            });
                            $("#err_"+index).text(value);
                            $("#err_"+index).show();
                        }
                    });
                    if(data.error_step.step0.length > 0){
                        $('#step1').trigger('click');
                        $('html, body').animate({
                            scrollTop: ($("#myTab").offset().top * 1) - 150
                        }, 200);
                    } else if(data.error_step.step1.length > 0){
                        $('#step2').trigger('click');
                        $('html, body').animate({
                            scrollTop: ($("#myTab").offset().top * 1) - 150
                        }, 200);
                    } else if (data.error_step.step2.length > 0) {
                        $('#step3').trigger('click');
                        $('html, body').animate({
                            scrollTop: ($("#myTab").offset().top * 1) - 150
                        }, 200);
                    } else if (data.error_step.step3.length > 0) {
                        $('#step4').trigger('click');
                        $('html, body').animate({
                            scrollTop: ($("#myTab").offset().top * 1) - 150
                        }, 200);
                    }
                    console.log(data.error_step);
                } else {
                    var post_data = {intID:<?php echo $member->intID ?>};
                    $.ajax({
                        url: "<?php echo site_url('members/submit_survey'); ?>",
                        method: "POST",
                        data: post_data,
                        type: "json",
                        success: function(obj){
                            var data = JSON.parse(obj);
                            if (data.status == false) {
                                alert(data.message);
                            } else {
                                SuccessColorboxConfirm();
                            }
                        }
                    });
                }
            }
        });

    });

//	$("#btnSubmit").click(function () {
//
//        var post_data = {intID:<?php //echo $member->intID ?>//};
//
//        $.ajax({
//            url: "<?php //echo site_url('members/submit_survey'); ?>//",
//            method: "POST",
//            data: post_data,
//            type: "json",
//            success: function(obj){
//                var data = JSON.parse(obj);
//                if (data.status == false) {
//                    alert(data.message);
//                } else {
//                    finishedSurvey();
//					SuccessColorboxConfirm();
//                }
//            }
//        });
//
//    });
	
	$('#next_2').click(function(){
	    next2();
        $('#step3').trigger('click');
        $('html, body').animate({
            scrollTop: ($("#myTab").offset().top * 1) - 150
        }, 200);
	});

	function next2(){
        var input_2 = ["website", "country"];

        var post_data = {intID:<?php echo $member->intID ?>};

        $.each(input_2, function( index, value ) {
            post_data[value] = $("#"+value).val();
        });

        var secondary_activity = [];
        $.each($("input[name='secondary_activity']:checked"), function(){
            secondary_activity.push($(this).val());
        });


        if ($('input[name="organization_operates_globally"]:checked').val() == 'yes') {
            post_data['organization_operates_globally'] = 'yes';
        } else {
            post_data['organization_operates_globally'] = 'no';
        }

        post_data['secondary_activity'] = secondary_activity;
        post_data['step'] = '1';
        post_data['have_secondary_activities'] = $('input[name="have_secondary_activities"]:checked').val();

        $.ajax({
            url: "<?php echo site_url('members/save_survey_temp'); ?>",
            method: "POST",
            data: post_data,
            type: "json",
            success: function(obj){
                var data = JSON.parse(obj);
                if (data.status == false) {
                    alert(data.message);
                } else {
                    SuccessColorboxConfirmSave();
                    setTimeout(parent.$.colorbox.close, 1200);
                }
            }
        });
    }
	
	$('#next_3').click(function(){
	    next3();

        $('#step4').trigger('click');
        $('html, body').animate({
            scrollTop: ($("#myTab").offset().top * 1) - 150
        }, 200);
	});

	function next3() {
        var input_3 = [
            "email_p",
            "name_p",
            "name_last_p",
            "telephone_p",
            "designation_p",
            "email_s",
            "name_s",
            "name_last_s",
            "telephone_s",
            "designation_s",
            "email_f",
            "name_f",
            "name_last_f",
            "telephone_f",
            "designation_f"
        ];

        var post_data = {intID:<?php echo $member->intID ?>};

        $.each(input_3, function( index, value ) {
            post_data[value] = $("#"+value).val();
        });

        $.ajax({
            url: "<?php echo site_url('members/save_survey_temp'); ?>",
            method: "POST",
            data: post_data,
            type: "json",
            success: function(obj){
                var data = JSON.parse(obj);
                if (data.status == false) {
                    alert(data.message);
                } else {
                    SuccessColorboxConfirmSave();
                    setTimeout(parent.$.colorbox.close, 1200);
                }
            }
        });
    }
	
	$('#prev_1').click(function(){
		$('#step1').trigger('click');
		$('html, body').animate({
			scrollTop: ($("#myTab").offset().top * 1) - 150
		}, 200);
	});
	
	$('#prev_2').click(function(){
		$('#step2').trigger('click');
		$('html, body').animate({
			scrollTop: ($("#myTab").offset().top * 1) - 150
		}, 200);
	});
	
	$('#prev_3').click(function(){
		$('#step3').trigger('click');
		$('html, body').animate({
			scrollTop: ($("#myTab").offset().top * 1) - 150
		}, 200);
	});
	
	$('#myTab a').click(function(e) {
        e.preventDefault();
        $(this).tab('show');
        AnimateScroll190();
	});
</script>
<script type="text/javascript">
    var currentStep = <?php echo ($is_parent) ? '2' : '1' ?>;
	/* step0 */
	/* skenario1 */
	$(".before_we_start_yes").slideUp('slow'); 
	$(".before_we_start_yes_yes").slideUp('slow'); 
	$(".before_we_start_yes_no").slideUp('slow'); 
	$(".before_we_start_yes_no_yes").slideUp('slow'); 
	$(".before_we_start_no").slideUp('slow');
	$(".before_we_start_no_yes").slideUp('slow');
	$(".message_of_no_yes_yes").slideUp('slow'); 
	
	<!-- Q1 answer yes no no please show message -->
	<!-- Q1 answer no yes no please show message -->
	<!-- Q1 answer no no please show message -->
	$(".there_are_3_condition").slideUp('slow');
	$(".complete_the_survey_when_ready").slideUp('slow');
	
	/* step3 */
	$(".message_of_no_yes_yes_delete_all_GM").slideUp('slow');
	$(".message_sngo_engo").slideUp('slow');
	$(".go_next_step_and_submit").slideDown('slow');
	
	/* step4 */
	$('.declare_we_are').prop('checked', false);
	
	<?php if ($member->category == 'Environmental or Nature Conservation Organisations (Non Governmental Organisations)' || $member->category == 'Social or Development Organisations (Non Governmental Organisations)') { ?>
		/* hide */
		$(".skenario_2_g_membership").slideUp('slow');
		$(".skenario_3_g_membership").slideUp('slow');
		$(".left_m_group_memberships").slideUp('slow');
		$(".skenario_1_g_membership").slideUp('slow');
		
		/* show up */
		$(".message_sngo_engo").slideDown('slow');
		$(".save_and_continue").slideDown('slow');
		$('.save_and_continue').css({"float":"left"});
	<?php } else{ ?>
		<?php if ($is_parent) { ?>
			<?php if (!empty($subsidiaries)) { ?>
				/* show up */
				$(".left_m_group_memberships").slideDown('slow'); 
				$(".skenario_1_g_membership").slideDown('slow');
				$(".save_and_continue").slideDown('slow');
				
				/* hide */
				$(".skenario_2_g_membership").slideUp('slow'); 
				$(".skenario_3_g_membership").slideUp('slow'); 
			<?php } else{ ?>
				/* show up */
				$(".skenario_2_g_membership").slideDown('slow');
				$(".save_and_continue").slideDown('slow');
				$('.save_and_continue').css({"float":"left"});
				
				/* hide */
				$(".left_m_group_memberships").slideUp('slow'); 
				$(".skenario_1_g_membership").slideUp('slow');
				$(".skenario_3_g_membership").slideUp('slow'); 
			<?php } ?>
		<?php } else { ?>
			/* hide */
			$(".skenario_1_g_membership").slideUp('slow');
			$(".skenario_2_g_membership").slideUp('slow');
			$(".skenario_3_g_membership").slideUp('slow');
			$(".left_m_group_memberships").slideUp('slow');
			
			uncilckable();
		<?php } ?>
	<?php } ?>
	
	/* clickable after step0 done */
	function cilckable(){
		$('#step2, #step3, #step4, #step5').attr('disabled', false);
		$('#next_1, #next_2, #next_3').attr('disabled', false);
		$('#prev_1, #prev_2').attr('disabled', false);
	}
	
	/* unclickable before step0 done */
	function uncilckable(){
		$('#step2, #step3, #step4, #step5').attr('disabled', true);
		$('#next_1, #next_2, #next_3').attr('disabled', true);
		$('#prev_1, #prev_2').attr('disabled', true);
	}
	
	function org_controlled_by_parent_Uncheck(){
		/* uncheck */
		$('.event_before_we_start_yes').prop('checked', false);
		$('.event_before_we_start_yes_no').prop('checked', false);
		$('.org_parent_gr_enti').prop('checked', false);
		$('.are_group_enti_under_y_orga_involved_rel_sc').prop('checked', false);
		$('.declare_we_are').prop('checked', false);
	}
	
	function event_before_we_start_yes_Uncheck(){
		/* uncheck */
		$('.event_before_we_start_yes_no').prop('checked', false);
	}
	
	function parent_group_entities_Uncheck(){
		/* uncheck */
		$('.are_group_enti_under_y_orga_involved_rel_sc').prop('checked', false);
	}
	
	function HideFormGM(){
		$(".skenario_1_g_membership").slideUp('slow');
		$(".left_m_group_memberships").slideUp('slow');
		$(".save_and_continue").slideDown('slow');
		$('.save_and_continue').css({"float":"left"});
	}
	
	function ShowFormGM(){
		$(".skenario_1_g_membership").slideDown('slow');
		$(".left_m_group_memberships").slideDown('slow');
		$(".save_and_continue").slideDown('slow');
		$('.save_and_continue').css({"float":"right"});
	}
	
	function org_controlled_by_parent(yes){
		if (yes=='yes'){
			
			/* unclickable */
			uncilckable();
			
			/* step0 */
			/* show up */
			$(".before_we_start_yes").slideDown('slow'); 
			
			/* step0 */
			/* hide */
			$(".before_we_start_yes_yes").slideUp('slow'); 
			$(".before_we_start_yes_no").slideUp('slow'); 
			$(".before_we_start_yes_no_yes").slideUp('slow'); 
			$(".there_are_3_condition").slideUp('slow'); 
			$(".before_we_start_no").slideUp('slow'); 
			$(".before_we_start_no_yes").slideUp('slow'); 
			$(".message_of_no_yes_yes").slideUp('slow'); 
			$(".message_of_no_yes_yes_delete_all_GM").slideUp('slow');
		} else {
			
			/* unclickable */
			uncilckable();
			
			/* step0 */
			/* hide */
			$(".before_we_start_yes").slideUp('slow'); 
			$(".before_we_start_yes_yes").slideUp('slow'); 
			$(".before_we_start_yes_no").slideUp('slow'); 
			$(".before_we_start_yes_no_yes").slideUp('slow'); 
			$(".before_we_start_no_yes").slideUp('slow'); 
			$(".message_of_no_yes_yes").slideUp('slow'); 
			$(".there_are_3_condition").slideUp('slow'); 
			$(".message_of_no_yes_yes_delete_all_GM").slideUp('slow');
			
			/* step0 */
			/* show up */
			$(".before_we_start_no").slideDown('slow'); 
		}
	}
	
	function event_before_we_start_yes(yes){
		if (yes=='yes'){
			
			/* clickable */
			cilckable();
			
			/* step0 */
			/* show up */
			$(".before_we_start_yes_yes").slideDown('slow');
			$(".complete_the_survey_when_ready").slideDown('slow');
			$(".save_and_continue").slideDown('slow');
			$('.save_and_continue').css({"float":"left"});
			
			/* step0 */
			/* hide */
			$(".before_we_start_yes_no").slideUp('slow'); 
			$(".before_we_start_yes_no_yes").slideUp('slow');
			$(".there_are_3_condition").slideUp('slow');	
			HideFormGM();
		} else {
			
			/* unclickable */
			uncilckable();
			
			/* step0 */
			/* hide */
			$(".before_we_start_yes_yes").slideUp('slow');
			$(".before_we_start_yes_no_yes").slideUp('slow'); 
			$(".there_are_3_condition").slideUp('slow');
			$(".complete_the_survey_when_ready").slideUp('slow');
			
			/* step0 */
			/* show */
			$(".before_we_start_yes_no").slideDown('slow'); 
			$(".save_and_continue").slideDown('slow');
			$('.save_and_continue').css({"float":"left"});
		}
	}
	
	function event_before_we_start_yes_no(yes){
		if (yes=='yes'){
			
			/* clickable */
			cilckable();
			
			/* step0 */
			/* show up */
			$(".before_we_start_yes_no_yes").slideDown('slow');
			$(".complete_the_survey_when_ready").slideDown('slow');
			
			/* step0 */
			/* hide */
			$(".message_sngo_engo").slideUp('slow');
			$(".there_are_3_condition").slideUp('slow');
			HideFormGM();
		} else {
			
			/* clickable */
			cilckable();
			
			/* step0 */
			/* hide */
			$(".before_we_start_yes_no_yes").slideUp('slow');
			$(".message_sngo_engo").slideUp('slow');
			
			/* step0 */
			/* show */
			$(".there_are_3_condition").slideDown('slow');
			$(".complete_the_survey_when_ready").slideDown('slow');
			HideFormGM();
		}
	}
	
	function parent_group_entities(yes){
		if (yes=='yes'){
			
			/* unclickable */
			uncilckable();
			
			/* step0 */
			/* show up */
			$(".before_we_start_no_yes").slideDown('slow'); 
			
			/* step0 */
			/* hide */
			$(".there_are_3_condition").slideUp('slow');
			$(".message_of_no_yes_yes").slideUp('slow');
			
			/* check */
			$(".org_parent_gr_enti[value='yes']:checked").prop('checked', true);
			$(".declare_we_are[value='parent_representing_having_control_entities']").prop('checked', true);
			
			/* uncheck */
			$(".declare_we_are[value='sole_corporate_involved_palm_oil_sc']").prop('checked', false);
		} else {
			
			/* clickable */
			cilckable();
			
			/* step0 */
			/* show up */
			$(".there_are_3_condition").slideDown('slow'); 
			$(".complete_the_survey_when_ready").slideDown('slow');
			$(".save_and_continue").slideDown('slow');
			$('.save_and_continue').css({"float":"left"});
			
			/* step0 */
			/* hide */
			$(".message_of_no_yes_yes").slideUp('slow');
			$(".before_we_start_no_yes").slideUp('slow');
			HideFormGM();
			
			/* check */
			$(".org_parent_gr_enti[value='no']:checked").prop('checked', true);
			$(".declare_we_are[value='sole_corporate_involved_palm_oil_sc']").prop('checked', true);
			
			/* uncheck */
			$(".declare_we_are[value='parent_representing_having_control_entities']").prop('checked', false);
		}
	}
	
	function group_enti_under_org_rel_sc(yes){
		if (yes=='yes'){
			
			/* clickable */
			cilckable();
			
			/* step0 */
			/* show up */
			$(".message_of_no_yes_yes").slideDown('slow');
			
			/* step0 */
			/* hide */
			$(".there_are_3_condition").slideUp('slow');
			$(".complete_the_survey_when_ready").slideUp('slow');
			
			/* change text skenario 1 */
			document.getElementById("skenario_no_yes_yes").innerHTML = "Based on your answers in the “Preliminary questions” step, you have group members to disclose. Please fill the forms below. You can add or delete group members as you see fit.";
			$('#list_gm_left').css({"top":"139px"});
			
			/* check */
			$(".are_group_enti_under_y_orga_involved_rel_sc[value='yes']:checked").prop('checked', true);
			
			add_more();
			$('.save_and_continue').css({"float":"right"});
		} else {
			
			/* clickable */
			cilckable();
			
			/* step0 */
			/* show up */
			$(".there_are_3_condition").slideDown('slow');
			$(".complete_the_survey_when_ready").slideDown('slow');
			
			/* step0 */
			/* hide */
			$(".message_of_no_yes_yes").slideUp('slow');
			HideFormGM();
			
			/* check */
			$(".are_group_enti_under_y_orga_involved_rel_sc[value='no']:checked").prop('checked', true);
		}
	}
	
	/* only load first */
	function group_enti_under_org_rel_sc_d_without_addmore(yes){
		if (yes=='yes'){
			
			/* clickable */
			cilckable();
			
			/* step0 */
			/* show up */
			$(".message_of_no_yes_yes").slideDown('slow');
			
			/* step0 */
			/* hide */
			$(".there_are_3_condition").slideUp('slow');
			$(".complete_the_survey_when_ready").slideUp('slow');
			
			/* change text skenario 1 */
			<?php if (!empty($subsidiaries)) {?>
			/* GM form */
			$(".skenario_1_g_membership").slideDown('slow');
			$(".left_m_group_memberships").slideDown('slow');
			$(".message_of_no_yes_yes_delete_all_GM").slideUp('slow');
			
			document.getElementById("skenario_no_yes_yes").innerHTML = "Based on your answers in the “Preliminary questions” step, you have group members to disclose. Please fill the forms below. You can add or delete group members as you see fit.";
			<?php } else{ ?>
			/* GM form */
			$(".skenario_1_g_membership").slideUp('slow');
			$(".left_m_group_memberships").slideUp('slow');
			$(".message_of_no_yes_yes_delete_all_GM").slideDown('slow');
			$(".save_and_continue").slideDown('slow');
			$('.save_and_continue').css({"float":"left"});
			<?php } ?>
			$('#list_gm_left').css({"top":"139px"});
		} else {
			/* clickable */
			cilckable();
			
			/* step0 */
			/* show up */
			$(".there_are_3_condition").slideDown('slow');
			$(".complete_the_survey_when_ready").slideDown('slow');
			
			/* step0 */
			/* hide */
			$(".message_of_no_yes_yes").slideUp('slow');
			HideFormGM();
		}
	}
		
	/* secondary activitis */
	<?php if (!empty($member->have_secondary_activities) && $member->have_secondary_activities == 'yes') { ?>
        $("#sector_secondary").slideDown('slow');
    <?php } else { ?>
        $("#sector_secondary").slideUp('slow');
    <?php } ?>
	function s_secondary_org(yes){
		if (yes=='yes')
		{
			$("#sector_secondary").slideDown('slow');
			$(".message_if_yes_secondary_act").slideDown('slow');
		} else {
			$("#sector_secondary").slideUp('slow');
			$(".message_if_yes_secondary_act").slideUp('slow');
            $("input[name='secondary_activity']:checked").prop('checked',false);
        }
	}
		
	/* organization_operates_globally */
	$(document).on('click','#organization_operates_globally',function(){
		if($('#organization_operates_globally').is(":checked")) {
			$(".dropdown_multiple_country_operate_in").slideUp('slow');
		} else {
			$(".dropdown_multiple_country_operate_in").slideDown('slow');
            $("#country option").attr("selected",false);
            $("#country").selectpicker('refresh');
		}
	});

	function next4(event){
	    event.preventDefault();
        var post_data = {intID:<?php echo $member->intID ?>, total:$("#total").val()};
        $("[id^='gm_']").each(function(data){
            temp = this.id.replace("gm_", "");
            temp = temp.replace("-y", "");
            temp = temp.replace("-n", "");
            temp = temp.replace("-r", "");
            temp = temp.replace("-o", "");
            if (this.type == 'radio') {
                if (this.checked) {
                    post_data[temp] = this.value;
                }
            } else {
                post_data[temp] = this.value;
            }
        });

        $.ajax({
            url: "<?php echo site_url('members/save_subsidiary'); ?>",
            method: "POST",
            data: post_data,
            type: "json",
            success: function(obj){
                var data = JSON.parse(obj);
                if (data.status == false) {
                    alert(data.message);
                } else {
                    $.each(data.data, function( index, value ) {
                        $("#gm_id"+index).prop({
                            value: value
                        });
                    });

                    SuccessColorboxConfirmSave();
                    setTimeout(parent.$.colorbox.close, 1200);	
                }
            }
        });
    }
    
    function next5(event){
        event.preventDefault();

        var post_data = {intID:<?php echo $member->intID ?>};
        post_data['declaration'] = $("input[name='declaration']:checked").val();

        if ($("input[name='declaration']").is(':checked')) {
            $.ajax({
                url: "<?php echo site_url('members/save_survey_temp'); ?>",
                method: "POST",
                data: post_data,
                type: "json",
                success: function(obj){
                    var data = JSON.parse(obj);
                    if (data.status == false) {
                        alert(data.message);
                    } else {
                        SuccessColorboxConfirmSave();
                        setTimeout(parent.$.colorbox.close, 1200);
                    }
                }
            });
        } else {
            SuccessColorboxConfirmSave();
            setTimeout(parent.$.colorbox.close, 1200);
        }

    }

    function saveGM(event){
	    next4(event);
    }

    $('#next_4').click(function(event){
        next4(event);

        $('#step5').trigger('click');
        $('html, body').animate({
            scrollTop: ($("#myTab").offset().top * 1) - 150
        }, 200);
    });

	/* step3 */
	$(document).ready(function(){

        if(location.hash=="#step1"){
            $('#step1').trigger('click');
        } else if (location.hash=="#step2") {
            $('#step2').trigger('click');
        } else if (location.hash=="#step3") {
            $('#step3').trigger('click');
        } else if (location.hash=="#step4") {
            $('#step4').trigger('click');
        }

        <?php if (empty($member->organization_operates_globally)) { ?>
            $(".dropdown_multiple_country_operate_in").slideDown('slow');
        <?php } else if ($member->organization_operates_globally == 'no') { ?>
            $(".dropdown_multiple_country_operate_in").slideDown('slow');
        <?php } else { ?>
            $(".dropdown_multiple_country_operate_in").slideUp('slow');
        <?php } ?>

        <?php if (isset($survey_questions['is_your_controller_by_a_parent']) && $survey_questions['is_your_controller_by_a_parent'] == 'yes') { ?>
            org_controlled_by_parent('yes');
        <?php } elseif (isset($survey_questions['is_your_controller_by_a_parent']) && $survey_questions['is_your_controller_by_a_parent'] == 'no') { ?>
            org_controlled_by_parent('no');
        <?php } ?>

        <?php if (isset($survey_questions['your_parent_member_of_rspo']) && $survey_questions['your_parent_member_of_rspo'] == 'yes') { ?>
            event_before_we_start_yes('yes');
        <?php } elseif (isset($survey_questions['your_parent_member_of_rspo']) && $survey_questions['your_parent_member_of_rspo'] == 'no') { ?>
            event_before_we_start_yes('no');
        <?php } ?>

        <?php if (isset($survey_questions['is_your_parent_involved_activi_related_po_sc']) && $survey_questions['is_your_parent_involved_activi_related_po_sc'] == 'yes') { ?>
            event_before_we_start_yes_no('yes');
        <?php } elseif (isset($survey_questions['is_your_parent_involved_activi_related_po_sc']) && $survey_questions['is_your_parent_involved_activi_related_po_sc'] == 'no') { ?>
            event_before_we_start_yes_no('no');
        <?php } ?>

        <?php if (isset($survey_questions['org_parent_gr_enti']) && $survey_questions['org_parent_gr_enti'] == 'yes') { ?>
            parent_group_entities('yes');
        <?php } elseif (isset($survey_questions['org_parent_gr_enti']) && $survey_questions['org_parent_gr_enti'] == 'no') { ?>
            parent_group_entities('no');
        <?php } ?>

        <?php if (isset($survey_questions['are_group_enti_under_y_orga_involved_rel_sc']) && $survey_questions['are_group_enti_under_y_orga_involved_rel_sc'] == 'yes') { ?>
            group_enti_under_org_rel_sc_d_without_addmore('yes');
        <?php } elseif (isset($survey_questions['are_group_enti_under_y_orga_involved_rel_sc']) && $survey_questions['are_group_enti_under_y_orga_involved_rel_sc'] == 'no') { ?>
            group_enti_under_org_rel_sc_d_without_addmore('no');
        <?php } ?>

		/* Type sector */
        <?php if (!empty($subsidiaries)) {
            $counter = 0;
            foreach($subsidiaries as $sub) {
                if (!empty($sub->type == 'other')) { ?>
                    $("#free_text_other_type<?php echo $counter; ?>").slideDown('slow');
                <?php } else { ?>
                    $("#free_text_other_type<?php echo $counter; ?>").slideUp('slow');
                <?php }
                $counter++;
            }
        } ?>
		if($('.type_sector_s3').is(":checked")) {
			var cek_other_val = $('.type_sector_s3').val();
			if(cek_other_val == 'other'){
				$(this).closest(".c_form_list").find(".free_text_other_type").slideDown('slow');
			} else{
				$(this).closest(".c_form_list").find(".free_text_other_type").slideUp('slow');
			}
		} else {
			$('.free_text_other_type').slideUp('slow');
		}
		$(document).on('click','.type_sector_s3',function(){
			
			var get_val_type_sector_s3 = $(this).val();
			// alert(get_val_type_sector_s3);
			
			if(get_val_type_sector_s3 == 'other'){
				$(this).closest(".c_form_list").find(".free_text_other_type").slideDown('slow');
			} else{
				$(this).closest(".c_form_list").find(".free_text_other_type").slideUp('slow');
			}
			
		});

		/* Is this group member an RSPO member? */
		<?php
            if (!empty($subsidiaries)) {
                $counter = 0;
                foreach($subsidiaries as $sub) {
                    if (!empty($sub->is_rspo_num) && $sub->is_rspo_num == 'yes') { ?>
                        $("#show_rspo_membership_number<?php echo $counter; ?>").slideDown('slow');
                <?php } else { ?>
                        $("#show_rspo_membership_number<?php echo $counter; ?>").slideUp('slow');
                    <?php }
            $counter++;}
            } else { ?>
                $("#show_rspo_membership_number0").slideUp('slow');
            <?php } ?>
        if($('.this_group_membership').is(":checked")) {
			var cek_is_no_gm_number_val = $('.this_group_membership').val();
			if(cek_is_no_gm_number_val == 'yes'){
				$(this).closest(".c_form_list").find(".show_rspo_membership_number").slideDown('slow');
			} else{
				$(this).closest(".c_form_list").find(".show_rspo_membership_number").slideUp('slow');
			}
		} else {
			$('.show_rspo_membership_number').slideUp('slow');
		}
		$(document).on('click','.this_group_membership',function(){

			var get_val_this_group_membership = $(this).val();
			// alert(get_val_type_sector_s3);

			if(get_val_this_group_membership == 'yes'){
				$(this).closest(".c_form_list").find(".show_rspo_membership_number").slideDown('slow');
			} else{
				$(this).closest(".c_form_list").find(".show_rspo_membership_number").slideUp('slow');
			}

		});
	});
	
	/* array auto fills */
    var val_array = [];
	var content = [];
	val_array = { <?php if (!empty($contacts)) {
            foreach ($contacts as $contact) {
				if(empty($contact->firstname) && empty($contact->lastname)){} 
				else{
					echo '"'.$contact->firstname.$contact->lastname.'":["'.$contact->firstname.'", "'.$contact->lastname.'", "'.$contact->email.'", "'.$contact->phone.'"],';
				} } } ?> };
	
	/* add more GM form */
	// $(document).on('click','a.g_m_add',function(){
	function g_m_add(element){
		add_more();
		
		/* auto fill */
		/* get id container div */
		// var content = parent.querySelector("div"); jika ingin mencari didalem div = alert(content.id);
		var curr_section = element.parentNode;
		var curr_section_id = '#'+curr_section.id;
		
		// console.log(curr_section);
		// console.log(curr_section_id);
		
		var get_fname = $(curr_section_id+' .gm_firstname_add').val();
		var get_lname = $(curr_section_id+' .gm_lastname_add').val();
		var get_email = $(curr_section_id+' .gm_email_add').val();
		var get_phone_n = $(curr_section_id+' .gm_phone_add').val();
		
		if(get_fname && get_lname){
			var GGD = '"'+get_fname+get_lname+'":["'+get_fname+'","'+get_lname+'","'+get_email+'","'+get_phone_n+'"],';
			for(var i = 0; i < GGD.length; i++) {
				content +=GGD[i];
			}
			
			var str_arr = content;
			var arr_res = str_arr.replace("[object Window]", "");
			
			array_g(arr_res);
			
			$('.sel_fill').append('<option value="'+get_fname+get_lname+'">'+get_fname+' '+get_lname+'</option>');
			// $('.contact_d_s, .sel_fill').css({"display":"block"});
			
			/* cek same value */
			$(".sel_fill option").each(function(){
				$(this).siblings("[value='"+ this.value+"']").remove();
			});
		} else{
			
		}
	}
	
	/* set array dorpdown autofill */
	function array_g(va){
		var va_db = <?php if(!empty($contacts)){
			echo "'";
			foreach($contacts as $contact){
				if(!empty($contact->firstname) && !empty($contact->lastname)){
					echo '"'.$contact->firstname.$contact->lastname.'":["'.$contact->firstname.'", "'.$contact->lastname.'", "'.$contact->email.'", "'.$contact->phone.'"],';
				}
			}
			echo "'";
		} else{ echo "''";}?> ;
			
		if(va === undefined){
			va = '';
		} else {
			va = va;
		}
		
		// console.log(va_db);
		// console.log(va);
			
		var va_db_and_arr_add = va_db + va;
			
		console.log(va_db_and_arr_add);
		
		var str_replace_last_comma = va_db_and_arr_add.replace(/,\s*$/, "");
		var text = '{'+ str_replace_last_comma + '}';
		val_array = JSON.parse(text);
	}
	
	/* choose from dropdown */
	function set_val_GM_info(element) {
		var curr_section = element.parentNode;
		var curr_section_id = '#'+curr_section.id;
		var value = element.value;
		
		console.log(curr_section_id);
		console.log(value);
			
		if(value){
			if (value.length == 0){}
			else {
				var catFName = "";
				var catLName = "";
				var catEmail = "";
				var catPhonenumber = "";
				
				for (categoryId in val_array[value]) {
					catFName = val_array[value][0];
					catLName = val_array[value][1];
					catEmail = val_array[value][2];
					catPhonenumber = val_array[value][3];
				}
				
				$(curr_section_id+" .gm_firstname_add").val(catFName);
				$(curr_section_id+" .gm_lastname_add").val(catLName);
				$(curr_section_id+" .gm_email_add").val(catEmail);
				$(curr_section_id+" .gm_phone_add").val(catPhonenumber);
			}
		}
	}
	
	/* get region */
	function getRegion(index){
        var country = $("#gm_country"+index).val();
        var post_data = {country: country};
        $.ajax({
            url: "<?php echo site_url('members/get_region'); ?>",
            method: "POST",
            data: post_data,
            type: "json",
            success: function(obj){
                var data = JSON.parse(obj);
                if (data.status == true) {
                    $("#gm_region"+index).val(data.data);
                }
            }
        });

        $.ajax({
            url: "<?php echo site_url('members/countrycode'); ?>",
            method: "POST",
            data: {c: country},
            type: "json",
            success: function(obj){
                $('#gm_phone'+index).intlTelInput("selectCountry", obj);
            }
        });
    }
	
		var count_gm = <?php echo $total_subs+1; ?>; // ini kalau ada data GM dari db need count GM to start autonumber
        function add_more(){
            /* append gm form */
            var componentGM1 = $('#componentGM1').html();
            var componentGM2 = $('#componentGM2').html();
            var componentGM3 = $('#componentGM3').html();
            var componentGM4 = $('#componentGM4').html();
            var componentGM5 = $('#componentGM5').html();
            var componentGM6 = $('#componentGM6').html();
            var componentGM7 = $('#componentGM7').html();
            // $(".list_of_gm").append(componentGM1);
            $(".list_of_gm").append(' <div id="new_gm" class="bg-f5f5f5 c_form_list"><a class="g_m_add" onClick="g_m_add(this); AnimateAddTarget(this);"><i class="fa fa-plus"></i> Add new group member</a><a class="g_m_del delete" id="new_delete"><i class="fa fa-times"></i> Delete this group member</a><div class="c_form_in">'+componentGM1+'<label class="margin-top-12" style="width:100%;">Nature of business*</label><div class="input-group"><select class="selectpicker show-tick form-control" title="Select nature of business" name="new_nature_of_business" id="new_nature_of_business">'+componentGM2+'</select><div id="err_new_nature_of_business" class="alert alert-danger" style="display:none"></div></div><div class="c2_left"><label>Country*</label><div class="input-group"><select class="selectpicker show-tick form-control" title="Select country" name="new_country" id="new_country">'+componentGM3+'</select></div><i style="position:absolute; margin-top:0px; font-size:11px; width:500px;">(The list of countries and regions are in accordance with the <a href="https://unstats.un.org/unsd/methodology/m49/" target="_blank">UN M49</a> standard)</i><div style="display:none; margin-bottom:5px; margin-left:-1px; margin-top:14px;" id="err_new_country" class="alert alert-danger"></div></div>'+componentGM4+'<div id="new_AUF" class="input-group">'+componentGM5+componentGM6+'</div>'+componentGM7+'</div></div> ');

            /* append anchor gm form */
            $(".GM_right").append('<li id="cAsyncGMlist'+ count_gm +'"><a id="Agm_name'+ count_gm +'" href="#gm'+ count_gm +'">New Group Membership</a></li>');

			$("#new_nature_of_business").prop({
                id: 'gm_nature_of_business'+count_gm,
                name: 'gm_nature_of_business'+count_gm
            });

            $("#err_new_nature_of_business").prop({
                id: 'err_gm_nature_of_business'+count_gm,
            });
			
			$('button[data-id="new_country"]').attr('data-id', 'gm_country'+count_gm );

            $("#new_country").prop({
                id: 'gm_country'+count_gm,
                name: 'gm_country'+count_gm
            }).attr('onchange', 'getRegion('+count_gm+')');

            $("#err_new_country").prop({
                id: 'err_gm_country'+count_gm,
            });
			
			$("#new_gm").prop({
                id: 'gm'+count_gm
            });
			
			$("#new_delete").attr({
                id: 'deleteGM'+count_gm,
                onClick: "delGM('"+count_gm+"', event)"
            });
			
			/* ================================ */

			$("#new_AUF").prop({
                id: 'gm_AUF_'+count_gm
            });
			
            $("#new_id").prop({
                id: 'gm_id'+count_gm,
                name: 'gm_id'+count_gm
            });

            $("#new_free_text_other_type").prop({
                id: 'free_text_other_type'+count_gm
            });

            $("#new_name").prop({
                id: 'gm_name'+count_gm,
                name: 'gm_name'+count_gm
            });

            $("#err_new_name").prop({
                id: 'err_gm_name'+count_gm,
            });

            $("#new_region").prop({
                id: 'gm_region'+count_gm,
                name: 'gm_region'+count_gm
            });
			
            $("#new_is_rspo_num-y").prop({
                id: 'gm_is_rspo_num'+count_gm+'-y',
                name: 'gm_is_rspo_num'+count_gm
            });

            $("#new_label_y").attr({
                id: 'g_is_rspo_num'+count_gm+'-y',
                for: 'gm_is_rspo_num'+count_gm+'-y'
            });

            $("#new_label_n").attr({
                id: 'g_is_rspo_num'+count_gm+'-n',
                for: 'gm_is_rspo_num'+count_gm+'-n'
            });

            $("#new_is_rspo_num-n").prop({
                id: 'gm_is_rspo_num'+count_gm+'-n',
                name: 'gm_is_rspo_num'+count_gm
            });

            var rand_r = 'gm_type'+count_gm+'-r';
            var rand_o = 'gm_type'+count_gm+'-o';

            $("#new_type_r").prop({
                id: rand_r,
                name: 'gm_type'+count_gm
            });

            $("#new_type_o").prop({
                id: rand_o,
                name: 'gm_type'+count_gm
            });

            $("#new_label_r").attr({
                id: 'g_type'+count_gm+'-r',
                for: rand_r
            });

            $("#new_label_o").attr({
                id: 'g_type'+count_gm+'-o',
                for: rand_o
            });

            $("#new_rspo_membership_num").prop({
                id: 'gm_rspo_membership_num'+count_gm,
                name: 'gm_rspo_membership_num'+count_gm
            });

            $("#err_new_rspo_membership_num").prop({
                id: 'err_gm_rspo_membership_num'+count_gm,
            });

            $("#new_other_type").prop({
                id: 'gm_other_type'+count_gm,
                name: 'gm_other_type'+count_gm
            });

            $("#err_new_other_type").prop({
                id: 'err_gm_other_type'+count_gm,
            });

            $("#new_num1").prop({
                id: 'num1'+count_gm,
                name: 'num1'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_num2").prop({
                id: 'num2'+count_gm,
                name: 'num2'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_num3").prop({
                id: 'num3'+count_gm,
                name: 'num3'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_num4").prop({
                id: 'num4'+count_gm,
                name: 'num4'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_num5").prop({
                id: 'num5'+count_gm,
                name: 'num5'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_firstname").prop({
                id: 'gm_firstname'+count_gm,
                name: 'gm_firstname'+count_gm
            });

            $("#err_new_firstname").prop({
                id: 'err_gm_firstname'+count_gm,
            });

            $("#new_lastname").prop({
                id: 'gm_lastname'+count_gm,
                name: 'gm_lastname'+count_gm
            });

            $("#err_new_lastname").prop({
                id: 'err_gm_lastname'+count_gm,
            });

            $("#new_email").prop({
                id: 'gm_email'+count_gm,
                name: 'gm_email'+count_gm
            });

            $("#err_new_email").prop({
                id: 'err_gm_email'+count_gm,
            });

            $("#new_phone").prop({
                id: 'gm_phone'+count_gm,
                name: 'gm_phone'+count_gm
            });

            $("#err_new_phone").prop({
                id: 'err_gm_phone'+count_gm,
            });

            $("#saveGM_new").prop({
                id: 'saveGM'+count_gm
            });

            $("#silentDelGM_new").attr({
                id: 'silentDelGM'+count_gm,
                onClick: "silentDelGM('"+count_gm+"')"
            });

            $("#total").val(count_gm);
            count_gm++;
            
			mobilenumber();
			$('.selectpicker').selectpicker('refresh');
			
			$(".message_of_no_yes_yes_delete_all_GM").slideUp('slow');
			$(".save_and_continue").slideDown('slow');
			$('.save_and_continue').css({"float":"right"});
			$(".left_m_group_memberships").slideDown('slow');
			<?php if ($is_parent) { ?>
			$(".skenario_1_g_membership").slideDown('slow');
			<?php } else{ ?>
			document.getElementById("skenario_no_yes_yes").innerHTML = "Based on your answers in the “Preliminary questions” step, you have group members to disclose. Please fill the forms below. You can add or delete group members as you see fit.";
			$(".skenario_1_g_membership").slideDown('slow');
			<?php } ?>
        }	
	
	/* animate */
	function AnimateAddTarget(curr_add_new_form) {
		/* scroll after add new form gm */
		var lastGMform = count_gm - 1;
		var curr_add_new_form = '#gm'+lastGMform;
		console.log('AnimateAddTarget() = '+curr_add_new_form);
		$('html, body').animate({
			scrollTop:( $(curr_add_new_form).offset().top * 1 ) - 150
		}, 800);
	}
	function AnimateScroll(){
		$('html, body').animate({
			scrollTop:( $('#line-steps').offset().top * 1 ) - 150
		}, 200);
	}
	function AnimateScroll190(){
		$('html, body').animate({
			scrollTop:( $('#line-steps').offset().top * 1 ) - 190
		}, 200);
	}
	
	/* delete form in target */
	function delGM(which, event){
		deleteColorboxConfirm();
			
		$('.process_delete').click(function(){
            var post_data = {id:$("#gm_id"+which).val()};
            $.ajax({
                url: "<?php echo site_url('members/delete_subsidiary'); ?>",
                method: "POST",
                data: post_data,
                type: "json",
                success: function(obj){
                    var data = JSON.parse(obj);
                    if (data.status == false) {
                        alert(data.message);
                    }
                }
            });
			$("#gm"+which).remove();
			$("#cAsyncGMlist"+which).remove();
			jQuery().colorbox.close();

            next4(event);

			var CountOfGM = $('.list_of_gm .c_form_list').length;
			console.log(CountOfGM);
			if(CountOfGM > 0){
				
			} else{
				$(".skenario_1_g_membership").slideUp();
				$(".left_m_group_memberships").slideUp();
				
				<?php if ($is_parent) { ?>
					$(".skenario_2_g_membership").slideDown('slow');
					$(".save_and_continue").slideDown('slow');
					$('.save_and_continue').css({"float":"left"});
				<?php } else { ?>
					$(".message_of_no_yes_yes_delete_all_GM").slideDown('slow');
					$(".save_and_continue").slideDown('slow');
					$('.save_and_continue').css({"float":"left"});
				<?php } ?>
			}

			$('.disclose_gm_we_dont').prop('checked', true);
		});
		$('.cancel_delete').click(function(){
			jQuery().colorbox.close();
		});
	}

	function silentDelGM(which){
            var post_data = {id:$("#gm_id"+which).val()};
            $.ajax({
                url: "<?php echo site_url('members/delete_subsidiary'); ?>",
                method: "POST",
                data: post_data,
                type: "json",
                success: function(obj){
                    var data = JSON.parse(obj);
                    if (data.status == false) {
                        alert(data.message);
                    }
                }
            });
			$("#gm"+which).remove();
			$("#cAsyncGMlist"+which).remove();

			var CountOfGM = $('.list_of_gm .c_form_list').length;
			console.log(CountOfGM);
			if(CountOfGM > 0){

			} else{
				$(".skenario_1_g_membership").slideUp();
				$(".left_m_group_memberships").slideUp();

				<?php if ($is_parent) { ?>
					$(".skenario_2_g_membership").slideDown('slow');
					$(".save_and_continue").slideDown('slow');
					$('.save_and_continue').css({"float":"left"});
				<?php } else { ?>
					$(".message_of_no_yes_yes_delete_all_GM").slideDown('slow');
					$(".save_and_continue").slideDown('slow');
					$('.save_and_continue').css({"float":"left"});
				<?php } ?>
			}

			$('.disclose_gm_we_dont').prop('checked', true);

	}
	
	/* delete confirm */
	var cboxOptions_deleteColorboxConfirm = {
		href: '#delete_confirm',
		inline:true, 
		width : '100%',
		maxWidth: "520px",
		maxHeight: "350px",
		fixed: true,
		close: false,
		onOpen: function(){
			$("#cboxClose").css("opacity", 0);
			$('#cboxOverlay').css({"background":"#000"});
		},
		onComplete: function(){
			$("#cboxClose").css({"opacity": 1});
			$('#cboxOverlay').css({"background":"#000"});
		},
		onClosed:function(){
			$("#cboxClose").css({"opacity": 0});
			$('#cboxOverlay').css({"background":"#000"});
		}
	}
	function deleteColorboxConfirm(){    
		$.colorbox(cboxOptions_deleteColorboxConfirm);
	}
	$(window).resize(function(){
		$.colorbox.resize({
			width: window.innerWidth > parseInt(cboxOptions_deleteColorboxConfirm.maxWidth) ? cboxOptions_deleteColorboxConfirm.maxWidth : cboxOptions_deleteColorboxConfirm.width,
			height: window.innerHeight > parseInt(cboxOptions_deleteColorboxConfirm.maxHeight) ? cboxOptions_deleteColorboxConfirm.maxHeight : cboxOptions_deleteColorboxConfirm.height
		});
	});
	
	/* success message submit */
	var cboxOptions_SuccessColorboxConfirm = {
		href: '#success_messages',
		inline:true, 
		width : '100%',
		maxWidth: "690px",
		maxHeight: "350px",
		fixed: true,
           escKey: false,
           overlayClose: false,
		onOpen: function(){
			$("#cboxClose").css("opacity", 0);
			$('#cboxOverlay').css({"background":"#000"});
		},
		onComplete: function(){
               $('#cboxClose').remove();
			$('#cboxOverlay').css({"background":"#000"});
		}
	}
	function SuccessColorboxConfirm(){    
		$.colorbox(cboxOptions_SuccessColorboxConfirm);
	}
	$(window).resize(function(){
		$.colorbox.resize({
			width: window.innerWidth > parseInt(cboxOptions_SuccessColorboxConfirm.maxWidth) ? cboxOptions_SuccessColorboxConfirm.maxWidth : cboxOptions_SuccessColorboxConfirm.width,
			height: window.innerHeight > parseInt(cboxOptions_SuccessColorboxConfirm.maxHeight) ? cboxOptions_SuccessColorboxConfirm.maxHeight : cboxOptions_SuccessColorboxConfirm.height
		});
	});

	/* success message save */
	var cboxOptions_SuccessColorboxConfirmSave = {
		href: '#success_messages_save',
		inline:true,
		width : '100%',
		maxWidth: "361px",
		maxHeight: "90px",
		fixed: true,
		bottom: 20, 
		right: 20,
		close: false,
		onOpen: function(){
			$("#cboxClose").css("opacity", 0);
			$('#cboxOverlay').css({"background":"transparent"});
		},
		onComplete: function(){
			$("#cboxClose").css({"opacity": 0});
			$('#cboxOverlay').css({"background":"transparent"});
		},
		onClosed:function(){
			$("#cboxClose").css({"opacity": 0});
			$('#cboxOverlay').css({"background":"transparent"});
		}
	}
	function SuccessColorboxConfirmSave(){
		$.colorbox(cboxOptions_SuccessColorboxConfirmSave);
	}
	$(window).resize(function(){
		$.colorbox.resize({
			width: window.innerWidth > parseInt(cboxOptions_SuccessColorboxConfirmSave.maxWidth) ? cboxOptions_SuccessColorboxConfirmSave.maxWidth : cboxOptions_SuccessColorboxConfirmSave.width,
			height: window.innerHeight > parseInt(cboxOptions_SuccessColorboxConfirmSave.maxHeight) ? cboxOptions_SuccessColorboxConfirmSave.maxHeight : cboxOptions_SuccessColorboxConfirmSave.height
		});
	});
	
	/* change organization */
	var cboxOptions_changeOrganizationsColorboxConfirm = {
		href: '#change_organization',
		inline:true, 
		width : '100%',
		height : '100%',
		maxWidth: "655px",
		maxHeight: "630px",
		fixed: true,
		close: false,
		onOpen: function(){
			$("#cboxClose").css("opacity", 0);
			$('#cboxOverlay').css({"background":"#000"});
		},
		onComplete: function(){
			$("#cboxClose").css({"opacity": 1});
			$('#cboxOverlay').css({"background":"#000"});
			$('body').css({"overflow-y":"hidden"});
		},
		onClosed:function(){
			$("#cboxClose").css({"opacity": 0});
			$('#cboxOverlay').css({"background":"#000"});
			$('body').css({"overflow-y":"unset"});
		}
	}
	function changeOrganizationsColorboxConfirm(){ 
		DetectChanges();
        if(formEdited) {
            $('#ignore-changes').show();
            $('#save-changes').show();
            $('#warning-before-changes').show();
            $('#default-changes').hide();
        } else {
            $('#ignore-changes').hide();
            $('#save-changes').hide();
            $('#warning-before-changes').hide();
            $('#default-changes').show();
        }
		$.colorbox(cboxOptions_changeOrganizationsColorboxConfirm);
	}
	$(window).resize(function(){
		$.colorbox.resize({
			width: window.innerWidth > parseInt(cboxOptions_changeOrganizationsColorboxConfirm.maxWidth) ? cboxOptions_changeOrganizationsColorboxConfirm.maxWidth : cboxOptions_changeOrganizationsColorboxConfirm.width,
			height: window.innerHeight > parseInt(cboxOptions_changeOrganizationsColorboxConfirm.maxHeight) ? cboxOptions_changeOrganizationsColorboxConfirm.maxHeight : cboxOptions_changeOrganizationsColorboxConfirm.height
		});
	});
	
	/* sync GM list with anchor */
	function syncGMlist(getid) {
		var id = getid.getAttribute('id');
		var value = getid.value;
		
		/* text in a href */
		var string_anchor = document.getElementById("A"+id).innerHTML;
		if(string_anchor.length > 0){
			document.getElementById("A"+id).innerHTML = value;
		} else{
			document.getElementById("A"+id).innerHTML = 'New Group Membership';
		}
	}
	
	/* after delete all GM need to confirm disclose or not */
	$(document).on('click','.disclose_gm',function(){

		var get_val_disclose = $(this).val();
		console.log(get_val_disclose);
		// alert(get_val_disclose); 
		// we-do-not-have-group-member 
		// we-wish-to-disclose-group-member 
		
		if(get_val_disclose == 'yes'){
			$(this).closest(".s_group_membership").find(".skenario_1_g_membership").slideUp('slow');
		} else{
			/* add more GM form */
			add_more();
			$(this).closest(".s_group_membership").find(".left_m_group_memberships").slideDown('slow');
			$(this).closest(".s_group_membership").find(".skenario_1_g_membership").slideDown('slow');
			
			$(this).closest(".s_group_membership").find(".skenario_2_g_membership").slideUp('slow');
			
			$('.save_and_continue').css({"float":"right"});
		}

	});
	
	/* submit step3 */
	$('#c_f_n').on('click', function(){
		if ($('#c_f_n').is(':checked'))
		{
			$('#btnSubmit').attr('disabled', false);
		} else {
			$('#btnSubmit').attr('disabled', true);
		}
	});
</script>
<script type="text/javascript">
    /*Scroll Spy*/
	$(document).ready(function(){
		var offset_top = 650;
		$('body').scrollspy({ target: '#list_gm_left', offset:offset_top});
		if (window.innerWidth <= 1100)
		{
			$('#nav').affix({
				offset: {
					top: $('#list_gm_left').offset().top + offset_top, // set left timeline sticky
					bottom: $('footer').outerHeight(true) + 80
				}
			});
		} else{
			$('#nav').affix({
				offset: {
					top: $('#list_gm_left').offset().top + offset_top, // set left timeline sticky
					bottom: $('footer').outerHeight(true) + 80
				}
			});
		}
		$(window).resize(function() {
			if (window.innerWidth <= 1100)
			{
				$('#nav').affix({
					offset: {
						top: $('#list_gm_left').offset().top + offset_top, // set left timeline sticky
						bottom: $('footer').outerHeight(true) + 80
					}
				});
			} else{
				$('#nav').affix({
					offset: {
						top: $('#list_gm_left').offset().top + offset_top, // set left timeline sticky
						bottom: $('footer').outerHeight(true) + 80
					}
				});
			}
		});
		
		$('html, body').animate({
			scrollTop: ($("#list_gm_left").offset().top * 1) - offset_top
		}, 200);
	});

	/* back to top */
	$(window).scroll(function(){
		if ($(this).scrollTop() > 514) {
			$('.backtoTop').fadeIn();
		} else {
			$('.backtoTop').fadeOut();
		}
	});
	$('.backtoTop a').click(function(){
		$('html, body').animate({scrollTop : 0},800);
		return false;
	});
	
    /*Smooth link animation*/
	// $('#list_gm_left a[href*=#]:not([href=#])').click(function() {
	$(document).on('click','#list_gm_left a[href*=#]:not([href=#])',function(){
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {

            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
				/* $('html,body').animate({
                    scrollTop: target.offset().top
                }, 1000); */
                $('html,body').animate({
                    scrollTop: target.offset().top  - 30
                }, 1000);
                return false;
            }
        }
    });

   function implodeNumber(counter) {
       var member_num = [
           $("#num1"+counter).val(),
           $("#num2"+counter).val(),
           $("#num3"+counter).val(),
           $("#num4"+counter).val(),
           $("#num5"+counter).val()
       ];
       $("#gm_rspo_membership_num"+counter).val(member_num.join("-"));
   }
	
    function implodeNumberQuestion(counter) {
        var member_num = [
            $("#num1"+counter).val(),
            $("#num2"+counter).val(),
            $("#num3"+counter).val(),
            $("#num4"+counter).val(),
            $("#num5"+counter).val()
        ];
        $("#deemed_complience_rspo_new_gm_parent_rspo_membership_number").val(member_num.join("-"));
    }

	$(document).ready(function(){
		/* membernumber next auto */
		$(document).on('keyup','.membership_number input',function(){
			if($(this).val().length==$(this).attr("maxlength")){
				$(this).next('span').next().focus();
			}
		});
		
		/* focus text clear val */
		$(document).on('focus','.membership_number input',function(){
			// pertama load, cek apa sudah ada val
			// kalau gak ada, simpen val sekrang ke data()
			if (!$(this).data('defaultText')) $(this).data('defaultText', $(this).val());

			// cek apakah data sama
			if ($(this).val()==$(this).data('defaultText')) $(this).val('');
		});

		$(document).on('blur','.membership_number input',function(){
			// jika gak ada val maka set defaultText
			if ($(this).val()=='') $(this).val($(this).data('defaultText')); 
		});
	});
</script>