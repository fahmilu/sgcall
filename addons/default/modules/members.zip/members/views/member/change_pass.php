<style>
	.border-top-gray {
		border-top: none;
	}
	.btn {
		border-radius: 0px;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
	.alert-success {
		border-radius: 3px;
		font-size: 14px;
		margin: 0px auto;
		border: 1px solid transparent;
	}
	.alert-warning{
		border-color: tranparent;
		border-radius: 3px;
		font-size: 14px;
		width: 400px;
		margin: 0 auto;
	}
	.alert-danger{
		border:none;
		border-radius: 3px;
		font-size: 14px;
	}
	.alert-success a, .alert-danger a, .alert-warning a{
		color:#000!important;
	}
</style>
<style type="text/css">
    .contact-form{ margin-top:15px;}
	.contact-form .textarea{ min-height:220px; resize:none;}
	.form-control{ box-shadow:none; border-color:#eee; height:45px;}
	.form-control:focus{ box-shadow:none; border-color:#00b09c;}
	.form-control-feedback{ line-height:50px;}
	.main-btn{ background:#00b09c; border-color:#00b09c; color:#fff;}
	.main-btn:hover{ background:#00a491;color:#fff;}
	.form-control-feedback {
		line-height: 50px;
		top: 0px;
	}
</style>
	
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.2/css/bootstrapValidator.min.css"/>
<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.2/js/bootstrapValidator.min.js"></script>

<section id="contact_detail">
	<div class="container text-center">
		<h1 style="font-weight: bold; margin-top:24px; margin-bottom:25px; font-size: 25px; padding-top:3px; text-transform:uppercase;">Change Password</h1>	
	</div>
	
	<div class="container">
	<div class="row">
		<div class="contain300">	
			
			<?php if(!empty($success_string)):?>
				
				<div class="alert alert-success no-margin-bottom">
					<?php echo $success_string;?> Please click <a href="{{url:site}}members/login">here</a> to log in.
				</div>
			
			<?php elseif(!empty($error_link_already_used)):?>
				
				<div class="alert alert-danger no-margin-bottom">
					<?php echo $error_link_already_used;?> Please click <a href="{{url:site}}members/login">here</a> to log in.
				</div>
			
			<?php else:?>
			
				<?php echo form_open('members/change_pass/'.$code_address, array('id'=>'change_pass')) ?>
				
				<?php if(!empty($error_string)):?>
					<div class="alert alert-danger margin-bottom-20">
						<?php echo $error_string;?>
					</div>
				<?php endif;?>
				
				<div class="box-contact-form organisation">
					<div class="form-group">
						<label>New password</label>
						<input type="password" class="form-control" name="changepassword" placeholder="New password" />
					</div>

					<div class="form-group">
						<label>Confirm password</label>
						<input type="password" class="form-control" name="confirmPassword" placeholder="Confirm password" />
					</div>
						
					<div class="form-group text-right" style="margin-bottom:0px;">
						<input type="submit" value="SUBMIT" class="btn btn-lg btn-orange btnconfirm">
					</div>
				</div>
				</form>	
					
				<script type="text/javascript">
					$(document).ready(function() {
						$('#change_pass').bootstrapValidator({
								feedbackIcons: {
									//valid: 'glyphicon glyphicon-ok',
									//invalid: 'glyphicon glyphicon-remove',
									//validating: 'glyphicon glyphicon-refresh'
								},
								fields: {
									changepassword: {
										enabled: false,
										validators: {
											notEmpty: {
												message: 'You must enter a new password.'
											},
											identical: {
												field: 'confirmPassword',
												message: 'The password you have entered here does not match the one below.'
											}
										}
									},
									confirmPassword: {
										//enabled: false,
										validators: {
											notEmpty: {
												message: 'You must confirm your password.'
											},
											identical: {
												field: 'changepassword',
												message: 'The password you have entered here does not match the one above.'
											}
										}
									}
								}
							})
							// Enable the password/confirm password validators if the password is not empty
							.on('keyup', '[name="confirmPassword"]', function() {
								var isEmpty = $(this).val() == '';
								$('#change_pass')
										.bootstrapValidator('enableFieldValidators', 'changepassword', !isEmpty)
										.bootstrapValidator('enableFieldValidators', 'confirmPassword');

								// Revalidate the field when user start typing in the password field
								if ($(this).val().length == 5) {
									$('#change_pass').bootstrapValidator('validateField', 'confirmPassword')
													.bootstrapValidator('enableFieldValidators', 'changepassword', !isEmpty);
								}
							})
							.on('keyup', '[name="changepassword"]', function() {
								
								var isEmpty = $(this).val() == '';
								if ($(this).val() == '') {
									$('#change_pass').bootstrapValidator('enableFieldValidators', 'confirmPassword', !isEmpty);
								}

							});
					});
				</script>
			<?php endif;?>
		</div>
	</div>
	</div>
</section>