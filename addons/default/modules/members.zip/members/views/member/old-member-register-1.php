<section id="contact_detail">
	<div class="container text-center">
		<h1>RSPO MEMBER REGISTRATION</h1>

	</div>

	<div class="clearfix"><br /></div>

	<div class="container">
		<div class="row">

		<div class="contain800">

			<div class="col-lg-6">
				<div class="bordered-tb">
					<p>This registration initiative is intended for active RSPO members who do not yet have login accounts on RSPO.org. Logging in will allow you to review and edit your member profile.</p> 

					<p>Members who in 2015 applied for their membership online can still use their username and password and do not have to re-register.</p>

					<p>If you have submitted your registration, but have not received the activation code, please <a href="<?php echo site_url('members/resend') ?>">click here</a>. The Activation code will be sent to the email used during the registration process.
					</p>

				</div>

			</div>

		<div class="col-lg-6">
		<!-- right column starts -->
		<div class="container-login-page">

			<?php echo form_open('', 'id="frmExisting" name="frmExisting"') ?>

			<?php if(!empty($step_msg)): ?>
			<div class="alert alert-danger">
				<?php echo $step_msg ?>
			</div>
			<?php endif;?>

			<div class="div_overlay" id="pleasewait">
				<div class="div_spin">
					<p><b>Please wait&hellip;</b></p>
					<div class="clearfix"></div>
					<p class="fa fa-cog fa-spin fa-2x"></p>
				</div>
			</div>


			<div class="box-contact-form organisation" style="margin-top:0px;">

				<div id="form_element">

					<label>Email <small style="font-weight:normal;"><br />Please use only the email that made the application for your company's RSPO membership. If you are unsure, please contact the Membership Department at this email address <a href="mailto:membership@rspo.org">here</a></small></label>
					<div class="clearfix"></div>
					<div class="input-group <?php echo form_error('email') ? 'has-error' : '' ?>">
						<?php $disabled = ( form_error('email') OR form_error('company_id') ) ? '' : 'disabled="disabled"' ?>
						<input style="border-right:0;" autocomplete="off" type="text" class="form-control" value="<?php echo set_value('email') ?>" name="email" placeholder="Your email" id="email_field" aria-describedby="edit-email">
						<span class="input-group-addon" id="edit-email" style="border-left:0;"><i class="fa fa-lg fa-fw fa-envelope"></i></span>
					</div>
						<?php echo form_error('email') ? '<div id="email_field_error" class="email_field_error text-danger">'.form_error('email').'</div>' : '' ?>

					<div class="clearfix"><br /></div>
				
					<label>
						Company/Organisation
						<small style="font-weight:normal;"><br />Please fill with your company/organization</small>
					</label>

					<?php if (isset($step2)) $disabled = false; else $disabled = true; ?>

					<div class="input-group <?php echo form_error('company_id') ? 'has-error' : '' ?>" id="country-dropdown">
						<input style="border-right:0;width:100%;" autocomplete="off" type="text" class="form-control" value="<?php echo htmlspecialchars_decode( set_value('company_name') ) ?>" name="company_name" id="company_name" placeholder="Your company or organisation name" aria-describedby="edit-company">
						<?php $icon =  $disabled != TRUE ? 'fa-exclamation red' : 'fa-building' ?>
						<span class="input-group-addon" id="edit-company" style="border-left:0;"><i class="fa fa-lg fa-fw <?php echo $icon ?>"></i></span>
					</div>
					<?php echo form_error('company_id') ? '<div id="company_error" class="text-danger">'.form_error('company_id').'</div>' : '' ?>
					<input type="hidden" name="company_id" id="company_id" value="<?php echo set_value('company_id') ?>" />

					<div class="clearfix"><br /></div>

					<div id="pwdsection" style="position:relative;">

						<div id="formfeedback">
						</div>

						<div class="input-group <?php echo form_error('password') ? 'has-error' : '' ?>" style="display: block;">
							<label class="control-label">Password</label>
							<input <?php echo $disabled ? 'disabled="disabled"' : '' ?> type="password" class="form-control pwdfield" value="" name="password" placeholder="Your password" />
						</div>
							<?php echo form_error('password') ? '<div class="text-danger">'.form_error('password').'</div>' : '' ?>

						<div class="clearfix"><br /><br /></div>

						<div class="input-group <?php echo form_error('password2') ? 'has-error' : '' ?>" style="display: block;">
							<label class="control-label">Confirm your Password</label>
							<input <?php echo $disabled ? 'disabled="disabled"' : '' ?> type="password" class="form-control pwdfield" value="" name="password2" placeholder="Confirm your password" />
						</div>
							<?php echo form_error('password2') ? '<div class="text-danger">'.form_error('password2').'</div>' : '' ?>

					</div>

				</div>

				<div class="clearfix"><br /><br /><p>&nbsp;</p></div>

				<div class="form-group" style="margin-bottom:0px; display: block; text-align:right;">
					<input type="submit" value="REGISTER" class="btn btn-lg btn-orange" style="border-radius:3px; margin-right:0px;">
				</div>

				<?php if (isset($step2)): ?>
					<input type="hidden" name="step2" value="" />
				<?php endif; ?>

			</div>

		</form>
		<!-- right column ends -->
		</div>

		</div> <!-- contain800 -->

	</div>
</section>

<?php $this->load->view('member/old-member-static'); ?>

<script>
document.frmExisting.email.focus();
</script>