<style>
	.btn {
		border-radius: 0px;
		padding: 11.4px 12px;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
</style>
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading">RESEND ACCOUNT ACTIVATION</h3>	
	</div>
	<div class="container">
		<div class="row">

			<?php echo form_open('members/resend', 'id="resendcode"') ?>
			<div class="col-md-offset-3 col-md-6 col-sm-12 col-xs-12">

				<?php if(!empty($error_string)): ?>
					<div class="alert alert-danger">
						<?php echo $error_string ?>
					</div>
				<?php endif; ?>

				{{ session:messages success="alert alert-success" notice="alert alert-info" error="alert alert-danger" }}

				<!-- <div class="box-contact-form organisation"> -->

				<p>Enter the email address you used to register to RSPO.org below to resend the activation code.</p>

				<div class="form-group">
					<label>Email</label>
					<input type="text" class="form-control" name="email" placeholder="Your email" />
				</div>

				<div class="form-group text-right" style="margin-bottom:0px;">
					<input type="submit" value="RESEND" class="btn btn-lg btn-orange" style="border-radius:3px;">
				</div>

				<!-- </div> -->
			</div>
		</form>
	</div>
</section>


