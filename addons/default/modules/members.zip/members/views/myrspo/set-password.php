<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<section class="set_password">
	<div class="container-1080 text-center">
		<h1>Set new password</h1>
	</div>
	<div class="container-600 text-center">
		<p>Verification successful. You may now set your MyRSPO password. You can change this password later via the MyRSPO profile page.</p>
	</div>
    <div class="clear"></div>

    <form action="/members/myrspo-set-password/<?php echo $data; ?>" method="post" >
	<div class="container-380 bg-f5f5f5">
		<label>New password</label>
		<div class="input-group">
			<input autocomplete="off" type="password" class="form-control" name="newPassword" id="" placeholder="">
            <?php echo form_error('newPassword')? '<div class="alert alert-danger">' . form_error('newPassword') . '</div>' : ''; ?>
		</div>
		
		<label>Confirm new password</label>
		<div class="input-group">
			<input autocomplete="off" type="password" class="form-control" name="confirmNewPassword" id="" placeholder="">
            <?php echo form_error('confirmNewPassword')? '<div class="alert alert-danger">' . form_error('confirmNewPassword') . '</div>' : ''; ?>
		</div>
		
		<input type="submit" value="Save password & proceed to MyRSPO" class="btn btn-lg btn-black">
	</div>
    </form>
</section>