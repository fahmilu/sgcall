<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<section class="set_activate_activate">
	<div class="container-1080 text-center">
		<h1>MyRSPO account activation</h1>
	</div>
	<div class="container-600 text-center">
		<!-- <p></p> -->
	</div>
    <?php echo form_open('members/myrspo-account-activation'); ?>
	<div class="container-380 bg-f5f5f5">
		<label>Email</label>
		<div class="input-group">
			<input autocomplete="off" type="text" class="form-control" value="<?php echo set_value('email') ?>" name="email" id="" placeholder="">
            <?php echo form_error('email')? '<div class="alert alert-danger">' . form_error('email') . '</div>' : ''; ?>
		</div>
		
		<label>Verification code</label>
		<div class="input-group">
			<input autocomplete="off" type="text" class="form-control" value="<?php echo set_value('activation_code') ?>" name="activation_code" id="" placeholder="">
            <?php echo form_error('activation_code')? '<div class="alert alert-danger">' . form_error('activation_code') . '</div>' : ''; ?>
		</div>
		
		<div class="align-right">
			<input type="submit" value="Activate" class="btn btn-lg btn-black">
		</div>
	</div>
    <?php echo form_close(); ?>
</section>