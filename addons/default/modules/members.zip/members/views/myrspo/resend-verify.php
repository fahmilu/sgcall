<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<section id="myrspo_resend_verify" class="set_password">
	<div class="container-1080 text-center">
		<h1>MyRSPO resend verification email</h1>
	</div>

	<?php if($this->session->flashdata('error')) { ?>
    <div class="container-600 text-center">
        <div class="set_password">
            <div class="input-group">
                <p class="alert alert-danger">
                    <p><?php echo $this->session->flashdata('error'); ?></p>
                </div>
            </div>
        </div>
    </div>
	<?php } else { ?>
        <div class="container-600 text-center">
            <p>Please fill in the form below if you did not receive your verification code.</p>

            <?php if($this->session->flashdata('success')) { ?>
                <p><?php echo $this->session->flashdata('success'); ?></p>
            <?php } ?>
        </div>
    <?php } ?>

    <form action="" method="post">
		<div class="container-380 bg-f5f5f5">
			<label style="float:left;">Organization name</label>
            <div class="input-group <?php echo form_error('company_id') ? 'has-error' : '' ?>" id="country-dropdown">
                <input autocomplete="off" type="text" class="form-control" value="<?php echo htmlspecialchars_decode( set_value('company_name') ) ?>" name="company_name" id="company_name" placeholder="Enter & choose from autocomplete suggestion">
                <input type="hidden" name="company_id" id="company_id" value="<?php echo set_value('company_id') ?>" />
                <?php echo form_error('company_name')? '<div class="alert alert-danger">' . form_error('company_name') . '</div>' : ''; ?>
            </div>
			
			<label style="float:left;">Contact Person’s email address</label>
			<div class="input-group <?php echo form_error('email') ? 'has-error' : '' ?>">
				<input autocomplete="off" type="" class="form-control" name="email" value="<?php echo set_value('email') ?>" placeholder="">
                <?php echo form_error('email')? '<div class="alert alert-danger">' . form_error('email') . '</div>' : ''; ?>
				<?php echo form_error('name_last_s')? '<div class="alert alert-danger">' . 'This field is req' . '</div>' : ''; ?>
            </div>

			<input type="submit" value="Resend verify" class="btn btn-lg btn-black">
		</div>
    </form>
</section>

<script>
    $(document).ready(function(){
    $('input[class=form-control]').on('blur', function(){
        if ($(this).val())
        {
            $(this).parent().removeClass('has-error');
            //$(this).parent().next('.text-danger').fadeTo('fast', 0);
            //$(this).parent().next('.text-danger').css('display', 'none');
        }
    });

    var m = '<?php echo set_value('member') ?>';
    if (m)
        $("#company_name").val(m);
    $("#company_name").autocomplete({
        minLength: 2,
        appendTo: '#country-dropdown',
        source: "<?php echo site_url('members/pickactive') ?>",
        select: function (event, ui) {
            $('#company_id').val(ui.item.id);
            $('#company_name').val(ui.item.value);
        },
        search: function() {
            var e = $('#company_name').val();
            if (e=='')
            {
                $('#company_name').focus();
                $('#company_id, #company_name').val('');
                return false;
            }
            $('#company_id').val('');
        }
    });
        $('a.cbox').colorbox();
    });
</script>