<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<section class="i_success">
	<div class="container-1080 text-center">
		<h1>Thank you for registering</h1>
	</div>
	<div class="container-600 text-center">
        <p>A verification email has been sent to <strong><?php echo $email; ?></strong><?php if (!empty($email_list)) {?>, and <strong><?php echo $email_list; ?></strong> have also been notified<?php } ?>.</p>
        <p>If you have registered, but did not receive an activation code, please <a onclick="resent(<?php echo $id; ?>);" href="#">click here</a> to have it resent. If the problem persists, please contact <a href="mailto:membership@rspo.org">RSPO Membership</a>.</p>
	</div>
</section>

<script>

    function resent (id){
        var post_data = {id:id};
        $.ajax({
            url: "<?php echo site_url('members/resend_myrspo_activation'); ?>",
            method: "POST",
            data: post_data,
            type: "json",
            success: function(obj){

                console.log(obj);
            }
        });

    }
</script>