<style>.ui-helper-hidden-accessible{display:none;}</style>
<section id="myrspo">
	<div class="container-1080 text-center myrspo_title">
		<h1>MyRSPO Registration</h1>
	</div>

	<div class="container-820 margin-top-33">
	<div class="row">
		<div class="left_myrspo col-lg-6">
			<div class="bordered_left_myrspo">
				<p>Welcome to MyRSPO Registration.</p>
			
				<p>MyRSPO is an online members portal that allows you to update your membership profile and details. The creation of a user accounts in MyRSPO will also provide you with a single sign-on to participate in the Annual Communications of Progress (ACOP) reporting.</p>

				<p>Please contact <a href="mailto:membership@rspo.org">membership@rspo.org</a> for assistance on creating the MyRSPO user account.</p>
				
				<p>If you did not receive an activation code after clicking “verify”, please <a href="<?php echo site_url('members/myrspo-resend-verification-email') ?>">click here</a> to have it resent.</p>
			</div>
		</div>

		<div class="right_myrspo col-lg-6">
			<!-- right column starts -->
			<div class="container-login-page">
			<?php echo form_open('', 'id="frmExisting" name="frmExisting"') ?>

				<?php if(!empty($step_msg)): ?>
				<div class="alert alert-danger">
					<?php echo $step_msg ?>
				</div>
				<?php endif;?>

				<div class="div_overlay" id="pleasewait">
					<div class="div_spin">
						<p><b>Please wait&hellip;</b></p>
						<div class="clearfix"></div>
						<p class="fa fa-cog fa-spin fa-2x"></p>
					</div>
				</div>

				<div class="box-contact-form organisation">
					<div id="form_element">
						<small>Please enter your organization name and RSPO membership number. The two must match before you can proceed.</small>
						
						<label>Organization name</label>
						<small class="margin-bottom-10">Start typing on the box below and select your organization's name from the dropdown.</small>
						<?php if (isset($step2)) $disabled = false; else $disabled = true; ?>
						<div class="input-group <?php echo form_error('company_id') ? 'has-error' : '' ?>" id="country-dropdown">
							<input autocomplete="off" type="text" class="form-control" value="<?php echo htmlspecialchars_decode( set_value('company_name') ) ?>" name="company_name" id="company_name" placeholder="Enter & choose from autocomplete suggestion" />
							<input type="hidden" name="company_id" id="company_id" value="<?php echo set_value('company_id') ?>" />
						</div>
						<div id="company_name_error" class="text-danger" style="display:none; font-size:12px; position:absolute;"></div>
						<?php echo form_error('company_id') ? '<div id="company_error" class="text-danger">'.form_error('company_id').'</div>' : '' ?>
						
						<label>RSPO membership number</label>
						<div class="input-group membership_number">
							<input id="m_number1" autocomplete="off" type="text" class="m_number form-control membership_number1" value="0" name="num[]" placeholder="" maxlength="1">
							<span>&#8722;</span>
							<input id="m_number2" autocomplete="off" type="text" class="m_number form-control membership_number2" value="0000" name="num[]" placeholder="" maxlength="4">
							<span>&#8722;</span>
							<input id="m_number3" autocomplete="off" type="text" class="m_number form-control membership_number3" value="00" name="num[]" placeholder="" maxlength="2">
							<span>&#8722;</span>
							<input id="m_number4" autocomplete="off" type="text" class="m_number form-control membership_number4" value="000" name="num[]" placeholder="" maxlength="3">
							<span>&#8722;</span>
							<input id="m_number5" autocomplete="off" type="text" class="m_number form-control membership_number5" value="00" name="num[]" placeholder="" maxlength="2">
						</div>
					</div>

					<div class="show_list_email_and_complete" style="display: none;">
						<small class="margin-bottom-15">The following 4 emails are listed under your organization, but only the Contact Person’s email (in green) can be used to create the single sign-on account. They are masked for security purposes.</small>
						<small class="margin-bottom-15">Please type in the complete address below and click “verify”.</small>
						<small class="margin-bottom-15">If you don’t recognize the email or it’s no longer active, please contact <a href="mailto:membership@rspo.org">RSPO Membership</a>.</small>

						<label>Primary contact</label>
						<div id="contact_p" class="input-group">
							<input autocomplete="off" type="text" class="form-control" value="" name="email_p" id="email_p" readonly="readonly">
						</div>
                        <div id="user_p_notif" class="alert_has_registered">Email already registered, <a href="<?php echo base_url('members/forget') ?>" target="_blank">forgot password?</a></div>

						<label>Secondary contact</label>
						<div id="contact_s"  class="input-group">
							<input autocomplete="off" type="text" class="form-control" value="" name="email_s" id="email_s" readonly="readonly">
						</div>
                        <div id="user_s_notif" class="alert_has_registered">Email already registered, <a href="<?php echo base_url('members/forget') ?>" target="_blank">forgot password?</a></div>

						<label>Finance contact</label>
						<div id="contact_f"  class="input-group">
							<input autocomplete="off" type="text" class="form-control" value="" name="email_f" id="email_f" readonly="readonly">
						</div>
                        <div id="user_f_notif" class="alert_has_registered">Email already registered, <a href="<?php echo base_url('members/forget') ?>" target="_blank">forgot password?</a></div>

						<label>Contact person</label>
						<div id="contact_c" class="input-group">
							<input autocomplete="off" type="text" class="form-control" value="" name="contact_email" id="contact_email" readonly="readonly">
						</div>
                        <div id="user_c_notif" class="alert_has_registered">Email already registered, <a href="<?php echo base_url('members/forget') ?>" target="_blank">forgot password?</a></div>

						<label>Enter the complete email address that you like to register</label>
						<div class="input-group">
							<input autocomplete="off" type="text" class="form-control" value="" name="registering_email" id="email_contact" placeholder="Enter complete email address">
						</div>

					</div>

					<div class="form-group align-right">
						<input type="submit" value="Submit" class="btn btn-lg btn-black" id="submit">
					</div>

					<?php if (isset($step2)): ?>
						<input type="hidden" name="step2" value="" />
					<?php endif; ?>
				</div>
				<div class="alert_didnotmatch" style="display:none;">
					<p>The organization name and RSPO membership number do not match. Please try again, or if the problem persists, contact <a href="mailto:membership@rspo.org">RSPO Membership</a>.</p>
				</div>
				<div class="alert_incorrect_contact_person_email" style="display:none;">
					<p>No Contact Person email is registered under your organization. Please contact <a href="mailto:membership@rspo.org">RSPO Membership</a> to submit one. You will need to prepare a name along with his or her position, email, and phone number.</p>
				</div>
				<div class="alert_has_previously_registered" style="display:none;">
					<p>Your organization is already registered. If you do not remember your account username, please contact <a href="mailto:membership@rspo.org">RSPO Membership</a>.</p>
				</div>
				<div class="alert_does_not_contain_contact_person" style="display:none;">
					<p>No Contact Person email is registered under your organization. Please contact <a href="mailto:membership@rspo.org">RSPO Membership</a> to submit one. You will need to prepare a name along with his or her position, email, and phone number.</p>
				</div>
			</form>
			</div>
		</div>
	</div>
</section>

<div style='display:none'>
    <div id='alert_message' class="popup_custom_by_am">
        <div class="t_popup">
            <h2>Connection time out</h2>
        </div>
        <div class="c_popup">
            <p>Sorry, the connection to our server timed-out, please try again.</p>
            <a class="btn btn-lg btn-black back-to-myrspo-reg">Back to MyRSPO registration</a>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){
	
	$('.back-to-myrspo-reg').click(function(){
        jQuery().colorbox.close();
    });
    
	$('input[class=form-control]').on('blur', function(){
		if ($(this).val())
		{
			$(this).parent().removeClass('has-error');
			//$(this).parent().next('.text-danger').fadeTo('fast', 0);
			//$(this).parent().next('.text-danger').css('display', 'none');
		}
	});
	
	$("#company_name").on('focusout', function(){
        var company_id = $("#company_id").val();
        var company_name = $("#company_name").val();
        $('#company_name_error').hide();
        if(company_id.length < 1 && company_name.length < 1) {
            $("#company_id").val('');
            $("#company_name_error").text('Field is required');
            $('#company_name_error').show();
        } else if (company_id.length < 1 ) {
            $("#company_id").val('');
            $("#company_name_error").text("Please select your organization's name from the dropdown");
            $('#company_name_error').show();
        }
    });
    
	var m = '<?php echo set_value('member') ?>';
	if (m)
		$("#company_name").val(m);

	$("#company_name").autocomplete({
		minLength: 2,
		autoFocus: true,
		appendTo: '#country-dropdown',
	    source: "<?php echo site_url('members/pickactive') ?>",
	    select: function (event, ui) {
	    	$('#company_id').val(ui.item.id);
	    	$('#company_name').val(ui.item.value);
		},
		search: function() {
			var e = $('#company_name').val();
	    	if (e=='')
	    	{
		    	$('#company_name').focus();
		    	$('#company_id, #company_name').val('');
	    		return false;
	    	}
	    	$('#company_id').val('');
		},
		response: function(event, ui) {
            if (!ui.content.length) {
                var not_found = { value:"",label:"No organization found" };
                ui.content.push(not_found);
            }
        }
	});
	
	function AlertMessage(){
        $.colorbox({
            href: '#alert_message',
            inline:true,
            maxWidth: "520px",
            maxHeight: "350px",
            fixed: true,
            close: true,
            escKey: true,
            overlayClose: true,
            onOpen: function(){
                $("#cboxClose").css("opacity", 0);
                $('#cboxOverlay').css({"background":"#000"});
            },
			onComplete: function(){
				$("#cboxClose").css({"opacity": 1});
				$('#cboxOverlay').css({"background":"#000"});
			},
            onClosed:function(){
				$("#cboxClose").css({"opacity": 0});
				$('#cboxOverlay').css({"background":"#000"});
                location.reload();
            }
        });
    }

	$("#frmExisting").on('submit', function(e){
        e.preventDefault();
        e.stopPropagation();
        var post_data = $('#frmExisting').serialize();
        if ($("#submit").val() == 'Submit') {
            $.ajax({
                url: "<?php echo site_url('members/myrspo_validate_member'); ?>",
                method: "POST",
                data: post_data,
                beforeSend: function(){
                    $('.alert_didnotmatch').fadeOut('fast');
                    $('.div_overlay').fadeIn('fast');
                },
                type: "json",
                success: function(obj){
                    var data = JSON.parse(obj);
                    if (data.status) {
                        $(".show_list_email_and_complete").fadeIn('fast');
                        $("#email_p").val(data.email_p);
                        if(data.user_c) {
                            $("#user_c_notif").show();
                        } else {
                            $("#contact_c").addClass( "input-group contact_person" );
                        }
                        if(data.user_p) {
                            $("#user_p_notif").show();
                        } else {
                            $("#contact_p").addClass( "input-group contact_person" );
                        }
                        $("#email_s").val(data.email_s);
                        if(data.user_s) {
                            $("#user_s_notif").show();
                        } else {
                            $("#contact_s").addClass( "input-group contact_person" );
                        }
                        $("#email_f").val(data.email_f);
                        if(data.user_f) {
                            $("#user_f_notif").show();
                        } else {
                            $("#contact_f").addClass( "input-group contact_person" );
                        }
                        $("#contact_email").val(data.email_contact);
                        $("#submit").val('Verify');
                    } else {
                        $(".alert_didnotmatch").html(data.message).fadeIn('fast');
                    }
                    $('.div_overlay').fadeOut('fast');
                }
            });
        } else {
            $.ajax({
                url: "<?php echo site_url('members/myrspo_validate_email'); ?>",
                method: "POST",
                data: post_data,
                timeout: 180000, //3 minutes
                beforeSend: function(){
                    $('.alert_didnotmatch').fadeOut('fast');
                    $('.div_overlay').fadeIn('fast');
                },
                type: "json",
                error: function(j, s){
                    if (s == 'timeout') {
                        AlertMessage();
                    }
                },
                success: function (obj) {
					console.log(obj);
                    var data = JSON.parse(obj);
                    if (data.status) {
                        window.location = "<?php echo site_url('members/myrspo-registration-successful') ?>?email="+data.code;
                    } else {
                        $(".alert_didnotmatch").html(data.message).fadeIn('fast');
                    }
                    $('.div_overlay').fadeOut('fast');
                }
            });
        }
    });

	$('a.cbox').colorbox();
});

$(document).ready(function(){
	/* membernumber next auto */
    $('.membership_number input').keyup(function(){
        if($(this).val().length==$(this).attr("maxlength")){
            $(this).next('span').next().focus();
        }
    });
	
	/* focus text clear val */
	$('.membership_number input').on('focus', function() {
		// pertama load, cek apa sudah ada val
		// kalau gak ada, simpen val sekrang ke data()
		if (!$(this).data('defaultText')) $(this).data('defaultText', $(this).val());

		// cek apakah data sama
		if ($(this).val()==$(this).data('defaultText')) $(this).val('');
	});
	$('.membership_number input').on('blur', function() {
		// jika gak ada val maka set defaultText
		if ($(this).val()=='') $(this).val($(this).data('defaultText')); 
	});
});
</script>