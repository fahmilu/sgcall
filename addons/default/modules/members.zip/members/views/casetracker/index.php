<style>
	.table.tablestyle_cat > thead > tr > th {
		padding-right:20px; white-space:nowrap; vertical-align:middle; position:relative; border-top:1px solid red;
	}
	.h61 {
		border:1px solid red; position:relative;
	}
</style>

<?php //if (empty($base_where['keywords'])): ?>
<?php if (empty($base_where['keywords']) AND empty($base_where['country']) AND empty($base_where['category'])): ?>

<div class="container">
	<div id="header-white" class="text-center">
		<h1>Status of Complaints</h1>
	</div>
</div>

<section id="casetracker" class="no-pad-bottom border-b">
	<div class="container-1080">
		<div class="row">
		<div class="contain800">
			<p>The RSPO aspires to ensure transparency throughout the mediation process and the reporting thereof. Decisions not to disclose information through the RSPO website or other media require motivation on genuine grounds that disclosure will go against the interest of the mediation process and/or may jeopardize the well-being or safety of stakeholders involved, and that non-disclosure does not undermine adherence to the principles and objectives of RSPO:</p>

			<ul>
				<li>The non-disclosed information relates to a legitimate aim, i.e. peaceful and constructive dispute settlement in accordance with RSPO objectives and P&amp;C;</li>
				<li>The disclosure of said information threatens harm to that aim; and</li>
				<li>The harm to the aim is greater than the public interest in having the information disclosed.</li>
			</ul>

			<p>Complaints status is referring to the <a href="{{url:site}}publications/download/f98ecfd5a03c72d">Complaints Procedure Flowchart</a></p>
		</div>
		</div>
	</div>
</section>

<?php endif; ?>

<section class="case_tracker_container">
	<div class="container-1080">
		<div class="row">

		<?php if (!empty($base_where['keywords']) OR !empty($base_where['country']) OR !empty($base_where['category'])): ?>
			<div class="text-center no-pad-b" id="header-white">
				<h1>Status of Complaints</h1>
				<h2 class="section-heading align-center">Case Tracker</h2>
			</div>
		<?php else: ?>
			<h2 class="align-center">Case Tracker</h2>
		<?php endif; ?>
		
		<div class="row pad-bottom-30">
			<form method="get" action="<?php echo site_url('members/status-of-complaints'); ?>">
				<div class="col-sm-10 no-pad-l-r">
					<input type="text" class="form-control input-member-keyword" id="input-keyword-certification" placeholder="Type keywords here" <?php echo (!empty($base_where['keywords']) ? 'value="'.$base_where['keywords'].'"' : '' ) ?> name="keywords">
				</div>
				<div class="col-sm-2 no-pad-r">
					<button id="submit-button" class="btn btn-black fullWidth" type="submit">SEARCH</button>
				</div>
			</form>
		</div>
			
	<?php if (!empty($cases)): ?>
		</div>
	</div>

	<div class="container-1080">
		<div class="table-responsive">
			<table class="table table-striped tablestyle_cat">
				<thead>
					<tr>
						<th width="43%" <?php echo $orderby == 'company' ? 'class="active"' : '' ?>>
							<?php if($orderby == 'company' && $order=='asc'):?>
								<a class="downarrow <?php echo $orderby == 'company' && $order=='desc' ? 'active' : '' ?>" title="Sort descending" href="<?php $base_where['orderby'] = 'company';$base_where['order'] = 'desc';echo site_url('members/status-of-complaints?').http_build_query($base_where); ?>">
									<span class="title">Company</span>
									<span class="fa fa-angle-down"></span>
								</a>
							<?php else: ?>
								<a class="uparrow <?php echo $orderby == 'company' && $order=='asc' ? 'active' : '' ?>" title="Sort ascending" href="<?php $base_where['orderby'] = 'company';$base_where['order'] = 'asc';echo site_url('members/status-of-complaints?').http_build_query($base_where); ?>">
									<span class="title">Company</span>
									<span class="fa fa-angle-up"></span>
								</a>
							<?php endif; ?>
						</th>
						<th width="30%" <?php echo $orderby == 'country' ? 'class="active"' : '' ?>>
							<?php if($orderby == 'country' && $order=='asc'): ?>
								<a class="downarrow <?php echo $orderby == 'country' && $order=='desc' ? 'active' : '' ?>" title="Sort descending" href="<?php $base_where['orderby'] = 'country';$base_where['order'] = 'desc'; echo site_url('members/status-of-complaints?').http_build_query($base_where); ?>">
									<span class="title">Country/Location</span>
									<span class="fa fa-angle-down"></span>
								</a>
							<?php else: ?>
								<a class="uparrow <?php echo $orderby == 'country' && $order=='asc' ? 'active' : '' ?>" title="Sort ascending" href="<?php $base_where['orderby'] = 'country';$base_where['order'] = 'asc'; echo site_url('members/status-of-complaints?').http_build_query($base_where); ?>">
									<span class="title">Country/Location</span>
									<span class="fa fa-angle-up"></span>
								</a>
							<?php endif; ?>
						</th>
						<th width="15%" <?php echo $orderby == 'category' ? 'class="active"' : '' ?>>
							<?php if($orderby == 'category' && $order=='asc'): ?>
								<a class="downarrow <?php echo $orderby == 'category' && $order=='desc' ? 'active' : '' ?>" title="Sort descending" href="<?php $base_where['orderby'] = 'category';$base_where['order'] = 'desc'; echo site_url('members/status-of-complaints?').http_build_query($base_where); ?>">
									<span class="title">Category</span>
									<span class="fa fa-angle-down"></span>
								</a>
							<?php else: ?>
								<a class="uparrow <?php echo $orderby == 'category' && $order=='asc' ? 'active' : '' ?>" title="Sort ascending" href="<?php $base_where['orderby'] = 'category';$base_where['order'] = 'asc'; echo site_url('members/status-of-complaints?').http_build_query($base_where); ?>">
									<span class="title">Category</span>
									<span class="fa fa-angle-up"></span>
								</a>
							<?php endif; ?>
						</th>
						<?php 
						if($orderby=='date'):
							echo "<th class='active' width='12%'>";
						elseif($orderby==''):
							echo "<th class='active' width='12%'>";
						else:
							echo "<th width='12%'>";
						endif; ?>
							<?php if($orderby == 'date' && $order=='asc'): ?>
								<a class="downarrow <?php echo $orderby == 'date' && $order=='desc' ? 'active' : '' ?>" title="Sort descending" href="<?php $base_where['orderby'] = 'date';$base_where['order'] = 'desc'; echo site_url('members/status-of-complaints?').http_build_query($base_where); ?>">
									<span class="title">Date Filed</span>
									<span class="fa fa-angle-down"></span>
								</a>
							<?php else: ?>
								<a class="uparrow <?php echo $orderby == 'date' && $order=='asc' ? 'active' : '' ?>" title="Sort ascending" href="<?php $base_where['orderby'] = 'date';$base_where['order'] = 'asc'; echo site_url('members/status-of-complaints?').http_build_query($base_where); ?>">
									<span class="title">Date Filed</span>
									<span class="fa fa-angle-up"></span>
								</a>
							<?php endif; ?>
						</th>
					</tr>
				</thead>

				<?php
					$num = 1;
					if (!empty($pagination))
					{
						$num += $pagination['offset'];
					}
				?>

				<tbody>
				<?php foreach($cases as $case): ?>
					<tr>
						<td><?php echo '<a href="'.site_url('members/complaints/status-of-complaints/view/'.$case->id).'">'.$case->company.'</a>'; ?></td>
						<td><?php echo $case->country ?></td>
						<td><?php echo $case->category  ?></td>
						<td class="col-md-2"><?php echo $case->date ? date('d M Y', $case->date) : '--';  ?></td>
					</tr>
					<?php $num++; ?>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	
		<div class="row notecasetracker">
			<div class="col-sm-7 no-pad-l-r">
				<div class="noteLeftcasetracker">
					<p>This tracker page will be updated on a weekly basis unless there is no development</p>
				</div>
			</div>
			<div class="col-sm-5 no-pad-l-r">
				<div class="pull-right">
					<?php echo $pagination['links']; ?>
				</div>
			</div>
		</div>
	</div>
	
	<?php else: ?>
		<p class="text-center">Sorry, your search produced no results. Try different keywords, country or category.</p>
	<?php endif; ?>
</section>