<style>
	table {
		border-collapse:collapse;
		border-color: #DDD;
	}
	
	table > tbody > tr > td{
		padding: 10px 15px 10px 15px;
		border:1px solid #ddd;
		vertical-align: top;
	}
</style>

<div class="container">
<div class="row">
<div class="contain800">
	<div class="text-center" id="header-white">
		<h1>CASE TRACKER</h1>
	</div>
</div>
</div>
</div>

<section id="related">
	<div class="container">
		<div class="row">
		<div class="contain800">
			<h2 class="no-pad-top" style="text-align:center;"><?php echo $case->company; ?></h2> 
			<div class="col-md-12">
				<table class="table table-striped">
				<thead>
					<tr>
						<th></th>
						<th></th>
					</tr>
				</thead>
				<tbody>	
					<tr>
						<td>Member</td>
						<td><?php echo $case->company; ?></td>
					</tr>
					<tr>
						<td>Date Filed</td>
						<td><?php echo $case->date ? date('d F Y', $case->date) : ''; ?></td>
					</tr>
					<tr>
						<td>Category</td>
						<td><?php echo $case->category; ?></td>
					</tr>
					<tr>
						<td>Complainant</td>
						<td><?php echo nl2br($case->complainant); ?></td>
					</tr>
					<tr>
						<td>Complaint</td>
						<td><?php echo $case->noc; ?></td>
					</tr>
				</tbody>
				</table>

				<?php if (!empty($case->synopsis)): ?>
					<h3 class="titleh3" style="padding-top:10px;">Synopsis</h3>
					<?php echo stripslashes($case->synopsis); ?>
					<?php //echo nl2br(stripslashes($case->synopsis)); ?>
				<?php endif; ?>

				<?php if (!empty($case->remark)): ?>
					<h3 class="titleh3" style="padding-top:10px;">Remarks</h3>
					<?php echo stripslashes($case->remark); ?>
					<?php //echo stripslashes($case->remark); ?>
				<?php endif; ?>
			</div>
		</div>
		</div>
	</div>
</section>