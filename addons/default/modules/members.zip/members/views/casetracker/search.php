<section class="first-header"></section>
<?php $this->load->view('partials/search-bar'); ?>

<section>
<div class="container">
<div class="row">
<div class="col-lg-12">

<?php if (!empty($pncs)): ?>

<div class="row">
	<div class="table-responsive">

<table class="table table-striped">
	<thead>
		<tr>
			<th width="25%">Member Name</th>
			<th>Mill/Supply Base</th>
			<th>Certification Body</th>
			<th>Status</th>
			<th>Assessment Date</th>
			<th>Approved Date</th>
			<th>Assessment Type</th>
			<th>Files</th>
		</tr>
	</thead>

	<tbody>
	<?php foreach($pncs as $pnc): ?>
		<tr>
			<td><a href="<?php echo site_url( 'members/'.$pnc->mid.'/'.url_title($pnc->member_name) ); ?>"><?php echo $pnc->member_name ?></a></td>
			<td><?php echo $pnc->mill ?></td>
			<td><?php echo $pnc->cb_name ?></td>
			<td><?php echo ucwords($pnc->status); ?></td>
			<td><?php echo $pnc->assessment_date ? date('d-M-Y', $pnc->assessment_date) : '--' ?></td>
			<td><?php echo $pnc->report_accepted_date ? date('d-M-Y', $pnc->report_accepted_date) : '--' ?></td>
			<td><?php echo $pnc->assessment_type ? $assessment_type[$pnc->assessment_type] : '--'; ?></td>
			<td>
<?php

						$ff = ($pnc->uploaded ? ','.$pnc->uploaded:'') .
							($pnc->notification ? ','.$pnc->notification:'') .
							($pnc->notification_2 ? ','.$pnc->notification_2:'') .
							($pnc->notification_3 ? ','.$pnc->notification_3:'');
						$files = explode(',' , $ff);
						$certfile = $certname = '';
						if ($pnc->certificate_file)
						{
							if ($pos = strpos($pnc->certificate_file, '/', 1))
							{
								$certname = substr(strrchr($pnc->certificate_file, '/'), 1);
								$certfile = '<b>'.$certname.'</b><br />';
							}
							else
							{
								$certname = $pnc->certificate_file;
								$certfile = '<b>'.$certname.'</b><br />';
							}

							if (strlen($certname) > 20)
								$certfile = "<a class=\"list-group-item\" title=\"".$certname."\" target='_blank' href='".site_url(UPLOAD_PATH.'pnc/'.$certname)."'><b>".substr($certname,0,20)."..</b></a>";
							else
				                $certfile = "<a class=\"list-group-item\" title=\"".$certname."\" target='_blank' href='".site_url(UPLOAD_PATH.'pnc/'.$certname)."'><b>".$certname."</b></a>";

						}
		                echo '<div class="list-group">'.PHP_EOL;
		                echo $certfile ? $certfile : '';
		                foreach($files as $key => $file){
		                	if ($file)
		                	{
		                		$pos = strpos($file, '/', 1);
		                		if ($pos OR $pos === 0)
		                		{
		                			$fname = substr(strrchr($file, "/"), 1);
		                		}
		                		else
		                		{
		                			$fname = $file;
		                		}

			                	if (strlen($fname) > 30)
				                    echo "<a class=\"list-group-item\" title=\"".$fname."\" target='_blank' href='".site_url(UPLOAD_PATH.'pnc/'.$fname)."'>".substr($fname,0,30)."..</a>";
								else
				                    echo "<a class=\"list-group-item\" title=\"".$fname."\" target='_blank' href='".site_url(UPLOAD_PATH.'pnc/'.$fname)."'>".$fname."</a>";
								//echo $files[$key];
							}
							else
								continue;
		                }
		                echo '</div>'.PHP_EOL;
		                //$item = '<ul class="list-group"><li>'.$certfile.'</li><li>'.implode('</li><li>', $files).'</li></ul>';
		                //$item =  
					//echo $item;

?>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>

</table>

	</div>
</div>

<?php echo $pagination['links']; ?>

<?php else: ?>

<?php endif; ?>


</div>
</div>
</div>
</section>
