<style>
	.alert-success {
		color: #3C763D;
		border-color: tranparent;
		border-radius: 3px;
		font-size: 14px;
		width: 400px;
		text-align:center;
		margin: 0 auto;
	}
	.alert-warning{
		border-color: tranparent;
		border-radius: 3px;
		font-size: 14px;
		width: 400px;
		text-align:center;
		margin: 0 auto;
	}
	.alert-danger{
		color: red;
		border-color: tranparent;
		border-radius: 0px 0px 3px 3px;
		font-size: 14px;
		margin: 0 auto;
	}

	.search-form input, .search-form div, .search-form button {
		border-color: #ccc;
	}
	label {
		display: inline-block;
		max-width: 100%;
		margin-bottom: 5px;
		font-size:14px;
		font-weight: 400;
	}
	.dropdown-menu {
		margin-top: 0px;
		border-radius: 0px;
	}
	.form-control {
		display: block;
		width: 100%;
		/* height: 34px; */
		padding: 6px 12px;
		font-size: 14px;
		line-height: 1.42857;
		color: #555;
		background-color: #FFF;
		background-image: none;
		border: 1px solid #CCC;
		border-radius: 0px;
		box-shadow: none;
		transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
	}
	.bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
		width: 100%;
	}
	.btn {
		padding: 9.4px 20px;
		font-size:13px;
		font-weight:600;
		border: 1px solid #ddd;
		border-radius: 0px;
	}
		
	.btn:hover, .btn:focus {
		color: #FFF;
		text-decoration: none;
		background: none repeat scroll 0% 0% #FF6500;
		border: 1px solid #FF6500;
	}
	.search-form input, .search-form div, .search-form button {
		border-radius: 0px;
		margin: 0px -2px 0px 0px;
		font-size: 13px;
		min-height: 40px;
		border-color: #ddd;
	}
	.bootstrap-select > .btn {
		padding-right: 0px;
	}		
</style>

<?php //if (empty($base_where['keywords'])): ?>
<?php if (empty($base_where['keywords']) AND empty($base_where['country']) AND empty($base_where['category'])): ?>

<div class="container">
	<div class="container text-center" id="header-white">
		<h1>Status of Complaints</h1>
	</div>
</div>

<section id="casetracker" style="padding-bottom:0px;">
	<div class="container">
		<div class="row">
		<div class="contain800">

			<p>The RSPO aspires to ensure transparency throughout the mediation process and the reporting thereof. Decisions not to disclose information through the RSPO website or other media require motivation on genuine grounds that disclosure will go against the interest of the mediation process and/or may jeopardize the well-being or safety of stakeholders involved, and that non-disclosure does not undermine adherence to the principles and objectives of RSPO:</p>

			<ul>
				<li>The non-disclosed information relates to a legitimate aim, i.e. peaceful and constructive dispute settlement in accordance with RSPO objectives and P&amp;C;</li>
				<li>The disclosure of said information threatens harm to that aim; and</li>
				<li>The harm to the aim is greater than the public interest in having the information disclosed.</li>
			</ul>

			<p style="margin-bottom:0px;">Complaints status is referring to the <a href="{{url:site}}publications/download/f98ecfd5a03c72d">Complaints Procedure Flowchart</a></p>
		</div>
		</div>
	</div>
</section>

<?php endif; ?>

<section>
	<div class="container">
		<div class="row">
		<div class="contain800">

<?php if (!empty($base_where['keywords']) OR !empty($base_where['country']) OR !empty($base_where['category'])): ?>

	<div class="text-center" id="header-white">
		<h1>Status of Complaints</h1>
		<h2 class="section-heading" STYLE="text-align:center;">CASE TRACKER</h2>
	</div>

<?php else: ?>

		<h2 class="section-heading" STYLE="text-align:center;">CASE TRACKER</h2>

<?php endif; ?>
		
			<div class="row" style="padding-bottom:20px;">
				<form method="get" action="<?php echo site_url('members/status-of-complaints'); ?>">
					<div class="col-lg-12">
						<div class="col-lg-6" style="padding-right:1px; padding-left:0px;">
							<input type="text" class="form-control input-member-keyword" id="input-keyword-certification" placeholder="Type keywords here" <?php echo (!empty($base_where['keywords']) ? 'value="'.$base_where['keywords'].'"' : '' ) ?> name="keywords" style="width:100%;">
						</div>
												
						<div class="col-lg-2" style="padding-right:1px; padding-left:0px;">
							{{ dropdowns:countries }}
						</div>
						
						<div class="col-lg-2" style="padding-right:0px; padding-left:0px;">
							{{ dropdowns:categories }}
						</div>	
						
						<div class="col-lg-2" style="padding-left:1px; padding-right:0px;"><button class="btn btn-primary" id="submit-button" style="border-color:transparent; width:100%; border-radius:0px 3px 3px 0px;" type="submit">SEARCH</button></div>
					</div>
				</form>
			</div>

			<?php if (!empty($cases)): ?>
		</div>
		</div>
	</div>

	<div class="row">
	<div class="contain800">
	<p class="text-center" style="font-size: 13px;padding-bottom:9px;">This tracker page will be updated on a weekly basis unless there is no development</p>
	<div class="table-responsive">
		<table class="table table-striped tablestyle_cat">
			<thead>
				<tr>
					<th width="25%">Company</th>
					<th>Country/Location</th>
					<th>Category</th>
					<th>Status</th>
					<th>Date Filed</th>
				</tr>
			</thead>

			<?php
				$num = 1;
				if (!empty($pagination))
				{
					$num += $pagination['offset'];
				}
			?>

			<tbody>
			<?php foreach($cases as $case): ?>
				<tr>
					<td><?php echo '<a href="'.site_url('members/complaints/status-of-complaints/view/'.$case->id).'">'.$case->company.'</a>'; ?></td>
					<td><?php echo $case->country ?></td>
					<td><?php echo $case->category  ?></td>
					<td><?php echo $case->status  ?></td>
					<td class="col-md-2"><?php echo $case->date ? date('d M Y', $case->date) : '--';  ?></td>
				</tr>
				<?php $num++; ?>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	
	<div class="pull-right">
	<?php echo $pagination['links']; ?>
	</div>
	
	</div>
	
	<?php else: ?>

		<p class="text-center">Sorry, your search produced no results. Try different keywords, country or category.</p>

	<?php endif; ?>
	</div>
</div>
</section>