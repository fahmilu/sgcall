﻿
	<!-- Full Page Image Background Carousel Header -->
    <header>
        <div class="row">
            <div class="container text-center" id="header-white">
                <h1 style="margin-top: 2px;">RSPO会员</h1>
            </div>
        </div>
        <div id="myCarousel">

            <!-- Wrapper for Slides -->
            <div class="carousel-inner">
                <div class="item active" style="background:url('{{ theme:image_path file='member_banner2.jpg' }}') no-repeat left center;background-size: cover;">
					<div class="carousel-caption">
					<div class="contain800">
                        <a href="#"><h2>将标准付诸行动</h2></a>
                        <a href="#">
                            <p>RSPO的会员代表了供应链上的各个环节和世界上最大的棕榈油生产地区。作为会员，他们在RSPO的决策制定过程中有发言权，共同决定通过何种方式使可持续棕榈油成为规范。</p>
                        </a>
					<div class="image-credit">Credit: NBPOL</div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

	<?php $this->load->view('partials/search-bar'); ?>

    <!-- ACOP-Complaint Section -->
    <section id="acop-complaint" style="padding-bottom:0px; border:none;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="col-lg-6 text-center pad-bottom-30">
                        <h2 class="section-heading">为什么要加入RSPO</h2>
                        <p class="whoweareabout">全球有超过1600个组织和公司已经加入RSPO —它们通过其会员资格享有从市场准入到技术工艺所带来的利益。</p>
                        <br/>
                        <a href="<?php echo site_url('members/why-become-a-member-of-rspo') ?>" class="btn btn-lg btn-orange">查看更多</a>
                    </div>
                    <div class="col-lg-6 text-center pad-bottom-30">
                        <h2 class="section-heading">成为会员</h2>
                        <p class="whoweareabout">通过加入RSPO，成为增长迅速的棕榈油行业中的一员，并始终为可持续棕榈油的常态化努力。</p>
                        <br/>
                        <a href="<?php echo site_url('members/apply') ?>" class="btn btn-lg btn-orange">申请</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
	 <!-- ACOP-Complaint Section -->
    <section id="acop-complaint" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">

                    <div class="col-lg-6 text-center">
                        <h2 class="section-heading">年度进展报告（ACOP）</h2>
                        <p class="whoweareabout">RSPO年度进展报告旨在评估会员实现100% RSPO认证可持续棕榈油目标的进展情况，相关内容均来自于会员提交的数据。该报告是每年强制性提交的。</p>
                        <br/>
                        <a href="<?php echo site_url('members/acop') ?>" class="btn btn-lg btn-orange">查看更多</a>
                    </div>
                    <div class="col-lg-6 text-center">
                        <h2 class="section-heading">投诉制度</h2>
                        <p class="whoweareabout">RSPO投诉制度旨在提供一个公平、透明、公正的程序来适当的处理和解决针对RSPO会员或RSPO系统的意见与投诉。</p>
                        <br/>
                        <a href="<?php echo site_url('members/complaints') ?>" class="btn btn-lg btn-orange">查看更多</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
<?php if (!empty($membersX)): ?>
<section>
<div class="container">
<div class="row">
<div class="col-lg-12">

<table class="table">
	<thead>
		<tr>
			<th>Name</th>
			<th>Country</th>
			<th>Status</th>
			<th>Member Since</th>
			<th>Membership Type</th>
		</tr>
	</thead>

	<tbody>
	<?php foreach($members as $m): ?>
		<tr>
			<td><a href="<?php echo site_url( 'members/'.$m->intID.'/'.url_title($m->title) ); ?>"><?php echo $m->title ?></a></td>
			<td><?php echo $m->country ?></td>
			<td><?php echo $m->status ?></td>
			<td><?php echo $m->approved_date; ?></td>
			<td><?php echo $m->type ?></td>
		</tr>
	<?php endforeach; ?>
	</tbody>

</table>
</div>
</div>
</div>

<div class="text-right pad-top-20">
<?php echo $pagination['links']; ?>
</div>

</section>
<?php else: ?>
<?php endif; ?>