<!-- member Section -->
<style>
    .LV_valid_field {
        border: 1px solid rgba(0, 180, 0, 0.75);
    }
    .LV_invalid_field {
        border: 1px solid rgba(240, 0, 0, 0.75);
    }
	.input-group-addon:first-child {
		border-right: 0px none;
		width: 100px;
	}
	.input-group-addon {
		padding: 6px 12px;
		font-size: 14px;
		font-weight: 400;
		line-height: 1;
		color: #555;
		text-align: center;
		background-color: #EEE;
		border: none;
		border-radius: 4px;
	}
	.btn-default, .btn-primary, .btn-success, .btn-info, .btn-warning, .btn-danger {
		text-shadow: none;
		box-shadow: none;
	}
	.btn { font-weight: normal; }
    #myTabMember label{ color: #43372c; }
    .block{ display: block; }
    li.active{ background-color: #f5f5f5; }
    #tab-profile-member li a{
        font-weight: normal;
        color: #f26522;
        padding: 0px;
    }
    #tab-profile-member li a:hover{ color: #FF6500; }
    input[type=radio].css-checkbox + label.css-label {
        padding-left: 28px;
        height: 23px;
        display: inline-block;
        line-height: 23px;
        background-repeat: no-repeat;
        background-position: 0 0;
        font-weight: normal;
        vertical-align: middle;
        cursor: pointer;
    }
    input[type=radio].css-checkbox:checked + label.css-label { background-position: 0 -23px; }
    label.css-label {
        background-image: url('http://rspo.org/addons/default/themes/rspo_revamp/img/csscheckbox.png');
        -webkit-touch-callout: none;
        -webkit-user-select: none;
        -khtml-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }
    input[type=radio].css-checkbox {
        position: absolute;
        z-index: -1000;
        left: -1000px;
        overflow: hidden;
        clip: rect(0 0 0 0);
        height: 1px;
        width: 1px;
        margin: -1px;
        padding: 0;
        border: 0;
    }
	.input-group { width: 100%; }
    .col3-profile{
        width: 23.25%;
		/* width:170px; */
        margin-right: 16px; 
        /* display: inline-block; */
		display:-moz-groupbox;
		display: inline-table;
    }
	.col6-profile{
		/* width: 360px;  */
		width: 48.8%;
		display: inline-block; 
		margin-right: 16px;
	}
    .time-history{
        font-weight: normal; 
        display: inline-block; 
        width: 70px;
        font-size: 13px;
    }
    .text-history{
        font-weight: normal; 
        display: inline-block;
        font-size: 13px;
    }
    .btn-loadmore{
        background-color: #fff;
        color: #ff7400;
        border-color: #fff;
        font-size: 14px;
        text-transform:none; 
        font-weight: bold;
    }
    .success-notification{
    	position: relative;
        font-weight: normal;
       /* display: none;*/
        padding: 10px 15px;
        color: #fff !important; 
        background-color: #85bb43;
        /* max-width: 330px; */
        margin-bottom: 35px;
        margin-top: 7px;
    }
    .error-notification{
        font-weight: normal;
    	position: relative;
       /* display: none;*/
        padding: 10px 15px 10px 15px;
        color: #fff !important; 
        background-color: #ff3931;
        /* max-width: 330px; */
        margin-bottom: 35px;
        margin-top: 7px;
    }
    .row-profile-wrapper input, .row-profile-wrapper textarea { color: #43372c; }
    .title-text-side-bar{ color: #949494 }
    .profile-column-right-wrapper{
		width:800px;
		max-width:915px; 
		margin-bottom:50px;
    }
	.col-profile-password {
		display: inline-block;
		width: 47.6%;
	}
    .col-profile-password-arrow{
        width: 32px;
        display: inline-block;
    }
    div#questions .block { font-weight: normal; }
	#member_profile #myTabMember .tab-pane .row { border: 1px solid #f5f5f5; }
    li.tab-profile { border: 1px solid #f5f5f5; }
    #tab-profile-member li.active a { color: #43372c !important; }
    .new_logs { display: none; }
	.intl-tel-input input, .intl-tel-input input[type="text"], .intl-tel-input input[type="tel"] { padding-left: 50px; }
	.input-group-addon.no-padding { position: relative; }
	.intl-tel-input .selected-flag .flag {
		width:16px;
		height: 11px;
		top: 50%;
		bottom: 50%;
	}
	.div_overlay {
		display: none;
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		margin: 0 auto;
		text-align: center;
		vertical-align: middle;
		background-color: rgba(255,255,255,0.85);
		z-index: 9999;
	}
	.div_spin {
		position: absolute;
		top: 40%;
		left: 0;
		right: 0;
		font-size: 20px;
		color: #ed7b1c;
	}
	.logo-traders div.btn-brown {
		text-align: center;
		font-size: 12px;
		font-weight: 400;
		text-transform: uppercase;
		line-height: 1.2em;
		background: #735636;
		color: #F2F2F2;
		width: 152px;
		border-radius: 3px !important;
		padding: 9px 20px;
		margin: 0 auto;
		text-align: center;
	}
	.btn { border: none; }
    .member-selected { color: #ee7813 !important; }
	a[disabled="disabled"], button[disabled="disabled"], input[disabled], input[disabled="disabled"], li.tab-profile[disabled="disabled"] { color:#d3d3d3!important; }
    .notes-div {
        margin-bottom: 30px;
		padding-left: 30px;
		padding-right: 30px;
    }
	
	/* popup */
	#cboxContent{ height: 100vh!important; }
	#cboxLoadedContent, 
	#cboxLoadedContent iframe { height: 100%!important; }
	#cboxLoadedContent { overflow: hidden !important; }
	#change_organization.popup_custom_by_am,
	#change_default_organization.popup_custom_by_am { max-height: 630px; }
	/* popup */
	
	/* responsive only this page */
	@media only screen and (max-width: 1920px) {
		#cboxTopLeft, #cboxMiddleLeft, #cboxMiddleRight, #cboxTopRight{ width: 25px; }
		#cboxContent, #cboxLoadedContent{ width: 100% !important; }
		#cboxTopLeft, #cboxMiddleLeft, #cboxMiddleRight, #cboxTopCenter, #cboxTopRight{ height: 35px; }
	}
	@media only screen and (max-width: 767px) {
		#colorbox, #cboxContent, #cboxLoadedContent, #change_organization, #change_default_organization{ border-radius:0px; }
		#cboxLoadingOverlay:before{ line-height: 100vh; }
		#colorbox, #cboxWrapper{
			width: 100%!important;
			height: 100vh!important;
			top: 0!important;
			left: 0px !important;
		}
		#cboxTopLeft, #cboxMiddleLeft, #cboxMiddleRight, #cboxTopRight{ width:0px; }
		#cboxContent, #cboxLoadedContent{ width: 100% !important; }
		#cboxTopLeft, #cboxMiddleLeft, #cboxMiddleRight, #cboxTopCenter, #cboxTopRight{ height:0px; }
		#change_organization.popup_custom_by_am,
		#change_default_organization.popup_custom_by_am { padding: 45px 30px 40px 30px; }
		.cboxClose, #cboxClose {
			background-image: url('{{url:site}}addons/default/themes/r3p1_revamp/img/icon/Button-Close-Black@2x.png');
			right: 20px;
			top:15px;
		}
		#change_organization.popup_custom_by_am,
		#change_default_organization.popup_custom_by_am {
			max-height: 100vh;
			height: 100vh;
		}
		.container_list_line {
			height: auto;
			max-height: 60vh;
			margin-bottom: 30px;
		}
		#cancel_change{ display:none; }
		#ignore-changes, #default-changes{ margin-left:30px; }
	}
	@media only screen and (max-width: 640px) {
		.container_list_line {
			max-height: 30vh;
			margin-bottom: 5px;
		}
		.notes-change-member { margin: 0px 30px 0px; }
	}
	@media only screen and (max-width: 351px) {
		#save-changes{
			margin-left:30px;
			margin-right: 30px;
		}
	}
</style>

<div class="div_overlay" id="pleasewait">
	<div class="div_spin">
		<p><b>Please wait, we're saving and synchronising your data to our CRM system&hellip;</b></p>
		<div class="clearfix"></div>
		<p class="fa fa-cog fa-spin fa-2x"></p>
	</div>
</div>

<section id="members-prof" class="first-section">
    <div class="container-1080">
        <div class="row">
           
		<div class="left_container_m_profile">
			<div class="row">
				<div class="back-linkmembers"> 
					<span><a href="<?php echo site_url('members/all') ?>"><i class="fa fa-caret-left"></i>VIEW ALL MEMBERS</a></span>          
				</div>
				<?php if ( $member->logo ) { ?>
				<div class="logo-members text-center" alt="">
					<?php 
						if (strstr($member->logo, '/sites/default/files/'))
						{
							echo '<img class="img-responsive" src="http://www.rspo.org'.$member->logo.'" />'.PHP_EOL;
						}
						elseif(strstr($member->logo, 'ma/logo/'))
						{
							echo '<img class="img-responsive" src="http://www.rspo.org/'.$member->logo.'" />'.PHP_EOL;
						}
						else
						{
							if ( file_exists(UPLOAD_PATH.'/memberlogos/'.thumbnail($member->logo)) )
								echo '<img class="img-responsive" src="'.site_url(UPLOAD_PATH).'/memberlogos/'.thumbnail($member->logo).'" />'.PHP_EOL;
							else
								echo '<img style="width:150px;" src="'.site_url(UPLOAD_PATH).'/memberlogos/'.($member->logo).'" />'.PHP_EOL;
						} ?>
				</div>
				<?php } ?>
				<div class="descr-profile">
					<div class="i_title">
						<p class="member_profile">You are currently logged in<br/>as <b><?php echo ucfirst($this->current_user->first_name).' '.ucfirst($this->current_user->last_name); ?></b></p>
					</div>
                    <?php if (count($member_list) > 1) { ?>
                        <a class="btn btn-lg btn-orange list_of_organizations margin-bottom-30" onclick="changeOrganizationsColorboxConfirm();" style="height:auto;">Change<br/>membership profile</a>
                    <?php } ?>

					<div class="info1">
						<span>Membership No.</span> 
						<p class="member_profile"><?php echo $member->member_num; ?></p>
					</div>
					<div class="info2">
						<span>Category</span> 
						<p class="member_profile"><?php echo $member->type; ?></p>
					</div>
					<div class="info3">
						<span>Sector</span> 
						<p class="member_profile"><?php echo $member->category; ?></p>
					</div>
					<div class="info4">
						<span>Country/Region</span>
						<p class="member_profile"><?php echo $member->country; ?></p>
					</div>
					<div class="info5">
						<span>Member since</span> 
						<p class="member_profile"><?php echo date("j F Y", $member->approved_date); ?></p>
					</div>
					<?php if(!empty($member->website)):?>
					<div class="info6">
                        <span>Web</span><br/>
                        <?php if (substr($member->website, 0, 7) <> 'http://') $member->website = 'http://'.$member->website; ?>
                        <?php echo $member->website ? '<a target="_blank" href="'.$member->website.'">'.str_ireplace(array('http://', 'www.'), '', trim($member->website, '/')).'</a>' : 'N/A'; ?>
					</div>
					<?php endif;?>
				</div>
			</div>
		</div>
        
        <!-- right -->
        <div class="right_container_m_profile profile-subsidiary-prymary col-md-9 col-sm-9 col-xs-12 text-left">
			<form id="member_profile" accept-charset="utf-8" action="{{url:site}}members/profile" method="post" enctype="multipart/form-data">

				<div class="row">
					<h3 class="profile-member-title-headline" style="margin-bottom:20px;">
						<?php echo stripslashes($member->name); ?>
					</h3>
					<?php if($member->status == 'Suspended') { ?>
                    <?php } else { ?>
					<a class="btn btn-black btnGotoACOP" href="http://acop-rspo.org/" target="_blank">Go to ACOP 2017</a>
					<?php } ?>
					
					<?php $status = $this->session->flashdata('status'); ?>
					<?php if (!empty($status) && $status == 'success'): ?>
						<div class="alert alert-success fade in" role="alert" style="text-align:left;">
							<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							Your changes have been successfully saved.
							<?php if ($this->session->flashdata('notice')): ?>
								<br /><?php echo $this->session->flashdata('notice'); ?>
							<?php endif; ?>
						</div>
					<?php elseif (!empty($status) && $status == 'error'): ?>
						<div class="alert alert-danger fade in" role="alert" style="text-align:left;">
							<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							Kindly check your form for missing value(s).
							<?php if ($this->session->flashdata('error')): ?>
								<br /><?php echo $this->session->flashdata('error'); ?>
							<?php endif; ?>
						</div>
					<?php elseif (!empty($status) && $status == 'pwerror'): ?>
						<div class="alert alert-danger fade in" role="alert" style="text-align:left;">
							<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<?php if ($this->session->flashdata('error')): ?>
								<?php echo $this->session->flashdata('error'); ?>
							<?php endif; ?>
						</div>
					<?php endif; ?>

					<?php if (validation_errors()): ?>
						<div class="alert alert-danger fade in" role="alert" style="text-align:left;">
							<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<?php echo validation_errors(); ?>
						</div>
					<?php endif; ?>

                    <?php if($member->status == 'Suspended') { ?>
					<div class="col-lg-12 col-md-12 tabbed-of-member content-member-profile">
						<p style="margin-top:5px;">Your membership status is currently <b>suspended</b>. Until your status has been lifted, you may not edit your information on this page. If you like to submit your ACOP 2017, please click the button below.</p>
						<a href="http://acop-rspo.org/" target="_blank" class="btn btn-lg btn-black margin-top-20">Go to ACOP 2017</a>
					</div>
                    <?php } else { ?>
					<div id="tabs-test" class="col-lg-12 col-md-12 tabbed-of-member content-member-profile" style="margin-bottom:30px;">
						<ul id="tab-profile-member" class="nav nav-tabs" role="tablist" style="padding-top:0px; margin-bottom:0px;">
							<li class="tab-profile active">
								<a href="#editprofile" id="link_editprofile" class="first-tabbed" role="tab" data-toggle="tab" style="background: rgba(0,0,0,0);">Edit profile</a>
							</li>
							<li class="tab-profile" style="margin-left: -1px;">
								<a href="#questions" id="link_questions" role="tab" data-toggle="tab" style="background: rgba(0,0,0,0);">Questions</a>
							</li>
							<li class="tab-profile" style="margin-left: -1px;">
								<a href="#contacts" id="link_contacts" role="tab" data-toggle="tab" style="background: rgba(0,0,0,0);">Contacts</a>
							</li>
							<li class="tab-profile" style="margin-left: -1px;">
								<a href="#password" id="link_password" role="tab" data-toggle="tab" style="background: rgba(0,0,0,0);">Password</a>
							</li>
							<li class="tab-profile" style="margin-left: -1px;">
								<a href="#historyprofile" id="link_historyprofile" role="tab" data-toggle="tab" style="background: rgba(0,0,0,0);">Revisions</a>
							</li>
							<li id="gm_editProfile" class="tab-profile" style="margin-left: -1px;">
								<a href="#g_membership" id="link_g_membership" role="tab" data-toggle="tab" style="background: rgba(0,0,0,0);">Group membership</a>
							</li>
							<li class="tab-profile" style="margin-left: -1px;">
								<a href="#f_acop" id="link_f_acop" role="tab" data-toggle="tab" style="background: rgba(0,0,0,0);">ACOP</a>
							</li>
						</ul>

						<div id="myTabMember" class="tab-content tab-content-profile">
							<div id="editprofile" class="tab-pane fade active in">
								<div class="row" >
									<div class="list-sub profile-tab-content" >
										<div class="col-sm-12" >
											<label class="block no-margin-top">Description</label>
											<textarea name="profile" class="form-control" style="text-align: left; height: 140px; max-height: 300px; overflow: hidden; overflow-wrap: break-word;"><?php echo htmlspecialchars_decode(strip_tags(stripslashes($member->profile))); ?></textarea>
											<?php echo form_error('profile') ? '<div class="alert alert-danger">'.form_error('profile').'</div>' : ''; ?>
										</div>
										<div class="col-sm-12">
											<label>Address</label>
											<input type="text" class="form-control" value="<?php echo htmlspecialchars_decode($member->address) ?>" name="address">
											<?php echo form_error('address') ? '<div class="alert alert-danger">'.form_error('address').'</div>' : ''; ?>
										</div>
										<div class="row-profile-wrapper">
											<div class="col-sm-12"></div>
											<div class="col-md-4 col-sm-12">
												<label>City</label>
												<input type="text" class="form-control" value="<?php echo htmlspecialchars_decode($member->address_city) ?>" name="address_city">
												<?php echo form_error('address_city') ? '<div class="alert alert-danger">'.form_error('address_city').'</div>' : ''; ?>
											</div>
											<div class="col-md-4 col-sm-12">
												<label>Postcode</label>
												<input type="text" class="form-control" value="<?php echo htmlspecialchars_decode($member->address_zip) ?>" name="address_zip">
												<?php echo form_error('address_zip') ? '<div class="alert alert-danger">'.form_error('address_zip').'</div>' : ''; ?>
											</div>
											<div class="col-md-4 col-sm-12">
												<label>State/Province</label>
												<input type="text" class="form-control" value="<?php echo htmlspecialchars_decode($member->address_state) ?>" name="address_state">
												<?php echo form_error('address_state') ? '<div class="alert alert-danger">'.form_error('address_state').'</div>' : ''; ?>
											</div>

											<div class="col-sm-12"></div>
											<div class="col-md-4 col-sm-12">
												<label>Countries/Regions</label>
												{{dropdowns:countries class="form-control selectpicker" id="mcountry" value="<?php echo $member->country ?>" }}
												<?php echo form_error('country') ? '<div class="alert alert-danger">'.form_error('country').'</div>' : ''; ?>
											</div>
											<div class="col-md-4 col-sm-12">
												<label>Telephone</label>
												<div class="input-group no-margin">
													<div class="input-group-addon no-padding" style="position:relative;">
														<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->telephone?>" name="telephone">
													</div>
												</div>
												<?php echo form_error('telephone') ? '<div class="alert alert-danger">'.form_error('telephone').'</div><div class="clearfix"></div>' : ''; ?>
											</div>
											<div class="col-md-4 col-sm-12">
												<label class="add-pad-am">Fax<span style="font-weight: normal;"> (optional)</span></label>
												<div class="input-group no-margin">
													<div class="input-group-addon no-padding">
														<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->fax?>" name="fax">
													</div>
												</div>
												<?php echo form_error('fax') ? '<div class="alert alert-danger">'.form_error('fax').'</div>' : ''; ?>
											</div>
										</div>
										<div class="clearfix"></div>
										<div class="row-profile-wrapper">
											<div class="col-lg-6 col-md-12 col-sm-12">
												<label>Email</label>
												<input type="text" class="form-control" name="email" value="<?php echo $member->email?>">
											</div>
											<div class="col-lg-6 col-md-12 col-sm-12">
												<label class="add-pad-am">Website</span></label>
												<input type="text" class="form-control" name="website" value="<?php echo $member->website?>">
											</div>
										</div>

										<?php if ($member->category=='Supply Chain Group Manager'): ?>
											<?php
											$scg_manager_members = null;
											if ($member->scg_manager_members)
											{
												$scg_manager_members = unserialize($member->scg_manager_members);
											}
										?>
										<div class="row-profile-wrapper col-sm-12">
											<label>Supply Chain Group Manager</label>
											<p>List of members under the manager, with Palm Oil consumption for each member</p>
											<table width="100%" cellspacing="1" id="scgm_table">
												<thead>
													<tr>
														<th>Member Name</th>
														<th>Palm Oil Consumption (MT)</th>
													</tr>
												</thead>
												<tbody>
												<?php if ($member->scg_manager_members && is_array($scg_manager_members)): ?>
													<tr>
														<td style="width:70%;padding-right:5px;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control required" value="<?php echo htmlspecialchars_decode($scg_manager_members[0]) ?>"/></td>
														<td style="width:30%;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control max500 required" value="<?php echo htmlspecialchars_decode($scg_manager_members[1]) ?>" /></td>
													</tr>
													<?php if (count($scg_manager_members) > 2): ?>
														<?php for ($i=2; $i<count($scg_manager_members); $i+=2): ?>
															<tr>
																<td style="width:70%;padding-right:5px;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control required" value="<?php echo htmlspecialchars_decode($scg_manager_members[$i]) ?>"/></td>
																<td style="width:30%;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control max500 required" style="float:left;width:75%;" value="<?php echo htmlspecialchars_decode($scg_manager_members[$i+1]) ?>" /><a href="#" class="btn btn-lg btn-orange remove_scgm" style="width:25%;">x</a></td>
															</tr>
														<?php endfor; ?>
													<?php endif; ?>
												<?php else: ?>
													<tr>
														<td style="width:70%;padding-right:5px;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control required" /></td>
														<td style="width:30%;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control max500 required" /></td>
													</tr>
												<?php endif; ?>
												</tbody>
												<tfoot>
													<tr>
														<td colspan="2"><a href="#" id="add_scgm">Add more</a></td>
													</tr>
												</tfoot>
											</table>
											<?php echo form_error('scg_manager_members[]') ? '<div class="alert alert-danger">'.form_error('scg_manager_members[]').'</div>' : ''; ?>
										</div>
										<?php endif; ?>
							
										<div class="row-profile-wrapper col-sm-12">
											<label>Organisation's Logo</label> <i>(PNG, JPG, or GIF and no more than 1.5MB)</i>

											<input type="hidden" />
											<?php if (!empty($member->logo)): ?>
											<?php echo form_hidden('upload_logo', $member->logo); ?>
											<div class="clear"></div>
											<label class="inline">Filename: </label> <?php echo $member->logo; ?>
											<div class="clear"></div>

											<?php
												if ( $member->logo )
												{
													if (strstr($member->logo, '/sites/default/files/'))
													{
														echo '<img class="img-responsive" src="http://www.rspo.org'.$member->logo.'" />'.PHP_EOL;
													}
													elseif(strstr($member->logo, 'ma/logo/'))
													{
														echo '<img class="img-responsive" src="'.site_url(thumbnail($member->logo)).'" />'.PHP_EOL;
													}
													else
													{
														echo '<img class="img-responsive" src="'.site_url(UPLOAD_PATH).'/memberlogos/'.thumbnail($member->logo).'" />'.PHP_EOL;
													}
												}
												else
												{ ?>
													{{theme:image file="generic-member.jpg"}}
												<?php }
											?>

											<?php endif; ?>

											<br /><input type="file" id="logo" class="filestyle" name="logo" onchange="copyfname(this.value, $(this), 'image')">
											<?php echo form_hidden('new_logo', $member->logo); ?>

											<?php echo form_error('upload_logo') ? '<div class="alert alert-danger">'.form_error('upload_logo').'</div>' : ''; ?>
										</div>

                                        <?php if (count($member_list) > 1) { ?>
                                            <div class="col-sm-12">
                                                <p style="margin-top:20px; display:inline-block; line-height:1.8;">Your current default membership profile is <b id="default_member_name" ><?php echo $this->session->userdata('default_member_name'); ?></b><br/><a onclick="changeDefaultOrganization();">Change</a></p>
                                            </div>
                                        <?php } ?>
										
										<div class="clearfix"></div>
										<?php if ($member->category == 'Environmental or Nature Conservation Organisations (Non Governmental Organisations)' or $member->category == 'Social or Development Organisations (Non Governmental Organisations)'):
                                            if ($member->parent_company == 'yes' && $member->is_corporation != 'y') {
                                                $member->is_corporation = 'y';
                                            }
                                            ?>
										<div class="col-sm-12">
											<div class="form-group">
												<label class="label_content_right">Are you a corporation?</label>
												<div class="radio_custom_by_am t_group_corporation_y_n">
													<div class="yn_left">
														<?php echo form_radio('is_corporation', 'y', isset($member->is_corporation) && $member->is_corporation == 'y', 'class="corporationOD-y" onclick="corporation_od(this.value);" id="corporationOD-y"') ?>
														<label for="corporationOD-y"><span><span></span></span>Yes</label>
													</div>
													<div class="yn_right">
														<?php echo form_radio('is_corporation', 'n', !isset($member->is_corporation) || $member->is_corporation == 'n', 'class="corporationOD-n" onclick="corporation_od(this.value);" id="corporationOD-n"') ?>
														<label for="corporationOD-n"><span><span></span></span>No</label>
													</div>
												</div>
											</div>
										</div>
										<script type="text/javascript">
											$(document).ready(function(){
												<?php if (isset($member->is_corporation) && $member->is_corporation == 'y'): ?>
													$("#divsubparent").slideDown('slow');
												<?php else: ?>
													$("#divsubparent").slideUp('slow');
												<?php endif; ?>
											});
											function corporation_od(v){
												if (v=='y'){
													$("#divsubparent").slideDown('slow');
												} else {
													$("#parentCompany").val(0).trigger("liszt:updated");
													displaychildfields('');
													$("#divsubparent").slideUp('slow');
												}
											}
										</script>
										<?php endif; ?>
										
										<?php if (($member->type <> 'Affiliate' && $member->category <> 'Individual')  && $member->category <> 'Smallholder Group Manager' ): ?>
										<div class="col-sm-12">
											<div id="divsubparent" class="form-group" style="margin-bottom:0px;">
												<label>Are you a parent/subsidiary company?</label><br/>
												<?php echo form_dropdown('parent_company', $parent_companies, $member->parent_company, 'class="selectpicker form-control required" id="parentCompany" title="Please select" onchange="displaychildfields(this.value);"'); ?>
												<br />&nbsp;
											</div>
										</div>
										<script type="text/javascript">
										function displaychildfields(v){
											console.log(v);
											if (v=='yes'){
												$('#gm_editProfile').attr('disabled', false);
											}
											else if (v=='sub'){
												$('#gm_editProfile').attr('disabled', true);
											}
											else {
												$('#gm_editProfile').attr('disabled', true);
											}
										}
										</script>
										<?php endif; ?>
										<script text="text/javascript">
										var cek_parent = $('#parentCompany').val();
										if(cek_parent=='yes'){
											$('#gm_editProfile').attr('disabled', false);
										} else if(cek_parent=='sub'){
											$('#gm_editProfile').attr('disabled', true);
										} else{
											$('#gm_editProfile').attr('disabled', true);
										}
										</script>
										
										<div class="col-sm-12 margin-top-30">
											<div class="pull-right">
												<button type="submit" onmousedown="checkGM()" class="btn btn-black btn-saveprofile" id="btn-save">Save Changes</button>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div id="questions" class="tab-pane fade">
								<div class="row" >
									<div class="list-sub profile-tab-content" >
										<div class="col-sm-12">
											<div class="row-profile-wrapper">
												<label class="block">How will your organisation promote the RSPO internally and to other stakeholders?</label>
												<textarea name="q1" class="form-control" style="height:auto; max-height:300px;"><?php echo htmlspecialchars_decode($member->q1)?></textarea>
												<?php echo form_error('q1') ? '<div class="alert alert-danger">'.form_error('q1').'</div>' : ''; ?>
											</div>
											<div class="row-profile-wrapper">
												<label class="block">
													Where relevant, what proceses is the organisation establishing to engage with interested parties, for example to resolve conflict
													or to use sustainably produces palm oil?
												</label>
												<textarea name="q2" class="form-control" style="height:auto; max-height:300px;"><?php echo htmlspecialchars_decode($member->q2)?></textarea>
												<?php echo form_error('q2') ? '<div class="alert alert-danger">'.form_error('q2').'</div>' : ''; ?>
											</div>
											<div class="row-profile-wrapper">
												<label class="block">
													Where relevant, how will your organisation work towards implementing the RSPO Principles and Criteria or assesing supplier
													performance against these criteria?
												</label>
												<textarea name="q3" class="form-control" style="height:auto; max-height:300px;"><?php echo htmlspecialchars_decode($member->q3)?></textarea>
												<?php echo form_error('q3') ? '<div class="alert alert-danger">'.form_error('q3').'</div>' : ''; ?>
											</div>

											<div class="row-profile-wrapper">
												<label class="block">
													Any other information that would support the application such as what your organization hopes to gain from joining RSPO
													and how it would support RSPO?
												</label>
												<textarea name="q4" class="form-control" style="height:auto; max-height:300px;"><?php echo htmlspecialchars_decode($member->q4)?></textarea>
												<?php echo form_error('q4') ? '<div class="alert alert-danger">'.form_error('q4').'</div>' : ''; ?>
											</div>

											<!--
											<?php if ($member->type<>'Ordinary Members' AND $member->type<>'Affiliate Members' AND $member->category<>'Supply Chain Group Manager' ): ?>
												<div class="row-profile-wrapper">Please state your annual usage of palm oil and palm derivatives in metric tonnes</label>
													<input type="text" class="form-control required" name="q_usage" value="<?php echo $member->q_usage; ?>">
													<?php echo form_error('q_usage') ? '<div class="alert alert-danger">'.form_error('q_usage').'</div>' : ''; ?>
												</div>
											<?php endif; ?>
											-->
										</div>
										<div class="col-sm-12 margin-top-30">
											<div class="pull-right">
												<button type="submit" onmousedown="checkGM()" class="btn btn-black btn-saveprofile" id="btn-save">Save Changes</button>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div id="historyprofile" class="tab-pane fade">
								<div id="logs">
									<?php $this->load->view('partials/member_log'); ?>
								</div>

								<div class="row history-list-wrapper">
									<button type="submit" id="log_more" class="btn btn-lg " style="">Load more...</button>
								</div>
							</div>

							<div id="contacts" class="tab-pane fade">
								<!-- check if user login -->
								<?php 
								if($this->current_user->email == $member->email_p){
									$readonly_email_p = 'readonly="readonly"';
								} else{
									$readonly_email_p = '';
								}
								
								if($this->current_user->email == $member->email_f){
									$readonly_email_f = 'readonly="readonly"';
								} else{
									$readonly_email_f = '';
								}
								
								if($this->current_user->email == $member->email_s){
									$readonly_email_s = 'readonly="readonly"';
								} else{
									$readonly_email_s = '';
								}
								?>
								
								<div class="row" >
									<div class="list-sub profile-tab-content contact_s">
										<div class="bg-f5f5f5 c_form c_form_contact">
											<div class="s_contact contact_1">
												<div class="t_i_contact">
													<p>Primary contact</p>
												</div>
												<div class="fl_name">
													<label for="" class="block">First name</label>
													<div class="input-group no-margin">
														<?php echo form_input('name_p', htmlspecialchars_decode($member->name_p), 'class="form-control required" id="name_p" style="border-right:none;"') ?>
													</div>
													<?php echo form_error('name_p') ? '<div class="alert alert-danger">'.form_error('name_p').'</div>' : ''; ?>
												</div>
												<div class="fl_name">
													<label for="" class="block">Last name</label>
													<div class="input-group no-margin">
														<?php echo form_input('name_last_p', htmlspecialchars_decode($member->name_last_p), 'class="form-control required" id="name_last_p"') ?>
													</div>
													<?php echo form_error('name_last_p') ? '<div class="alert alert-danger">'.form_error('name_last_p').'</div>' : ''; ?>
												</div>
												
												<label for="" class="block">Position</label>
												<div class="input-group no-margin">
													<?php echo form_input('designation_p', htmlspecialchars_decode($member->designation_p), 'class="form-control required" id="designation_p"') ?>
												</div>
												<?php echo form_error('designation_p') ? '<div class="alert alert-danger">'.form_error('designation_p').'</div>' : ''; ?>
												
												<label class="add-pad-am">Telephone</label>
												<div class="input-group no-margin">
													<div class="input-group-addon no-padding">
														<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->telephone_p?>" name="telephone_p">
													</div>
												</div>
												<?php echo form_error('telephone_p') ? '<div class="alert alert-danger">'.form_error('telephone_p').'</div>' : ''; ?>
												
												<label for="" class="block">Email</label>
												<div class="input-group no-margin">
													<?php echo form_input('email_p', $member->email_p, 'class="form-control required" id="email_p" '. $readonly_email_p .'') ?>
												</div>
												<?php echo form_error('email_p') ? '<div class="alert alert-danger">'.form_error('email_p').'</div>' : ''; ?>
											</div>
											<div class="s_contact contact_2">
												<div class="t_i_contact">
													<p>Finance contact</p>
												</div>
												<div class="fl_name">
													<label for="" class="block">First name</label>
													<div class="input-group no-margin">
														<?php echo form_input('name_f', htmlspecialchars_decode($member->name_f), 'class="form-control required" id="name_f" style="border-right:none;"') ?>
													</div>
													<?php echo form_error('name_f') ? '<div class="alert alert-danger">'.form_error('name_f').'</div>' : ''; ?>
												</div>
												<div class="fl_name">
													<label for="" class="block">Last name</label>
													<div class="input-group no-margin">
														<?php echo form_input('name_last_f', htmlspecialchars_decode($member->name_last_f), 'class="form-control required" id="name_last_f"') ?>
													</div>
													<?php echo form_error('name_last_f') ? '<div class="alert alert-danger">'.form_error('name_last_f').'</div>' : ''; ?>
												</div>
												
												<label for="" class="block">Position</label>
												<div class="input-group no-margin">
													<?php echo form_input('designation_f', htmlspecialchars_decode($member->designation_f), 'class="form-control required" id="designation_f"') ?>
												</div>
												<?php echo form_error('designation_f') ? '<div class="alert alert-danger">'.form_error('designation_f').'</div>' : ''; ?>
												
												<label class="add-pad-am">Telephone</label>
												<div class="input-group no-margin">
													<div class="input-group-addon no-padding">
														<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->telephone_f?>" name="telephone_f">
													</div>
												</div>
												<?php echo form_error('telephone_f') ? '<div class="alert alert-danger">'.form_error('telephone_f').'</div>' : ''; ?>
												
												<label for="" class="block">Email</label>
												<div class="input-group no-margin">
													<?php echo form_input('email_f', $member->email_f, 'class="form-control required" id="email_f"  '. $readonly_email_f .'') ?>
												</div>
												<?php echo form_error('email_f') ? '<div class="alert alert-danger">'.form_error('email_f').'</div>' : ''; ?>
											</div>
											<div class="s_contact contact_3">
												<div class="t_i_contact">
													<p>Secondary contact</p>
												</div>
												<div class="fl_name">
													<label for="" class="block">First name</label>
													<div class="input-group no-margin">
														<?php echo form_input('name_s', htmlspecialchars_decode($member->name_s), 'class="form-control required" id="name_s" style="border-right:none;"') ?>
													</div>
													<?php echo form_error('name_s') ? '<div class="alert alert-danger">'.form_error('name_s').'</div>' : ''; ?>
												</div>
												<div class="fl_name">
													<label for="" class="block">Last name</label>
													<div class="input-group no-margin">
														<?php echo form_input('name_last_s', htmlspecialchars_decode($member->name_last_s), 'class="form-control required" id="name_last_s"') ?>
													</div>
													<?php echo form_error('name_last_s') ? '<div class="alert alert-danger">'.form_error('name_last_s').'</div>' : ''; ?>
												</div>
												
												<label for="" class="block">Position</label>
												<div class="input-group no-margin">
													<?php echo form_input('designation_s', htmlspecialchars_decode($member->designation_s), 'class="form-control required" id="designation_s"') ?>
												</div>
												<?php echo form_error('designation_s') ? '<div class="alert alert-danger">'.form_error('designation_s').'</div>' : ''; ?>
												
												<label class="add-pad-am">Telephone</label>
												<div class="input-group no-margin">
													<div class="input-group-addon no-padding">
														<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->telephone_s?>" name="telephone_s">
													</div>
												</div>
												<?php echo form_error('telephone_s') ? '<div class="alert alert-danger">'.form_error('telephone_s').'</div>' : ''; ?>
												
												<label for="" class="block">Email</label>
												<div class="input-group no-margin">
													<?php echo form_input('email_s', $member->email_s, 'class="form-control required" id="email_s" '. $readonly_email_s .'') ?>
												</div>
												<?php echo form_error('email_s') ? '<div class="alert alert-danger">'.form_error('email_s').'</div>' : ''; ?>
											</div>
											<div class="s_contact contact_4">
												<div class="t_i_contact">
													<p>Contact person</p>
												</div>
												<div class="fl_name">
													<label for="" class="block">First Name</label>
													<div class="input-group no-margin">
														<?php echo form_input('contact_person', htmlspecialchars_decode($member->contact_person), 'class="form-control required" id="contact_person" style="border-right:1px solid #F5F5F5!important;" readonly="readonly"') ?>
													</div>
													<?php echo form_error('contact_person') ? '<div class="alert alert-danger">'.form_error('contact_person').'</div>' : ''; ?>
												</div>
												<div class="fl_name">
													<label for="" class="block">Last Name</label>
													<div class="input-group no-margin">
														<?php echo form_input('contact_lname', htmlspecialchars_decode($member->contact_lname), 'class="form-control required" id="contact_lname" readonly="readonly" style="border-right:1px solid #F5F5F5!important;"') ?>
													</div>
													<?php echo form_error('contact_lname') ? '<div class="alert alert-danger">'.form_error('contact_lname').'</div>' : ''; ?>
												</div>
												
												<label for="" class="block">Position</label>
												<div class="input-group no-margin">
													<?php echo form_input('designation', htmlspecialchars_decode($member->designation), 'class="form-control required" id="designation" readonly="readonly"') ?>
												</div>
												<?php echo form_error('designation') ? '<div class="alert alert-danger">'.form_error('designation').'</div>' : ''; ?>
												
												<label class="add-pad-am">Telephone</label>
												<div class="input-group no-margin">
													<div class="input-group-addon no-padding">
														<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->contact_tel?>" name="contact_tel" readonly="readonly">
													</div>
												</div>
												<?php echo form_error('contact_tel') ? '<div class="alert alert-danger">'.form_error('contact_tel').'</div>' : ''; ?>
												
												<label for="" class="block">Email</label>
												<div class="input-group no-margin">
													<?php echo form_input('contact_email', $member->contact_email, 'class="form-control required" id="contact_email" readonly="readonly"') ?>
												</div>
												<?php echo form_error('contact_email') ? '<div class="alert alert-danger">'.form_error('contact_email').'</div>' : ''; ?>
											</div>
										</div>

										<div class="col-sm-12 margin-top-10 pad-lr20">
											<div class="pull-right">
												<a class="btn btn-black btn-saveprofile" onclick="saveContactColorboxConfirm();">Save Changes</a>
											</div>
										</div>
									</div>
								</div>
							</div>
								
							<div id="password" class="tab-pane fade">
								<div class="row list-sub profile-tab-content">
									<div class="col-sm-12">
										<div class="row">
											<div class="col-md-6 col-xs-12 no-pad-l-r">
												<div>You are currently logged in as <b><?php echo $this->current_user->email ?></b></div>
												<!--
												<label>Your name</label>
												<input class="form-control" type="text" maxlength="50" name="display_name" value="<?php echo $this->current_user->display_name ?>"
												-->
												<div class="clearfix"></div>
											</div>

											<div class="clearfix"><br /></div>
											<hr />

											<div class="col-lg-6 no-pad-left">
												<div class="">
													<label>Current Password</label>
													<input type="password" class="form-control" name="currentPassword">
													<?php echo form_error('currentPassword') ? '<div class="alert alert-danger">'.form_error('currentPassword').'</div>' : ''; ?>
												</div>
											</div>

											<div class="col-lg-6 no-pad-right">
												<div class="" style="margin-right: 0px;">
													<label><span>New Password</span></label>
													<input type="password" class="form-control" name="newPassword">
													<?php echo form_error('newPassword') ? '<div class="alert alert-danger">'.form_error('newPassword').'</div>' : ''; ?>
												</div>
												<div class="" style="margin-right: 0px;">
													<label><span>Confirm New Password</span></label>
													<input type="password" class="form-control" name="confirmNewPassword">
													<?php echo form_error('confirmNewPassword') ? '<div class="alert alert-danger">'.form_error('confirmNewPassword').'</div>' : ''; ?>
												</div>
											</div>

											<div class="col-sm-12 no-pad-l-r margin-top-30">
												<div class="pull-right">
													<button type="submit" onmousedown="checkGM()" class="btn btn-black btn-saveprofile" id="btn-save">Save Changes</button>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						
							<div id="g_membership" class="tab-pane fade">
								<div class="row">
									<div class="tabbable tabs-left">
										<div class="filter_left_gm add_out_f_list">
											<a class="g_m_add" onClick="g_m_add(this);"><i class="fa fa-plus"></i> Add new group member</a>
										</div>
										<div class="filter_right_gm"></div>
										
										<!-- Left list GM -->
										<div class="list_group_membership mCustomScrollbar">
											<ul class="nav nav-tabs GM_list_profile">
                                                <?php $i = 1; if($subsidiaries) {
                                                foreach ($subsidiaries as $subsidiary) { ?>
                                                    <li class="gm-index" id="cAsyncGMlist<?php echo $i; ?>" <?php echo ($i==1) ? 'class="active"' : ''; ?>>
                                                        <span><?php echo $i; ?></span>
                                                        <a id="Agm_name<?php echo $i; ?>" href="#gm<?php echo $i; ?>" data-toggle="tab">
                                                            <?php $gm_name = '';
                                                            $gm_name = (isset($_POST['gm_name'.$i])) ? $_POST['gm_name'.$i] : $subsidiary->name;
                                                            ?>
                                                            <p><?php echo (!empty($gm_name)) ? $gm_name : 'New Group Membership'; ?></p>
                                                        </a>
                                                    </li>
                                                <?php $i++;}
                                                } ?>
											</ul>
										</div>
										
										<!-- Form GM -->
										<div class="tab-content list_of_gm_prof">
                                            <?php $i = 1; if($subsidiaries) {
                                            foreach ($subsidiaries as $subsidiary) { ?>
                                                <input type="hidden" value="<?php echo $member->intID; ?>" name="intID">
                                                <div class="tab-pane c_form_list <?php echo ($i==1) ? 'active' : ''; ?>" id="gm<?php echo $i; ?>">
                                                    <!-- filter add only in mobile -->
                                                    <div class="filter_left_gm add_in_f_list">
                                                        <a class="g_m_add" onClick="g_m_add(this);"><i class="fa fa-plus"></i> Add new group member</a>
                                                    </div>

                                                    <!-- filter del each GM -->
                                                    <div class="m_prof_del_gm">
                                                        <a class="g_m_del delete" onclick="delGM('<?php echo $i; ?>', event)"><i class="fa fa-times"></i> Delete this group member</a>
                                                    </div>

                                                    <div class="">
                                                        <div class="c_form_in">
                                                            <label>Group member name*</label>
                                                            <div class="input-group">
                                                                <input id="gm_name<?php echo $i; ?>"
                                                                       autocomplete="off" type="text" class="form-control"
                                                                       name="gm_name<?php echo $i; ?>"
                                                                       value="<?php echo (isset($_POST['gm_name'.$i])) ? $_POST['gm_name'.$i] : $subsidiary->name; ?>"
                                                                       placeholder="" onblur="syncGMlist(this); checkSubsidiaryName(<?php echo $i; ?>);" onchange="syncGMlist(this);">
                                                                <input type="hidden" value="<?php echo $subsidiary->id; ?>"
                                                                       name="gm_id<?php echo $i; ?>"
                                                                       id="gm_id<?php echo $i; ?>">
<!--                                                                <div id="err_gm_name--><?php //echo $i; ?><!--" class="alert alert-danger" style="display:none"></div>-->
                                                                <?php echo form_error('gm_name'.$i) ? '<div class="alert alert-danger " data-gm-index="'.$i.'">Field is required</div>' : ''; ?>
                                                            </div>

                                                            <label class="t_radio l_group_membership type_membership">Type* </label>
                                                            <div class="radio_custom_by_am t_group_membership">
                                                                <div class="yn_left">
                                                                    <input id="gm_type<?php echo $i; ?>-r" name="gm_type<?php echo $i; ?>" value="subsidiary"  type="radio" <?php echo (strtolower($subsidiary->type) == 'management_unit' || strtolower($subsidiary->type) == 'supply_chain_group_manager' || strtolower($subsidiary->type) == 'subsidiary') ? 'checked="checked"' : ''; ?> class="type_sector_s3">
                                                                    <label for="gm_type<?php echo $i; ?>-r">
																		<span><span></span></span>Subsidiary
																		<i></i>
																		<div class="tooltip_am">
																			<div class="content_more">
																				<p><span>Subsidiary</span> - An Entity where the Parent:</p>
																				<ul>
																					<li>holds (whether as a legal owner or as a beneficiary) more than half of the issued share capital of that Entity (excluding any part thereof which consists of preference shares); or</li>
																					<li>controls more than half of the voting power of that Entity; or</li>
																					<li>controls the composition of the board of directors of that Entity.</li>
																				</ul>
																			</div>
																		</div>
																	</label>
                                                                </div>
                                                                <div class="yn_right">
                                                                    <input id="gm_type<?php echo $i; ?>-o" name="gm_type<?php echo $i; ?>" value="Other" type="radio" class="type_sector_s3" <?php echo ($subsidiary->type == 'Other') ? 'checked="checked"' : ''; ?>>
                                                                    <label for="gm_type<?php echo $i; ?>-o"><span><span></span></span>Other...</label>
                                                                </div>
                                                            </div>
                                                            <div class="free_text_other_type" id="free_text_other_type<?php echo $i; ?>" style="display:none;">
                                                                <div class="input-group pad-top-17 pad-bottom-1<?php echo $i; ?>">
                                                                    <input autocomplete="off" class="form-control" value="<?php echo $subsidiary->other_type; ?>" name="gm_other_type<?php echo $i; ?>" id="gm_other_type<?php echo $i; ?>" placeholder="Enter custom group membership type" type="text">
                                                                </div>
<!--                                                                <div id="err_gm_other_type--><?php //echo $i; ?><!--" class="alert alert-danger" style="display:none"></div>-->
                                                                <?php echo form_error('gm_other_type'.$i) ? '<div class="alert alert-danger gmer'.$i.'">Field is required</div>' : ''; ?>
                                                            </div>

                                                            <label class="margin-top-12" style="width:100%;">Nature of business*</label>
                                                            <div class="input-group">
                                                                <select class="selectpicker show-tick form-control" title="Select nature of business"
                                                                        name="gm_nature_of_business<?php echo $i; ?>"
                                                                        id="gm_nature_of_business<?php echo $i; ?>">
                                                                    <option value="Growers" <?php echo (!empty($subsidiary->nature_of_business)) ? ($subsidiary->nature_of_business == 'Growers') ? 'selected="selected"' : '' : set_select('gm_nature_of_business'.$i, 'Growers'); ?>>Growers</option>
                                                                    <option value="Processors and Traders" <?php echo (!empty($subsidiary->nature_of_business)) ? ($subsidiary->nature_of_business == 'Processors and Traders') ? 'selected="selected"' : '' : set_select('gm_nature_of_business'.$i, 'Processors and Traders'); ?>>Processor and/or Traders</option>
                                                                    <option value="Retailers" <?php echo (!empty($subsidiary->nature_of_business)) ? ($subsidiary->nature_of_business == 'Retailers') ? 'selected="selected"' : '' : set_select('gm_nature_of_business'.$i, 'Retailers'); ?>>Retailers</option>
                                                                    <option value="Consumer Goods Manufacturers" <?php echo (!empty($subsidiary->nature_of_business)) ? ($subsidiary->nature_of_business == 'Consumer Goods Manufacturers') ? 'selected="selected"' : '' : set_select('gm_nature_of_business'.$i, 'Consumer Goods Manufacturers'); ?>>Consumer Goods Manufacturers</option>
																	<option value="Other" <?php echo (!empty($subsidiary->nature_of_business)) ? ($subsidiary->nature_of_business == 'Other') ? 'selected="selected"' : '' : set_select('gm_nature_of_business'.$i, 'Other'); ?>>Other</option>
                                                                </select>
<!--                                                                <div id="err_gm_nature_of_business--><?php //echo $i; ?><!--" class="alert alert-danger" style="display:none"></div>-->
                                                                <?php echo form_error('gm_nature_of_business'.$i) ? '<div class="alert alert-danger" data-gm-index="'.$i.'">Field is required</div>' : ''; ?>
                                                            </div>

                                                            <div class="c2_left">
                                                                <label>Countries/Regions*</label>
                                                                <div class="input-group">
                                                                    <select class="selectpicker show-tick form-control" title="Select country/region"
                                                                            onchange="getRegion(<?php echo $i; ?>)"
                                                                            name="gm_country<?php echo $i; ?>"
                                                                            id="gm_country<?php echo $i; ?>">
                                                                        <?php foreach ($new_country_arrays as $country => $region) { ?>
                                                                            <option value="<?php echo $country; ?>" <?php echo  (!empty($subsidiary->country)) ? ($subsidiary->country == $country) ? 'selected' : '' : set_select('gm_country'.$i, $country); ?>><?php echo $country; ?></option>
                                                                        <?php } ?>
                                                                    </select>
																	<i style="position:absolute; top:46px; left:0px; font-size:11px; width:500px;">(The list of countries and regions are in accordance with the <a href="https://unstats.un.org/unsd/methodology/m49/" target="_blank">UN M49</a> standard)</i>
<!--                                                                    <div id="err_gm_country--><?php //echo $i; ?><!--" class="alert alert-danger" style="display:none; margin-bottom:5px; margin-left:-1px; margin-top:60px;"></div>-->
                                                                    <?php echo form_error('gm_country'.$i) ? '<div class="alert alert-danger" data-gm-index="'.$i.'" style="margin-top:60px;">Field is required</div>' : ''; ?>
                                                                </div>
                                                            </div>
                                                            <div class="c2_right">
                                                                <label>Region*</label>
                                                                <div class="input-group region_gm_profile">
                                                                    <input autocomplete="off" type="text" class="form-control"
                                                                           value="<?php echo (!empty($subsidiary->region)) ? $subsidiary->region : set_value('gm_region'. $i)  ?>"
                                                                           name="gm_region<?php echo $i; ?>"
                                                                           id="gm_region<?php echo $i; ?>"
                                                                           placeholder="" readonly="readonly"
                                                                           style="border-left:1px solid transparent!important;">
                                                                </div>
                                                            </div>
															
															<div style="display:inline-block; margin-top:18px;">
																<label class="t_radio l_group_membership">Is this group member an RSPO member?*</label>
																<div class="radio_custom_by_am t_group_membership_y_n">
																	<div class="yn_left">
																		<input id="gm_is_rspo_num<?php echo $i; ?>-y" name="gm_is_rspo_num<?php echo $i; ?>" value="yes" type="radio" class="this_group_membership" <?php echo (!empty($subsidiary->is_rspo_num) && $subsidiary->is_rspo_num == 'yes') ? 'checked="checked"' : ''; ?>><label for="gm_is_rspo_num<?php echo $i; ?>-y"><span><span></span></span>Yes</label>
																	</div>
																	<div class="yn_right">
																		<input id="gm_is_rspo_num<?php echo $i; ?>-n" name="gm_is_rspo_num<?php echo $i; ?>" value="no" type="radio" class="this_group_membership" <?php echo (empty($subsidiary->is_rspo_num) || $subsidiary->is_rspo_num == 'no') ? 'checked="checked"' : ''; ?>><label for="gm_is_rspo_num<?php echo $i; ?>-n"><span><span></span></span>No</label>
																	</div>
																</div>
                                                            </div>

                                                            <div class="show_rspo_membership_number" id="show_rspo_membership_number<?php echo $i; ?>" style="display:none;">
                                                                <label class="margin-top-12">Please enter its RSPO membership
                                                                    number</label>
                                                                <div class="input-group membership_number">
                                                                    <?php
                                                                    $num = ['0','0000','00','000','00'];
                                                                    if (!empty($subsidiary->rspo_membership_num)) {
                                                                        $str = explode('-',$subsidiary->rspo_membership_num);
                                                                        for ($j = 0; $j < 5; $j++) {
                                                                            if (isset($str[$j])) {
                                                                                $num[$j] = $str[$j];
                                                                            }
                                                                        }

                                                                    } elseif (!empty(set_value('gm_firstname'. $i))) {
                                                                        $str = explode('-',set_value('gm_firstname'. $i));
                                                                        for ($j = 0; $j < 5; $j++) {
                                                                            if (isset($str[$j])) {
                                                                                $num[$j] = $str[$j];
                                                                            }
                                                                        }
                                                                    } ?>
                                                                    <input autocomplete="off" class="form-control" value="<?php echo $num[0]; ?>"
                                                                           id="num1<?php echo $i; ?>"
                                                                           onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                           name="num1<?php echo $i; ?>"
                                                                           placeholder="" maxlength="1" type="text">
                                                                    <span>−</span>
                                                                    <input autocomplete="off" class="form-control" value="<?php echo $num[1]; ?>"
                                                                           id="num2<?php echo $i; ?>"
                                                                           onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                           name="num2<?php echo $i; ?>"
                                                                           placeholder="" maxlength="4" type="text">
                                                                    <span>−</span>
                                                                    <input autocomplete="off" class="form-control" value="<?php echo $num[2]; ?>"
                                                                           id="num3<?php echo $i; ?>"
                                                                           onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                           name="num3<?php echo $i; ?>"
                                                                           placeholder="" maxlength="2" type="text">
                                                                    <span>−</span>
                                                                    <input autocomplete="off" class="form-control" value="<?php echo $num[3]; ?>"
                                                                           id="num4<?php echo $i; ?>"
                                                                           onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                           name="num4<?php echo $i; ?>"
                                                                           placeholder="" maxlength="3" type="text">
                                                                    <span>−</span>
                                                                    <input autocomplete="off" class="form-control" value="<?php echo $num[4]; ?>"
                                                                           id="num5<?php echo $i; ?>"
                                                                           onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                           name="num5<?php echo $i; ?>"
                                                                           placeholder="" maxlength="2" type="text">

                                                                    <input name="gm_rspo_membership_num<?php echo $i; ?>"
                                                                           id="gm_rspo_membership_num<?php echo $i; ?>"
                                                                           value="<?php echo $subsidiary->rspo_membership_num; ?>" type="hidden">
                                                                </div>
                                                                <?php echo form_error('gm_rspo_membership_num'.$i) ? '<div class="alert alert-danger" data-gm-index="'.$i.'">Field is required</div>' : ''; ?>
                                                            </div>

                                                            <h2>Group member contact information</h2>
                                                            <div id="gm_AUF_<?php echo $i; ?>" class="input-group">
                                                                <div class="fl_name">
                                                                    <label for="" class="block">First name</label>
                                                                    <div class="input-group no-margin">
                                                                        <input autocomplete="off" type="text" class="form-control gm_firstname_add"
                                                                               value="<?php echo (!empty($subsidiary->firstname)) ? $subsidiary->firstname : set_value('gm_firstname'. $i)  ?>"
                                                                               name="gm_firstname<?php echo $i; ?>"
                                                                               id="gm_firstname<?php echo $i; ?>"
                                                                               placeholder="" style="border-right:none;">
<!--                                                                        <div id="err_gm_firstname--><?php //echo $i; ?><!--" class="alert alert-danger" style="display:none"></div>-->
                                                                        <?php echo form_error('gm_firstname'.$i) ? '<div class="alert alert-danger" data-gm-index="'.$i.'">Field is required</div>' : ''; ?>
                                                                    </div>
                                                                </div>
                                                                <div class="fl_name">
                                                                    <label for="" class="block">Last name</label>
                                                                    <div class="input-group no-margin">
                                                                        <input autocomplete="off" type="text" class="form-control gm_lastname_add"
                                                                               value="<?php echo (!empty($subsidiary->lastname)) ? $subsidiary->lastname : set_value('gm_lastname'. $i)  ?>"
                                                                               name="gm_lastname<?php echo $i; ?>"
                                                                               id="gm_lastname<?php echo $i; ?>"
                                                                               placeholder="">
<!--                                                                        <div id="err_gm_lastname--><?php //echo $i; ?><!--" class="alert alert-danger" style="display:none"></div>-->
                                                                        <?php echo form_error('gm_lastname'.$i) ? '<div class="alert alert-danger" data-gm-index="'.$i.'">Field is required</div>' : ''; ?>
                                                                    </div>
                                                                </div>

                                                                <div class="c2_left c2_e_p">
                                                                    <label for="" class="block">Email address</label>
                                                                    <div class="input-group no-margin">
                                                                        <input autocomplete="off" type="text" class="form-control gm_email_add"
                                                                               value="<?php echo (!empty($subsidiary->email)) ? $subsidiary->email : set_value('gm_email'. $i)  ?>"
                                                                               name="gm_email<?php echo $i; ?>"
                                                                               id="gm_email<?php echo $i; ?>"
                                                                               placeholder="">
<!--                                                                        <div id="err_gm_email--><?php //echo $i; ?><!--" class="alert alert-danger" style="display:none"></div>-->
                                                                        <?php echo form_error('gm_email'.$i) ? '<div class="alert alert-danger" data-gm-index="'.$i.'">'.strip_tags(form_error('gm_email'.$i)).'</div>' : ''; ?>
                                                                    </div>
                                                                </div>
                                                                <div class="c2_right">
                                                                    <label class="add-pad-am">Phone number</label>
                                                                    <div class="input-group no-margin">
<!--                                                                        <div id="err_gm_phone--><?php //echo $i; ?><!--" class="alert alert-danger" style="display:none"></div>-->
                                                                        <?php echo form_error('gm_phone'.$i) ? '<div class="alert alert-danger" data-gm-index="'.$i.'">Field is required</div>' : ''; ?>
                                                                        <div class="input-group-addon no-padding" style="width:100%;">
                                                                            <input class="mobile-number tlp-code form-control gm_phone_add"
                                                                                   type="tel" value="<?php echo (!empty($subsidiary->phone)) ? $subsidiary->phone : set_value('gm_phone'. $i) ?>"
                                                                                   name="gm_phone<?php echo $i; ?>"
                                                                                   id="gm_phone<?php echo $i; ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="align-right margin-top-20 g_membership_button">
<!--                                                                <button onclick="saveGM(event)" id="saveGM--><?php //echo $i; ?><!--" data-gm-index="--><?php //echo $i; ?><!--"  class='btn btn-lg btn-black'>Save</button>-->
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php $i++;}
                                            } ?>
										</div>
									</div>
									
									<div class="verify_gm_profile">
										<div class="verify_gm_profile_l">
											<p>When you have completed editing your group membership details,<br/>please click the Save Changes button.</p>
										</div>
										<div class="verify_gm_profile_r">
                                            <button type="submit" onmousedown="checkGM()" class="btn btn-black btn-saveprofile" id="btn-save">Save Changes</button>
										</div>
									</div>
								</div>
							</div>
							
							<div id="f_acop" class="tab-pane fade">
								<div class="row c_f_acop bg-f5f5f5">
									<p>Your current and latest submission will be uploaded here once all post processing of the report is completed by RSPO.</p>
									<div class="mCustomScrollbar">
										<div id="content_list_custom_table" class="no_border">
											<div class="content_table_file">
												<div id="t_doc_library" class="table-responsive">

												<?php if (!empty($member->acop)): ?>
													<?php
														$a_year_title = array(
															'2005' => '2004/2005',
															'2006' => '2005/2006',
															'2007' => '2006/2007',
															'2008' => '2007/2008',
															'2009' => '2008/2009',
															'2010' => '2009/2010',
															'2011' => '2010/2011',
															'2012' => '2011/2012',
															'2013' => '2012/2013',
															'2014' => '2013/2014',
															'2014b' => '2014',
															'20142' => '2014',
															'2015' => '2015',
															'2016' => '2016',
														);
													?>
													<table id="tableSearchResults_attachments" class="table">
														<tbody>

														<?php foreach($member->acop as $i => $file): ?>
														<?php
															$fname = $file->file_name;
															$a_year = sprintf('%s', trim($file->acopyear));

															switch($a_year)
															{
																case '2013':
																	$real_file = $_SERVER['DOCUMENT_ROOT'].'/file/acop'.$file->acopyear.'/submissions/'.$file->file_name;
																	$file_name = site_url('/file/acop'.$file->acopyear.'/submissions/'.$file->file_name);
																	break;
																case "2014b":
																	$fname = str_ireplace(array('/', ':'), ' ', $file->file_name);
																	$fname = $file->file_name;
																	$fname = str_ireplace('&amp;', '&', $fname);
																	$fname = str_ireplace('/', '-', $fname);
																	$fname = str_ireplace(' ACOP2014', '-ACOP2014', $fname);
																	$real_file = $_SERVER['DOCUMENT_ROOT'].'/file/acop2014b/submissions/'.$fname;
																	$file_name = site_url('/file/acop2014b/submissions/'.$fname);
																	break;
																case '2014':
																	$real_file = $_SERVER['DOCUMENT_ROOT'].$file->file_name;
																	$file_name = site_url($file->file_name);
																	$fname = substr(strrchr($fname, "/"), 1);
																	break;
																default:
																	$real_file = $_SERVER['DOCUMENT_ROOT'].'/file/acop'.$a_year.'/submissions/'.$file->file_name;
																	$file_name = site_url('/file/acop'.$a_year.'/submissions/').'/'.$fname;
																	//site_url($file->file_name);
																	if (strrpos($fname, '/'))
																	{
																		$file_name = site_url('/file/'.$a_year.'/submissions').'/'.substr(strrchr($fname, "/"), 1);
																		$fname = substr(strrchr($fname, "/"), 1);
																		$real_file = $_SERVER['DOCUMENT_ROOT'].$file->file_name;
																	}
															}

															$filesize = '';
															if (file_exists($real_file))
															{
																$filesize = filesize($real_file);
																$len = strlen($filesize);
																if ($len <= 6)
																{
																	$filesize = number_format($filesize/1024, 1, '.', ',') . ' KB';
																}
																elseif ($len >= 7)
																{
																	$filesize = number_format($filesize/1048576, 1, '.', ',') . ' MB';
																}
															}
															else
															{
																$filesize = '';
															}

														?>
															<tr>
																<td>
																	<span class=""><?php echo $i+1 ?></span>
																	<div class="t_names"><?php echo $fname ?> (<?php echo !empty($a_year_title[$file->acopyear]) ? $a_year_title[$file->acopyear] : $file->acopyear; ?>)</div>
																</td>
																<td>
																	<ul>
																	<?php if ($filesize): ?>
																		<!-- still waiting for function preview file <li><a href="2" class="t_preview" alt="preview"></a></li> -->
																		<li><a target="_blank" href="<?php echo $file_name ?>" class="t_download" alt="download"></a></li>
																	<?php else: ?>
																		<!--<li><a href="#" onclick="return false;" class="t_download" alt="download"></a></li> -->
																	<?php endif; ?>
																	</ul>
																</td>
															</tr>
														<?php endforeach; ?>

														</tbody>
													</table>
												<?php else: ?>
													<div class="alert alert-notify" style="margin-bottom: 0px;">Sorry, we could not find any ACOP submissions from you.</div>
												<?php endif; ?>
												</div> 
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
                    <?php } ?>
				</div>
			</form>
		</div>
		
		<div class="questionMembers" style="display:none!important;">
			<a class="maximize">
				<h2>Question?</h2>
			</a>
			<p>if you encountered issues,<br/>please send your question here</p>
			<a href="https://askrspo.force.com/memberships/s/contactsupport" class="btn btn-black" target="_blank">Send your question</a>
			<a class="minimize"></a>
		</div>
		
		</div>
	</div>
</section>

<!-- del modal -->
<div style='display:none'>
	<div id='delete_confirm' class="popup_custom_by_am p_delete">
		<div class="c_popup">
			<p>Are you sure you want to delete this group member permanently?<br/><br/>
                WARNING: All data will be permanently deleted once you agree to proceed by clicking YES</p>
			
			<a class="btn btn-lg btn-gray margin-right-8 cancel_delete">Cancel</a>
			<a class="btn btn-lg btn-black process_delete">Yes, save all progress and delete</a>
		</div>
	</div>
</div>

<!-- save contact modal -->
<div style='display:none'>
    <div id='save_contact_confirm' class="popup_custom_by_am p_delete">
        <div class="c_popup">
            <p>Are you sure want to update email contact? System will delete old user and replaced with new email?</p>

            <a class="btn btn-lg btn-gray margin-right-8 cancel_save_contact">Cancel</a>
            <a class="btn btn-lg btn-black process_save_contact">Yes, continue saving</a>
        </div>
    </div>
</div>

<!-- change organization -->
<div style='display:none'>
	<div id='change_organization' class="popup_custom_by_am p_c_organizations no-pad-l-r">
		<div class="t_popup mar-left-right-30">
			<h2><?php echo count($member_list); ?> Membership(s)</h2>
		</div>
		<div class="c_popup">
			<div class="container_list_line mCustomScrollbar">
				<ul class="list_line">
                    <?php foreach ($member_list as $mem) { ?>
						<?php if($mem->status == 'Approved' || $mem->status == 'Suspended' || $mem->status == 'Draft') { ?>
							<li><a id="member-<?php echo $mem->intID; ?>" class="member-list <?php echo ($this->session->userdata('intID') == $mem->intID) ? 'member-selected' : ''; ?>" onclick="changeCurrentMemberID(<?php echo $mem->intID; ?>);" ><?php echo $mem->title ?></a></li>
                        <?php } else { ?>
                            <li><a class="member-list" disabled="disabled" ><?php echo $mem->title ?> (<?php echo $mem->status ?>)</a></li>
                        <?php } ?>
                    <?php } ?>
				</ul>
            </div>
			
			<div class="notes-div">
				<div class="radio_custom_by_am my_default">
					<ul class="listnone">
						<li>
							<div class="checkbox checkbox-warning">
								<input id="my-default" name="my_default" value="my-default" type="checkbox">
								<label for="my-default">Select this member as my default profile</label>
							</div>
						</li>
					</ul>
				</div>
			</div>
			
            <input id="current_member" name="current_member" type="hidden" value="<?php echo $this->session->userdata('intID'); ?>" />
			<a id="cancel_change" class="btn btn-lg btn-gray margin-right-8 margin-left-30">Cancel</a>
			<a id="default-changes" class="btn btn-lg btn-black margin-right-8" onclick="change_member();" style="display:none;">Change</a>
			<a id="ignore-changes" class="btn btn-lg btn-black margin-right-8" onclick="change_member();" style="display:none;">Ignore changes</a>
			<a id="save-changes" class="btn btn-lg btn-black margin-right-8" style="display:none;">Save and change</a>
			
			<div id="warning-before-changes" class="notes-div" style="margin-top:5px; margin-bottom:0px; display:none;">
				<small>You have unsaved changes. Are you sure you want to change?</small>
			</div>
		</div>
	</div>
</div>

<!-- change default organization -->
<div style='display:none'>
	<div id='change_default_organization' class="popup_custom_by_am p_c_organizations no-pad-l-r">
		<div class="t_popup mar-left-right-30">
			<h2>Please select a member as your default profile.</h2>
		</div>
		<div class="c_popup">
			<div class="container_list_line mCustomScrollbar">
				<ul class="list_line">
                    <?php foreach ($member_list as $mem) {
                        if($mem->status == 'Approved' || $mem->status == 'Suspended' || $mem->status == 'Draft') { ?>
                            <li><a id="default-member-<?php echo $mem->intID; ?>" class="default-member-list <?php echo ($this->session->userdata('default_member_id') == $mem->intID) ? 'member-selected' : ''; ?>" onclick="changeCurrentDefaultMemberID(<?php echo $mem->intID; ?>);" ><?php echo $mem->title ?></a></li>
                        <?php } else { ?>
                            <li><a class="default-member-list" disabled="disabled" ><?php echo $mem->title ?> (<?php echo $mem->status ?>)</a></li>
                        <?php } ?>
                    <?php } ?>
				</ul>
            </div>
            <input id="current_default_member" name="default_member" type="hidden" value="<?php echo $this->session->userdata('default_member_id'); ?>" />
			<a id="cancel_default_change" class="btn btn-lg btn-gray margin-right-8 margin-left-30">Cancel</a>
			<a id="save-changes-default" class="btn btn-lg btn-black margin-right-8" onclick="change_default_member();">Save</a>
		</div>
	</div>
</div>

<!-- redirect to acop now or later -->
<div style='display:none'>
    <div id='redirect_acop_now' class="popup_custom_by_am p_delete">
        <div class="t_popup mar-left-right-30">
            <h2>ACOP 2017 starts from 5th March 2018 til 4th May 2018</h2>
        </div>
        <div class="c_popup">
            <p style="margin-left: 30px;">Do you want to go to your ACOP 2017 online questionnaire now?</p>
            <a id="go_to_acop_now" class="btn btn-lg btn-black margin-right-8 margin-left-30" href="<?php echo site_url('members/go_to_acop'); ?>">Yes</a>
            <a id="go_to_acop_later" class="btn btn-lg btn-black margin-right-8" >Maybe later</a>
        </div>
    </div>
</div>

<!-- container add gm -->
<div style="display:none">
    <div id="componentGM1">
				<label>Group member name*</label>
				<div class="input-group">
					<input id="new_name"
						   autocomplete="off" type="text" class="form-control"
						   value="" name="new_name"
						   placeholder="" onblur="syncGMlist(this);" onchange="syncGMlist(this);">
					<input type="hidden" value="new"
						   name="new_id"
						   id="new_id">
                    <div id="err_new_name" class="alert alert-danger" style="display:none"></div>
				</div>

				<label class="t_radio l_group_membership type_membership">Type* </label>
				<div class="radio_custom_by_am t_group_membership">
					<div class="yn_left">
						<input id="new_type_r" name="new_type"  value="subsidiary" type="radio" checked="checked" class="type_sector_s3">
						<label id="new_label_r" for="new_type">
							<span><span></span></span>Subsidiary
							<i></i>
							<div class="tooltip_am">
								<div class="content_more">
									<p><span>Subsidiary</span> - An Entity where the Parent:</p>
									<ul>
										<li>holds (whether as a legal owner or as a beneficiary) more than half of the issued share capital of that Entity (excluding any part thereof which consists of preference shares); or</li>
										<li>controls more than half of the voting power of that Entity; or</li>
										<li>controls the composition of the board of directors of that Entity.</li>
									</ul>
									<hr/>
									<p><span>Management unit</span> - A unit/office managing a plantation(s) operations</p>
								</div>
							</div>
						</label>
					</div>
					<div class="yn_right">
						<input id="new_type_o" name="new_type"  value="Other" type="radio" class="type_sector_s3">
						<label id="new_label_o" for="new_type"><span><span></span></span>Other...</label>
					</div>
                    <div id="err_new_type" class="alert alert-danger" style="display:none"></div>
				</div>

				<div class="free_text_other_type" id="new_free_text_other_type" style="display:none;">
					<div class="input-group pad-top-17 pad-bottom-10">
						<input autocomplete="off" type="text" class="form-control"
							   value=""
							   name="new_other_type"
							   id="new_other_type"
							   placeholder="Enter custom group membership type">
                        <div id="err_new_other_type" class="alert alert-danger" style="display:none"></div>
					</div>
				</div>
	</div>
	<div id="componentGM2">
						<option value="Growers">Growers</option>
						<option value="Processors and Traders">Processor and/or Trader</option>
						<option value="Retailers">Retailers</option>
						<option value="Consumer Goods Manufacturers">Consumer Goods Manufacturers</option>	
						<option value="Other">Other</option>
	</div>
	<div id="componentGM3">
        <?php foreach ($new_country_arrays as $country => $region) { ?>
            <option value="<?php echo $country; ?>"><?php echo $country; ?></option>
        <?php } ?>
	</div>
	<div id="componentGM4">
				<div class="c2_right">
					<label>Region*</label>
					<div class="input-group">
						<input autocomplete="off" type="text" class="form-control"
							   value=""
							   name="new_region"
							   id="new_region"
							   placeholder="" readonly="readonly"
							   style="border-left:1px solid transparent!important;">
					</div>
				</div>
				
				<div style="display:inline-block; margin-top:18px;">
					<label class="t_radio l_group_membership">Is this group member an RSPO member?*</label>
					<div class="radio_custom_by_am t_group_membership_y_n">
						<div class="yn_left">
							<input id="new_is_rspo_num-y" name="new_is_rspo_num" value="yes"
								   type="radio" class="this_group_membership"><label
									id="new_label_y"
									for="new_is_rspo_num-y"><span><span></span></span>Yes</label>
						</div>
						<div class="yn_right">
							<input id="new_is_rspo_num-n" name="new_is_rspo_num" value="no" checked="checked"
								   type="radio" class="this_group_membership"><label
									id="new_label_n"
									for="new_is_rspo_num-n"><span><span></span></span>No</label>
						</div>
					</div>
				</div>

				<div class="show_rspo_membership_number" id="new_show_rspo_membership_number" style="display:none;">
					<label class="margin-top-12">Please enter its RSPO membership
						number</label>
					<div class="input-group membership_number">
						<input autocomplete="off" class="form-control membership_number1" value="0"
							   id="new_num1"
							   name="new_num1"
							   placeholder="" maxlength="1" type="text">
						<span>−</span>
						<input autocomplete="off" class="form-control membership_number2" value="0000"
							   id="new_num2"
							   name="new_num2"
							   placeholder="" maxlength="4" type="text">
						<span>−</span>
						<input autocomplete="off" class="form-control membership_number3" value="00"
							   id="new_num3"
							   name="new_num3"
							   placeholder="" maxlength="2" type="text">
						<span>−</span>
						<input autocomplete="off" class="form-control membership_number4" value="000"
							   id="new_num4"
							   name="new_num4"
							   placeholder="" maxlength="3" type="text">
						<span>−</span>
						<input autocomplete="off" class="form-control membership_number5" value="00"
							   id="new_num5"
							   name="new_num5"
							   placeholder="" maxlength="2" type="text">

						<input name="new_rspo_membership_num"
							   id="new_rspo_membership_num"
							   value="" type="hidden">
                        <div id="err_new_rspo_membership_num" class="alert alert-danger" style="display:none"></div>
					</div>
				</div>
	</div>
	<div id="componentGM5">
					<h2>Group member contact information</h2>
	</div>
	<div id="componentGM6">
					<div class="fl_name">
						<label for="" class="block">First name</label>
						<div class="input-group no-margin">
							<input autocomplete="off" type="text" class="form-control gm_firstname_add"
								   value=""
								   name="new_firstname"
								   id="new_firstname"
								   placeholder="" style="border-right:none;">
                            <div id="err_new_firstname" class="alert alert-danger" style="display:none"></div>
						</div>
					</div>
					<div class="fl_name">
						<label for="" class="block">Last name</label>
						<div class="input-group no-margin">
							<input autocomplete="off" type="text" class="form-control gm_lastname_add"
								   value=""
								   name="new_lastname"
								   id="new_lastname"
								   placeholder="">
                            <div id="err_new_lastname" class="alert alert-danger" style="display:none"></div>
						</div>
					</div>

					<div class="c2_left c2_e_p">
						<label for="" class="block">Email address</label>
						<div class="input-group no-margin">
							<input autocomplete="off" type="text" class="form-control gm_email_add"
								   value=""
								   name="new_email"
								   id="new_email"
								   placeholder="">
                            <div id="err_new_email" class="alert alert-danger" style="display:none"></div>
						</div>
					</div>
					<div class="c2_right">
						<label class="add-pad-am">Phone number</label>
						<div class="input-group no-margin">
							<div id="err_new_phone" class="alert alert-danger" style="display:none"></div>
							<div class="input-group-addon no-padding" style="width:100%;">
								<input class="mobile-number tlp-code form-control gm_phone_add"
									   type="tel" value=""
									   name="new_phone"
									   id="new_phone">
							</div>
						</div>
					</div>
	</div>
	<div id="componentGM7">
				<div class="align-right margin-top-20 g_membership_button">
<!--                    <button id="silentDelGM_new" class='btn btn-lg btn-gray margin-right-8'>Cancel</button>-->
<!--					<button onclick="saveGM(event)" data-gm-index="new" id="saveGM_new" class='btn btn-lg btn-black'>Save</button>-->
				</div>
	</div>
</div>

<div style='display:none'>
    <div id='success_messages_save' class="popup_custom_by_am">
        <div class="c_popup">
            <p class="no-margin">Your form has been successfully saved</p>
            <i class="fa fa-check" aria-hidden="true"></i>
        </div>
    </div>
</div>

<div style='display:none'>
    <div id='success_messages_verify' class="popup_custom_by_am">
        <div class="c_popup">
            <p class="no-margin">Your form has been verified</p>
            <i class="fa fa-check" aria-hidden="true"></i>
        </div>
    </div>
</div>

<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.7/jquery.validate.min.js"></script>
<script type="text/javascript">
/* show or hide container question box */
$(function () {
	var $win = $(window);
	var $footerHeight = $('footer').height();

	$win.scroll(function () {
		var $pageHeight = $(document).height();
		var $positionScroll = $win.height() + $win.scrollTop();
		var $showQuestion = ($pageHeight - $footerHeight) + 100;	 
		
		var $showQuestion = ($pageHeight - $footerHeight) + 100;	  
		if ($positionScroll >= $showQuestion){
			$('.questionMembers').addClass('show');
		} else{
			$('.questionMembers').removeClass('show');
			
			/* reset css attr */
			$('.questionMembers').css({'height':'',});
			$('.questionMembers h2').css({'margin-top':'',});
			$('.questionMembers a.minimize').css({'display':'block',});
		}
	});
});
$(window).resize(function(){
	$(function () {
		var $win = $(window);
		var $footerHeight = $('footer').height();

		$win.scroll(function () {
			var $pageHeight = $(document).height();
			var $positionScroll = $win.height() + $win.scrollTop();
			
			var $showQuestion = ($pageHeight - $footerHeight) + 100;	  
			if ($positionScroll >= $showQuestion){
				$('.questionMembers').addClass('show');
			} else{
				$('.questionMembers').removeClass('show');
			
				/* reset css attr */
				$('.questionMembers').css({'height':'',});
				$('.questionMembers h2').css({'margin-top':'',});
				$('.questionMembers a.minimize').css({'display':'block',});
			}
		});
	});	
});
$(document).on('click','.maximize',function(){
	$('.questionMembers').css({'height':'200px',});
	$('.questionMembers h2').css({'margin-top':'24px',});
	$('.questionMembers a.minimize').css({'display':'block',});
});
$(document).on('click','.minimize',function(){
	$('.questionMembers').css({'height':'52px',});
	$('.questionMembers h2').css({'margin-top':'13px',});
	$('.questionMembers a.minimize').css({'display':'none',});
});
/* end show or hide container question box */

        /* Change membership */
        function changeCurrentMemberID(intID)
        {
            $("#current_member").val(intID);
            $(".member-list").removeClass('member-selected');
            $("#member-"+intID).addClass('member-list member-selected');
        }

        function changeCurrentDefaultMemberID(intID)
        {
            $("#current_default_member").val(intID);
            $(".default-member-list").removeClass('member-selected');
            $("#default-member-"+intID).addClass('default-member-list member-selected');
        }

        $("#cancel_change").click(function() {
            changeCurrentMemberID(<?php echo $this->session->userdata('intID'); ?>);
            parent.$.colorbox.close();
            return false;
        });

        $("#cancel_default_change").click(function() {
            changeCurrentDefaultMemberID(<?php echo $this->session->userdata('intID'); ?>);
            parent.$.colorbox.close();
            return false;
        });

	    function change_member(){
            var post_data = {intID:$("#current_member").val()};
            if ($("#my-default").is(':checked')) {
                post_data['make_as_default'] = 'my-default';
            }
            $.ajax({
                url: "<?php echo site_url('members/change_default_member_user'); ?>",
                method: "POST",
                data: post_data,
                type: "json",
                success: function(obj){
                    var data = JSON.parse(obj);
                    if (data.status == false) {
                        alert(data.message);
                    }
                    location.reload();
                }
            });
        }

        function change_default_member(){
            var post_data = {default_member:$("#current_default_member").val()};
            $.ajax({
                url: "<?php echo site_url('members/change_default_member'); ?>",
                method: "POST",
                data: post_data,
                type: "json",
                success: function(obj){
                    var data = JSON.parse(obj);
                    if (data.status == false) {
                        alert(data.message);
                    }
                    if(data.default_member_name.length > 0) {
                        $('#default_member_name').text(data.default_member_name);
                    }
                    parent.$.colorbox.close();
                    return false;
                }
            });
        }
		
    /* add new gm */
		var count_gm = <?php echo count($subsidiaries) + 1 ?>; // ini kalau ada data GM dari db need count GM to start autonumber
        function add_more(){
            /* append gm form */
            var componentGM1 = $('#componentGM1').html();
            var componentGM2 = $('#componentGM2').html();
            var componentGM3 = $('#componentGM3').html();
            var componentGM4 = $('#componentGM4').html();
            var componentGM5 = $('#componentGM5').html();
            var componentGM6 = $('#componentGM6').html();
            var componentGM7 = $('#componentGM7').html();
            // $(".list_of_gm_prof").append(componentGM1);
            $(".list_of_gm_prof").append('<div id="new_gm" class="tab-pane c_form_list"><div class="filter_left_gm add_in_f_list"><a class="g_m_add" onClick="g_m_add(this);><i class="fa fa-plus"></i> Add new group member</a></div><div class="m_prof_del_gm"><a id="new_delete" class="g_m_del delete"><i class="fa fa-times"></i> Delete this group member</a></div><div><div class="c_form_in">'+componentGM1+'<label class="margin-top-12" style="width:100%;">Nature of business*</label><div class="input-group"><select class="selectpicker show-tick form-control" title="Select nature of business"  name="new_nature_of_business" id="new_nature_of_business">'+componentGM2+'</select><div id="err_new_nature_of_business" class="alert alert-danger" style="display:none"></div></div><div class="c2_left"><label>Countries/Regions*</label><div class="input-group"><select class="selectpicker show-tick form-control"  title="Select country/region" name="new_country" id="new_country">'+componentGM3+'</select><i style="position:absolute; top:46px; left:0px; font-size:11px; width:500px;">(The list of countries and regions are in accordance with the <a href="https://unstats.un.org/unsd/methodology/m49/" target="_blank">UN M49</a> standard)</i><div id="err_new_country" class="alert alert-danger" style="display:none; margin-bottom:5px; margin-left:-1px; margin-top:60px;"></div></div></div>'+componentGM4+'<div id="new_AUF" class="input-group">'+componentGM5+componentGM6+'</div>'+componentGM7+'</div></div></div>');
			
			var count_li_gm = $('.GM_list_profile li').length;
			var count_li_gm_new = count_li_gm + 1;
			
            /* append anchor gm form */
            $(".GM_list_profile").append('<li id="cAsyncGMlist'+ count_gm +'"><span>'+ count_li_gm_new +'</span><a id="Agm_name'+ count_gm +'" href="#gm'+ count_gm +'" data-toggle="tab"><p>New Group Membership</p></a></li>');
			
			$("#new_nature_of_business").prop({
                id: 'gm_nature_of_business'+count_gm,
                name: 'gm_nature_of_business'+count_gm
            });

            $("#err_new_nature_of_business").prop({
                id: 'err_gm_nature_of_business'+count_gm
            });
			
			$('button[data-id="new_country"]').attr('data-id', 'gm_country'+count_gm );

            $("#new_country").prop({
                id: 'gm_country'+count_gm,
                name: 'gm_country'+count_gm
            }).attr('onchange', 'getRegion('+count_gm+')');

            $("#err_new_country").prop({
                id: 'err_gm_country'+count_gm
            });
			
			$("#new_gm").prop({
                id: 'gm'+count_gm
            });
			
			$("#new_delete").attr({
                id: 'deleteGM'+count_gm,
                onClick: "delGM('"+count_gm+"', event)"
            });
			
			/* ================================ */

			$("#new_AUF").prop({
                id: 'gm_AUF_'+count_gm
            });
			
            $("#new_id").prop({
                id: 'gm_id'+count_gm,
                name: 'gm_id'+count_gm
            });

            $("#new_free_text_other_type").prop({
                id: 'free_text_other_type'+count_gm
            });

            $("#new_name").prop({
                id: 'gm_name'+count_gm,
                name: 'gm_name'+count_gm
            }).attr('onblur', 'syncGMlist(this); checkSubsidiaryName('+count_gm+');');

            $("#err_new_name").prop({
                id: 'err_gm_name'+count_gm
            });

            $("#new_region").prop({
                id: 'gm_region'+count_gm,
                name: 'gm_region'+count_gm
            });
			
            $("#new_is_rspo_num-y").prop({
                id: 'gm_is_rspo_num'+count_gm+'-y',
                name: 'gm_is_rspo_num'+count_gm
            });

            $("#new_label_y").attr({
                id: 'g_is_rspo_num'+count_gm+'-y',
                for: 'gm_is_rspo_num'+count_gm+'-y'
            });

            $("#new_label_n").attr({
                id: 'g_is_rspo_num'+count_gm+'-n',
                for: 'gm_is_rspo_num'+count_gm+'-n'
            });

            $("#new_is_rspo_num-n").prop({
                id: 'gm_is_rspo_num'+count_gm+'-n',
                name: 'gm_is_rspo_num'+count_gm
            });

            var rand_r = 'gm_type'+count_gm+'-r';
            var rand_o = 'gm_type'+count_gm+'-o';

            $("#new_type_r").prop({
                id: rand_r,
                name: 'gm_type'+count_gm
            });

            $("#new_type_o").prop({
                id: rand_o,
                name: 'gm_type'+count_gm
            });

            $("#new_label_r").attr({
                id: 'g_type'+count_gm+'-r',
                for: rand_r
            });

            $("#new_label_o").attr({
                id: 'g_type'+count_gm+'-o',
                for: rand_o
            });

            $("#new_rspo_membership_num").prop({
                id: 'gm_rspo_membership_num'+count_gm,
                name: 'gm_rspo_membership_num'+count_gm
            });

            $("#err_new_rspo_membership_num").prop({
                id: 'err_gm_rspo_membership_num'+count_gm
            });

            $("#new_other_type").prop({
                id: 'gm_other_type'+count_gm,
                name: 'gm_other_type'+count_gm
            });

            $("#err_new_other_type").prop({
                id: 'err_gm_other_type'+count_gm
            });

            $("#new_num1").prop({
                id: 'num1'+count_gm,
                name: 'num1'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_num2").prop({
                id: 'num2'+count_gm,
                name: 'num2'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_num3").prop({
                id: 'num3'+count_gm,
                name: 'num3'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_num4").prop({
                id: 'num4'+count_gm,
                name: 'num4'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_num5").prop({
                id: 'num5'+count_gm,
                name: 'num5'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_firstname").prop({
                id: 'gm_firstname'+count_gm,
                name: 'gm_firstname'+count_gm
            });

            $("#err_new_firstname").prop({
                id: 'err_gm_firstname'+count_gm
            });

            $("#new_lastname").prop({
                id: 'gm_lastname'+count_gm,
                name: 'gm_lastname'+count_gm
            });

            $("#err_new_lastname").prop({
                id: 'err_gm_lastname'+count_gm
            });

            $("#new_email").prop({
                id: 'gm_email'+count_gm,
                name: 'gm_email'+count_gm
            });

            $("#err_new_email").prop({
                id: 'err_gm_email'+count_gm
            });

            $("#new_phone").prop({
                id: 'gm_phone'+count_gm,
                name: 'gm_phone'+count_gm
            });

            $("#err_new_phone").prop({
                id: 'err_gm_phone'+count_gm
            });

//            $("#saveGM_new").prop({
//                id: 'saveGM'+count_gm
//            });

//            $("#silentDelGM_new").attr({
//                id: 'silentDelGM'+count_gm,
//                onClick: "silentDelGM('"+count_gm+"')"
//            });

            $("#total").val(count_gm);
            count_gm++;
            
			mobilenumber();
			$('.selectpicker').selectpicker('refresh');
			
			$(".message_of_no_yes_yes_delete_all_GM").slideUp('slow');
			$(".save_and_continue").slideDown('slow');
			$('.save_and_continue').css({"float":"right"});
			$(".left_m_group_memberships").slideDown('slow');
			
			/* <?php if ($is_parent) { ?>
			$(".skenario_1_g_membership").slideDown('slow');
			<?php } else{ ?>
			document.getElementById("skenario_no_yes_yes").innerHTML = "Based on your answers in the “Preliminary questions” step, you have group members to disclose. Please fill the forms below. You can add or delete group members as you see fit.";
			$(".skenario_1_g_membership").slideDown('slow');
			<?php } ?> */
        }
		
	/* add more GM form */
	function g_m_add(element){
		add_more();
		
		/* add desc each sector */
		desc_sectors();

        var last_index = $('.list_of_gm_prof .c_form_list').last().attr('id').substring(2);
        $("a#Agm_name"+last_index).trigger('click');
	}
	
	/* delete form in target */
	function delGM(which, event){
		deleteColorboxConfirm();
			
		$('.process_delete').click(function(){
            var post_data = {id:$("#gm_id"+which).val()};
            $.ajax({
                url: "<?php echo site_url('members/delete_subsidiary'); ?>",
                method: "POST",
                data: post_data,
                type: "json",
                success: function(obj){
                    var data = JSON.parse(obj);
                    if (data.status == false) {
                        alert(data.message);
                    }
                }
            });
			$("#gm"+which).remove();
			$("#cAsyncGMlist"+which).remove();
			jQuery().colorbox.close();

             next4(event);

			var CountOfGM = $('.list_of_gm_prof .c_form_list').length;
			if(CountOfGM > 0){
                var last_index = $('.list_of_gm_prof .c_form_list').last().attr('id').substring(2);
                $("a#Agm_name"+last_index).trigger('click');
			} else{
				$(".skenario_1_g_membership").slideUp();
				$(".left_m_group_memberships").slideUp();
				
				/* <?php if ($is_parent) { ?>
					$(".skenario_2_g_membership").slideDown('slow');
					$(".save_and_continue").slideDown('slow');
					$('.save_and_continue').css({"float":"left"});
				<?php } else { ?>
					$(".message_of_no_yes_yes_delete_all_GM").slideDown('slow');
					$(".save_and_continue").slideDown('slow');
					$('.save_and_continue').css({"float":"left"});
				<?php } ?> */
			}

			$('.disclose_gm_we_dont').prop('checked', true);
		});
		$('.cancel_delete').click(function(){
			jQuery().colorbox.close();
		});
	}

        /* save contact confirm */
        var cboxOptions_saveContactColorboxConfirm = {
            href: '#save_contact_confirm',
            inline:true,
            width : '100%',
			height: '100%',
            maxWidth: "520px",
            maxHeight: "250px",
            fixed: true,
            close: false,
            onOpen: function(){
                $("#cboxClose").css("opacity", 0);
                $('#cboxOverlay').css({"background":"#000"});
            },
            onComplete: function(){
                $("#cboxClose").css({"opacity": 1});
                $('#cboxOverlay').css({"background":"#000"});
            },
            onClosed:function(){
                $("#cboxClose").css({"opacity": 0});
                $('#cboxOverlay').css({"background":"#000"});
            }
        };
        function saveContactColorboxConfirm(){
            $.colorbox(cboxOptions_saveContactColorboxConfirm);
        }
        $(window).resize(function(){
            $.colorbox.resize({
                width: window.innerWidth > parseInt(cboxOptions_saveContactColorboxConfirm.maxWidth) ? cboxOptions_saveContactColorboxConfirm.maxWidth : cboxOptions_saveContactColorboxConfirm.width,
                height: window.innerHeight > parseInt(cboxOptions_saveContactColorboxConfirm.maxHeight) ? cboxOptions_saveContactColorboxConfirm.maxHeight : cboxOptions_saveContactColorboxConfirm.height
            });
        });
	
	/* delete confirm */
	var cboxOptions_deleteColorboxConfirm = {
		href: '#delete_confirm',
		inline:true, 
		width : '100%',
		height: '100%',
		maxWidth: "520px",
		maxHeight: "250px",
		fixed: true,
		close: false,
		onOpen: function(){
			$("#cboxClose").css("opacity", 0);
			$('#cboxOverlay').css({"background":"#000"});
		},
		onComplete: function(){
			$("#cboxClose").css({"opacity": 1});
			$('#cboxOverlay').css({"background":"#000"});
		},
		onClosed:function(){
			$("#cboxClose").css({"opacity": 0});
			$('#cboxOverlay').css({"background":"#000"});
		}
	}	
	function deleteColorboxConfirm(){    
		$.colorbox(cboxOptions_deleteColorboxConfirm);
	}
	$(window).resize(function(){
		$.colorbox.resize({
			width: window.innerWidth > parseInt(cboxOptions_deleteColorboxConfirm.maxWidth) ? cboxOptions_deleteColorboxConfirm.maxWidth : cboxOptions_deleteColorboxConfirm.width,
			height: window.innerHeight > parseInt(cboxOptions_deleteColorboxConfirm.maxHeight) ? cboxOptions_deleteColorboxConfirm.maxHeight : cboxOptions_deleteColorboxConfirm.height
		});
	});
	
	/* change organization */
	var cboxOptions_changeOrganizationsColorboxConfirm = {
		href: '#change_organization',
		inline:true, 
		width : '100%',
		height: '100%',
		maxWidth: "655px",
		maxHeight: "630px",
		fixed: true,
		close: false,
		onOpen: function(){
			$("#cboxClose").css("opacity", 0);
			$('#cboxOverlay').css({"background":"#000"});
		},
		onComplete: function(){
			$("#cboxClose").css({"opacity": 1});
			$('#cboxOverlay').css({"background":"#000"});
			$('body').css({"overflow-y":"hidden"});
		},
		onClosed:function(){
			$("#cboxClose").css({"opacity": 0});
			$('#cboxOverlay').css({"background":"#000"});
			$('body').css({"overflow-y":"unset"});
		}
	}
	function changeOrganizationsColorboxConfirm(){
        DetectChanges();
        if(formEdited) {
            $('#ignore-changes').show();
            $('#save-changes').show();
            $('#warning-before-changes').show();
            $('#default-changes').hide();
        } else {
            $('#ignore-changes').hide();
            $('#save-changes').hide();
            $('#warning-before-changes').hide();
            $('#default-changes').show();
        }
		$.colorbox(cboxOptions_changeOrganizationsColorboxConfirm);
	}
	$(window).resize(function(){
		$.colorbox.resize({
			width: window.innerWidth > parseInt(cboxOptions_changeOrganizationsColorboxConfirm.maxWidth) ? cboxOptions_changeOrganizationsColorboxConfirm.maxWidth : cboxOptions_changeOrganizationsColorboxConfirm.width,
			height: window.innerHeight > parseInt(cboxOptions_changeOrganizationsColorboxConfirm.maxHeight) ? cboxOptions_changeOrganizationsColorboxConfirm.maxHeight : cboxOptions_changeOrganizationsColorboxConfirm.height
		});
	});

	/* change default organization */
	var cboxOptions_changeDefaultOrganization = {
		href: '#change_default_organization',
		inline:true, 
		width : '100%',
		height : '100%',
		maxWidth: "655px",
		maxHeight: "600px",
		fixed: true,
		close: false,
		onOpen: function(){
			$("#cboxClose").css("opacity", 0);
			$('#cboxOverlay').css({"background":"#000"});
		},
		onComplete: function(){
			$("#cboxClose").css({"opacity": 1});
			$('#cboxOverlay').css({"background":"#000"});
			$('body').css({"overflow-y":"hidden"});
		},
		onClosed:function(){
			$("#cboxClose").css({"opacity": 0});
			$('#cboxOverlay').css({"background":"#000"});
			$('body').css({"overflow-y":"unset"});
		}
	}
	function changeDefaultOrganization(){
		$.colorbox(cboxOptions_changeDefaultOrganization);
	}
	$(window).resize(function(){
		$.colorbox.resize({
			width: window.innerWidth > parseInt(cboxOptions_changeDefaultOrganization.maxWidth) ? cboxOptions_changeDefaultOrganization.maxWidth : cboxOptions_changeDefaultOrganization.width,
			height: window.innerHeight > parseInt(cboxOptions_changeDefaultOrganization.maxHeight) ? cboxOptions_changeDefaultOrganization.maxHeight : cboxOptions_changeDefaultOrganization.height
		});
	});
	
	// run if default organization empty
	$(document).ready(function(){
        <?php //if (count($member_list) > 1) { ?>
        <?php if($this->session->userdata('default_member_name') == 'Not set' && (count($member_list) > 1)) { ?>
			$.colorbox(cboxOptions_changeDefaultOrganization);
		<?php } ?>
        <?php if($this->input->cookie($this->current_user->user_id) !== 'seen' && $acop_start_date < now() && $acop_end_date > now()) { ?>
            $.colorbox(cboxGoToACOPNow);
        <?php } ?>
	});

        $("#go_to_acop_later").click(function() {
            $.ajax({
                url: "<?php echo site_url('members/go_to_acop'); ?>",
                method: "POST",
                data: {go_acop:'later'},
                type: "json",
                success: function(obj){
                    console.log(obj);
                }
            });
            parent.$.colorbox.close();
            return false;
        });

	/* goToACOPNow */
	var cboxGoToACOPNow = {
		href: '#redirect_acop_now',
		inline:true,
		width : '100%',
		height : '100%',
		maxWidth: "655px",
		maxHeight: "600px",
		fixed: true,
		close: false,
		onOpen: function(){
			$("#cboxClose").css("opacity", 0);
			$('#cboxOverlay').css({"background":"#000"});
		},
		onComplete: function(){
			$("#cboxClose").css({"opacity": 1});
			$('#cboxOverlay').css({"background":"#000"});
			$('body').css({"overflow-y":"hidden"});
		},
		onClosed:function(){
            $.ajax({
                url: "<?php echo site_url('members/go_to_acop'); ?>",
                method: "POST",
                data: {go_acop:'later'},
                type: "json",
                success: function(obj){
                    console.log(obj);
                }
            });
			$("#cboxClose").css({"opacity": 0});
			$('#cboxOverlay').css({"background":"#000"});
			$('body').css({"overflow-y":"unset"});
		}
	}
	function goToACOPNow(){
		$.colorbox(cboxGoToACOPNow);
	}
	$(window).resize(function(){
		$.colorbox.resize({
			width: window.innerWidth > parseInt(cboxGoToACOPNow.maxWidth) ? cboxGoToACOPNow.maxWidth : cboxGoToACOPNow.width,
			height: window.innerHeight > parseInt(cboxGoToACOPNow.maxHeight) ? cboxGoToACOPNow.maxHeight : cboxGoToACOPNow.height
		});
	});

	/* click cancel each form */
	function silentDelGM(which){
            var post_data = {id:$("#gm_id"+which).val()};
            $.ajax({
                url: "<?php echo site_url('members/delete_subsidiary'); ?>",
                method: "POST",
                data: post_data,
                type: "json",
                success: function(obj){
                    var data = JSON.parse(obj);
                    if (data.status == false) {
                        alert(data.message);
                    }
                }
            });
			$("#gm"+which).remove();
			$("#cAsyncGMlist"+which).remove();

			var CountOfGM = $('.list_of_gm_prof .c_form_list').length;
			console.log(CountOfGM);
			if(CountOfGM > 0){

			} else{
				$(".skenario_1_g_membership").slideUp();
				$(".left_m_group_memberships").slideUp();

				/* <?php if ($is_parent) { ?>
					$(".skenario_2_g_membership").slideDown('slow');
					$(".save_and_continue").slideDown('slow');
					$('.save_and_continue').css({"float":"left"});
				<?php } else { ?>
					$(".message_of_no_yes_yes_delete_all_GM").slideDown('slow');
					$(".save_and_continue").slideDown('slow');
					$('.save_and_continue').css({"float":"left"});
				<?php } ?> */
			}

			$('.disclose_gm_we_dont').prop('checked', true);

	}
</script>
<script type="text/javascript">
    $("#btnSubmit").click(function (event) {
        event.preventDefault();
        var post_data =  {intID:<?php echo $member->intID ?>};
        $("[id^='gm_']").each(function(data){
            temp = this.id.replace("-y", "");
            temp = temp.replace("-n", "");
            temp = temp.replace("-r", "");
            temp = temp.replace("-o", "");
            if (this.type == 'radio') {
                if (this.checked) {
                    post_data[temp] = this.value;
                }
            } else {
                post_data[temp] = this.value;
            }
        });

        console.log(post_data);

        $.ajax({
            url: "<?php echo site_url('members/verify_GM'); ?>",
            method: "POST",
            data: post_data,
            type: "json",
            success: function(obj){
                var data = JSON.parse(obj);
                if(data.status == false) {
                    $.each(data.error, function( index, value ) {
                        $("#err_"+index).hide();
                        if(value !== '') {
                            $("#err_"+index).text(value);
                            $("#err_"+index).show();
                        }
                    });
                } else {

                    SuccessColorboxConfirmVerify();
                    setTimeout(parent.$.colorbox.close, 1800);
//                    var post_data = {intID:<?php //echo $member->intID ?>//};
//                    $.ajax({
//                        url: "<?php //echo site_url('members/verify_GM'); ?>//",
//                        method: "POST",
//                        data: post_data,
//                        type: "json",
//                        success: function(obj){
//                            var data = JSON.parse(obj);
//                            console.log(data);
//                            if (data.status == false) {
//                                alert(data.message);
//                            } else {
//                                SuccessColorboxConfirm();
//                            }
//                        }
//                    });
                }
            }
        });

    });

var SITE_URL = 'http://rspo.catalyze.id/';
var log_count = 0;
var log_loaded = 10;
var form = document.getElementById("member_profile");
var formEdited = false;

    function DetectChanges() {
        var f = FormChanges(form);
        var msg = "";
        for (var e = 0, el = f.length; e < el; e++) {
            if(f[e].id === 'gm_phone0' && f[e].value === '+62 ') {

            } else {
                formEdited = true;
            }
        }
    }

var cboxOptions_SuccessColorboxConfirmSave = {
    href: '#success_messages_save',
    inline:true,
    width : '100%',
	height: '100%',
    maxWidth: "361px",
    maxHeight: "90px",
    fixed: true,
    bottom: 20,
    right: 20,
    close: false,
    onOpen: function(){
        $("#cboxClose").css("opacity", 0);
        $('#cboxOverlay').css({"background":"transparent"});
    },
    onComplete: function(){
        $("#cboxClose").css({"opacity": 0});
        $('#cboxOverlay').css({"background":"transparent"});
    },
    onClosed:function(){
        $("#cboxClose").css({"opacity": 0});
        $('#cboxOverlay').css({"background":"transparent"});
    }
}
function SuccessColorboxConfirmSave(){
    $.colorbox(cboxOptions_SuccessColorboxConfirmSave);
}
$(window).resize(function(){
	$.colorbox.resize({
		width: window.innerWidth > parseInt(cboxOptions_SuccessColorboxConfirmSave.maxWidth) ? cboxOptions_SuccessColorboxConfirmSave.maxWidth : cboxOptions_SuccessColorboxConfirmSave.width,
		height: window.innerHeight > parseInt(cboxOptions_SuccessColorboxConfirmSave.maxHeight) ? cboxOptions_SuccessColorboxConfirmSave.maxHeight : cboxOptions_SuccessColorboxConfirmSave.height
	});
});

var cboxOptions_SuccessColorboxConfirmVerify = {
    href: '#success_messages_verify',
    inline:true,
    width : '100%',
	height: '100%',
    maxWidth: "361px",
    maxHeight: "90px",
    fixed: true,
    bottom: 20,
    right: 20,
    close: false,
    onOpen: function(){
        $("#cboxClose").css("opacity", 0);
        $('#cboxOverlay').css({"background":"transparent"});
    },
    onComplete: function(){
        $("#cboxClose").css({"opacity": 0});
        $('#cboxOverlay').css({"background":"transparent"});
    },
    onClosed:function(){
        $("#cboxClose").css({"opacity": 0});
        $('#cboxOverlay').css({"background":"transparent"});
    }
}
function SuccessColorboxConfirmVerify(){
    $.colorbox(cboxOptions_SuccessColorboxConfirmVerify);
}
$(window).resize(function(){
	$.colorbox.resize({
		width: window.innerWidth > parseInt(cboxOptions_SuccessColorboxConfirmVerify.maxWidth) ? cboxOptions_SuccessColorboxConfirmVerify.maxWidth : cboxOptions_SuccessColorboxConfirmVerify.width,
		height: window.innerHeight > parseInt(cboxOptions_SuccessColorboxConfirmVerify.maxHeight) ? cboxOptions_SuccessColorboxConfirmVerify.maxHeight : cboxOptions_SuccessColorboxConfirmVerify.height
	});
});

/* get region */
function getRegion(index){
    var country = $("#gm_country"+index).val();
    var post_data = {country: country};
    $.ajax({
        url: "<?php echo site_url('members/get_region'); ?>",
        method: "POST",
        data: post_data,
        type: "json",
        success: function(obj){
            var data = JSON.parse(obj);
            if (data.status == true) {
                $("#gm_region"+index).val(data.data);
            }
        }
    });

    $.ajax({
        url: "<?php echo site_url('members/countrycode'); ?>",
        method: "POST",
        data: {c: country},
        type: "json",
        success: function(obj){
            $('#gm_phone'+index).intlTelInput("selectCountry", obj);
        }
    });
}

    $("input[id^='gm_']").blur(function() {
        if ($(this).val() !== '') {
            if ($(this).next().hasClass('alert')) {
                $(this).next().hide();    
            }
        }
    });

function saveGM(event){
    event.preventDefault();
    $("[id^='gm_']").prop('required',true);

    var myform = $("#member_profile")[0];
    if (!myform.checkValidity()) {
        console.log('checkValidity == false');
        if (myform.reportValidity) {
            console.log('reportValidity == true');
            myform.reportValidity();
        } else {
            console.log('reportValidity == false');
        }
    } else {
        console.log('checkValidity == true');
        $("[id^='gm_']").prop('required',false);
        next4(event);
    }
}

function implodeNumber(counter) {
    var member_num = [
        $("#num1"+counter).val(),
        $("#num2"+counter).val(),
        $("#num3"+counter).val(),
        $("#num4"+counter).val(),
        $("#num5"+counter).val()
    ];
    $("#gm_rspo_membership_num"+counter).val(member_num.join("-"));
}

    function checkGM() {
        event.preventDefault();
        $("[id^='gm_']").prop('required',false);
        $('form#member_profile').trigger('submit');
    }

function next4(event){
    event.preventDefault();
    var post_data = {intID:<?php echo $member->intID ?>};
    $("[id^='gm_']").each(function(data){
        temp = this.id.replace("gm_", "");
        temp = temp.replace("-y", "");
        temp = temp.replace("-n", "");
        temp = temp.replace("-r", "");
        temp = temp.replace("-o", "");
        if (this.type == 'radio') {
            if (this.checked) {
                post_data[temp] = this.value;
            }
        } else {
            post_data[temp] = this.value;
        }
    });

        $.ajax({
            url: "<?php echo site_url('members/save_subsidiary'); ?>",
            method: "POST",
            data: post_data,
            type: "json",
            success: function(obj){
                var data = JSON.parse(obj);
                if (data.status == false) {
                    alert(data.message);
                } else {
                    $.each(data.data, function( index, value ) {
                        $("#gm_id"+index).prop({
                            value: value
                        });
                    });

                    SuccessColorboxConfirmSave();
					setTimeout(parent.$.colorbox.close, 1800);
                }
            }
        });
}

$(document).ready(function(){
	/*
		$("#member_profile").on('submit', function(e){
			$('.alert').fadeTo('fast', 0);
			$('.div_overlay').fadeIn('fast');
		});
	*/

    <?php
    if (!empty($subsidiaries)) {
    $counter = 1;
    foreach($subsidiaries as $sub) {
    if (!empty($sub->is_rspo_num) && $sub->is_rspo_num == 'yes') { ?>
    $("#show_rspo_membership_number<?php echo $counter; ?>").slideDown('slow');
    <?php } else { ?>
    $("#show_rspo_membership_number<?php echo $counter; ?>").slideUp('slow');
    <?php }
    $counter++;}
    } else { ?>
    $("#show_rspo_membership_number0").slideUp('slow');
    <?php } ?>

	$(function(){
		$(".mobile-number").intlTelInput({
			//autoFormat: false,
			//autoHideDialCode: false,
			//defaultCountry: "jp",
			//nationalMode: true,
			//onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
			//preferredCountries: ['cn', 'jp'],
			//responsiveDropdown: true,
			defaultCountry: "",
			utilsScript: "utils.js",
			defaultStyling: "outside"
		})
	});

	$('.tab-pane').each(function(idx, v){

		var i = $(this).attr('id');
		var f = $(this).find('.alert').text();

        if (i == 'f_acop') {
            $("a#link_editprofile").trigger('click');
            return false;
        }
		if (f)
		{
			$("a#link_"+i).trigger('click');
            if(i == 'g_membership') {
                var gm_index = $(this).find('.alert').attr('data-gm-index');
                $("a#Agm_name"+gm_index).trigger('click');
                return false;
            }
			return false;
		}
	});

    $('#save-changes').on('click', function(e){
        e.preventDefault();
        parent.$.colorbox.close();
        $('<input />').attr('type', 'hidden')
            .attr('name', "reload_intID")
            .attr('value', $("#current_member").val())
            .appendTo('#member_profile');
        $('form#member_profile').trigger('submit');
    });

	$('form#member_profile').on('submit', function(e){

		var fil_name_p = $('#name_p').val();
		var fil_name_last_p = $('#name_last_p').val();
			
		var fil_name_s = $('#name_s').val();
		var fil_name_last_s = $('#name_last_s').val();
			
		var fill_name_p_last = fil_name_p + ' ' + fil_name_last_p;
		var fill_name_s_last = fil_name_s + ' ' + fil_name_last_s;
			
		//if ( $('#name_p').val() == $('#name_s').val() || $('#designation_p').val() == $('#designation_s').val() || $('#email_p').val() == $('#email_s').val() )
// 		if ( fill_name_p_last == fill_name_s_last || $('#designation_p').val() == $('#designation_s').val() || $('#email_p').val() == $('#email_s').val() )
        if ((fill_name_s_last != ' ' || fill_name_p_last!= ' ') && (fill_name_p_last == fill_name_s_last || $('#designation_p').val() == $('#designation_s').val() || $('#email_p').val() == $('#email_s').val() ))
		{
		    var msg = '';
		    if (fill_name_p_last == fill_name_s_last && (fill_name_s_last != ' ' || fill_name_p_last!= ' ')) {
                msg += "Primary and Secondary name can not be the same.\n";
            }
            if ($('#designation_p').val() == $('#designation_s').val()) {
                msg += "Primary and Secondary position can not be the same.\n";
            }
            if ($('#email_p').val() == $('#email_s').val()) {
                msg += "Primary and Secondary email can not be the same.\n";
            }
			alert(msg);
			$('#tab_contact').trigger('click');
			$("html, body").animate({
				scrollTop: $("#members-prof").offset().top
			}, 50);
			return false;
		}

		$('.alert').fadeTo('fast', 0);
		$('.div_overlay').fadeIn('fast');

		//alert('fill_name_p_last: '+fill_name_p_last+'; fill_name_s_last: '+fill_name_s_last);
		//return false;
	});

    $('.process_save_contact').click(function(){
        jQuery().colorbox.close();
        $('form#member_profile').trigger('submit');
    });

    $('.cancel_save_contact').click(function(){
        jQuery().colorbox.close();
    });

	if (log_count <= log_loaded)
	{
		$('#log_more').hide();
	}

	$('#log_more').on('click', function(e){
		e.preventDefault();
		if (log_loaded < log_count)
		{
			$.ajax({
				url: SITE_URL + 'members/getlog',
				data: {offset: log_loaded},
				method: 'post',
				datatype: 'json',
				success: function(obj){
					obj = JSON.parse(obj);

					if (obj.log_loaded && obj.logs)
					{
						log_loaded = log_loaded + obj.log_loaded;
						$('#logs').append('<div id="'+obj.id+'" class="new_logs">'+obj.logs+'</div>');
						$('#'+obj.id).fadeIn();
					}

					if (log_loaded >= log_count)
						$('#log_more').hide();
				}
			});
		}
	});

	$('a#add_scgm').click(function(e){
		e.preventDefault();
		var h = '							<tr>'+
				'							<td style="width:70%;padding-right:5px;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control required" /></td>'+
				'							<td style="width:30%;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control max500 required" style="float:left;width:75%;" /><a href="#" class="btn btn-lg btn-orange remove_scgm" style="width:25%;">x</a></td>'+
				'						</tr>';

		$('#scgm_table > tbody:last').append(h);
	});

	$('.remove_scgm').livequery('click', function(e){
		if (confirm('Are you sure you want to delete this row?'))
		{
			var d = $(this).parent().parent();
			d.fadeOut('fast', function(e){
				d.remove().empty();
			});
			e.preventDefault();
		}
		return false;
	});

	$('.max500').livequery('blur', function(e){
		var v = $(this).val();
		var d = $('#scgm_table');
		if (v)
		{
			var n = $.isNumeric(v);
			if (!n)
			{
				$(this).val('');
				if (d.parent().find('div.alert').html()==undefined)
				{
					d.parent().append('<div class="alert alert-danger">Please enter Palm Oil Consumption in numbers (metric tonnes).</div>');
				}
				else
				{
					d.parent().find('div.alert').fadeTo('fast', 0, function(){
						$(this).html('Please enter Palm Oil Consumption in numbers (metric tonnes).').fadeTo('fast', 1);
					});
				}
			}
			else
			{
				if (v > 500)
				{
					$(this).val('');
					if (d.parent().find('div.alert').html()==undefined)
					{
						d.parent().append('<div class="alert alert-danger">Please enter a number less than 500.</div>');
					}
					else
					{
						d.parent().find('div.alert').fadeTo('fast', 0, function(){
							$(this).html('Please enter a number less than 500.').fadeTo('fast', 1);
						});
					}
				}
				else
				{
					d.parent().find('div.alert').fadeTo('fast', 0);
				}
			}
		}
	});
});

function in_array (needle, haystack, argStrict) {
	var key = '', strict = !!argStrict;

	if (strict) {
		for (key in haystack) {
			if (haystack[key] === needle) {
				return true;
			}
		}
	} else {
		for (key in haystack) {
			if (haystack[key] == needle) {
				return true;
			}
		}
	}

	return false;
}

function copyfname(v,divname,t){
	var ftocheck = (t==undefined) ? ftocheck = 'doc' : t;

	//(this.value, $(this), 'all')

	var id = divname.attr('id');

	if (ftocheck != "" && ftocheck == 'image')
	{
		var e = ['gif','jpg','jpeg', 'png'];
		var msg = 'GIF, JPG, JPEG, PNG';
	}
	else if (ftocheck != "" && ftocheck == 'all')
	{
		var e = ['pdf','doc','xls','docx','xlsx','gif','jpg','jpeg', 'png','kml','kmz'];
		var msg = 'PDF, DOC, DOCX, XLS, XLSX, GIF, JPG, JPEG, PNG, KML, KMZ';
	}
	else
	{
		var e = ['pdf','doc','xls','docx','xlsx'];
		var msg = 'PDF, DOC, DOCX, XLS, XLSX';
	}

	if (v)
	{
		//console.log('v: '+v);
		// check for extension
		var ext = v.substr((~-v.lastIndexOf(".") >>> 0) + 2);
		//if (ext.toLowerCase() == 'pdf')
		if (in_array(ext.toLowerCase(), e))
		{
			var nextdiv = $(":input:eq(" + ($(":input").index(divname) + 2) + ")");

			//console.log('rel: '+nextdiv.attr('rel'));
			//console.log('next div index: '+$(":input").index(divname));

			if (v)
			{
				//console.log('setting value for nextdiv');
				nextdiv.val(v);
			}
		}
		else
		{

			divname.wrap('<form>').closest('form').get(0).reset();
			divname.unwrap();

			alert('Please upload only '+msg+' format file.\nThank you...');

			return false;
		}
	}
}

$(function(){
    $("li.tab-profile").click(function(){
        var elm = $(this).children("a");
        elm[0].click(function(e){e.stopPropagation()});
    });
})
</script>
<script type='text/javascript'>
/* scroll custom */
$(window).ready(function(){
	$(".mCustomScrollbar").mCustomScrollbar({
		/* mouseWheelPixels: 250, */
		scrollInertia: 500	
	});
});
</script>
<script type='text/javascript'>
	/* tab group membership */
	$(window).ready(function(){
		/* Is this group member an RSPO member? */
		if($('.this_group_membership').is(":checked")) {
			var cek_is_no_gm_number_val = $('.this_group_membership').val();
			if(cek_is_no_gm_number_val == 'yes'){
				$(this).closest(".c_form_list").find(".show_rspo_membership_number").slideDown('slow');
			} else{
				$(this).closest(".c_form_list").find(".show_rspo_membership_number").slideUp('slow');
			}
		} else {
			$('.show_rspo_membership_number').slideUp('slow');
		}
		$(document).on('click','.this_group_membership',function(){

			var get_val_this_group_membership = $(this).val();
			// alert(get_val_type_sector_s3);

			if(get_val_this_group_membership == 'yes'){
				$(this).closest(".c_form_list").find(".show_rspo_membership_number").slideDown('slow');
			} else{
				$(this).closest(".c_form_list").find(".show_rspo_membership_number").slideUp('slow');
			}

		});
		
		/* type other */
		if($('.type_sector_s3').is(":checked")) {
			var cek_other_val = $('.type_sector_s3').val();
			if(cek_other_val == 'Other'){
				$(this).closest(".c_form_list").find(".free_text_other_type").slideDown('slow');
			} else{
				$(this).closest(".c_form_list").find(".free_text_other_type").slideUp('slow');
			}
		} else {
			$('.free_text_other_type').slideUp('slow');
		}
		$(document).on('click','.type_sector_s3',function(){
				
			var get_val_type_sector_s3 = $(this).val();
			// alert(get_val_type_sector_s3);
				
			if(get_val_type_sector_s3 == 'Other'){
				$(this).closest(".c_form_list").find(".free_text_other_type").slideDown('slow');
			} else{
				$(this).closest(".c_form_list").find(".free_text_other_type").slideUp('slow');
			}
				
		});
	});

	$(document).ready(function(){
        <?php if (!empty($subsidiaries)) {
        $counter = 1;
        foreach($subsidiaries as $sub) {
        if (!empty($sub->type == 'Other')) { ?>
        $("#free_text_other_type<?php echo $counter; ?>").slideDown('slow');
        <?php } else { ?>
        $("#free_text_other_type<?php echo $counter; ?>").slideUp('slow');
        <?php }
        $counter++;
        }
        } ?>

		/* membernumber next auto */
		$(document).on('keyup','.membership_number input',function(){
			if($(this).val().length==$(this).attr("maxlength")){
				$(this).next('span').next().focus();
			}
		});
		
		/* focus text clear val */
		$(document).on('focus','.membership_number input',function(){
			// pertama load, cek apa sudah ada val
			// kalau gak ada, simpen val sekrang ke data()
			if (!$(this).data('defaultText')) $(this).data('defaultText', $(this).val());

			// cek apakah data sama
			if ($(this).val()==$(this).data('defaultText')) $(this).val('');
		});

		$(document).on('blur','.membership_number input',function(){
			// jika gak ada val maka set defaultText
			if ($(this).val()=='') $(this).val($(this).data('defaultText')); 
		});
	});
	
	/* sync GM list with anchor */
	function syncGMlist(getid) {
		var id = getid.getAttribute('id');
		var value = getid.value;
		
		/* text in a href */
		var string_anchor = document.getElementById("A"+id).innerHTML;
		if(string_anchor.length > 0){
			if(value != ''){
				document.getElementById("A"+id).innerHTML = "<p>"+value+"</p>";
			} else{
				document.getElementById("A"+id).innerHTML = '<p>New Group Membership</p>';
			}
			
		} else{
			document.getElementById("A"+id).innerHTML = '<p>New Group Membership</p>';
		}
	}

	function checkSubsidiaryName(i) {
        var post_data = {
            intID : <?php echo $member->intID ?>,
            name : $('#gm_name'+i).val(),
            member_intID : $('#gm_id'+i).val()
        };
        if (post_data.name.length > 0) {
            $.ajax({
                url: "<?php echo site_url('members/check_subsidiary_name'); ?>",
                method: "POST",
                data: post_data,
                type: "json",
                success: function(obj){
                    var data = JSON.parse(obj);
                    if (data.status === false) {
                        $("#err_gm_name"+i).text("Name '"+ post_data.name +"' already used").show();
                        alert("Name '"+ post_data.name +"' already used");
                    } else {
                        $("#err_gm_name"+i).hide();
                    }
                }
            });
        }
    }
</script>
<script type="text/javascript">
	function desc_sectors() {
		$('span.text').each(function(){
			var cek_sector = $(this).text(); //cek value sector
			cek_sector = cek_sector.replace(/ /g, "");
				
			if(cek_sector == 'BanksandInvestors'){
				$(this).after('<span class="desc_sector"><?php echo $BI;?></span>');
			}
					
			if(cek_sector == 'ConsumerGoodsManufacturers'){
				$(this).after('<span class="desc_sector"><?php echo $CGM;?></span>');
			}
					
			if(cek_sector == 'EnvironmentalorNatureConservationOrganisations(NonGovernmentalOrganisation)'){
				$(this).after('<span class="desc_sector"><?php echo $ENGO;?></span>');
			}
					
			if(cek_sector == 'OilPalmGrowers'){
				$(this).after('<span class="desc_sector"><?php echo $OPG;?></span>');
			}
					
			if(cek_sector == 'Growers'){
				$(this).after('<span class="desc_sector"><?php echo $OPG;?></span>');
			}
					
			if(cek_sector == 'PalmOilProcessorsand/orTraders'){
				$(this).after('<span class="desc_sector"><?php echo $PNT;?></span>');
			}
				
			if(cek_sector == 'Processorand/orTrader'){
				$(this).after('<span class="desc_sector"><?php echo $PNT;?></span>');
			}
					
			if(cek_sector == 'Retailers'){
				$(this).after('<span class="desc_sector"><?php echo $Retailers;?></span>');
			}
					
			if(cek_sector == 'SocialorDevelopmentOrganisations(NonGovernmentalOrganisation)'){
				$(this).after('<span class="desc_sector"><?php echo $SNGO;?></span>');
			}
					
			if(cek_sector == 'Associations'){
				$(this).after('<span class="desc_sector"><?php echo $Associations;?></span>');
			}
					
			if(cek_sector == 'Individuals'){
				$(this).after('<span class="desc_sector"><?php echo $Individuals;?></span>');
			}
					
			if(cek_sector == 'Organisations'){
				$(this).after('<span class="desc_sector"><?php echo $Organisations;?></span>');
			}
					
			if(cek_sector == 'SupplyChainAssociate'){
				$(this).after('<span class="desc_sector"><?php echo $SCA;?></span>');
			}
					
			if(cek_sector == 'SupplyChainGroupManager'){
				$(this).after('<span class="desc_sector"><?php echo $SCGM;?></span>');
			}
					
			if(cek_sector == 'Other'){
				$(this).after('<span class="desc_sector"><?php echo $Other;?></span>');
			}
		}); 
	} 

$(document).ready(function(){
	desc_sectors();
});
</script>