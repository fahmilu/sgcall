		<style>
			.image-credit {
				position: absolute;
				right: 0px;
				left: 0px;
				padding: 3px 6px;
				bottom: 30px;
				color: #f2f2f2;
				text-align: center;
				font-size: 11px;
				text-shadow: 1px 1px 1px #0A0203;
			}
		</style>

	<!-- Full Page Image Background Carousel Header -->
    <header>
        <div class="row" style="margin-left:0px; margin-right:0px;">
            <div class="container text-center" id="header-white">
                <h1>MEMBERS</h1>
            </div>
        </div>
        <div id="myCarousel">

            <!-- Wrapper for Slides -->
            <div class="carousel-inner" style="height:457px;">
                <div class="item active">
                    <!-- Set the first background image using inline CSS below. -->
                    <div class="fill" style="background-image:url('{{ theme:image_path file='member_banner2.jpg' }}'); height:457px;"></div>
					
					<div class="carousel-caption" style="width:800px;">
						<?php $this->load->view('partials/search-bar'); ?>
						<!--
                        <a href="#"><h2>RSPO Participates in Palm Oil Sustainability Workshop Organized</h2></a>
                        <a href="#">
                            <p>Corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similiqcorrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi More..</p>
                        </a>-->
                    </div>
					
                </div>
				<div class="image-credit">Credit NBPOL</div>
            </div>
        </div>
    </header>

	<?php //$this->load->view('partials/search-bar'); ?>

    <!-- ACOP-Complaint Section -->
    <section id="acop-complaint" style="padding-bottom:0px; border:none;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="col-lg-6 text-center">
                        <h2 class="section-heading">WHY JOIN THE RSPO</h2>
                        <p class="whoweareabout">From market access to technical know-how, find out why more than 1,600 organizations and companies globally have joined the RSPO &mdash; and about the benefits they are enjoying through their membership.</p>
                        <br/>
                        <a href="#" class="btn btn-lg btn-orange">VIEW MORE</a>
                        <p>&nbsp;</p>
                    </div>
                    <div class="col-lg-6 text-center">
                        <h2 class="section-heading">BECOME A MEMBER</h2>
                        <p class="whoweareabout">By joining the RSPO, become part of a fast-growing community of actors in the palm oil industry who are working to make sustainable palm oil the norm.<br/>Find out how.</p>
                        <br/>
                        <a href="<?php echo site_url('members/online_application') ?>" class="btn btn-lg btn-orange">APPLY</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
	 <!-- ACOP-Complaint Section -->
    <section id="acop-complaint" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">

                    <div class="col-lg-6 text-center">
                        <h2 class="section-heading">ANNUAL COMMUNICATIONS<br/>OF PROGRESS (ACOP)</h2>
                        <p class="whoweareabout">The Annual Communications of Progress are reports submitted by RSPO members to gauge their progress towards 100% RSPO-certified sustainable palm oil. These reports are mandatory and submitted each year.</p>
                        <br/>
                        <a href="<?php echo site_url('members/acop') ?>" class="btn btn-lg btn-orange">VIEW MORE</a>
                    </div>
                    <div class="col-lg-6 text-center">
                        <h2 class="section-heading">COMPLAINTS<br/>SYSTEM</h2>
                        <p class="whoweareabout">The RSPO Complaints System aims to provide a fair, transparent and impartial process to duly handle and address complaints against RSPO members or against the RSPO system itself.</p>
                        <br/>
                        <a href="#" class="btn btn-lg btn-orange">VIEW MORE</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php if (!empty($membersX)): ?>
<section>
<div class="container">
<div class="row">
<div class="col-lg-12">

<table class="table">
	<thead>
		<tr>
			<th>Name</th>
			<th>Country</th>
			<th>Status</th>
			<th>Member Since</th>
			<th>Membership Type</th>
		</tr>
	</thead>

	<tbody>
	<?php foreach($members as $m): ?>
		<tr>
			<td><a href="<?php echo site_url( 'members/'.$m->intID.'/'.url_title($m->title) ); ?>"><?php echo $m->title ?></a></td>
			<td><?php echo $m->country ?></td>
			<td><?php echo $m->status ?></td>
			<td><?php echo $m->date; ?></td>
			<td><?php echo $m->type ?></td>
		</tr>
	<?php endforeach; ?>
	</tbody>

</table>

<?php echo $pagination['links']; ?>

</div>
</div>
</div>
</section>

<?php else: ?>
<?php endif; ?>