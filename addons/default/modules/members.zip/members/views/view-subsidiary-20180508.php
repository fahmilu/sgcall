<style>
hr { margin-bottom: 10px; margin-top: 26px; }
</style>

<!-- subsidiary -->
<section id="members-prof" class="first-section">
	<div class="container text-center">

		<div class="col-md-3 col-sm-3 col-xs-12 text-left">
		<div class="back-linkmembers">
			<span><a href="<?php echo site_url('members/all') ?>"><i class="fa fa-caret-left"></i>ALL MEMBERS</a></span>			
		</div>
			<div class="logo-members text-left" alt="" style="margin-bottom:20px;">
				<?php
					if ( $member->logo )
					{
						if (strstr($member->logo, '/sites/default/files/'))
							echo '<img class="img-responsive" src="//www.rspo.org'.$member->logo.'" />'.PHP_EOL;
						elseif (strstr($member->logo, 'ma/logo'))
							echo '<img class="img-responsive" src="//www.rspo.org/'.$member->logo.'" />'.PHP_EOL;
						else
							echo '<img class="img-responsive" src="'.site_url(UPLOAD_PATH).'/memberlogos/'.$member->logo.'" />'.PHP_EOL;
					}
					else
					{?>
						{{theme:image file="generic-member.jpg"}}
					<? }
						//echo '<img class="img-responsive" src="//www.rspo.org/tpl/default/images/members/generic-member.jpg" />'.PHP_EOL;
				?>	
			</div>
			<div class="descr-profile">
				<span>Membership No.</span> 
				<p class="member_profile"><?php echo $member->member_num; ?></p>
				<span>Category</span> 
				<p class="member_profile"><?php echo $member->type; ?></p>
				<span>Sector</span> 
				<p class="member_profile"><?php echo $member->category; ?></p>
				<span>Country/Region</span> 
				<p class="member_profile"><?php echo $member->country; ?></p>
				<span>Member since</span> 
				<p class="member_profile"><?php echo date("j F Y", $member->approved_date); ?></p>
				<?php if(!empty($member->website)):?>
				<span>Web</span><br/>
				<?php if (substr($member->website, 0, 7) <> '//') $member->website = '//'.$member->website; ?>
				<?php echo $member->website ? '<a target="_blank" href="'.$member->website.'">'.str_ireplace(array('http://', 'www.'), '', trim($member->website, '/')).'</a>' : 'N/A'; ?>
				<?php endif;?>
			</div>
		</div>
		
		<!-- right -->
		<div class="col-md-9 col-sm-9 col-xs-12 text-left primary-subsidiary">
			<h3 class="members-primay-subsidiary-am"><?php echo str_ireplace("\\", "", stripslashes($member->title) ); ?></h3>
            <div class="col-lg-12 col-md-12 primary-member">

            <?php if (!empty($member->parent_member)): ?>
				<a href="<?php echo site_url('members/'.$member->parent_member->intID.'/'.url_title($member->parent_member->name)); ?>" class="btn btn-orange-member" style="margin-bottom:22px;">A Subsidiary Of <?php echo $member->parent_member->name ?></a>
			<?php endif; ?>

				<div class="desc-primary-members">
					<div class="row">
						<h3 class="no-pad-top">Profile</h3>
						<div class="text-desc-members" style="padding-top:4px;">
							<font style="color:#43372c; line-height:1.75"><?php echo nl2br(strip_tags(stripslashes($member->profile))) ?></font>
						</div>
					</div>
				</div>
			</div>

			<?php $this->load->view('partials/view-acop') ?>

			<?php if (!empty($sccs)): ?>
			<div class="col-md-12 suply-chain no-pad-right" style="padding-bottom:7px; padding-top:0px;">
				<hr />
				<h3 class="subsection-heading">Supply Chain Certification</h3>
				<div class="table-responsive" style="margin-top:16px;">
					<?php $this->load->view('partials/scc'); ?>
				</div>	 
			</div>	
			<?php endif; ?>
			
			<div class="col-md-12 col-sm-12 col-xs-12 text-left no-pad-left" style="border-top: 1px solid #ededed; margin-top: 24px; padding-top: 13px;">
				<?php if ( strlen($member->q1) > 5 OR strlen($member->q2) > 5 OR strlen($member->q3) > 5 OR strlen($member->q4) > 5 ): ?>
				<?php //if ( $member->q1 OR $member->q2 OR $member->q3 OR $member->q4 ): ?>
					<style>
						.m_question, .m_answer {
							padding: 0 0 10px 30px;
							position: relative;
						}
						.m_question {
							color: #999999;
						}
						.m_answer {
							display: none;
							padding-bottom: 20px;
						}
						.m_question i.fa, .m_answer i.fa {
							position: absolute;
							left: 0;
							top: 5px;
						}
					</style>
					<script>
					$(document).ready(function(){
					  
					$('a#show_all').click(function(e){
						e.preventDefault();
						$('.m_answer').slideToggle('fast', function(){
							if ($('.m_answer').css('display')=='none')
							{
								$('html, body').animate({
									scrollTop: ($("#member_question").offset().top * 1) - 100
								}, 200);
							}
						});
					});
					  
					});
					</script>
					<div class="member-report" id="member_question" style="padding-bottom:30px;">
						<h3 class="subsection-heading">Organisation's Commitments Toward Sustainability</h3> 
						<div class="list-reports">

						<?php if ($member->q1): ?>
						<li>
							<div class="m_question"><i class="fa fa-lg fa-question-circle"></i>How will your organisation promote the RSPO internally and to other stakeholders?</div>
							<div class="m_answer">
								<!-- <i class="fa fa-lg fa-pencil-square"></i> -->
								<?php echo nl2br(str_ireplace('\\', '', $member->q1)); ?>
							</div>
						</li>
						<?php endif; ?>

						<?php if ($member->q2): ?>
						<li>
							<div class="m_question"><i class="fa fa-lg fa-question-circle"></i>Where relevant, what processes is the organisation establishing to engage with interested parties, for example to resolve conflict or to use sustainably produced palm oil?</div>
							<div class="m_answer">
								<!-- <i class="fa fa-lg fa-pencil-square"></i> -->
								<?php echo nl2br(str_ireplace('\\', '', $member->q2)); ?>
							</div>
						</li>
						<?php endif; ?>

						<?php if ($member->q3): ?>
						<li>
							<div class="m_question"><i class="fa fa-lg fa-question-circle"></i>Where relevant, how will your organisation work towards implementing the RSPO Principles and Criteria or assessing supplier performance against these criteria?</div>
							<div class="m_answer">
								<!-- <i class="fa fa-lg fa-pencil-square"></i> -->
								<?php echo nl2br(str_ireplace('\\', '', $member->q3)); ?>
							</div>
						</li>
						<?php endif; ?>

						<?php if ($member->q4): ?>
						<li>
						<div class="m_question"><i class="fa fa-lg fa-question-circle"></i>Any other information that would support the application such as what your organisation hopes to gain from joining RSPO and how it would support RSPO?</div>
						<div class="m_answer">
						<!-- <i class="fa fa-lg fa-pencil-square"></i> -->
						<?php echo nl2br(str_ireplace('\\', '', $member->q4)); ?>
						</div>
						</li>
						<?php endif; ?>
						</div>
						<a href="#" id="show_all" class="btn btn-sm btn-primary">View all responses</a>
					</div>
					<?php endif; ?>
			</div>
			
			<div class="col-lg-12 col-sm-12 tabbed-of-member bg-light-gray" style="padding: 0px 20px 15px; margin-top: 18px;">
				<h3 style="line-height:1.75; padding-top:12px; padding-bottom: 5px;">DISCLAIMER</h3>	
				<p class="member_profile" style="color:#43372c; margin-bottom:0px; line-height:1.75;">This material and accompanying data is based on submissions from RSPO members which has not been independently verified and is provided by the RSPO and authors without warranty of any kind, either expressed or implied. By making use of this material you do so at your own risk and you accept that the author shall not be liable for any claims, liabilities, losses, damages, costs or expenses of any kind arising.</p>
            </div>
		</div>			  
	</div></div>
</section>

<section id="related" class="first-section">
	<div class="container text-center">	
	</div>
</section>