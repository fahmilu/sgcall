<style>
	table {
		border-collapse:collapse;
		border-color: #DDD;
	}
	
	table > tbody > tr > td{
		padding: 10px 15px 10px 15px;
		border:1px solid #ddd;
		vertical-align: top;
	}
</style>

<div class="container">
<div class="row">
<div class="contain800">
	<div class="text-center" id="header-white">
		<h1>CASE TRACKER</h1>
	</div>
</div>
</div>
</div>

<section id="related">
	<div class="container">
		<div class="row">
		<div class="contain800">
		
		<h2 class="section-heading" style="text-align:center; padding-top:0px; padding-bottom:0px;"><?php echo $case->company; ?></h2> 
		
			<div class="col-md-12">
				<table class="table table-striped">
				<thead>
					<tr>
						<th></th>
						<th></th>
					</tr>
				</thead>
				<tbody>	
					<tr>
						<td>Member</td>
						<td><?php echo $case->company; ?></td>
					</tr>
					<tr>
						<td>Category</td>
						<td><?php echo $case->category; ?></td>
					</tr>
					<tr>
						<td>Complainant</td>
						<td><?php echo nl2br($case->complainant); ?></td>
					</tr>
					<tr>
						<td>Complaint</td>
						<td><?php echo $case->noc; ?></td>
					</tr>
					<tr>
						<td>Status</td>
						<td><?php echo $case->status; ?></td>
					</tr>
				</tbody>
				</table>
				
				<h3 class="titleh3" style="padding-top:10px;">Synopsis</h3>
				<p><?php echo nl2br(stripslashes($case->synopsis)); ?></p>
				<h3 class="titleh3" style="padding-top:10px;">Remarks</h3>
				<p><?php echo stripslashes($case->remark); ?></p>
			</div>
		</div>
		</div>
	</div>
</section>