<!-- member Section -->
<style>
    #questions .row-profile-wrapper {
        margin-bottom: 24px;
    }
	.bootstrap-select.btn-group:not(.input-group-btn), .bootstrap-select.btn-group[class*="col-"] {
		border: 1px solid #ccc;
	}
	.input-group-addon:first-child {
		border-right: 0px none;
		width: 100px;
	}
	.input-group-addon {
		padding: 6px 12px;
		font-size: 14px;
		font-weight: 400;
		line-height: 1;
		color: #555;
		text-align: center;
		background-color: #EEE;
		border: none;
		border-radius: 4px;
	}
	.btn-default, .btn-primary, .btn-success, .btn-info, .btn-warning, .btn-danger {
		text-shadow: none;
		box-shadow: none;
	}
	.btn {
		font-weight: normal;
	}
    #myTabMember .btn {
        font-size: 14px;
        text-transform: none;
		border-bottom: 1px solid #D5CEC8;
        /* border-radius: 3px; */
        /* font-weight: bold; */
    }
    #myTabMember label{
        color: #43372c;
    }
    .profile-tab-content{
        padding: 25px 5px;
        background-color: #f5f5f5;
        /* width: 800px; */ /* AM - dimatikan for responsive */
    }
    .block{
        display: block;
    }
    .row-profile-wrapper{
		width: 100%;
    	position: relative;
        display: block;
        margin-bottom: 13px;
    }
    .tab-profile {
        background-color: #fff;
        color: #ff7400;
        text-align:center; 
        border-top-left-radius:0px; 
        border-top-right-radius:0px; 
        padding: 10px 20px;
        cursor: pointer;
    }
    li.active{
        background-color: #f5f5f5;
    }
    #tab-profile-member{
        /*color: #fff !important;*/
        /* margin-left: -15px; */
    }
    #tab-profile-member li a{
        font-weight: normal;
        color: #f26522;
        padding: 0px;
    }
    #tab-profile-member li a:hover{
        color: #FF6500;
    }
    input[type=radio].css-checkbox + label.css-label {
        padding-left: 28px;
        height: 23px;
        display: inline-block;
        line-height: 23px;
        background-repeat: no-repeat;
        background-position: 0 0;
        font-weight: normal;
        vertical-align: middle;
        cursor: pointer;
    }
    input[type=radio].css-checkbox:checked + label.css-label {
        background-position: 0 -23px;
    }
    label.css-label {
        background-image: url('http://rspo.org/addons/default/themes/rspo_revamp/img/csscheckbox.png');
        -webkit-touch-callout: none;
        -webkit-user-select: none;
        -khtml-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }
    input[type=radio].css-checkbox {
        position: absolute;
        z-index: -1000;
        left: -1000px;
        overflow: hidden;
        clip: rect(0 0 0 0);
        height: 1px;
        width: 1px;
        margin: -1px;
        padding: 0;
        border: 0;
    }
    textarea.form-control{
        height: 120px;
    }
    .histroy-list-wrapper{
        padding: 22px 30px 20px;
        background-color: #f5f5f5;
        margin-bottom: 1px;
    }
	.input-group {
		width: 100%;
	}
    .col3-profile{
        width: 23.25%;
		/* width:170px; */
        margin-right: 16px; 
        /* display: inline-block; */
		display:-moz-groupbox;
		display: inline-table;
    }
	.col6-profile{
		/* width: 360px;  */
		width: 48.8%;
		display: inline-block; 
		margin-right: 16px;
	}
    .col6-profile-row {
    	width: 100%;
    }
    .btn-saveprofile{
        float:right; 
        text-transform: none;
        font-size: 14px;
    }
    .time-history{
        font-weight: normal; 
        display: inline-block; 
        width: 70px;
        font-size: 13px;
    }
    .text-history{
        font-weight: normal; 
        display: inline-block;
        font-size: 13px;
    }
    .btn-loadmore{
        background-color: #fff;
        color: #ff7400;
        border-color: #fff;
        font-size: 14px;
        text-transform:none; 
        font-weight: bold;
    }
    .success-notification{
    	position: relative;
        font-weight: normal;
       /* display: none;*/
        padding: 10px 15px;
        color: #fff !important; 
        background-color: #85bb43;
        /* max-width: 330px; */
        margin-bottom: 35px;
        margin-top: 7px;
    }
    .error-notification{
        font-weight: normal;
    	position: relative;
       /* display: none;*/
        padding: 10px 15px 10px 15px;
        color: #fff !important; 
        background-color: #ff3931;
        /* max-width: 330px; */
        margin-bottom: 35px;
        margin-top: 7px;
    }
    .row-profile-wrapper input, .row-profile-wrapper textarea {
        color: #43372c;
    }
    .logo-members{
        width: 215px;
        padding: 30px;
    }
    .logo-members > img {
		max-width: 100%;
		width: 100%;
		display: inline-block;
	}
    .title-text-side-bar{
        color: #949494
    }
    .profile-column-right-wrapper{
        width:800px;
         max-width:915px; 
         margin-bottom:50px;
    }
    .profile-member-title-headline{
        font-weight:normal; 
        font-size:24px; 
        margin-top: 6px;
        margin-bottom: -2px;
        width: 100%;
        display: block;
        padding-right: 120px;
        position: relative;
    }
    .profile-member-title-headline small {
    	margin: 9px 0;
    	float: right;
    	position: absolute;
    	right: 20px;
    	top: 0;
    }
    /* #members-prof > .container{
        width: 1045px !important;
    } */
    /* .col-profile-password{
        width: 350px; 
        display: inline-block; 
    } */
	
	.col-profile-password {
		display: inline-block;
		width: 47.6%;
	}
	
    .col-profile-password-arrow{
        width: 32px;
        display: inline-block;
    }
    div#questions .block {
        font-weight: normal;
    }
    .tab-pane .row {
        border: 1px solid #f5f5f5;
    }
    li.tab-profile {
        border: 1px solid #f5f5f5;
    }
    #tab-profile-member li.active a {
        color: #43372c !important;
    }
    .new_logs {
    	display: none;
    }
	.intl-tel-input input, .intl-tel-input input[type="text"], .intl-tel-input input[type="tel"] {
		padding-left: 50px;
	}
	.col-lg-6, .col-md-12, .col-sm-12 {
		padding-top: 15px;
	}
.tlp-code {
	border: 1px solid #cccccc !important;
}
.input-group-addon.no-padding {
	position: relative;
}
.intl-tel-input .selected-flag {
	position: relative;
	height: 36px;
	width: 45px;
}
.intl-tel-input .selected-flag .flag {
	width:16px;
	height: 11px;
	top: 50%;
	bottom: 50%;
}
.div_overlay {
	display: none;
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	margin: 0 auto;
	text-align: center;
	vertical-align: middle;
	background-color: rgba(255,255,255,0.85);
	z-index: 9999;
}
.div_spin {
	position: absolute;
	top: 40%;
	left: 0;
	right: 0;
	font-size: 20px;
	color: #ed7b1c;
}
</style>

<div class="div_overlay" id="pleasewait">
	<div class="div_spin">
		<p><b>Please wait, we're saving and synchronising your data to our CRM system&hellip;</b></p>
		<div class="clearfix"></div>
		<p class="fa fa-cog fa-spin fa-2x"></p>
	</div>
</div>

<section id="members-prof" class="first-section">
    <div class="container text-center">
        <div class="row">

            <div class="col-md-3 col-sm-3 col-xs-12 text-left">
                <div class="row">
                    <div class="back-linkmembers" style="height:75px;">
                        <!--<span><a href="<?php echo site_url('members/all') ?>"><i class="fa fa-caret-left"></i>ALL MEMBERS</a></span>-->  
                        <span><a href="<?php echo site_url('members/all') ?>"><i class="fa fa-caret-left"></i>VIEW ALL MEMBERS</a></span>          
                    </div>
                    <div class="logo-members text-center" alt="">
						<?php
							if ( $member->logo )
							{
								if (strstr($member->logo, '/sites/default/files/'))
								{
									echo '<img class="img-responsive" src="http://www.rspo.org'.$member->logo.'" />'.PHP_EOL;
								}
								elseif(strstr($member->logo, 'ma/logo/'))
								{
									echo '<img class="img-responsive" src="http://www.rspo.org/'.$member->logo.'" />'.PHP_EOL;
								}
								else
								{
									if ( file_exists(UPLOAD_PATH.'/memberlogos/'.thumbnail($member->logo)) )
										echo '<img class="img-responsive" src="'.site_url(UPLOAD_PATH).'/memberlogos/'.thumbnail($member->logo).'" />'.PHP_EOL;
									else
										echo '<img style="width:150px;" src="'.site_url(UPLOAD_PATH).'/memberlogos/'.($member->logo).'" />'.PHP_EOL;
								}
							}
							else
							{ ?>
								{{theme:image file="generic-member.jpg"}}
							<?php }
								//echo '<img class="img-responsive" src="http://www.rspo.org/tpl/default/images/members/generic-member.jpg" />'.PHP_EOL;
						?>
                    </div>
                    <div class="descr-profile">
                        <span>Membership No.</span> 
                        <p class="member_profile"><?php echo $member->member_num; ?></p>
						<span>Category</span> 
						<p class="member_profile"><?php echo $member->type; ?></p>
						<span>Sector</span> 
						<p class="member_profile"><?php echo $member->category; ?></p>
                        <span>Country</span> 
                        <p class="member_profile"><?php echo $member->country; ?></p>
                        <span>Member since</span> 
                        <p class="member_profile"><?php echo date("j F Y", $member->approved_date); ?></p>
                        <?php if(!empty($member->website)):?>
                        <span>Web</span><br/>
                        <?php if (substr($member->website, 0, 7) <> 'http://') $member->website = 'http://'.$member->website; ?>
                        <?php echo $member->website ? '<a target="_blank" href="'.$member->website.'">'.str_ireplace(array('http://', 'www.'), '', trim($member->website, '/')).'</a>' : 'N/A'; ?>
                        <?php endif;?>
                    </div>
                    <style>
                        .logo-traders div.btn-brown {
                            text-align: center;
                            font-size: 12px;
                            font-weight: 400;
                            text-transform: uppercase;
                            line-height: 1.2em;
                            background: #735636;
                            color: #F2F2F2;
                            width: 152px;
                            border-radius: 3px !important;
                            padding: 9px 20px;
                            margin: 0 auto;
                            text-align: center;
                        }
                        .btn {
                            border: none;
                        }
                    </style>
                    <div class="brand-trade text-center">
                        <div class="logo-traders text-center">
                            <img class="img-responsive traders-img" src="{{ theme:image_path file='trade-logo.png' alt='Pursuit for Betterment Towards 100% CSPO'}}">
                            <h3>Pursuit For Betterment<br />Towards 100% CSPO</h3> 
                            <div class="btn-brown">pledge towards<br /> 100% cspo</div>
                        </div>
                    </div>
                </div>

            </div>
        
        <!-- right -->
        <div class="col-md-9 col-sm-9 col-xs-12 text-left profile-subsidiary-prymary">

		<form id="member_profile" accept-charset="utf-8" action="{{url:site}}members/profile" method="post" enctype="multipart/form-data" />

            <div class="row">
                <h3 class="profile-member-title-headline">
                    <?php echo stripslashes($member->name); ?>
                </h3>

				<?php $status = $this->session->flashdata('status'); ?>
                <?php if (!empty($status) && $status == 'success'): ?>
					<div class="alert alert-success fade in" role="alert" style="text-align:left;">
						<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						Your changes have been successfully saved.
						<?php if ($this->session->flashdata('notice')): ?>
							<br /><?php echo $this->session->flashdata('notice'); ?>
						<?php endif; ?>
					</div>
				<?php elseif (!empty($status) && $status == 'error'): ?>
					<div class="alert alert-danger fade in" role="alert" style="text-align:left;">
						<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						Kindly check your form for missing value(s).
						<?php if ($this->session->flashdata('error')): ?>
							<br /><?php echo $this->session->flashdata('error'); ?>
						<?php endif; ?>
					</div>
				<?php elseif (!empty($status) && $status == 'pwerror'): ?>
					<div class="alert alert-danger fade in" role="alert" style="text-align:left;">
						<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<?php if ($this->session->flashdata('error')): ?>
							<?php echo $this->session->flashdata('error'); ?>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<?php if (validation_errors()): ?>
					<div class="alert alert-danger fade in" role="alert" style="text-align:left;">
						<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<?php echo validation_errors(); ?>
					</div>
				<?php endif; ?>

                <div class="col-lg-12 col-md-12 tabbed-of-member content-member-profile" style="margin-bottom:30px;">
                    <ul id="tab-profile-member" class="nav nav-tabs" role="tablist" style="padding-top:18px; margin-bottom:0px;">
                        <li class="tab-profile active">
                            <a href="#editprofile" id="link_editprofile" class="first-tabbed" role="tab" data-toggle="tab" style="background: rgba(0,0,0,0);">
                             Edit company profile
                            </a>
                        </li>
                        <li class="tab-profile" style="margin-left: -1px;">
                            <a href="#questions" id="link_questions" role="tab" data-toggle="tab" style="background: rgba(0,0,0,0);">Questions</a>
                        </li>
                        <li class="tab-profile" style="margin-left: -1px;">
                            <a href="#contacts" id="link_contacts" role="tab" data-toggle="tab" style="background: rgba(0,0,0,0);">Contacts</a>
                        </li>
                        <li class="tab-profile" style="margin-left: -1px;">
                            <a href="#password" id="link_password" role="tab" data-toggle="tab" style="background: rgba(0,0,0,0);">Change password</a>
                        </li>
                        <li class="tab-profile" style="margin-left: -1px;">
                            <a href="#historyprofile" id="link_historyprofile" role="tab" data-toggle="tab" style="background: rgba(0,0,0,0);">Revisions history</a>
                        </li>
                    </ul>

                    <div id="myTabMember" class="tab-content tab-content-profile">
                        	<div class="tab-pane fade active in" id="editprofile">
                            <div class="row" >
                                <div class="list-sub profile-tab-content" >
                                    <div class="col-sm-12" >
                                        <label class="block">Description</label>
                                        <textarea name="profile" class="form-control" style="text-align: left; height: 300px;"><?php echo htmlspecialchars_decode(strip_tags(stripslashes($member->profile))); ?></textarea>
											<?php echo form_error('profile') ? '<div class="alert alert-danger">'.form_error('profile').'</div>' : ''; ?>
                                    </div>
                                    <div class="col-sm-12">
                                        <label>Address</label>
                                        <input type="text" class="form-control" value="<?php echo htmlspecialchars_decode($member->address) ?>" name="address">
											<?php echo form_error('address') ? '<div class="alert alert-danger">'.form_error('address').'</div>' : ''; ?>
                                    </div>
                                    <div class="row-profile-wrapper">
                                        <div class="col-sm-12"></div>
                                        <div class="col-md-4 col-sm-12">
                                            <label>City</label>
                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars_decode($member->address_city) ?>" name="address_city">
											<?php echo form_error('address_city') ? '<div class="alert alert-danger">'.form_error('address_city').'</div>' : ''; ?>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                        <label>Postcode</label>
                                        <input type="text" class="form-control" value="<?php echo htmlspecialchars_decode($member->address_zip) ?>" name="address_zip">
										<?php echo form_error('address_zip') ? '<div class="alert alert-danger">'.form_error('address_zip').'</div>' : ''; ?>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <label>State/Province</label>
                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars_decode($member->address_state) ?>" name="address_state">
											<?php echo form_error('address_state') ? '<div class="alert alert-danger">'.form_error('address_state').'</div>' : ''; ?>
                                        </div>

                                        <div class="col-sm-12"></div>
                                        <div class="col-md-4 col-sm-12">
                                            <label>Country</label>
                                            {{dropdowns:countries class="form-control selectpicker" id="mcountry" value="<?php echo $member->country ?>" }}
											<?php echo form_error('country') ? '<div class="alert alert-danger">'.form_error('country').'</div>' : ''; ?>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="row-profile-wrapper">
                                        <div class="col-sm-12"></div>
                                        <div class="col-lg-6 col-md-12 col-sm-12">
                                            <label>Telephone</label>
											<div class="input-group no-margin">
											<div class="input-group-addon no-padding" style="position:relative;">
												<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->telephone?>" name="telephone">
											</div>
												<?php //echo form_input('telephone', $member->telephone, 'class="form-control required required2"') ?>
											</div>
												<?php echo form_error('telephone') ? '<div class="alert alert-danger">'.form_error('telephone').'</div><div class="clearfix"></div>' : ''; ?>
										</div>
										
                                        <div class="col-lg-6 col-md-12 col-sm-12">
											<label class="add-pad-am">Fax<span style="font-weight: normal;"> (optional)</span></label>
											<div class="input-group no-margin">
												<div class="input-group-addon no-padding">
													<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->fax?>" name="fax">
												</div>
												<?php //echo form_input('fax', $member->fax, 'class="form-control required required2"') ?>
											</div>
												<?php echo form_error('fax') ? '<div class="alert alert-danger">'.form_error('fax').'</div>' : ''; ?>
										</div>
                                        <div class="clearfix"></div>
									</div>
                                         <div class="row-profile-wrapper">
                                      	  <div class="col-lg-6 col-md-12 col-sm-12">
                                                <label>Email</label>
                                                <input type="text" class="form-control" name="email" value="<?php echo $member->email?>">
                                            </div>
                                    	    <div class="col-lg-6 col-md-12 col-sm-12">
                                                <label class="add-pad-am">Website</span></label>
                                                <input type="text" class="form-control" name="website" value="<?php echo $member->website?>">
                                            </div>
                                        </div>


										<?php if ($member->category=='Supply Chain Group Manager'): ?>
										<?php
											$scg_manager_members = null;
											if ($member->scg_manager_members)
											{
												$scg_manager_members = unserialize($member->scg_manager_members);
											}
										?>
										<div class="row-profile-wrapper col-sm-12">
											<label>Supply Chain Group Manager</label>
											<p>List of members under the manager, with Palm Oil consumption for each member</p>
											<table width="100%" cellspacing="1" id="scgm_table">
												<thead>
													<tr>
														<th>Member Name</th>
														<th>Palm Oil Consumption (MT)</th>
													</tr>
												</thead>
												<tbody>
												<?php if ($member->scg_manager_members && is_array($scg_manager_members)): ?>
													<tr>
														<td style="width:70%;padding-right:5px;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control required" value="<?php echo htmlspecialchars_decode($scg_manager_members[0]) ?>"/></td>
														<td style="width:30%;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control max500 required" value="<?php echo htmlspecialchars_decode($scg_manager_members[1]) ?>" /></td>
													</tr>
													<?php if (count($scg_manager_members) > 2): ?>
														<?php for ($i=2; $i<count($scg_manager_members); $i+=2): ?>
															<tr>
																<td style="width:70%;padding-right:5px;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control required" value="<?php echo htmlspecialchars_decode($scg_manager_members[$i]) ?>"/></td>
																<td style="width:30%;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control max500 required" style="float:left;width:75%;" value="<?php echo htmlspecialchars_decode($scg_manager_members[$i+1]) ?>" /><a href="#" class="btn btn-lg btn-orange remove_scgm" style="width:25%;">x</a></td>
															</tr>
														<?php endfor; ?>
													<?php endif; ?>
												<?php else: ?>
													<tr>
														<td style="width:70%;padding-right:5px;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control required" /></td>
														<td style="width:30%;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control max500 required" /></td>
													</tr>
												<?php endif; ?>
												</tbody>
												<tfoot>
													<tr>
														<td colspan="2"><a href="#" id="add_scgm">Add more</a></td>
													</tr>
												</tfoot>
											</table>
											<?php echo form_error('scg_manager_members[]') ? '<div class="alert alert-danger">'.form_error('scg_manager_members[]').'</div>' : ''; ?>
										</div>
										<?php endif; ?>
						
										<div class="row-profile-wrapper col-sm-12">
											<label>Organisation's Logo</label> <i>(PNG, JPG, or GIF and no more than 1.5MB)</i>

											<input type="hidden" />
											<?php if (!empty($member->logo)): ?>
												<?php echo form_hidden('upload_logo', $member->logo); ?>
												<div class="clear"></div>
												<label class="inline">Filename: </label> <?php echo $member->logo; ?>
												<div class="clear"></div>

												<?php
													if ( $member->logo )
													{
														if (strstr($member->logo, '/sites/default/files/'))
														{
															echo '<img class="img-responsive" src="http://www.rspo.org'.$member->logo.'" />'.PHP_EOL;
														}
														elseif(strstr($member->logo, 'ma/logo/'))
														{
															echo '<img class="img-responsive" src="'.site_url(thumbnail($member->logo)).'" />'.PHP_EOL;
														}
														else
														{
															echo '<img class="img-responsive" src="'.site_url(UPLOAD_PATH).'/memberlogos/'.thumbnail($member->logo).'" />'.PHP_EOL;
														}
													}
													else
													{ ?>
														{{theme:image file="generic-member.jpg"}}
													<?php }
												?>

											<?php endif; ?>

											<br /><input type="file" id="logo" class="filestyle" name="logo" onchange="copyfname(this.value, $(this), 'image')">
											<?php echo form_hidden('new_logo', $member->logo); ?>

											<?php echo form_error('upload_logo') ? '<div class="alert alert-danger">'.form_error('upload_logo').'</div>' : ''; ?>
										</div>
										<div class="clearfix"></div>

										<div class="col-sm-12">
											<div class="pull-right">
                                            <button type="submit" class="btn btn-lg btn-saveprofile" id="btn-save">Save Changes</button>
											</div>
										</div>
										<div class="clearfix"></div>

                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="questions">
                                 <div class="row" >
                                    <div class="list-sub profile-tab-content" >
	                                 <div class="col-sm-12">

                                        <div class="row-profile-wrapper" style="margin-top:-13px;">
                                            <label class="block">How will your organisation promote the RSPO internally and to other stakeholders?</label>
                                            <textarea name="q1" class="form-control" style="text-align: left;"><?php echo htmlspecialchars_decode($member->q1)?></textarea>
												<?php echo form_error('q1') ? '<div class="alert alert-danger">'.form_error('q1').'</div>' : ''; ?>
                                        </div>
                                        <div class="row-profile-wrapper">
                                            <label class="block">
                                                Where relevant, what proceses is the organisation establishing to engage with interested parties, for example to resolve conflict
                                                or to use sustainably produces palm oil?
                                            </label>
                                            <textarea name="q2" class="form-control" style="text-align: left;"><?php echo htmlspecialchars_decode($member->q2)?></textarea>
												<?php echo form_error('q2') ? '<div class="alert alert-danger">'.form_error('q2').'</div>' : ''; ?>
                                        </div>
                                        <div class="row-profile-wrapper">
                                            <label class="block">
                                                Where relevant, how will your organisation work towards implementing the RSPO Principles and Criteria or assesing supplier
                                                performance against these criteria?
                                            </label>
                                            <textarea name="q3" class="form-control" style="text-align: left;"><?php echo htmlspecialchars_decode($member->q3)?></textarea>
												<?php echo form_error('q3') ? '<div class="alert alert-danger">'.form_error('q3').'</div>' : ''; ?>
                                        </div>

                                        <div class="row-profile-wrapper">
                                            <label class="block">
                                                Any other information that would support the application such as what your organication hopes to gain from joining RSPO
                                                and how it would support RSPO?
                                            </label>
                                            <textarea name="q4" class="form-control" style="text-align: left;"><?php echo htmlspecialchars_decode($member->q4)?></textarea>
												<?php echo form_error('q4') ? '<div class="alert alert-danger">'.form_error('q4').'</div>' : ''; ?>
                                        </div>

<!--
				<?php if ($member->type<>'Ordinary Members' AND $member->type<>'Affiliate Members' AND $member->category<>'Supply Chain Group Manager' ): ?>
                    <div class="row-profile-wrapper">Please state your annual usage of palm oil and palm derivatives in metric tonnes</label>
						<input type="text" class="form-control required" name="q_usage" value="<?php echo $member->q_usage; ?>">
						<?php echo form_error('q_usage') ? '<div class="alert alert-danger">'.form_error('q_usage').'</div>' : ''; ?>
					</div>
				<?php endif; ?>
-->

                                    </div>
										<div class="col-sm-12">
											<div class="pull-right">
                                            <button type="submit" class="btn btn-lg btn-saveprofile" id="btn-save">Save Changes</button>
											</div>
										</div>
										<div class="clearfix"></div>
                                 	</div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="historyprofile">

								<div id="logs">
                            		<?php $this->load->view('partials/member_log'); ?>
								</div>

                                <div class="row histroy-list-wrapper">
                                    <button type="submit" id="log_more" class="btn btn-lg " style="">Load more...</button>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="contacts">
                                <div class="row" >
                                    <div class="list-sub profile-tab-content" >
                                        <div class="row-profile-wrapper" style="margin-top: -12px;">

											<!-- primary nomination -->
	                                        <!-- <div class="col6-profile" style="margin-top:15px;margin-bottom:15px;padding-right:10px;"> -->
	                                        <div class="col-md-6 col-sm-12" style="margin-top:20px;">
	                                        	<div class="col6-profile-row">
		                                            <label for="name_p" class="block">PRIMARY NOMINATION<span style="font-weight: normal;"><br />OF REPRESENTATIVE</span></label>
													
													<label for="designation_p" class="block">First Name</label>
													<div class="input-group no-margin">
													<?php echo form_input('name_p', htmlspecialchars_decode($member->name_p), 'class="form-control required" id="name_p"') ?>
													</div>
													<?php echo form_error('name_p') ? '<div class="alert alert-danger">'.form_error('name_p').'</div>' : ''; ?>
	                                        	</div>
												
												<div class="col6-profile-row">
													<label for="designation_p" class="block">Last Name</label>
													<div class="input-group no-margin">
													<?php echo form_input('name_last_p', htmlspecialchars_decode($member->name_last_p), 'class="form-control required" id="name_last_p"') ?>
													</div>
													<?php echo form_error('name_last_p') ? '<div class="alert alert-danger">'.form_error('name_last_p').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
		                                            <label for="designation_p" class="block">Position</label>
													<div class="input-group no-margin">
													<?php echo form_input('designation_p', htmlspecialchars_decode($member->designation_p), 'class="form-control required" id="designation_p"') ?>
													</div>
													<?php echo form_error('designation_p') ? '<div class="alert alert-danger">'.form_error('designation_p').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
													<label class="add-pad-am">Telephone</label>
													<div class="input-group no-margin">
														<div class="input-group-addon no-padding">
															<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->telephone_p?>" name="telephone_p">
														</div>
															<?php //echo form_input('telephone_p', $member->telephone_p, 'class="form-control required required2"') ?>
													</div>
														<?php echo form_error('telephone_p') ? '<div class="alert alert-danger">'.form_error('telephone_p').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
													<label class="add-pad-am">Fax<span style="font-weight: normal;"> (optional)</span></label>
													<div class="input-group no-margin">
														<div class="input-group-addon no-padding">
															<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->fax_p?>" name="fax_p">
														</div>
															<?php //echo form_input('fax_p', $member->fax_p, 'class="form-control required required2"') ?>
													</div>
														<?php echo form_error('fax_p') ? '<div class="alert alert-danger">'.form_error('fax_p').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
		                                            <label for="email_p" class="block">Email</label>
													<div class="input-group no-margin">
													<?php echo form_input('email_p', $member->email_p, 'class="form-control required" id="email_p"') ?>
													</div>
													<?php echo form_error('email_p') ? '<div class="alert alert-danger">'.form_error('email_p').'</div>' : ''; ?>
	                                        	</div>
											</div> <!-- profile row -->
											<!-- primary nomination ends -->

											<!-- secondary nomination -->
	                                        <div class="col-md-6 col-sm-12" style="margin-top:20px;">
	                                        	<div class="col6-profile-row">
		                                            <label for="name_s" class="block">SECONDARY NOMINATION<span style="font-weight: normal;"><br />OF REPRESENTATIVE</span></label>
													
													<label for="designation_s" class="block">First Name</label>
													<div class="input-group no-margin">
													<?php echo form_input('name_s', htmlspecialchars_decode($member->name_s), 'class="form-control required" id="name_s"') ?>
													</div>
													<?php echo form_error('name_s') ? '<div class="alert alert-danger">'.form_error('name_s').'</div>' : ''; ?>
	                                        	</div>
												
												<div class="col6-profile-row">
													<label for="designation_s" class="block">Last Name</label>
													<div class="input-group no-margin">
													<?php echo form_input('name_last_s', htmlspecialchars_decode($member->name_last_s), 'class="form-control required" id="name_last_s"') ?>
													</div>
													<?php echo form_error('name_last_s') ? '<div class="alert alert-danger">'.form_error('name_last_s').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
		                                            <label for="designation_s" class="block">Position</label>
													<div class="input-group no-margin">
													<?php echo form_input('designation_s', htmlspecialchars_decode($member->designation_s), 'class="form-control required" id="designation_s"') ?>
													</div>
													<?php echo form_error('designation_s') ? '<div class="alert alert-danger">'.form_error('designation_s').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
													<label class="add-pad-am">Telephone</label>
													<div class="input-group no-margin">
														<div class="input-group-addon no-padding">
															<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->telephone_s?>" name="telephone_s">
														</div>
													</div>
														<?php echo form_error('telephone_s') ? '<div class="alert alert-danger">'.form_error('telephone_s').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
													<label class="add-pad-am">Fax<span style="font-weight: normal;"> (optional)</span></label>
													<div class="input-group no-margin">
														<div class="input-group-addon no-padding">
															<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->fax_s?>" name="fax_s">
														</div>
													</div>
														<?php echo form_error('fax_s') ? '<div class="alert alert-danger">'.form_error('fax_s').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
		                                            <label for="email_s" class="block">Email</label>
													<div class="input-group no-margin">
													<?php echo form_input('email_s', $member->email_s, 'class="form-control required" id="email_s"') ?>
													</div>
													<?php echo form_error('email_s') ? '<div class="alert alert-danger">'.form_error('email_s').'</div>' : ''; ?>
	                                        	</div>
											</div> <!-- profile row -->
											<!-- secondary nomination ends -->

											<div class="clearfix"><br /></div>
											<br />
											<hr />

											<!-- contact person -->
	                                        <div class="col-md-6 col-sm-12" style="margin-top:20px;">
	                                        	<div class="col6-profile-row">
		                                            <label for="contact_person" class="block">CONTACT PERSON<span style="font-weight: normal;"><br />&nbsp;</span></label>
													
													<label for="designation" class="block">First Name</label>
													<div class="input-group no-margin">
													<?php echo form_input('contact_person', htmlspecialchars_decode($member->contact_person), 'class="form-control required" id="contact_person"') ?>
													</div>
													<?php echo form_error('contact_person') ? '<div class="alert alert-danger">'.form_error('contact_person').'</div>' : ''; ?>
	                                        	</div>
												
												<div class="col6-profile-row">
		                                            <label for="designation" class="block">Last Name</label>
													<div class="input-group no-margin">
													<?php echo form_input('contact_lname', htmlspecialchars_decode($member->contact_lname), 'class="form-control required" id="contact_lname"') ?>
													</div>
													<?php echo form_error('contact_lname') ? '<div class="alert alert-danger">'.form_error('contact_lname').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
		                                            <label for="designation" class="block">Position</label>
													<div class="input-group no-margin">
													<?php echo form_input('designation', htmlspecialchars_decode($member->designation), 'class="form-control required" id="designation"') ?>
													</div>
													<?php echo form_error('designation') ? '<div class="alert alert-danger">'.form_error('designation').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
													<label class="add-pad-am">Telephone</label>
													<div class="input-group no-margin">
														<div class="input-group-addon no-padding">
															<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->contact_tel?>" name="contact_tel">
														</div>
															<?php //echo form_input('contact_tel', $member->contact_tel, 'class="form-control required required2"') ?>
													</div>
														<?php echo form_error('contact_tel') ? '<div class="alert alert-danger">'.form_error('contact_tel').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
													<label class="add-pad-am">Fax<span style="font-weight: normal;"> (optional)</span></label>
													<div class="input-group no-margin">
														<div class="input-group-addon no-padding">
															<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->contact_fax?>" name="contact_fax">
														</div>
															<?php //echo form_input('contact_fax', $member->contact_fax, 'class="form-control required required2"') ?>
													</div>
														<?php echo form_error('contact_fax') ? '<div class="alert alert-danger">'.form_error('contact_fax').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
		                                            <label for="contact_email" class="block">Email</label>
													<div class="input-group no-margin">
													<?php echo form_input('contact_email', $member->contact_email, 'class="form-control required" id="contact_email"') ?>
													</div>
													<?php echo form_error('contact_email') ? '<div class="alert alert-danger">'.form_error('contact_email').'</div>' : ''; ?>
	                                        	</div>
											</div> <!-- profile row -->
											<!-- contact person ends -->

											<!-- financial nomination -->
	                                        <div class="col-md-6 col-sm-12" style="margin-top:20px;">
	                                        	<div class="col6-profile-row">
		                                            <label for="name_f" class="block">FINANCE CONTACT<span style="font-weight: normal;"><br />FOR MEMBERSHIP FEE</span></label>
													
													<label for="designation_f" class="block">First Name</label>
													<div class="input-group no-margin">
													<?php echo form_input('name_f', htmlspecialchars_decode($member->name_f), 'class="form-control required" id="name_f"') ?>
													</div>
													<?php echo form_error('name_f') ? '<div class="alert alert-danger">'.form_error('name_f').'</div>' : ''; ?>
	                                        	</div>
												
												<div class="col6-profile-row">
		                                            <label for="designation_f" class="block">Last Name</label>
													<div class="input-group no-margin">
													<?php echo form_input('name_last_f', htmlspecialchars_decode($member->name_last_f), 'class="form-control required" id="name_last_f"') ?>
													</div>
													<?php echo form_error('name_last_f') ? '<div class="alert alert-danger">'.form_error('name_last_f').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
		                                            <label for="designation_f" class="block">Position</label>
													<div class="input-group no-margin">
													<?php echo form_input('designation_f', htmlspecialchars_decode($member->designation_f), 'class="form-control required" id="designation_f"') ?>
													</div>
													<?php echo form_error('designation_f') ? '<div class="alert alert-danger">'.form_error('designation_f').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
													<label class="add-pad-am">Telephone</label>
													<div class="input-group no-margin">
														<div class="input-group-addon no-padding">
															<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->telephone_f?>" name="telephone_f">
														</div>
															<?php //echo form_input('telephone_f', $member->telephone_f, 'class="form-control required required2"') ?>
													</div>
														<?php echo form_error('telephone_f') ? '<div class="alert alert-danger">'.form_error('telephone_f').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
													<label class="add-pad-am">Fax<span style="font-weight: normal;"> (optional)</span></label>
													<div class="input-group no-margin">
														<div class="input-group-addon no-padding">
															<input class="mobile-number tlp-code form-control" type="tel" value="<?php echo $member->fax_f?>" name="fax_f">
														</div>
															<?php //echo form_input('fax_f', $member->fax_f, 'class="form-control required required2"') ?>
													</div>
														<?php echo form_error('fax_f') ? '<div class="alert alert-danger">'.form_error('fax_f').'</div>' : ''; ?>
	                                        	</div>

	                                        	<div class="col6-profile-row" style="margin-top:15px;">
		                                            <label for="email_f" class="block">Email</label>
													<div class="input-group no-margin">
													<?php echo form_input('email_f', $member->email_f, 'class="form-control required" id="email_f"') ?>
													</div>
													<?php echo form_error('email_f') ? '<div class="alert alert-danger">'.form_error('email_f').'</div>' : ''; ?>
	                                        	</div>
											</div> <!-- profile row -->
											<!-- financial nomination ends -->
											<div class="clearfix"></div>
                                        </div>

										<div class="col-sm-12">
											<div class="pull-right">
                                            <button type="submit" class="btn btn-lg btn-saveprofile" id="btn-save">Save Changes</button>
											</div>
										</div>
										<div class="clearfix"></div>

                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="password">
                                <div class="row list-sub profile-tab-content">

									<div class="col-sm-12">

										<div class="row">

											<div class="col-lg-6">
		                                            <div class="">
		                                                <label>Current Password</label>
		                                                <input type="password" class="form-control" name="currentPassword">
														<?php echo form_error('currentPassword') ? '<div class="alert alert-danger">'.form_error('currentPassword').'</div>' : ''; ?>
		                                            </div>
											</div>

											<div class="col-lg-6">
		                                            <div class="" style="margin-right: 0px;">
		                                                <label>New Password</span></label>
		                                                <input type="password" class="form-control" name="newPassword">
		                                            </div>
														<?php echo form_error('newPassword') ? '<div class="alert alert-danger">'.form_error('newPassword').'</div>' : ''; ?>
		                                            <div class="col-profile-password-arrow">
		                                            </div>
		                                            <div class="" style="margin-right: 0px;">
		                                                <label>Confirm New Password</span></label>
		                                                <input type="password" class="form-control" name="confirmNewPassword">
														<?php echo form_error('confirmNewPassword') ? '<div class="alert alert-danger">'.form_error('confirmNewPassword').'</div>' : ''; ?>
		                                            </div>
											</div>

										<div class="col-sm-12">
											<div class="pull-right">
                                            <button type="submit" class="btn btn-lg btn-saveprofile" id="btn-save">Save Changes</button>
											</div>
										</div>

										</div>

									</div>
                                	<div class="clearfix"></div>

                                </div>
                            </div>

                        </div>
                        
                    </div>

                 </div>

             </div>

         </div>
	</form>

    </div>
</section>


<script>
var SITE_URL = '<?php echo site_url(); ?>';
var log_count = <?php echo !empty($log_count) ? $log_count : 0 ?>;
var log_loaded = 10;

$(document).ready(function(){

	$("#member_profile").on('submit', function(e){
		$('.alert').fadeTo('fast', 0);
		$('.div_overlay').fadeIn('fast');
	});

$(function(){
	$(".mobile-number").intlTelInput({
		//autoFormat: false,
        //autoHideDialCode: false,
        //defaultCountry: "jp",
        //nationalMode: true,
        //onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
        //preferredCountries: ['cn', 'jp'],
        //responsiveDropdown: true,
        defaultCountry: "",
        utilsScript: "utils.js",
        defaultStyling: "outside"
	})
});

	$('.tab-pane').each(function(idx, v){

		var i = $(this).attr('id');
		var f = $(this).find('.alert').text();

		if (f)
		{
			$("a#link_"+i).trigger('click');
			return false;
		}
	});


	$('form#member_profile').on('submit', function(e){
		
		var fil_name_p = $('#name_p').val();
		var fil_name_last_p = $('#name_last_p').val();
		
		var fil_name_s = $('#name_s').val();
		var fil_name_last_s = $('#name_last_s').val();
		
		var fill_name_p_last = fil_name_p + ' ' + fil_name_last_p;
		var fill_name_s_last = fil_name_s + ' ' + fil_name_last_s;
		
		//if ( $('#name_p').val() == $('#name_s').val() || $('#designation_p').val() == $('#designation_s').val() || $('#email_p').val() == $('#email_s').val() )
		if ( fill_name_p_last == fill_name_s_last || $('#designation_p').val() == $('#designation_s').val() || $('#email_p').val() == $('#email_s').val() )
		{
			alert('Primary and Secondary Nomination can not be the same person.');
			$('#tab_contact').trigger('click');
			$("html, body").animate({
				scrollTop: $("#members-prof").offset().top
			}, 50);
			return false;
		}
	});

	if (log_count < log_loaded)
	{
		$('#log_more').hide();
	}

	$('#log_more').on('click', function(e){
		e.preventDefault();
		if (log_loaded < log_count)
		{
			$.ajax({
				url: SITE_URL + 'members/getlog',
				data: {offset: log_loaded},
				method: 'post',
				datatype: 'json',
				success: function(obj){
					obj = JSON.parse(obj);

					if (obj.log_loaded && obj.logs)
					{
						log_loaded = log_loaded + obj.log_loaded;
						$('#logs').append('<div id="'+obj.id+'" class="new_logs">'+obj.logs+'</div>');
						$('#'+obj.id).fadeIn();
					}

					if (log_loaded >= log_count)
						$('#log_more').hide();
				}
			});
		}
	});

			$('a#add_scgm').click(function(e){
				e.preventDefault();
				var h = '							<tr>'+
					'							<td style="width:70%;padding-right:5px;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control required" /></td>'+
					'							<td style="width:30%;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control max500 required" style="float:left;width:75%;" /><a href="#" class="btn btn-lg btn-orange remove_scgm" style="width:25%;">x</a></td>'+
					'						</tr>';

				$('#scgm_table > tbody:last').append(h);
			});

			$('.remove_scgm').livequery('click', function(e){
				if (confirm('Are you sure you want to delete this row?'))
				{
					var d = $(this).parent().parent();
					d.fadeOut('fast', function(e){
						d.remove().empty();
					});
					e.preventDefault();
				}
				return false;
			});

			$('.max500').livequery('blur', function(e){
				var v = $(this).val();
				var d = $('#scgm_table');
				if (v)
				{
					var n = $.isNumeric(v);
					if (!n)
					{
						$(this).val('');
						if (d.parent().find('div.alert').html()==undefined)
						{
							d.parent().append('<div class="alert alert-danger">Please enter Palm Oil Consumption in numbers (metric tonnes).</div>');
						}
						else
						{
							d.parent().find('div.alert').fadeTo('fast', 0, function(){
								$(this).html('Please enter Palm Oil Consumption in numbers (metric tonnes).').fadeTo('fast', 1);
							});
						}
					}
					else
					{
						if (v > 500)
						{
							$(this).val('');
							if (d.parent().find('div.alert').html()==undefined)
							{
								d.parent().append('<div class="alert alert-danger">Please enter a number less than 500.</div>');
							}
							else
							{
								d.parent().find('div.alert').fadeTo('fast', 0, function(){
									$(this).html('Please enter a number less than 500.').fadeTo('fast', 1);
								});
							}
						}
						else
						{
							d.parent().find('div.alert').fadeTo('fast', 0);
						}
					}
				}
			});

});

function in_array (needle, haystack, argStrict) {
	var key = '', strict = !!argStrict;

	if (strict) {
		for (key in haystack) {
			if (haystack[key] === needle) {
				return true;
			}
		}
	} else {
		for (key in haystack) {
			if (haystack[key] == needle) {
				return true;
			}
		}
	}

	return false;
}

function copyfname(v,divname,t)
{
	var ftocheck = (t==undefined) ? ftocheck = 'doc' : t;

//(this.value, $(this), 'all')

	var id = divname.attr('id');

	if (ftocheck != "" && ftocheck == 'image')
	{
		var e = ['gif','jpg','jpeg', 'png'];
		var msg = 'GIF, JPG, JPEG, PNG';
	}
	else if (ftocheck != "" && ftocheck == 'all')
	{
		var e = ['pdf','doc','xls','docx','xlsx','gif','jpg','jpeg', 'png','kml','kmz'];
		var msg = 'PDF, DOC, DOCX, XLS, XLSX, GIF, JPG, JPEG, PNG, KML, KMZ';
	}
	else
	{
		var e = ['pdf','doc','xls','docx','xlsx'];
		var msg = 'PDF, DOC, DOCX, XLS, XLSX';
	}

	if (v)
	{
		//console.log('v: '+v);
		// check for extension
		var ext = v.substr((~-v.lastIndexOf(".") >>> 0) + 2);
		//if (ext.toLowerCase() == 'pdf')
		if (in_array(ext.toLowerCase(), e))
		{
			var nextdiv = $(":input:eq(" + ($(":input").index(divname) + 2) + ")");

			//console.log('rel: '+nextdiv.attr('rel'));
			//console.log('next div index: '+$(":input").index(divname));

			if (v)
			{
				//console.log('setting value for nextdiv');
				nextdiv.val(v);
			}
		}
		else
		{

			divname.wrap('<form>').closest('form').get(0).reset();
			divname.unwrap();

			alert('Please upload only '+msg+' format file.\nThank you...');

			return false;
		}
	}
}


$(function(){

    $("li.tab-profile").click(function(){
        var elm = $(this).children("a");
        elm[0].click(function(e){e.stopPropagation()});
    });
})

// function enableSubsidiary(params){
//         if(params == "true")
//         {
//             var input = $("input[name=parent_company]");
//             input.removeAttr("readonly");
//             console.log(true);
//         }
//         else{
//             var input = $("input[name=parent_company]");
//             input.attr("readonly", "readonly");
//             input.val("");
//             console.log(false);
//         }
//     }



</script>
