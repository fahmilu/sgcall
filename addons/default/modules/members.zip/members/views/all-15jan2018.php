<?php if(SITE_REF == "bcn"): ?>
<!--<header> -->
	<div class="row">
		<div class="container text-center" id="header-white">
			<h1 style="padding-top:0px; margin-top:0px;">查找会员</h1>
		</div>
	</div>
<!--</header> -->

	<?php 
	if(!empty($this->uri->segment(1))){ $segment1 = $this->uri->segment(1); } else{ $segment1 = '';}
	if(!empty($this->uri->segment(2))){ $segment2 = '/' .$this->uri->segment(2); } else{ $segment2 = '';}
	if(!empty($this->uri->segment(3))){ $segment3 = '/' .$this->uri->segment(3); } else{ $segment3 = '';}
	if(!empty($this->uri->segment(4))){ $segment4 = '/' .$this->uri->segment(4); } else{ $segment4 = '';}
	if(!empty($this->uri->segment(5))){ $segment5 = '/' .$this->uri->segment(5); } else{ $segment5 = '';}
	
	$urlredirect = $segment1.$segment2.$segment3.$segment4.$segment5 ;
	?>
	
	<section style="border:none;">
		<div class="container">
			<div class="contain-redirect">
				<div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
						<p class="text-redirect">{{ widgets:instance id="22"}}</p>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6 col-md-6 col-lg-6 button-back-redirect">
						<button onclick="goBack()" type="submit" class="btn btn-redirect-white">{{ widgets:instance id="23"}}</button>
					</div>
					<div class="col-sm-6 col-md-6 col-lg-6 button-continue-redirect">
						<a href="http://rspo.org/<?php echo $urlredirect?>" class="btn btn-lg btn-redirect-orange" target="_blank">{{ widgets:instance id="24"}}</a>
					</div>
                </div>
            </div>
        </div>
    </section>
	
	<script>
	function goBack() {
		window.history.go(-1);
	}
	</script>

<?php else: ?>
	
<!-- Full Page Image Background Carousel Header -->
<!--<header> -->
	<div class="row">
		<div class="container text-center" id="header-white">
			<h1>MEMBERS</h1>
		</div>
	</div>
<!--</header> -->

<?php $this->load->view('partials/search-bar'); ?>

<?php if (!empty($members)): ?>
<section class="pad-top-30">
<div class="container">	
<div class="row">
<div class="col-lg-12">
<div class="table-responsive">
<table class="table table-striped table-supplychain" style="border:1px solid #ddd;">
	<thead>
		<tr>
			<th>Name</th>
			<th>Country</th>
			<th>Status</th>
			<th>Member Since</th>
			<th>Membership Type</th>
		</tr>
	</thead>

	<tbody>
	<?php foreach($members as $m): ?>
		<?php $ms = explode(' ', $m->date); $membersince = date('d M Y', strtotime($ms[0])); ?>
		<tr>
			<td><a href="<?php echo site_url( 'members/'.$m->intID.'/'.url_title($m->title) ); ?>"><?php echo str_ireplace("\\", "", stripslashes($m->title) ) ?></a></td>
			<td><?php echo $m->country ?></td>
			<td><?php echo $m->status ?></td>
			<td><?php echo date("j F Y", $m->approved_date); ?><?php //echo $membersince; ?></td>
			<td><?php echo $m->type ?></td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
</div>

<div class="text-right">
	<?php echo $pagination['links']; ?>
</div>

</div>
</div>
</div>
</section>

<?php else: ?>

<section class="pad-top-30">
<div class="container text-center">
<div class="contain800">
	<p>Sorry, there are no results for your search query.</p>
</div>
</div>
</section>

<?php endif; ?>
<?php endif; ?>