<h2><?php echo $member->name; ?></h2>

<pre>
$member:
<?php print_r($member); ?>
</pre>