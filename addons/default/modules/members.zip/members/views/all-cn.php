﻿<!--<header> -->
	<div class="row">
		<div class="container text-center" id="header-white">
			<h1 style="padding-top:0px; margin-top:0px;">查找会员</h1>
		</div>
	</div>
<!--</header> -->

	<?php 
	if(!empty($this->uri->segment(1))){ $segment1 = $this->uri->segment(1); } else{ $segment1 = '';}
	if(!empty($this->uri->segment(2))){ $segment2 = '/' .$this->uri->segment(2); } else{ $segment2 = '';}
	if(!empty($this->uri->segment(3))){ $segment3 = '/' .$this->uri->segment(3); } else{ $segment3 = '';}
	if(!empty($this->uri->segment(4))){ $segment4 = '/' .$this->uri->segment(4); } else{ $segment4 = '';}
	if(!empty($this->uri->segment(5))){ $segment5 = '/' .$this->uri->segment(5); } else{ $segment5 = '';}
	
	$urlredirect = $segment1.$segment2.$segment3.$segment4.$segment5 ;
	?>
	
	<section style="border:none;">
		<div class="container">
			<div class="contain-redirect">
				<div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
						<p class="text-redirect">{{ widgets:instance id="22"}}</p>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6 col-md-6 col-lg-6 button-back-redirect">
						<button onclick="goBack()" type="submit" class="btn btn-redirect-white">{{ widgets:instance id="23"}}</button>
					</div>
					<div class="col-sm-6 col-md-6 col-lg-6 button-continue-redirect">
						<a href="http://rspo.org/<?php echo $urlredirect?>" class="btn btn-lg btn-redirect-orange go-to-members-all" target="_blank">{{ widgets:instance id="24"}}</a>
					</div>
                </div>
            </div>
        </div>
    </section>
	
	<script>
	function goBack() {
		window.history.go(-1);
	}
	</script>