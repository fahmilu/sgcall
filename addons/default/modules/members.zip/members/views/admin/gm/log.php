<style media="screen">
	#shortcuts li a {
		display: none !important;
	}
	.subbar {
		height:42px;
		top: 25px !important;
	}
</style>
<section class="title">
	<h4><?php echo lang('item_list'); ?></h4>
</section>

<section class="item">
	<section class="content">

		<table class="table table-striped table-bordered" id="data-table">
			<thead>
				<tr>
					<th>Id</th>
					<th>Date</th>
					<th>Status</th>
					<th>Description</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no = 1;
				foreach( $items as $item ): ?>
				<tr>
					<td><?= $item->id; ?></td>
					<td><?= date('d-m-Y H:i:s',strtotime($item->created_on)); ?></td>
					<td><?php if($item->condition == 1) { ?> Success <?php } else { ?> Failed <?php } ?></td>
					<td><?= $item->description; ?></td>
				</tr>
				<?php $no++; endforeach; ?>
			</tbody>
		</table>
	</section>
</section>
<script type="text/javascript">
	$('#data-table').DataTable();
</script>
