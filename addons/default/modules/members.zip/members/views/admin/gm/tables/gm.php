<!-- <small>Number of data: <?php //echo number_format($count); ?></small> -->

	<table>
		<thead>
			<tr>
				<th width="20"><?php echo form_checkbox(array('name' => 'action_to_all', 'class' => 'check-all')); ?></th>
				<th width="200" class="collapse">Name</th>
				<th class="collapse">Country</th>
				<!--<th class="collapse">Certification</th>
				<th class="collapse">Accreditation</th>-->
				<th class="collapse">Accreditation</th>
				<th class="collapse">Contact Person</th>
				<th class="collapse">RED Auditor</th>
				<th class="collapse">Status</th>
				<th width="200">Actions</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="10">
					<div class="inner"><?php $this->load->view('admin/partials/pagination'); ?></div>
				</td>
			</tr>
		</tfoot>
		<tbody>
			<?php foreach ($cbs as $cb) : ?>
				<tr>
					<td><?php echo form_checkbox('action_to[]', $cb->id); ?></td>
					<td class="collapse"><?php echo $cb->name; ?></td>
					<td><?php echo $cb->country; ?></td>
					<!--<td><?php //echo str_ireplace(',', '<br />', strtoupper($cb->certification)); ?></td>
					<td><?php //echo $cb->accreditation; ?></td>-->
					<td class="collapse"><?php echo $cb->geographical; ?></td>
					<td class="collapse"><?php echo $cb->pic_and_position; ?></td>
					<td class="collapse"><?php echo $cb->red_auditor == 'yes' ? ucwords($cb->red_auditor) : '--'; ?></td>
					<td class="collapse"><?php echo $cb->status ? ucwords($cb->status) : '--'; ?></td>
					<td>
						<?php
						echo anchor('admin/members/cb/view/'.$cb->id, lang('global:view'), 'class="button modal" target="_blank"').' ';
						echo anchor('admin/members/cb/edit/'.$cb->id, lang('global:edit'), 'class="button"').' ';
						echo anchor('admin/members/cb/delete/'.$cb->id, lang('global:delete'), 'class="button confirm"').' ';
						?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<div class="table_action_buttons">
		<?php $this->load->view('admin/partials/buttons', array('buttons' => array('delete'))) ?>
	</div>