<style media="screen">
	#shortcuts li a {
		display: none !important;
	}
	.subbar {
		height:42px;
		top: 25px !important;
	}
</style>
<section class="title">
	<h4><?php echo lang('item_list'); ?></h4>
</section>

<section class="item">
	<section class="content">

	<div class="form_inputs">
		<fieldset>
		<ul>
			<li>
				<div class="one_full" style="float:right;text-align:right">
					<?php echo anchor('admin/members/gm/log', 'Log', array('class'=>'btn green','target'=>'_blank')); ?>
				</div>
				<div class="clearfix"></div>
			</li>
			<li>
				<div class="one_quarter" style="margin-right:50px;">
					<?php echo form_open_multipart('admin/members/gm/import');?>
					<label>import csv | seperated with (,) comma, make sure all column content does not contain comma</label>
					<input type="file" name="csv" required>
					<button type="submit" class="btn small blue">Import</button>
					<!--<?php echo anchor('#', 'Clear data', array('class'=>'btn small red confirm-all' ,'disabled'=>'disabled')); ?>-->
					<?php echo form_close(); ?>
				</div>
			</li>
		</ul>
	</fieldset>
	</div>
	<hr/>
	<?php echo form_open('admin/members/gm/delete');?>

	<?php if (!empty($items)): ?>
		<div class="table_action_buttons form-group">
			<?php $this->load->view('admin/partials/buttons', array('buttons' => array('delete'))); ?>
		</div>
		<br/>
		<table class="table table-striped table-bordered" id="data-table">
			<thead>
				<tr>
					<th><?php echo form_checkbox(array('title' => 'action_to_all', 'class' => 'check-all'));?></th>
					<th>Id</th>
					<th>Name</th>
					<th>Business</th>
					<th>Country</th>
					<th>Region</th>
					<th>GM SF Id</th>
					<th>Account SF Id</th>
					<th>action</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no = 1;
				foreach( $items as $item ): ?>
				<tr>
					<td><?php echo form_checkbox('action_to[]', $item->id); ?></td>
					<td><?= $item->id; ?></td>
					<td><?= $item->name; ?></td>
					<td><?= $item->nature_of_business; ?></td>
					<td><?= $item->country; ?></td>
					<td><?= $item->region; ?></td>
					<td><?= $item->gm_sf_id; ?></td>
					<td><?= $item->account_sf_id; ?></td>
					<td>
						<?php echo anchor('admin/members/gm/delete/'.$item->id, 'delete', array('class'=>'btn small red confirm')); ?>
					</td>
				</tr>
				<?php $no++; endforeach; ?>
			</tbody>
		</table>

	<?php else: ?>
		<div class="no_data"><?php echo lang('no_items'); ?></div>
	<?php endif;?>

	<?php echo form_close(); ?>
	</section>
</section>
<script type="text/javascript">
	$('#data-table').DataTable();

	$('.confirm').click(function() {
		var confirm1 = confirm('Are you sure to delete data?');
	  if (confirm1) {
				return true;
	  } else {
			return false;
		}
	});
	$('.confirm-all').click(function() {
		var confirm1 = confirm('Are you sure to delete all data?');
	  if (confirm1) {
				return true;
	  } else {
				return false;
		}
	});
</script>
