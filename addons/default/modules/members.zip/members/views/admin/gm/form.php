<section class="title">
<?php if ($this->method == 'create'): ?>
	<h4><?php echo lang('cb:create_title'); ?></h4>
<?php else: ?>
	<h4><?php echo sprintf(lang('cb:edit_title'), $cb->name); ?></h4>
<?php endif; ?>
</section>

<style>
.required_field{
	color:red;
}
</style>

<section class="item">
<div class="content">

<?php echo form_open_multipart(uri_string(), 'class="crud" name="cbForm" id="cbForm"'); ?>

<fieldset>
<div class="form_inputs">

	<ul>
		<li>
			<label for="status"><?php echo lang('cb:status_label'); ?></label><br/>
			
			<label class="inline"><input name="status" value="draft" type="radio" <?php if($cb->status == 'draft'){echo "checked = 'checked'";} elseif($cb->status == ''){echo "checked = 'checked'";} else ''?>> Draft</label>
			<label class="inline"><input name="status" value="live" type="radio" <?php if($cb->status == 'live'){echo "checked = 'checked'";} else ''?>> Live</label>
			
			<!--<div class="input"><?php echo form_dropdown('status', array('draft'=>'Draft', 'live'=>'Live'), $cb->status, 'id="status"') ?></div>-->
		</li>

		<li>
			<div style="display:block;width:40%;float:left;">
				<label for="name"><?php echo lang('cb:name_label'); ?></label>
				<div class="input"><?php echo form_input('name', $cb->name, 'id="name" style="width:280px;"') ?></div>
			</div>
			<div style="display:block;width:30%;float:left;">
				<label for="slug"><?php echo lang('cb:slug_label'); ?></label>
				<div class="input"><?php echo form_input('slug', $cb->slug, 'id="slug"') ?></div>
			</div>
			<div class="clearfix"></div>
		</li>

		<li>
			<div style="display:block;width:40%;float:left;">
			<label for="certification"><?php echo lang('cb:certification_label'); ?></label>
			<div class="input">
				<?php $certifications = explode(',', $cb->certification); ?>
				<?php foreach($cb_certifications as $c=>$v): ?>
					<label class="inline"><?php echo form_checkbox('certification[]', $c, in_array($c, $certifications) ) . ' ' . $v; ?> </label>
				<?php endforeach; ?>
			</div>
			</div>
			<div style="display:block;width:40%;float:left;">
			<label for="red_auditor"><?php echo lang('cb:red_auditor_label'); ?></label>
			<div class="input"><label class="inline"><?php echo form_checkbox('red_auditor', 'yes', $cb->red_auditor == 'yes', 'id="red_auditor"') ?> Available</label></div>
			</div>
			<div class="clearfix"></div>
		</li>
		
		<!--<li>
			<label for="accreditation"><?php //echo lang('cb:accreditation_label'); ?><span class="required_field">*</span></label>
			<div class="input"><?php //echo form_input('accreditation', $cb->accreditation, 'id="accreditation"') ?></div>
		</li>-->

		<li>
			<label for="address"><?php echo lang('cb:address_label'); ?></label>
			<div class="input"><textarea name="address" id="address" style="width:350px;height:90px;"><?php echo $cb->address; ?></textarea></div>
		</li>
		
		<li>
			<label for="website"><?php echo lang('cb:website_label'); ?></label>
			<div class="input"><?php echo form_input('website', $cb->website, 'id="website"') ?></div>
		</li>
		
		<li>
			<label for="pic_and_position"><?php echo lang('cb:pic_and_position_label'); ?></label>
			<div class="input"><?php echo form_input('pic_and_position', $cb->pic_and_position, 'id="pic_and_position" class="pic_and_position"') ?></div>
		</li>

		<li>
			<label for="phone"><?php echo lang('cb:phone_label'); ?></label>
			<div class="input"><?php echo form_input('phone', $cb->phone, 'id="phone"') ?></div>
		</li>
		
		<li>
			<label for="mobile"><?php echo lang('cb:mobile_label'); ?></label>
			<div class="input"><?php echo form_input('mobile', $cb->mobile, 'id="mobile"') ?></div>
		</li>

		<li>
			<label for="fax"><?php echo lang('cb:fax_label'); ?></label>
			<div class="input"><?php echo form_input('fax', $cb->fax, 'id="fax"') ?></div>
		</li>

		<li>
			<label for="email"><?php echo lang('cb:email_label'); ?></label>
			<div class="input"><?php echo form_input('email', $cb->email, 'id="email"') ?></div>
		</li>

		<li>
			<label for="country"><?php echo lang('cb:country_label'); ?></label>
			<div class="input"><?php echo form_dropdown('country', $countries, $cb->country, 'id="country"') ?></div>
		</li>

		<!--<li>
			<label for="geographical"><?php //echo lang('cb:geographical_label'); ?><span class="required_field">*</span> <small>Separate area with a coma</small></label>
			<div class="input"><textarea name="geographical" id="geographical" style="width:350px;height:120px;"><?php //echo $cb->geographical; ?></textarea></div>
		</li>-->
		
		<li>
			<label for="geographical"><?php echo lang('cb:accreditation_label'); ?></label>
			<div class="input">
			<?php echo form_textarea(array('id' => 'geographical', 'name' => 'geographical', 'value' => $cb->geographical, 'rows' => '5', 'class' => 'wysiwyg-module')); ?>
			</div>
		</li>
	</ul>

</div>
</fieldset>

<div class="buttons">
	<?php $this->load->view('admin/partials/buttons', array('buttons' => array('save', 'save_exit', 'cancel'))) ?>
</div>

<?php echo form_close(); ?>

<script>
(function($) {
	$(function(){

		// generate a slug when the user types a title in
		pyro.generate_slug('input[name="name"]', 'input[name="slug"]');

		$('.datepicker').datepicker({
			dateFormat: 'yy-mm-dd'
		})


	});
})(jQuery);
</script>

</div>
</section>