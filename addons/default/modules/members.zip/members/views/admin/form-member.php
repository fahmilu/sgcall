<section class="title">
<?php if ($this->method == 'create'): ?>
	<h4><?php echo lang('members:create_title'); ?></h4>
<?php else: ?>
	<h4><?php echo sprintf(lang('members:edit_title'), $membersapp->name); ?></h4>
<?php endif; ?>
</section>

<section class="item">
<div class="content">

<?php echo form_open_multipart(uri_string(), 'class="crud" name="memberApplication" id="memberApplication"'); ?>

<div class="tabs">

	<ul class="tab-menu">
		<li><a href="#status-tab"><span><?php echo lang('members:tab_status'); ?></span></a></li>
		<li><a href="#about-tab"><span><?php echo lang('members:tab_about'); ?></span></a></li>
		<li><a href="#contact-tab"><span><?php echo lang('members:tab_contact'); ?></span></a></li>
		<li><a href="#questions-tab"><span><?php echo lang('members:tab_questions'); ?></span></a></li>
		<li><a href="#documents-tab"><span><?php echo lang('members:tab_documents'); ?></span></a></li>
	</ul>

	<div class="form_inputs" id="status-tab">
		<fieldset>
			<ul>
				<li>
					<label for="org_category">Membership status</label>
					<div class="input" style="padding-top:9px;">
						<?php echo form_dropdown('status', $membership_status, $membersapp->status, 'onChange="displayExpiry(this.value);"'); ?>
					</div>
				</li>
				<li id="li_expiry_date" style="display:<?php echo $membersapp->status=='Call for Comment' ? 'block' : 'none'; ?>;">
					<label for="expiry_date">Call for Comment Deadline</label>
					<div class="input" style="padding-top:9px;">
						<?php echo form_input('expiry_date', $membersapp->expiry_date ? date('Y-m-d', $membersapp->expiry_date) : '', 'class="datepicker"'); ?>
					</div>
				</li>
			</ul>
		</fieldset>
	</div>

<script>
function displayExpiry(v)
{
	if (v && v=='Call for Comment')
	{
		$('#li_expiry_date').fadeIn();
	}
	else
	{
		$('#li_expiry_date').fadeOut();
	}
}
</script>

	<div class="form_inputs" id="about-tab">
		<?php $this->load->view('admin/forms/_form-member-step1'); ?>
	</div>

	<div class="form_inputs" id="contact-tab">
		<?php $this->load->view('admin/forms/_form-member-step2'); ?>
	</div>

	<div class="form_inputs" id="questions-tab">
		<?php $this->load->view('admin/forms/_form-member-step3'); ?>
	</div>

	<div class="form_inputs" id="documents-tab">
		<?php $this->load->view('admin/forms/_form-member-step4'); ?>
	</div>

</div>

<div class="buttons">
	<?php $this->load->view('admin/partials/buttons', array('buttons' => array('save', 'cancel'))) ?>
</div>

<?php echo form_close(); ?>

<script>
$(document).ready(function(){
	$('a.update').colorbox({
		inline: true,
		href: "#fileupdate",
		width: "400px",
		height: "90px",
		onComplete: function(){
			$.colorbox.resize();
		}
	});
	$('a.archive').colorbox({
		inline: true,
		href: "#filearchive",
		minWidth: "400px",
		minHeight: "90px",
		onComplete: function(){
			$.colorbox.resize();
		}
	});
});
</script>

</div>
</section>

<style>
input.org_children {
	width: 250px;
}
</style>