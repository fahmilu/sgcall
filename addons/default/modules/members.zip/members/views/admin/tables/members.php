
	<table>
		<thead>
			<tr>
				<th width="20"><?php echo form_checkbox(array('name' => 'action_to_all', 'class' => 'check-all')); ?></th>
				<th width="250">Organisation</th>
				<th class="collapse"><?php echo lang('members:status_label'); ?></th>
				<th class="collapse"><?php echo lang('members:approved_date_label'); ?></th>
				<th class="collapse"><?php echo lang('members:type_label'); ?></th>
				<th width="150" class="collapse"><?php echo lang('members:category_label'); ?></th>
				<th width="250">Actions</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="7">
					<div class="inner"><?php $this->load->view('admin/partials/pagination'); ?></div>
				</td>
			</tr>
		</tfoot>
		<tbody>
			<?php foreach ($members as $member) : ?>
				<?php $trclass = ($member->status <> 'Approved' AND $member->status <> 'Call for Comment') ? 'class="pending_members"' : '' ?>
				<?php if ( $member->status == 'Deleted' ) $trclass='class="deleted_members"' ?>
				<tr <?php echo $trclass ?>>
					<td><?php echo form_checkbox('action_to[]', $member->intID); ?></td>
					<td><?php echo stripslashes($member->name); ?></td>
					<td class="collapse"><?php echo $member->status; ?></td>
					<td class="collapse"><?php echo $member->status == 'Approved' ? format_date($member->approved_date) : '--'; ?></td>
					<td class="collapse"><?php echo $member->type; ?></td>
					<td class="collapse"><?php echo $member->category; ?></td>
					<td>
						<?php
						echo
						anchor('admin/members/pncassessment/create/'.$member->intID, '+P&C', 'class="btn small gray"').' '.
						anchor('admin/members/scc/create/'.$member->intID, '+SCC', 'class="btn small gray"').' '.
						anchor('members/'.$member->intID . '/'. url_title($member->title), lang('global:view'), 'class="btn small gray modal-large" target="_blank"').' '.
						anchor('admin/members/memberclone/'.$member->intID, 'Clone', 'class="btn small gray"').' '.
						anchor('admin/members/edit/'.$member->intID, lang('global:edit'), 'class="btn small gray"').' ';
/*
						echo
						anchor('members/'.$member->intID . '/'. url_title($member->title), lang('global:view'), 'class="btn small green" target="_blank"').' '.
						anchor('admin/members/pncassessment/create/'.$member->intID, '+P&C', 'class="btn small blue"').' '.
						anchor('admin/members/scc/create/'.$member->intID, '+SCC', 'class="btn small blue"').' '.
						anchor('admin/members/edit/'.$member->intID, lang('global:edit'), 'class="btn small orange"').' ';
*/
						?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<div class="table_action_buttons">
		<?php $this->load->view('admin/partials/buttons', array('buttons' => array('delete'))) ?>
	</div>