<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>


<section class="title">
	<h4>Cloning <?php echo $member->title ?></h4>
</section>

<section class="item">
<div class="content">

<?php if (isset($error_msg)): ?>
	<div class="notification alert error">
		<p class="error"><?php echo $error_msg; ?></p>
	</div>
<?php endif; ?>

<?php echo form_open_multipart(uri_string(), 'class="crud" name="memberClone" id="memberClone"'); ?>

<div class="form_inputs">

	<fieldset>
		<legend>User</legend>
		<ul>
			<li>
				<label>Link to this user<small>You need to either create a new user or ask applying member to create one.</small></label>
				<div class="input">
					<?php echo form_dropdown('user', $users, $member->MemberID_2); ?>
				</div>
			</li>
		</ul>
	</fieldset>

	<fieldset>

		<legend> About the Organisation</legend>

		<ul>

			<li>
				<label>Company/Organisation Name</label>
				<div class="input">
					<?php echo form_input('name', $member->name, 'style="width:500px;"') ?>
				</div>
			</li>

			<li>
				<label>Category</label>
				<div class="input">
					<?php echo form_dropdown('type', array(''=>'Please select')+$member_types, $member->type) ?>
				</div>
			</li>

			<li>
				<label>Sector</label>
				<div class="input">
					<?php echo form_dropdown('category', array(''=>'Please select')+$member_categories, $member->category) ?>
				</div>
			</li>

		</ul>

	</fieldset>

	<fieldset>
		<legend> Contacts </legend>
		<ul>

			<li>
				<label>Primary Contact</label>
				<div class="input">
					<label class="inline"><input <?php echo $clone->contact_primary=='y'?'checked="checked"':'' ?> type="checkbox" name="contact_primary" value="y"> Include primary contact</label>
				</div>
			</li>

			<li>
				<label>Secondary Contact</label>
				<div class="input">
					<label class="inline"><input <?php echo $clone->contact_secondary=='y'?'checked="checked"':'' ?> type="checkbox" name="contact_secondary" value="y"> Include secondary contact</label>
				</div>
			</li>

			<li>
				<label>Finance Contact</label>
				<div class="input">
					<label class="inline"><input <?php echo $clone->contact_finance=='y'?'checked="checked"':'' ?> type="checkbox" name="contact_finance" value="y"> Include finance contact</label>
				</div>
			</li>

			<li>
				<label>Contact Person</label>
				<div class="input">
					<label class="inline"><input <?php echo $clone->contact_other=='y'?'checked="checked"':'' ?> type="checkbox" name="contact_other" value="y"> Include contact person</label>
				</div>
			</li>

		</ul>
	</fieldset>

	<fieldset>
		<legend> Files & Questions </legend>
		<ul>

			<li>
				<label>Include all answers in Question 1 - 4?</label>
				<div class="input">
					<label class="inline"><input <?php echo $clone->all_answers=='y'?'checked="checked"':'' ?> type="checkbox" name="all_answers" value="y"> Include all answers</label>
				</div>
			</li>

			<li>
				<label>Include all file attachment</label>
				<div class="input">
					<label class="inline"><input <?php echo $clone->all_files=='y'?'checked="checked"':'' ?> type="checkbox" name="all_files" value="y"> Include all files</label>
				</div>
			</li>

		</ul>
	</fieldset>

    <fieldset>
		<legend> Group Membership</legend>
		<ul>

			<li>
				<label>Include all GM?</label>
				<div class="input">
					<label class="inline"><input <?php echo $clone->all_gm=='y'?'checked="checked"':'' ?> type="checkbox" name="all_gm" value="y"> Include all GM</label>
				</div>
			</li>

		</ul>
	</fieldset>

</div>

<div class="buttons">
	<button type="submit" name="btnAction" value="save" class="btn blue"><span>Clone</span></button>
	<a href="<?php site_url(); ?>admin/members" class="btn gray cancel">Cancel</a>
</div>

<?php echo form_close(); ?>

<!--
<pre>
$member
<? print_r($member) ?>
</pre>
-->

</div>


<script>
$(document).ready(function(){

	$('#memberClone').on('submit', function(e){
		if (!confirm('Are you sure you want to clone this member?'))
		{
			e.preventDefault();
			return false;
		}
	});

});
</script>

</div>
</section>