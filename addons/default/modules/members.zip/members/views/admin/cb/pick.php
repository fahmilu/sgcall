<div style="margin: 0 auto;">
<h4>Choose a Certification Body:</h4>
<?php
	echo form_dropdown('cbodies', $cbs, $id, 'id="cbodies" style="margin:0 auto;"');
?>
</div>
