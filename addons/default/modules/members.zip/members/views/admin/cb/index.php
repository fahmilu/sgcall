<section class="title">
	<h4><?php echo lang('cb:cb_title'); ?></h4>
</section>

<section class="item">
<div class="content">

<?php if (!empty($cbs)) : ?>

	<?php echo $this->load->view('admin/partials/filters_cb'); ?>

	<?php echo form_open('admin/members/cb/action'); ?>
	<div id="filter-stage">

		<?php echo $this->load->view('admin/cb/tables/cb'); ?>
	
	</div>
	<?php echo form_close(); ?>

<?php else : ?>
	<div class="no_data"><?php echo lang('cb:empty_cbs_msg'); ?></div>
<?php endif; ?>

</div>
</section>