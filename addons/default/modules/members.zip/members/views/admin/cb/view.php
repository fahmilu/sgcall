<!--
<section class="title">
</section>
-->

<!-- <section class="item"> -->
<div class="content">

	<h4><?php echo !empty($cb->name) ? ''. $cb->name : 'cb'; ?>  &nbsp; <?php echo !empty($cb->mid) ? '<a title="View member in new tab" href="'.site_url('members/'.$cb->mid.'/'.url_title($cb->name)).'" target="_blank" class="button">View</a> <a title="Edit member in new tab" href="'.site_url('admin/members/edit/'.$cb->mid).'" target="_blank" class="button">Edit</a>' : ''?></h4>

<?php if (!empty($cb)) : ?>

<form class="crud" action="">
<div class="form_inputs">
<fieldset>
<ul>

	<li>
		<div class="one_half">
			<label>Certification Body</label>
			<div class="input"><?php echo $cb->name; ?></div>
		</div>
		<div class="one_half">
			<label>Slug</label>
			<div class="input"><?php echo $cb->slug; ?></div>
		</div>
		<div class="clearfix"></div>
	</li>
	
	<li>
		<div class="one_half">
			<label>RSPO certification provided</label>
			<div class="input"><?php echo $cb->certification; ?></div>
		</div>
		<div class="one_half">
			<label>RSPO-RED Editor</label>
			<div class="input"><?php echo $cb->red_auditor; ?></div>
		</div>
		<div class="clearfix"></div>
	</li>
	
	<li>
		<div class="one_half">
			<label>Accreditation</label>
			<div class="input"><?php echo $cb->accreditation; ?></div>
		</div>
		<div class="one_half">
			<label>Complete Address</label>
			<div class="input"><?php echo $cb->address; ?></div>
		</div>
		<div class="clearfix"></div>
	</li>
	
	<li>
		<div class="one_half">
			<label>Website</label>
			<div class="input"><?php echo $cb->website; ?></div>
		</div>
		<div class="one_half">
			<label>Contact person & position</label>
			<div class="input"><?php echo $cb->pic_and_position; ?></div>
		</div>
		<div class="clearfix"></div>
	</li>

	<li>
		<div class="one_half">
			<label>Office phone number (with area code)</label>
			<div class="input"><?php echo $cb->phone; ?></div>
		</div>
		<div class="one_half">
			<label>Mobile phone number (with area code)</label>
			<div class="input"><?php echo $cb->mobile; ?></div>
		</div>
		<div class="clearfix"></div>
	</li>

	<li>
		<div class="one_half">
			<label>Fax number (with area code)</label>
			<div class="input"><?php echo $cb->fax; ?></div>
		</div>
		<div class="one_half">
			<label>Email</label>
			<div class="input"><?php echo $cb->email; ?></div>
		</div>
		<div class="clearfix"></div>
	</li>

	<li>
		<div class="one_half">
			<label>Country</label>
			<div class="input"><?php echo $cb->country; ?></div>
		</div>
		<div class="one_half">
			<label>Geographical Area</label>
			<div class="input"><?php echo $cb->geographical; ?></div>
		</div>
		<div class="clearfix"></div>
	</li>
</ul>

	<div class="table_action_buttons">
		<?php echo anchor('admin/members/cb/delete/'.$cb->id, lang('global:delete'), 'class="btn red confirm"').' '; ?>
	</div>

</fieldset>
</div>
</form>

<?php else : ?>
	<div class=" alert error"><p>Error retrieving cb</p></div>
<?php endif; ?>

</div>
<!-- </section> -->

<div class="clearfix"><br /></div>