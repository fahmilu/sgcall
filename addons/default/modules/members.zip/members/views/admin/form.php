<section class="title">
<?php if ($this->method == 'create'): ?>
	<h4><?php echo lang('members:create_title'); ?></h4>
<?php else: ?>
	<h4><?php echo sprintf(lang('members:edit_title'), $global_user->name); ?></h4>
<?php endif; ?>
</section>

<section class="item">
<div class="content">

<?php echo form_open_multipart(uri_string(), 'class="crud" name="memberApplication" id="memberApplication"'); ?>

<div class="tabs">

	<ul class="tab-menu">
		<li><a href="#about-tab"><span><?php echo lang('members:tab_about'); ?></span></a></li>
		<li><a href="#contact-tab"><span><?php echo lang('members:tab_contact'); ?></span></a></li>
		<li><a href="#questions-tab"><span><?php echo lang('members:tab_questions'); ?></span></a></li>
		<li><a href="#documents-tab"><span><?php echo lang('members:tab_documents'); ?></span></a></li>
		<li><a href="#test-tab"><span>Test Only</span></a></li>
	</ul>

	<div class="form_inputs" id="about-tab">
		<?php $this->load->view('admin/forms/_form-member-step1'); ?>
	</div>

	<div class="form_inputs" id="contact-tab">
		<?php $this->load->view('admin/forms/_form-member-step2'); ?>
	</div>

	<div class="form_inputs" id="questions-tab">
		<?php $this->load->view('admin/forms/_form-member-step3'); ?>
	</div>

	<div class="form_inputs" id="documents-tab">
		<?php $this->load->view('admin/forms/_form-member-step4'); ?>
	</div>

	<div class="form_inputs" id="test-tab">
		<table>
			<tr>
				<th>Title</th>
				<th>Date</th>
				<th>Languages</th>
				<th>Actions</th>
			</tr>
			<tr>
				<td width="400" valign="top" style="vertical-align:top;">
					The latest publications of my organisation
				</td>
				<td valign="top" style="vertical-align:top;">
					28 August 2014
				</td>
				<td valign="top">
					<div style="display:block; padding: 9px 0;height: 20px;clear:both;">
						<div style="float:left;width:100px;">English</div> <div style="float:left;"><a href="#" class="button update">Update</a></div>
					</div>
					<div style="display:block; padding: 9px 0;height: 20px;clear:both;">
						<div style="float:left;width:100px;">Germany</div> <div style="float:left;"><a href="#" class="button">Update</a></div>
					</div>
					<div style="display:block; padding: 9px 0;height: 20px;clear:both;">
						<div style="float:left;width:100px;">Chinese</div> <div style="float:left;"><a href="#" class="button">Update</a></div>
					</div>
				</td>
				<td valign="top" style="vertical-align:top;">
					<a href="#" class="button">Edit</a>
					<a href="#" class="button">Delete</a>
					<a href="#" class="button">Unpublish</a>
					<a href="#" class="button archive">See Archive</a>
				</td>
			</tr>
			<tr>
				<td width="400" valign="top" style="vertical-align:top;">
					The latest publications of my organisation
				</td>
				<td valign="top" style="vertical-align:top;">
					28 August 2014
				</td>
				<td valign="top">
					<div style="display:block; padding: 9px 0;height: 20px;clear:both;">
						<div style="float:left;width:100px;">English</div> <div style="float:left;"><a href="#" class="button update">Update</a></div>
					</div>
					<div style="display:block; padding: 9px 0;height: 20px;clear:both;">
						<div style="float:left;width:100px;">Germany</div> <div style="float:left;"><a href="#" class="button">Update</a></div>
					</div>
					<div style="display:block; padding: 9px 0;height: 20px;clear:both;">
						<div style="float:left;width:100px;">Chinese</div> <div style="float:left;"><a href="#" class="button">Update</a></div>
					</div>
				</td>
				<td valign="top" style="vertical-align:top;">
					<a href="#" class="button">Edit</a>
					<a href="#" class="button">Delete</a>
					<a href="#" class="button">Unpublish</a>
					<a href="#" class="button archive">See Archive</a>
				</td>
			</tr>
			<tr>
				<td width="400" valign="top" style="vertical-align:top;">
					The latest publications of my organisation
				</td>
				<td valign="top" style="vertical-align:top;">
					28 August 2014
				</td>
				<td valign="top">
					<div style="display:block; padding: 9px 0;height: 20px;clear:both;">
						<div style="float:left;width:100px;">English</div> <div style="float:left;"><a href="#" class="button update">Update</a></div>
					</div>
					<div style="display:block; padding: 9px 0;height: 20px;clear:both;">
						<div style="float:left;width:100px;">Germany</div> <div style="float:left;"><a href="#" class="button">Update</a></div>
					</div>
				</td>
				<td valign="top" style="vertical-align:top;">
					<a href="#" class="button">Edit</a>
					<a href="#" class="button">Delete</a>
					<a href="#" class="button">Unpublish</a>
					<a href="#" class="button archive">See Archive</a>
				</td>
			</tr>
		</table>

	</div>

</div>

<div class="buttons">
	<?php $this->load->view('admin/partials/buttons', array('buttons' => array('save', 'cancel'))) ?>
</div>

<?php echo form_close(); ?>
<div  style="display:none;">
<div id="fileupdate">
	<h3>Update file</h3>
	<input type="file" name="file" />
</div>
</div>

<div  style="display:none;">
<div id="filearchive">
	<h3>File archive</h3>
	<table>
		<tr>
			<th>File name</th>
			<th>File size</th>
			<th>Language</th>
			<th>Uploaded date</th>
			<th>Uploaded by</th>
		</tr>
		<tr>
			<td>File_Attachment_One.pdf</td>
			<td>1.2MB</td>
			<td>
				<a href="#" style="padding:5px 0;">English</a><br />
				<a href="#" style="padding:5px 0;">Germany</a><br />
			</td>
			<td>12 August 2014</td>
			<td>Admin One</td>
		</tr>
		<tr>
			<td>File_Attachment_Two.pdf</td>
			<td>1.2MB</td>
			<td>
				<a href="#" style="padding:5px 0;">English</a><br />
				<a href="#" style="padding:5px 0;">Chinese</a><br />
			</td>
			<td>22 August 2014</td>
			<td>Admin Two</td>
		</tr>
	</table>
</div>
</div>

<script>
$(document).ready(function(){
	$('a.update').colorbox({
		inline: true,
		href: "#fileupdate",
		width: "400px",
		height: "90px",
		onComplete: function(){
			$.colorbox.resize();
		}
	});
	$('a.archive').colorbox({
		inline: true,
		href: "#filearchive",
		minWidth: "400px",
		minHeight: "90px",
		onComplete: function(){
			$.colorbox.resize();
		}
	});
});
</script>

</div>
</section>