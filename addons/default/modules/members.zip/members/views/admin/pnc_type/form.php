<?php
//echo "<pre>";
// print_r($_POST);
//echo "</pre>";
?>
<section class="title">
	<?php if ($this->controller == 'admin_categories' && $this->method === 'edit'): ?>
	<h4><?php echo sprintf(lang('cat_edit_title'), $category->title);?></h4>
	<?php else: ?>
	<h4><?php echo lang('cat_create_title');?></h4>
	<?php endif; ?>
</section>

<section class="item">
<div class="content">

<?php echo form_open($this->uri->uri_string(), 'class="crud" id="categories"'); ?>

<div class="form_inputs">

	<ul>
		<li>
			<label for="title"><?php echo lang('global:title');?> <span>*</span></label>
			<div class="input"><?php echo  form_input('title', $category->title); ?></div>
			<div class="input"><?php echo  form_hidden('id', $category->id); ?></div>
		</li>
		<li>
			<label for="title"><?php echo lang('global:slug');?> <span>*</span></label>
			<div class="input"><?php echo  form_input('slug', $category->slug); ?></div>
		</li>
		<li>
			<label for="respect_expiry_date"><?php echo lang('cat_respect_expiry_date');?></label>
			<div class="input"><label class="inline"><?php echo  form_checkbox('respect_expiry_date', 'y', $category->respect_expiry_date == 'y'); ?> <?php echo lang('cat_respect_expiry_date_yes'); ?></label></div>
		</li>
		<li>
			<label for="meta_description"><?php echo 'Meta ' . lang('global:description');?></label>
			<div class="input"><textarea name="meta_description" id="meta_description" style="width:350px;height:100px;"><?php echo $category->meta_description; ?></textarea></div>
		</li>
	</ul>
	
</div>

	<div><?php $this->load->view('admin/partials/buttons', array('buttons' => array('save', 'cancel') )); ?></div>

<?php echo form_close(); ?>

</div>
</section>