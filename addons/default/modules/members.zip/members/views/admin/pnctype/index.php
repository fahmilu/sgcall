<section class="title">
	<h4><?php echo lang('pnc:assessment_type_label'); ?></h4>
</section>

<section class="item">
<div class="content">

<?php if (!empty($pnctypes)) : ?>

	<?php echo form_open('admin/members/pncassessment_type/action'); ?>
	<div id="filter-stage">


<small>Number of data: <?php echo number_format($count); ?></small>

	<table>
		<thead>
			<tr>
				<th width="20"><?php echo form_checkbox(array('name' => 'action_to_all', 'class' => 'check-all')); ?></th>
				<th width="20" class="collapse">Position</th>
				<th width="50" class="collapse">Type</th>
				<th width="250" class="collapse">Description</th>
				<th width="200">Actions</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="8">
					<div class="inner"><?php $this->load->view('admin/partials/pagination'); ?></div>
				</td>
			</tr>
		</tfoot>
		<tbody>
			<?php foreach ($pnctypes as $type) : ?>
				<tr>
					<td><?php echo form_checkbox('action_to[]', $type->id); ?></td>
					<td><?php echo $type->position; ?></td>
					<td class="collapse"><?php echo $type->stage; ?></td>
					<td><?php echo $type->description; ?></td>
					<td>
						<?php
						echo anchor('admin/members/pncassessment_type/edit/'.$type->id, lang('global:edit'), 'class="button"').' ';
						echo anchor('admin/members/pncassessment_type/delete/'.$type->id, lang('global:delete'), 'class="button confirm"').' ';
						?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<div class="table_action_buttons">
		<?php $this->load->view('admin/partials/buttons', array('buttons' => array('delete'))) ?>
	</div>
	
	</div>
	<?php echo form_close(); ?>

<?php else : ?>
	<div class="no_data"><?php echo lang('cb:empty_cbs_msg'); ?></div>
<?php endif; ?>

</div>
</section>