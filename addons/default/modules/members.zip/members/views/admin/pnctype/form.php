<section class="title">
<?php if ($this->method == 'create'): ?>
	<h4><?php echo lang('pnc:type_create_title'); ?></h4>
<?php else: ?>
	<h4><?php echo sprintf(lang('pnc:type_edit_title'), $type->stage); ?></h4>
<?php endif; ?>
</section>

<section class="item">
<div class="content">

<?php echo form_open_multipart(uri_string(), 'class="crud" name="pnctype" id="pnctype"'); ?>

<fieldset>
<div class="form_inputs">

	<ul>
		<li>
			<label for="position"><?php echo lang('pnc:position_label'); ?></label>
			<div class="input">
				<select name="position" id="position" class="skip" style="height:35px;width:150px;padding:5px;">
					<option value="">Select position</option>
					<?php
						$lc = count($last_position);
						$lp = $lc - 1;
						for($i=1; $i < $lp + 5;$i++)
						{
							if ( $i <> $type->position && in_array($i, $last_position) )
								echo '<option value="'.$i.'" disabled="disabled">'.$i.'</option>'.PHP_EOL;
							elseif ($i == $type->position)
								echo '<option value="'.$i.'" selected="selected">'.$i.'</option>'.PHP_EOL;
							else
								echo '<option value="'.$i.'">'.$i.'</option>'.PHP_EOL;
						}
					?>
				</select>
				<?php //echo form_dropdown('position', array('draft'=>'Draft', 'live'=>'Live'), $type->position, 'id="position"') ?>
			</div>

		</li>

		<li>
			<label for="stage"><?php echo lang('pnc:stage_label'); ?></label>
			<div class="input"><?php echo form_input('stage', $type->stage, 'id="stage"') ?></div>
		</li>

		<li>
			<label for="description"><?php echo lang('pnc:description_label'); ?></label>
			<div class="input"><textarea name="description" id="description" style="width:350px;height:90px;"><?php echo $type->description; ?></textarea></div>
		</li>

	</ul>

</div>
</fieldset>

<div class="buttons">
	<?php $this->load->view('admin/partials/buttons', array('buttons' => array('save', 'save_exit', 'cancel'))) ?>
</div>

<?php echo form_close(); ?>

</div>
</section>