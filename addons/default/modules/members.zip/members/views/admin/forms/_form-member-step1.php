<br />
<fieldset>
<legend>About the Organisation</legend>
<?php
/*
	$subcat = '';
	if (!empty($om_subcat))
		$subcat = $om_subcat;
	elseif (!empty($am_subcat))
		$subcat = $am_subcat;
	elseif (!empty($sca_subcat))
		$subcat = $sca_subcat;
	elseif (!empty($membersapp->type))
*/
		$subcat = $membersapp->category;

/*
	if (!empty($types[$mshiptype]))
		$membershiptype = $types[$mshiptype];
	elseif (!empty($membersapp->type))
		$membershiptype = $membersapp->type;
*/

?>

	<ul>

		<li>
			<label for="org_category">Membership type <span>*</span></label>
			<div class="input" style="padding-top:9px;">

				<?php echo form_dropdown('type', $member_types, $membersapp->type); ?>
			<input id="membership_type" name="membership_type" type="hidden" value="<?php echo $membersapp->type ?>" />
			<input id="membership_subcat" name="membership_subcat" type="hidden" value="<?php echo $subcat ?>" />

			</div>
		</li>

	<li>
		<label for="org_category">
			What is your organisation's category? <span>*</span>
		</label>
		<div class="input" style="padding-top:9px;">
			<?php echo form_dropdown('category', $member_categories, $membersapp->category, 'onchange="dropdownlist(this.value);"'); ?>
			<div class="clear">&nbsp;</div>

			<?php if ($membersapp->category): ?>
				<script>$(document).ready(function(){ dropdownlist('<?php echo $membersapp->category; ?>') });</script>
			<?php endif; ?>
			<div id="subcategory" style="display:<?php echo $membersapp->profession ? 'block' : 'none' ?>;">	
				<label for="org_category">
					Select the organisation's sub-category? <span>*</span>
				</label>
				<div class="input">
					<select name="profession" id="profession" class="fixedWidth">
						<option value="">Select subcategory</option>
					</select>
				</div>
			</div>
		</div>
	</li>

	<!-- <label class="block"><a href="#" id="hide_category_dropdown">&laquo; Cancel</a></label> -->

	<li>
		<label for="org_name">
			What is your organisation's name? <span>*</span>
			<small>Please use the full legal entity name</small>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's name" data-validation-engine="validate[required]" type="text" name="name" id="name" value="<?php echo htmlspecialchars_decode($membersapp->name); ?>" />
		</div>
	</li>

	<li>
		<label for="org_street">
			Street name and number<span>*</span>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's Address" data-validation-engine="validate[required]" type="text" name="address" id="address" value="<?php echo stripslashes(strip_tags($membersapp->address)); ?>" />
		</div>
	</li>

	<li>
		<label for="org_city">
			City <span>*</span>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's City" data-validation-engine="validate[required]" type="text" name="address_city" id="address_city" value="<?php echo $membersapp->address_city; ?>" />
		</div>
	</li>

	<li>
		<label for="org_state">
			State/Province <span>*</span>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's State/Province" data-validation-engine="validate[required]" type="text" name="address_state" id="address_state" value="<?php echo $membersapp->address_state; ?>" />
		</div>
	</li>

	<li>
		<label for="org_zipcode">
			Postal/Zip Code <span>*</span>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's Zip Code" data-validation-engine="validate[required]" type="text" name="address_zip" id="address_zip" value="<?php echo $membersapp->address_zip; ?>" />
		</div>
	</li>

	<li>
		<label for="org_country">
			Country <span>*</span>
		</label>
		<div class="input">
			[country dropdown]
			<?php //echo country_dropdown('org_country',$org_country, TRUE); ?>
		</div>
	</li>

	<li>
		<label for="org_phone">
			Telephone <span>*</span>
			<small>Include country code</small>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's Phone No." data-validation-engine="validate[required]" type="text" name="telephone" id="telephone" value="<?php echo $membersapp->telephone; ?>" />
		</div>
	</li>

	<li>
		<label for="org_fax">
			Fax
			<small>Include country code</small>
		</label>
		<div class="input">
			<input type="text" name="fax" id="fax" value="<?php echo $membersapp->fax; ?>" />
		</div>
	</li>

	<li>
		<label for="org_email">
			Email <span>*</span>
			<small>Enter you primary email (one only)</small>
		</label>
		<div class="input">
			<input class="email required" rel="Organisation's Primary Email" data-validation-engine="validate[custom[notEqual[org_rep1_email,org_rep2_email]]]" type="text" name="email" id="email" value="<?php echo $membersapp->email; ?>" />
		</div>
	</li>

	<li>
		<label for="org_website">
			Website
		</label>
		<div class="input">
			<input type="text" name="website" id="website" value="<?php echo $membersapp->website; ?>" />
		</div>
	</li>

	<li>
		<label for="org_regnum">
			What is your registration number? <span>*</span>
			<small>Please use the full legal entity number</small>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's registration number" data-validation-engine="validate[required]" type="text" name="registration_number" id="registration_number" value="<?php echo $membersapp->registration_number; ?>" />
		</div>
	</li>

	<li>
		<label for="org_parent">
			Are you a parent company?
		</label>
		<div class="input">
			<?php echo form_dropdown('parent_company', array(''=>'Select', 'y'=>'Yes', 'n'=>'No'), $membersapp->parent_company, ' onchange="displaychildfields(this.value);"'); ?>
		</div>
	</li>

	<?php $org_children = unserialize($membersapp->sub_company); ?>
	<li id="subsidiaries-container" style="display:<?php echo !empty($org_children) ? 'block' : 'none' ?>;">

		<div class="input_row" id="org_subsidiaries">
			<label>
				Subsidiary company/companies
				<small>Click <b>Add more</b> if you have more than one subsidiary companies</small>
			</label>
			<div class="input">
				<div id="childfields">
		<?php if (!empty($org_children)): ?>
			<?php foreach($org_children as $org_child): ?>
				<?php if ($org_child['name']): ?>
					<p>
						<label class="inline">Subsidiary name</label> <input class="org_children" type="text" name="sub_company[name][]" value="<?php echo $org_child['name']; ?>" />
						<input class="org_children_id" type="hidden" name="sub_company[id][]" value="<?php echo !empty($org_child['id'])?$org_child['id']:''; ?>" />
						<a href="#" tabindex="-1" class="btn small red remove_child"> &nbsp;x&nbsp; </a>
					</p>
				<?php endif; ?>
			<?php endforeach; ?>
		<?php else: ?>
			<p>
				<label class="inline">Subsidiary name</label> <input class="org_children" type="text" name="sub_company[name][]" value="" />
				<input class="org_children_id" type="hidden" name="sub_company[id][]" value="" />
				<a href="#" tabindex="-1" class="btn small red remove_child"> &nbsp;x&nbsp; </a>
			</p>
		<?php endif; ?>
				</div>
				<div><a class="add-more" href="#" onclick="add_more_child(); return false;">Add more</a></div>
				<div id="tocopy-container" style="display:none;">
					<div id="tocopy">
						<p>
							<label class="inline">Subsidiary name</label> <input class="org_children" type="text" name="sub_company[name][]" value="" />
							<input class="org_children_id" type="hidden" name="sub_company[id][]" value="" />
							<a href="#" tabindex="-1" class="btn small red remove_child"> &nbsp;x&nbsp; </a>
						</p>
					</div>
				</div>
				<script>
					function displaychildfields(v)
					{
						if (v=="y")
						{
							var ht;
							$("#subsidiaries-container").slideDown();
							var ht = $("#org_subsidiaries").outerHeight();
							var pheight = $("#step1").height();
							$("#form-slider").parent().height(pheight+ht);
						}
						else
							$("#subsidiaries-container").slideUp();
						//$("#memberApplication").validationEngine("updatePromptsPosition");
					}
		
					function add_more_child()
					{
						var newfield = $("#tocopy").html();
						$("#childfields").append(newfield);
						var ht2 = $("#tocopy").height();
						var pheight = $("#form-slider").parent().height();
						var pheight2 = $("#step1").height();
						$("#form-slider").parent().height(pheight2+ht2);
						return false;
					}
				</script>
			</div><br />
			<div class="clearboth"></div>
		</div>
	</li>

	<li>
		<label for="org_market">
			Primary market operations
		</label>
		<div class="input">
			<label><input <?php echo $membersapp->primary_market_ops == 'Indonesia' ? 'checked="checked"' : ''; ?> name="primary_market_ops" type="radio" value="Indonesia" > Indonesia</label>
			<label><input <?php echo $membersapp->primary_market_ops == 'Malaysia' ? 'checked="checked"' : ''; ?> name="primary_market_ops" type="radio" value="Malaysia" > Malaysia</label>
			<label><input <?php echo $membersapp->primary_market_ops == 'World' ? 'checked="checked"' : ''; ?> name="primary_market_ops" type="radio" value="World" > The rest of the world</label>
		</div>
	</li>

	<li>
		<label for="org_othermarket">
			Other market operations
			<small>Please separate country names with comas</small>
		</label>
		<div class="input">
			<textarea name="other_market_ops" rows="5" id="other_market_ops"><?php echo $membersapp->other_market_ops; ?></textarea>
		</div>
	</li>

	<li>
		<label for="org_logo">
			Upload your organisation logo <span>*</span>
			<small>Your logo should be in PNG, JPG, or GIF format, and no more than 1.5MB in size</small>
		</label>
		<div class="input">
			<input onchange="copyfname(this.value, $(this))" type="file" name="org_logo" id="org_logo">
			<input rel="Organisation's logo" class="required" data-validation-engine="validate[required]" type="hidden" id="org_logo_div" name="org_logo_div" value="<?php echo !empty($membersapp->logo) ? $membersapp->logo : '' ?>" />
			<?php if (!empty($membersapp->logo)): ?>
			<div class="clear"></div>
				<label class="inline">Filename: </label> <?php echo $membersapp->logo; ?>
				<br />
				<img style="width:200px;margin-top:20px;" src="<?php echo site_url(UPLOAD_PATH.'memberlogos/'.$membersapp->logo) ?>" />
			<?php endif; ?>
		</div>
	</li>

	<li>
		<label for="org_about">
			Tell us about your organisation
			<small>Please provide some background information on your organisation in no more than 250 words</small>
		</label>
		<div class="input">
			<textarea
				name="profile"
				class="wysiwyg-advanced"
				rows="10"
				id="org_about"
			><?php echo $membersapp->profile ?></textarea><br />
		</div>
	</li>
</ul>

</fieldset>

<script>

$(document).ready(function(){

	$( ".org_children" ).livequery(function(){
		$(this).autocomplete({
			source: SITE_URL + 'admin/members/pick',
			minLength: 2,
			select: function( event, ui ) {
				$(this).next('.org_children_id').val(ui.item.id);
			}
		});
	});

	$(".remove_child").livequery('click', function(e){
		e.preventDefault();
		if (confirm('Are you sure you want to remove this subsidiary?'))
		{
			var $this = $(this).parent();
			$this.fadeOut('slow', function(){
				$this.empty().remove();
			});
		}
		else
		{
			return false;
		}
	});

	var step1ht = $("#step1").height();

	$('#show_category_dropdown').click(function(e){
		e.preventDefault();
		$('#category_dropdown').show();
		var ht2 = $('#category_dropdown').outerHeight();
		//var pheight = $("#form-slider").height();
		$("#form-slider").parent().height(step1ht+ht2);
	});

	$('#hide_category_dropdown').click(function(e){
		e.preventDefault();
		$('#category_dropdown').hide();
		//var pheight = $("#form-slider").height();
		$("#form-slider").parent().height(step1ht);
	});

	<?php
	// membership type
	switch($membersapp->type)
	{
		case 'om_subcat':
		case 'Ordinary Members':
		?>
			//$("#primary-market").show();
			//$("#org_other_market").show();
			$('#q_om1, #q_om2, #q_om3, #q_am, #q_sca').show();
			<?php
			break;

		case 'am_subcat':
		case 'Affiliate Members':
		?>
			$("#primary-market").hide();
			$("#org_other_market").hide();
			$('#q_om1, #q_om2, #q_om3, #q_sca').hide();
			$('#q_am').show();
			<?php
			break;

		case 'sca_subcat':
		case 'Supply Chain Associate':
		?>
			$("#primary-market").hide();
			$("#org_other_market").hide();
			$('#q_sca').show();
			$('#q_om1, #q_om2, #q_om3, #q_am').hide();
			<?php
			break;
	}
	?>

<?php
if (!empty($membersapp->category)):
	// ordinary member categories
	switch($membersapp->category)
	{
		case 'Oil Palm Growers':
		?>
			$("#subcategory div:first span").html("Select subcategory");
			document.memberApplication.profession.options.length = 0;
			document.memberApplication.profession.options[0]=new Option("Select subcategory","");
		<?php
			foreach($subcat_growers as $i=>$v)
			{
			?>
			document.memberApplication.profession.options[<?php echo ($i+1) ?>]=new Option("<?php echo $v ?>", "<?php echo $v ?>");
			<?php
				if ($v == $membersapp->profession)
				{
					echo 'document.memberApplication.profession.options['.($i+1).'].selected=true;'.PHP_EOL;
					echo '$("#subcategory div:first span").html("'.$membersapp->profession.'");'.PHP_EOL;
				}
			}
		?>
			$("#subcategory").show();
			$("#primary-market").show();
			$("#org_other_market").show();
		<?php
		break;

		case 'Consumer Goods Manufacturers':
		?>
			document.memberApplication.profession.options.length = 0;
			document.memberApplication.profession.options[0]=new Option("Select subcategory","");
		<?php
			foreach($subcat_others as $i=>$v)
			{
			?>
			document.memberApplication.profession.options[<?php echo ($i+1) ?>]=new Option("<?php echo $v ?>", "<?php echo $v ?>");
			<?php
				if ($v == $membersapp->profession)
					echo 'document.memberApplication.profession.options['.($i+1).'].selected=true;'.PHP_EOL;
			}
		?>
			$("#subcategory div:first span").html("Select subcategory");
			$("#subcategory").show();
		<?
		break;
		case 'Palm Oil Processors and Traders':
		?>
			document.memberApplication.profession.options.length = 0;
			document.memberApplication.profession.options[0]=new Option("Select subcategory","");
		<?php
			foreach($subcat_popt as $i=>$v)
			{
			?>
			document.memberApplication.profession.options[<?php echo ($i+1) ?>]=new Option("<?php echo $v ?>", "<?php echo $v ?>");
			<?php
				if ($v == $membersapp->profession)
					echo 'document.memberApplication.profession.options['.($i+1).'].selected=true;'.PHP_EOL;
			}
		?>
			$("#subcategory div:first span").html("Select subcategory");
			$("#subcategory").show();
		<?
		break;
	}
	// ordinary member categories ends
	?>
<?php endif ?>


});



function dropdowncat(v)
{
	var ht2 = 0;
	var ht3 = 0;

//	alert('v: '+v);
	switch (v)
	{
		case 'om_subcat':
			document.memberApplication.org_category.options.length = 0;
			document.memberApplication.org_category.options[0]=new Option("Select Category","");
			<?php foreach($categories['om'] as $k=>$v): ?>
			document.memberApplication.org_category.options[<?php echo $k+1 ?>]=new Option("<?php echo $v ?>","<?php echo $v ?>");
			<?php endforeach; ?>
			$("#subcategory").slideDown();
			$("#primary-market").slideDown();
//			ht2 = $("#primary-market > div").outerHeight();
//			$("#org_other_market").slideDown();
//			ht3 = $("#org_other_market > div").outerHeight();
			$('#q_sca').hide();
			$('#q_om1, #q_om2, #q_om3, #q_am').show();
			var pheight = $("#step1").height();
//			$("#form-slider").parent().height(pheight+ht2+ht3+50);
		break;

		case 'am_subcat':
			document.memberApplication.org_category.options.length = 0;
			document.memberApplication.org_category.options[0]=new Option("Select Category","");
			<?php foreach($categories['am'] as $k=>$v): ?>
			document.memberApplication.org_category.options[<?php echo $k+1 ?>]=new Option("<?php echo $v ?>","<?php echo $v ?>");
			<?php endforeach; ?>
			$("#subcategory").slideUp();
			$("#primary-market").slideUp();
			$("#org_other_market").slideUp();
			var pheight = $("#form-slider").height();
			if ($("#primary-market").css('display')=='block')
			{
				ht2 = $("#primary-market > div").outerHeight();
				ht3 = $("#org_other_market > div").outerHeight();
				$("#form-slider").parent().height(pheight-ht2-ht3+50);
			}
			$('#q_om1, #q_om2, #q_om3, #q_sca').hide();
			$('#q_am').show();
		break;

		case 'sca_subcat':
			document.memberApplication.org_category.options.length = 0;
			document.memberApplication.org_category.options[0]=new Option("Select Category","");
			<?php foreach($categories['sca'] as $k=>$v): ?>
			document.memberApplication.org_category.options[<?php echo $k+1 ?>]=new Option("<?php echo $v ?>","<?php echo $v ?>");
			<?php endforeach; ?>
			$("#subcategory").slideUp();
		 	$("#primary-market").slideUp();
			$("#org_other_market").slideUp();
			ht2 = $("#primary-market > div").outerHeight();
			ht3 = $("#org_other_market > div").outerHeight();
			var pheight = $("#form-slider").height();
			if ($("#primary-market").css('display')=='block')
			{
				ht2 = $("#primary-market > div").outerHeight();
				ht3 = $("#org_other_market > div").outerHeight();
				$("#form-slider").parent().height(pheight-ht2-ht3+50);
			}
			$('#q_sca').show();
			$('#q_om1, #q_om2, #q_om3, #q_am').hide();
		break;
	}
	document.memberApplication.org_category.options[0].selected=true;
	$("#membercategory div:first span").html("Select Category");
}

function dropdownlist(listindex)
{
	$select = $("#profession");
	switch (listindex)
	{
		case "Oil Palm Growers":
			//document.memberApplication.profession.options.length = 0;
			$select.find('option').remove().end();
			$select.append('<option value="Select subcategory" >Select subcategory</option>');
			<?php foreach($subcat_growers as $s): ?>
				$select.append('<option value="<?php echo $s; ?>" > <?php echo $s; ?></option>');
			<?php endforeach; ?>
			$select.trigger("liszt:updated");

			$("#subcategory div:first span").html("Select subcategory");
			$("#subcategory").show();
			$("#primary-market").show();
			var ht2 = $("#primary-market").outerHeight();
			$("#org_other_market").slideDown();
			ht3 = $("#org_other_market > div").outerHeight();
			var pheight = $("#form-slider").height();
			$("#form-slider").parent().height(pheight+ht2+ht3+50);
		break;
		case "Consumer Goods Manufacturers":
		case "Palm Oil Processors and Traders":
			$select.find('option').remove().end();
			//document.memberApplication.profession.options.length = 0;
			$select.append('<option value="Select subcategory" >Select subcategory</option>');
			<?php foreach($subcat_popt as $s): ?>
				$select.append('<option value="<?php echo $s; ?>" > <?php echo $s; ?></option>');
			<?php endforeach; ?>
			$("#subcategory div:first span").html("Select subcategory");
			$("#subcategory").show();
			$select.trigger("liszt:updated");
/*
			$("#primary-market").show();
			var ht2 = $("#primary-market").outerHeight();
			var pheight = $("#form-slider").height();
			$("#form-slider").parent().height(pheight+ht2);
*/
		break;
		default:
			 if (document.memberApplication.profession != undefined)
			 {
				$select.find('option').remove().end();
				$select.trigger("liszt:updated");
				$("#subcategory").slideUp();
				 //$("#primary-market").slideUp();
			 }
		break;
	}
	return true;
}
</script>

