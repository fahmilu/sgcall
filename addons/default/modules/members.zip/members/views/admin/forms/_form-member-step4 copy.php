
<fieldset>

<li>

	<label class="notbold">
		Copy of the certificate of incorporation of your organisation
		<small>Your file should be in either PDF, PNG, JPG, or GIF format and no more than 2MB in size</small>
	</label>
	<div class="input">
		<div id="org_certificate_fields">

<?php
		$org_certificate = explode(',', $membersapp->file_certificates);
		if (count($org_certificate))
		{
			echo '<ul>'.PHP_EOL;
			foreach($org_certificate as $oc)
			{
				if ($oc)
				{
					echo '<li>File: <a target="_blank" href="/'.$oc.'">'.str_ireplace('ma/doc/', '', $oc).'</a>'.PHP_EOL;
					echo '<input type="hidden" name="org_certificate_div[]" value="'.$oc.'" /></li>'.PHP_EOL;
				}
			}
			echo '</ul>'.PHP_EOL;
		}
		else
		{?>
			<input class="no-uniform" id="org_certificate_file" rel="Copy of the certificate of incorporation of your organisation" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this))" type="file" name="org_certificate[]" >
			<input id="org_cert_1" class="required" rel="Copy of the certificate of incorporation of your organisation" data-validation-engine="validate[required]" type="hidden" name="t_org_certificate_div[]" value="" />
		<?php
		}
		?>

		</div>
		<div style="clear:both;display:block;">
			<a class="add-more-file" href="#" onclick="add_more_certificate(); return false;">Add more files</a>
		</div>
		<div id="more-certificate-container" style="display:none;">
			<div id="more-certificate">
				<input class="no-uniform" onchange="copyfname(this.value, $(this))" type="file" name="org_certificate[]" >
				<input type="hidden" name="t_org_certificate_div[]" value="" />
			</div>
		</div>
		<script>
			function add_more_certificate()
			{
				var newfield = $("#more-certificate").html();
				$("#org_certificate_fields").append(newfield);
				//$("#org_certificate_fields input[type=hidden]:last-child").addClass("required");
				var ht = $("#step4").height();
				var ht2 = $("#more-certificate").height();
				$("#form-slider").parent().height(ht+ht2);
				$("#memberApplication").validationEngine("updatePromptsPosition");
				return false;
			}
		</script>
	</div>
	<div class="clearboth"></div>
</div>

<?php if ($membersapp->type=="Supply Chain Associate"): ?>

	<div class="clearboth"></div>
	
	<div class="input_row">

		<p><b>For Supply Chain Associate Members</b> – Please attach a signed copy of the RSPO Agreement (<a href="/file/downloads/SCA Agreement.pdf" target="blank">click here to download</a>). This should be at the bottom of the final page and accompanied by your organisation’s logo or stamp.</p>
	
		<label for="org_agreement" class="notbold">
			<small>Your file should be in either PDF, PNG, JPG, or GIF format and no more than 2MB in size.<br />
			Uploading new file will overwrite the existing one.
			</small>
		</label>
		<div class="input">
		<?php $org_agreement = explode(',', $membersapp->file); ?>
			<input class="no-uniform" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this))" type="file" name="org_agreement" id="org_agreement">
			<input class="required" rel="Signed copy of the RSPO Agreement" data-validation-engine="validate[required]" type="hidden" name="org_agreement_div" id="org_agreement_div" value="<?php //echo $org_agreement[0] ?>" />
			<p>File: <?php //echo $org_agreement[0] ? '<a target="_blank" href="'.$org_agreement[0].'">'.str_ireplace('ma/doc/', '', $org_agreement[0]).'</a>' : 'none' ?>
			<input type="hidden" name="cur_org_agreement_div" id="cur_org_agreement_div" value="<?php //echo $org_agreement[0] ?>" />
		</div>
	</div><br />

<?php endif; ?>


<?php if (!empty($membersapp->category) && $membersapp->category=='Oil Palm Growers'): ?>
	<div class="clearboth"></div>
	
	<div class="input_row">
	
		<br />
		<b>For Ordinary Members – "Growers" category only</b>:
		<ol>
		<li>
			Organisation status (corporate and organization chart)
		</li>
		<li>
			Disclosure of plans to implement the RSPO P&C
		</li>
		<li>
			Estate location and map
		</li>
		<li>
			Disclosure of existing field practices and policies of CSR/ sustainability policy
		</li>
		</ol>
	
		<label class="notbold">
			<small>Your file should be in either PDF, PNG, JPG, or GIF format and no more than 2MB in size</small><br />
		</label>

		<div class="input">
			<div id="org_growers_fields">
	
	<?php 
			$org_growers = explode(',', $membersapp->file);
			if (count($org_growers))
			{
/*
				echo '<ul>'.PHP_EOL;
				foreach($org_growers as $og)
				{
					if ($og)
					{
						echo '<li>File: <a target="_blank" href="/'.$og.'">'.str_ireplace('ma/doc/', '', $og).'</a>'.PHP_EOL;
						echo '<input type="hidden" name="org_growers_div[]" value="'.$og.'" /></li>'.PHP_EOL;
					}
				}
				echo '</ul>'.PHP_EOL;
*/
			}
			else
			{?>
			<p>
				<input class="no-uniform" data-validation-engine="validate[custom[checkFile]]" onchange="copyfname(this.value, $(this))" type="file" name="org_growers[]" >
				<input class="required" rel="Ordinary Members - Growers file attachment" data-validation-engine="validate[required]" type="hidden" name="org_growers_div[]" value="" />
			</p>
			<?php
			}
			?>

			</div>
			<div style="clear:both;display:block;">
				<a class="add-more-file" href="#" onclick="add_more_growers(); return false;">Add more files</a>
			</div>
			<div id="more-growers-container" style="display:none;">
				<div id="more-growers">
				<p>
					<input class="no-uniform" onchange="copyfname(this.value, $(this))" type="file" name="org_growers[]" ><br />
					<input type="hidden" name="t_org_growers_div[]" value="" />
				</p>
				</div>
			</div>
			<script>
				function add_more_growers()
				{
					var newfield = $("#more-growers").html();
					$("#org_growers_fields").append(newfield);
					var ht = $("#step4").height();
					var ht2 = $("#more-growers").height();
					$("#form-slider").parent().height(ht+ht2);
					$("#memberApplication").validationEngine("updatePromptsPosition");
					$("input[name='org_growers[]']").not(".no-uniform").uniform();
					return false;
				}
			</script>
		</div>

		<div class="clearboth"><br /></div>
	</div>

<?php endif; ?>

<div class="clearboth"></div>

<div class="input_row">
<div class="clearboth"></div>

	<div class="mapp-agreement">
		<p><b>I agree to the following by checking the box below:</b> <span>*</span></p>
		<table width="100%" cellspacing="0" cellpadding="5">
			<tr>
				<td valign="top" width="20"><input type="checkbox" onclick="agree(this);" name="org_agreement" value="y" id="org_agreement"></td>
				<td valign="top" style="line-height:1.5;">I hereby acknowledge that I have read and understand all of my obligations, duties and responsibilities under each principle and provision of RSPO’s <a target="_blank" href="/file/downloads/<?php echo ($membershiptype=="Supply Chain Associate"?"RSPO-Code of Conduct (SCA).pdf":"RSPO-Code of Conduct.pdf")?>" >Code of Conduct</a> and will accept the future amendments and modifications to the Code of Conduct.</td>

			</tr>
		</table>
	</div>
</div>

<fieldset>
<legend>Membership application is made by:</legend>

<div class="input_row">
	<label for="org_app_by" class="notbold">
		Full name <span>*</span>
	</label>
	<div class="input">
		<input class="required" rel="Full name of person making membership application" data-validation-engine="validate[required]" type="text" name="org_app_by" id="org_app_by" value="<?php echo ($membersapp->name_a ? $membersapp->name_a : '') ?>" />
	</div>
</div>

<div class="clearboth"></div>

<div class="input_row">
	<label for="org_app_position" class="notbold">
		Position <span>*</span>
	</label>
	<div class="input">
		<input class="required" rel="Position of person making membership application" data-validation-engine="validate[required]" type="text" name="org_app_position" id="org_app_position" value="<?php echo ($membersapp->designation_a ? $membersapp->designation_a : '') ?>" />
	</div>
</div>

<div class="clearboth"></div>

<div class="input_row">
	<label for="org_app_by" class="notbold">
		Email address <span>*</span>
	</label>
	<div class="input">
		<input class="required" rel="Email address of the person making membership application" data-validation-engine="validate[required,custom[email]]]" type="text" name="org_app_by_email" id="org_app_by_email" value="<?php echo ($membersapp->name_a ? $membersapp->name_a : '') ?>" />
	</div>
</div>

<div class="clearboth"></div>

<div class="input_row">
	<label for="org_app_date" class="notbold">
		Applied date <span>*</span>
	</label>
	<div class="input">
		<input class="required" data-validation-engine="validate[required]" type="text" name="org_app_date" id="org_app_date" value="<?php echo ($membersapp->date_2 ? date("d/m/Y", strtotime($membersapp->date_2)) : date("d/m/Y")) ?>" />
	</div>
	<script>
		$(document).ready(function(){
			$("#org_app_date").datepicker({
				dateFormat	: "dd/mm/yy"
			});
		});
	</script>
</div>

<div class="clearboth"></div>

</fieldset>

<script>
	function agree(v)
	{
		if(v.checked)
		{
			$("button#submit").removeAttr("disabled");
/*
	$("#memberApplication").validationEngine('attach', {
		promptPosition: "bottomLeft",
		scroll : false
	});
*/
			listrequiredfields(false);
			$("#fieldlist").fadeIn();
		}
		else
		{
			$("button#submit").attr("disabled", "disabled");
			$("#memberApplication").validationEngine("hide");
			$("#fieldlist").fadeOut();
		}
	}
</script>


<!-- </fieldset> -->
<!-- end form-slide step 4 -->
</div>

