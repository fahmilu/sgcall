
<fieldset id="organisation_info">

<?php
/*
	$subcat = '';
	if (!empty($om_subcat))
		$subcat = $om_subcat;
	elseif (!empty($am_subcat))
		$subcat = $am_subcat;
	elseif (!empty($sca_subcat))
		$subcat = $sca_subcat;
	elseif (!empty($global_user->type))
*/
		$subcat = $global_user->category;

/*
	if (!empty($types[$mshiptype]))
		$membershiptype = $types[$mshiptype];
	elseif (!empty($global_user->type))
		$membershiptype = $global_user->type;
*/

?>

	<ul>

		<li>
			<label for="org_category">Membership type <span>*</span></label>
			<div class="input" style="padding-top:9px;">
				[membership type]
			</div>
		</li>

	<li>
		<label for="org_category">
			What is your organisation's category? <span>*</span>
		</label>
		<div class="input" style="padding-top:9px;">
			<?php //echo $subcat ?>
			[category]

			<div class="clearfix">&nbsp;</div>
			<div id="subcategory" style="display:none;">
	
				<select name="org_subcategory" class="fixedWidth">
					<option value="">Select subcategory</option>
				</select>
	
			</div>
		</div>
	</li>

	<!-- <label class="block"><a href="#" id="hide_category_dropdown">&laquo; Cancel</a></label> -->

	<li>
		<label for="org_name">
			What is your organisation's name? <span>*</span>
			<small>Please use the full legal entity name</small>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's name" data-validation-engine="validate[required]" type="text" name="org_name" id="org_name" value="<?php echo $global_user->name; ?>" />
		</div>
	</li>

	<li>
		<label for="org_street">
			Street name and number <span>*</span>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's Address" data-validation-engine="validate[required]" type="text" name="org_street" id="org_street" value="<?php echo stripslashes(strip_tags($global_user->address)); ?>" />
		</div>
	</li>

	<li>
		<label for="org_city">
			City <span>*</span>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's City" data-validation-engine="validate[required]" type="text" name="org_city" id="org_city" value="<?php echo $global_user->address_city; ?>" />
		</div>
	</li>

	<li>
		<label for="org_state">
			State/Province <span>*</span>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's State/Province" data-validation-engine="validate[required]" type="text" name="org_state" id="org_state" value="<?php echo $global_user->address_state; ?>" />
		</div>
	</li>

	<li>
		<label for="org_zipcode">
			Postal/Zip Code <span>*</span>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's Zip Code" data-validation-engine="validate[required]" type="text" name="org_zipcode" id="org_zipcode" value="<?php echo $global_user->address_zip; ?>" />
		</div>
	</li>

	<li>
		<label for="org_country">
			Country <span>*</span>
		</label>
		<div class="input">
			[country dropdown]
			<?php //echo country_dropdown('org_country',$org_country, TRUE); ?>
		</div>
	</li>

	<li>
		<label for="org_phone">
			Telephone <span>*</span>
			<small>Include country code</small>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's Phone No." data-validation-engine="validate[required]" type="text" name="org_phone" id="org_phone" value="<?php echo $global_user->telephone; ?>" />
		</div>
	</li>

	<li>
		<label for="org_fax">
			Fax
			<small>Include country code</small>
		</label>
		<div class="input">
			<input type="text" name="org_fax" id="org_fax" value="<?php echo $global_user->fax; ?>" />
		</div>
	</li>

	<li>
		<label for="org_email">
			Email <span>*</span>
			<small>Enter you primary email (one only)</small>
		</label>
		<div class="input">
			<input class="email required" rel="Organisation's Primary Email" data-validation-engine="validate[custom[notEqual[org_rep1_email,org_rep2_email]]]" type="text" name="org_email" id="org_email" value="<?php echo $global_user->email; ?>" />
		</div>
	</li>

	<li>
		<label for="org_website">
			Website
		</label>
		<div class="input">
			<input type="text" name="org_website" id="org_website" value="<?php echo $global_user->website; ?>" />
		</div>
	</li>

	<li>
		<label for="org_regnum">
			What is your registration number? <span>*</span>
			<small>Please use the full legal entity number</small>
		</label>
		<div class="input">
			<input class="required" rel="Organisation's registration number" data-validation-engine="validate[required]" type="text" name="org_regnum" id="org_regnum" value="<?php echo $global_user->registration_number; ?>" />
		</div>
	</li>

	<li>
		<label for="org_parent">
			Are you a parent company?
		</label>
		<div class="input">
			<select name="org_parent" id="org_parent" onchange="displaychildfields(this.value);" >
				<option value="">Select Yes/No
				<option <?php //echo $org_parent == 'y' ? 'selected="selected"' : '' ?> value="y" >Yes
				<option <?php //echo $org_parent == 'n' ? 'selected="selected"' : '' ?>value="n" >No
			</select>
		</div>
	</li>

	<li id="subsidiaries-container" style="display:<?php echo !empty($org_children) ? 'block' : 'none' ?>;">
		<div class="input_row" id="org_subsidiaries">
			<label>
				Subsidiary company/companies
				<small>Click <b>Add more</b> if you have more than one subsidiary companies</small>
			</label>
			<div class="input">
				<div id="childfields">
		<?php if (!empty($org_children)): ?>
			<?php foreach($org_children as $org_child): ?>
				<p><input class="org_children" type="text" name="org_children[][name]" value="<?php echo $org_child['name']; ?>" /></p>
			<?php endforeach; ?>
		<?php else: ?>
			<p><input class="org_children" type="text" name="org_children[][name]" value="" /></p>
		<?php endif; ?>
				</div>
				<div><a class="add-more" href="#" onclick="add_more_child(); return false;">Add more</a></div>
				<div id="tocopy-container" style="display:none;"><div id="tocopy"><p><input class="org_children" type="text" name="org_children[][name]" value="" /></p></div></div>
				<script>
					function displaychildfields(v)
					{
						if (v=="y")
						{
							var ht;
							$("#subsidiaries-container").slideDown();
							var ht = $("#org_subsidiaries").outerHeight();
							var pheight = $("#step1").height();
							$("#form-slider").parent().height(pheight+ht);
						}
						else
							$("#subsidiaries-container").slideUp();
						$("#memberApplication").validationEngine("updatePromptsPosition");
					}
		
					function add_more_child()
					{
						var newfield = $("#tocopy").html();
						$("#childfields").append(newfield);
						var ht2 = $("#tocopy").height();
						var pheight = $("#form-slider").parent().height();
						var pheight2 = $("#step1").height();
						$("#form-slider").parent().height(pheight2+ht2);
						return false;
					}
				</script>
			</div><br />
			<div class="clearboth"></div>
		</div>
	</li>

	<li>
		<label for="org_market">
			Primary market operations
		</label>
		<div class="input">
			<label class="normal"><input <?php echo $global_user->primary_market_ops == 'Indonesia' ? 'checked="checked"' : ''; ?> name="org_market" type="radio" value="Indonesia" > Indonesia</label>
			<label class="normal"><input <?php echo $global_user->primary_market_ops == 'Malaysia' ? 'checked="checked"' : ''; ?> name="org_market" type="radio" value="Malaysia" > Malaysia</label>
			<label class="normal"><input <?php echo $global_user->primary_market_ops == 'World' ? 'checked="checked"' : ''; ?> name="org_market" type="radio" value="World" > The rest of the world</label>
		</div>
	</li>

	<li>
		<label for="org_othermarket">
			Other market operations
			<small>Please separate country names with comas</small>
		</label>
		<div class="input">
			<textarea name="org_othermarket" rows="5" id="org_othermarket"><?php echo $global_user->other_market_ops; ?></textarea>
		</div>
	</li>

	<li>
		<label for="org_logo">
			Upload your organisation logo <span>*</span>
			<small>Your logo should be in PNG, JPG, or GIF format, and no more than 1.5MB in size</small>
		</label>
		<div class="input">
			<input onchange="copyfname(this.value, $(this))" type="file" name="org_logo" id="org_logo">
			<input rel="Organisation's logo" class="required" data-validation-engine="validate[required]" type="hidden" id="org_logo_div" name="org_logo_div" value="<?php echo !empty($global_user->logo) ? $global_user->logo : '' ?>" />
			<?php if (!empty($global_user->logo)): ?>
				<br />
				<img src="/<?php echo $global_user->logo ?>" />
			<?php endif; ?>
		</div>
	</li>

	<li>
		<label for="org_about">
			Tell us about your organisation
			<small>Please provide some background information on your organisation in no more than 250 words</small>
		</label>
		<div class="input">
			<textarea
				name="org_about"
				class="wysiwyg-advanced"
				rows="10"
				id="org_about"
			><?php echo $global_user->profile ?></textarea><br />
		</div>
	</li>
</ul>

</fieldset>

<script>
$(document).ready(function(){

	var step1ht = $("#step1").height();

	$('#show_category_dropdown').click(function(e){
		e.preventDefault();
		$('#category_dropdown').show();
		var ht2 = $('#category_dropdown').outerHeight();
		//var pheight = $("#form-slider").height();
		$("#form-slider").parent().height(step1ht+ht2);
	});

	$('#hide_category_dropdown').click(function(e){
		e.preventDefault();
		$('#category_dropdown').hide();
		//var pheight = $("#form-slider").height();
		$("#form-slider").parent().height(step1ht);
	});

	<?php
	// membership type
	if (empty($mshiptype) && !empty($global_user->type))
	{
		$mshiptype = $global_user->type;
	}

	switch($mshiptype)
	{
		case 'om_subcat':
		case 'Ordinary Members':
		?>
			//$("#primary-market").show();
			//$("#org_other_market").show();
			$('#q_om1, #q_om2, #q_om3, #q_am, #q_sca').show();
			<?php
			break;

		case 'am_subcat':
		case 'Affiliate Members':
		?>
			$("#primary-market").hide();
			$("#org_other_market").hide();
			$('#q_om1, #q_om2, #q_om3, #q_sca').hide();
			$('#q_am').show();
			<?php
			break;

		case 'sca_subcat':
		case 'Supply Chain Associate':
		?>
			$("#primary-market").hide();
			$("#org_other_market").hide();
			$('#q_sca').show();
			$('#q_om1, #q_om2, #q_om3, #q_am').hide();
			<?php
			break;
	}

if (empty($om_subcat) && !empty($global_user->category))
	$om_subcat = $global_user->category;

if (!empty($om_subcat)):
	// ordinary member categories
	switch($om_subcat)
	{
		case 'Oil Palm Growers':
		?>
			$("#subcategory div:first span").html("Select subcategory");
			document.memberApplication.org_subcategory.options.length = 0;
			document.memberApplication.org_subcategory.options[0]=new Option("Select subcategory","");
		<?php
			foreach($subcat_growers as $i=>$v)
			{
			?>
			document.memberApplication.org_subcategory.options[<?php echo ($i+1) ?>]=new Option("<?php echo $v ?>", "<?php echo $v ?>");
			<?php
				if ($v == $org_subcategory)
				{
					echo 'document.memberApplication.org_subcategory.options['.($i+1).'].selected=true;'.PHP_EOL;
					echo '$("#subcategory div:first span").html("'.$org_subcategory.'");'.PHP_EOL;
				}
			}
		?>
			$("#subcategory").show();
			$("#primary-market").show();
			$("#org_other_market").show();
		<?php
		break;

		case 'Consumer Goods Manufacturers':
		?>
			document.memberApplication.org_subcategory.options.length = 0;
			document.memberApplication.org_subcategory.options[0]=new Option("Select subcategory","");
		<?php
			foreach($subcat_others as $i=>$v)
			{
			?>
			document.memberApplication.org_subcategory.options[<?php echo ($i+1) ?>]=new Option("<?php echo $v ?>", "<?php echo $v ?>");
			<?php
				if ($v == $org_subcategory)
					echo 'document.memberApplication.org_subcategory.options['.($i+1).'].selected=true;'.PHP_EOL;
			}
		?>
			$("#subcategory div:first span").html("Select subcategory");
			$("#subcategory").show();
		<?
		break;
		case 'Palm Oil Processors and Traders':
		?>
			document.memberApplication.org_subcategory.options.length = 0;
			document.memberApplication.org_subcategory.options[0]=new Option("Select subcategory","");
		<?php
			foreach($subcat_popt as $i=>$v)
			{
			?>
			document.memberApplication.org_subcategory.options[<?php echo ($i+1) ?>]=new Option("<?php echo $v ?>", "<?php echo $v ?>");
			<?php
				if ($v == $org_subcategory)
					echo 'document.memberApplication.org_subcategory.options['.($i+1).'].selected=true;'.PHP_EOL;
			}
		?>
			$("#subcategory div:first span").html("Select subcategory");
			$("#subcategory").show();
		<?
		break;
	}
	// ordinary member categories ends
	?>
<?php endif ?>

});

function dropdowncat(v)
{
	var ht2 = 0;
	var ht3 = 0;

//	alert('v: '+v);
	switch (v)
	{
		case 'om_subcat':
			document.memberApplication.org_category.options.length = 0;
			document.memberApplication.org_category.options[0]=new Option("Select Category","");
			<?php foreach($categories['om'] as $k=>$v): ?>
			document.memberApplication.org_category.options[<?php echo $k+1 ?>]=new Option("<?php echo $v ?>","<?php echo $v ?>");
			<?php endforeach; ?>
			$("#subcategory").slideDown();
			$("#primary-market").slideDown();
//			ht2 = $("#primary-market > div").outerHeight();
//			$("#org_other_market").slideDown();
//			ht3 = $("#org_other_market > div").outerHeight();
			$('#q_sca').hide();
			$('#q_om1, #q_om2, #q_om3, #q_am').show();
			var pheight = $("#step1").height();
//			$("#form-slider").parent().height(pheight+ht2+ht3+50);
		break;

		case 'am_subcat':
			document.memberApplication.org_category.options.length = 0;
			document.memberApplication.org_category.options[0]=new Option("Select Category","");
			<?php foreach($categories['am'] as $k=>$v): ?>
			document.memberApplication.org_category.options[<?php echo $k+1 ?>]=new Option("<?php echo $v ?>","<?php echo $v ?>");
			<?php endforeach; ?>
			$("#subcategory").slideUp();
			$("#primary-market").slideUp();
			$("#org_other_market").slideUp();
			var pheight = $("#form-slider").height();
			if ($("#primary-market").css('display')=='block')
			{
				ht2 = $("#primary-market > div").outerHeight();
				ht3 = $("#org_other_market > div").outerHeight();
				$("#form-slider").parent().height(pheight-ht2-ht3+50);
			}
			$('#q_om1, #q_om2, #q_om3, #q_sca').hide();
			$('#q_am').show();
		break;

		case 'sca_subcat':
			document.memberApplication.org_category.options.length = 0;
			document.memberApplication.org_category.options[0]=new Option("Select Category","");
			<?php foreach($categories['sca'] as $k=>$v): ?>
			document.memberApplication.org_category.options[<?php echo $k+1 ?>]=new Option("<?php echo $v ?>","<?php echo $v ?>");
			<?php endforeach; ?>
			$("#subcategory").slideUp();
		 	$("#primary-market").slideUp();
			$("#org_other_market").slideUp();
			ht2 = $("#primary-market > div").outerHeight();
			ht3 = $("#org_other_market > div").outerHeight();
			var pheight = $("#form-slider").height();
			if ($("#primary-market").css('display')=='block')
			{
				ht2 = $("#primary-market > div").outerHeight();
				ht3 = $("#org_other_market > div").outerHeight();
				$("#form-slider").parent().height(pheight-ht2-ht3+50);
			}
			$('#q_sca').show();
			$('#q_om1, #q_om2, #q_om3, #q_am').hide();
		break;
	}
	document.memberApplication.org_category.options[0].selected=true;
	$("#membercategory div:first span").html("Select Category");
}

function dropdownlist(listindex)
{
	switch (listindex)
	{
 
		case "Oil Palm Growers":
			document.memberApplication.org_subcategory.options.length = 0;
			document.memberApplication.org_subcategory.options[0]=new Option("Select subcategory","");
			document.memberApplication.org_subcategory.options[1]=new Option("Smallholders","Smallholders");
			document.memberApplication.org_subcategory.options[2]=new Option("Small growers","Small growers");
			$("#subcategory div:first span").html("Select subcategory");
			$("#subcategory").show();
			$("#primary-market").show();
			var ht2 = $("#primary-market").outerHeight();
			$("#org_other_market").slideDown();
			ht3 = $("#org_other_market > div").outerHeight();
			var pheight = $("#form-slider").height();
			$("#form-slider").parent().height(pheight+ht2+ht3+50);
		break;
		case "Consumer Goods Manufacturers":
		case "Palm Oil Processors and Traders":
			document.memberApplication.org_subcategory.options.length = 0;
			document.memberApplication.org_subcategory.options[0]=new Option("Select subcategory","");
			document.memberApplication.org_subcategory.options[1]=new Option("Refinery, Edible oils and Food ingredients processors","Refinery, Edible oils and Food ingredients processors");
			document.memberApplication.org_subcategory.options[2]=new Option("Only Trading, Logistics and Distributions","Only Trading, Logistics and Distributions");
			document.memberApplication.org_subcategory.options[3]=new Option("Power, Energy and Bio-fuel","Power, Energy and Bio-fuel");
			document.memberApplication.org_subcategory.options[4]=new Option("Chemicals, Surfactants, and Non-Food ingredients processors","Chemicals, Surfactants, and Non-Food ingredients processors");
			document.memberApplication.org_subcategory.options[5]=new Option("Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)","Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)");
			$("#subcategory div:first span").html("Select subcategory");
			$("#subcategory").show();
/*
			$("#primary-market").show();
			var ht2 = $("#primary-market").outerHeight();
			var pheight = $("#form-slider").height();
			$("#form-slider").parent().height(pheight+ht2);
*/
		break;
		default:
			 if (document.memberApplication.org_subcategory != undefined)
			 {
				 document.memberApplication.org_subcategory.options.length = 0;
				 $("#subcategory").slideUp();
				 //$("#primary-market").slideUp();
			 }
		break;
	}
	return true;
}
</script>

