<fieldset>

<ul>

<?php if ($membersapp->type=='Ordinary Members'): ?>

<li class="input_row" id="q_om1" style="display:none;">
	<label for="question_1" class="notbold">
		How will your organisation promote the RSPO internally and to other stakeholders?
 <span>*</span>
	</label>
	<div class="input">
		<textarea class="required" rel="Brief description to promote RSPO internally and other stakeholders" data-validation-engine="validate[required]" rows="10" name="q1" id="question_1"><?php echo ($membersapp->q1 ? $membersapp->q1 : '')?></textarea>
	</div>
</li>

<?php //if ($om_subcat=='Oil Palm Growers'): ?>
<li class="input_row" id="q_om2" style="display:none;">
	<label for="question_2" class="notbold">
		Where relevant, what processes is the organisation establishing to engage with interested parties, for example to resolve conflict or to use sustainably produced palm oil?
 <span>*</span>
	</label>
	<div class="input">
		<textarea class="required" rel="Processes to engage with interested parties" data-validation-engine="validate[required]" rows="10" name="q2" id="question_2"><?php echo ($membersapp->q2 ? $membersapp->q2 : '') ?></textarea>
	</div>
</li>

<?php //if ($om_subcat=='Oil Palm Growers'): ?>
<li class="input_row" id="q_om3" style="display:none;">
	<label for="question_3" class="notbold">
		Where relevant, how will your organisation work towards implementing the RSPO Principles and Criteria or assessing supplier performance against these criteria?
 <span>*</span>
	</label>
	<div class="input">
		<textarea class="required" rel="Work towards implementing RSPO Principles and Criteria" data-validation-engine="validate[required]" rows="10" name="q3" id="question_3"><?php echo ($membersapp->q3 ? $membersapp->q3 : '') ?></textarea>
	</div>
</li>

<?php endif; // if ($membershiptype=='Oil Palm Growers') ?>

<li class="input_row" id="q_am" style="display:none;">
	<label for="question_4" class="notbold">
		Any other information that would support the application such as what your organisation hopes gain from joining the RSPO.
	</label>
	<div class="input">
		<textarea rows="10" name="q4" id="question_4"><?php echo ($membersapp->q4 ? $membersapp->q4 : '') ?></textarea>
	</div>
</li>

<?php if ($membersapp->type=='Supply Chain Associate' OR $membersapp->type=='Ordinary Members'): ?>
<li class="input_row" id="q_sca" style="display:block; margin-bottom: 15px;">
	<label for="question_5" class="notbold">
		Please state your annual usage of palm oil and palm derivatives in metric tonnes
	</label>
	<div class="input">
		<input type="text" value="<?php echo ($membersapp->q_usage ? $membersapp->q_usage : '') ?>" name="q_usage" id="question_5" />
	</div>
	<p>&nbsp;</p>
	<div class="clearboth"><br /></div>
</li>

<?php endif; // if ($membershiptype=='Oil Palm Growers') ?>

</ul>

</fieldset>
