<br />

<fieldset>
<legend>Primary nomination of representative</legend>
<ul>
<li>
	<label for="org_rep1_name" class="notbold">
		Full name <span>*</span>
	</label>
	<div class="input">
		<input class="required" rel="Primary nomination representative full name" data-validation-engine="validate[required]" type="text" name="name_p" id="org_rep1_name" value="<?php echo ($membersapp->name_p ? $membersapp->name_p : '')?>" />
	</div>
</li>

<li>
	<label for="org_rep1_position" class="notbold">
		Position <span>*</span>
	</label>
	<div class="input">
		<input class="required" rel="Primary nomination representative position" data-validation-engine="validate[required]" type="text" name="designation_p" id="org_rep1_position" value="<?php echo ($membersapp->designation_p ? $membersapp->designation_p : '')?>" />
	</div>
</li>

<li>
	<label for="org_rep1_phone" class="notbold">
		Telephone <span>*</span>
		<small>Include country code</small>
	</label>
	<div class="input">
		<input class="required" rel="Primary nomination representative phone number" data-validation-engine="validate[required]" type="text" name="telephone_p" id="org_rep1_phone" value="<?php echo ($membersapp->telephone_p ? $membersapp->telephone_p : '')?>" />
	</div>
</li>

<li>
	<label for="org_rep1_fax" class="notbold">
		Fax
		<small>Include country code</small>
	</label>
	<div class="input">
		<input type="text" name="fax_p" id="org_rep1_fax" value="<?php echo ($membersapp->fax_p ? $membersapp->fax_p : '')?>" />
	</div>
</li>

<li>
	<label for="org_rep1_email" class="notbold">
		Email <span>*</span>
	</label>
	<div class="input">
		<input class="email required" rel="Primary nomination representative email" data-validation-engine="validate[custom[notEqual[org_contact_email,org_email]]]" type="text" name="email_p" id="org_rep1_email" value="<?php echo ($membersapp->email_p ? $membersapp->email_p : '')?>" />
	</div>
</li>

</ul>

</fieldset>


<fieldset id="secondary_person">
<legend>Secondary nomination of representative</legend>
<ul>

<li>
	<label for="org_rep2_name" class="notbold">
		Full name <span>*</span>
	</label>
	<div class="input">
		<input class="required" rel="Secondary nomination representative full name" data-validation-engine="validate[required]" type="text" name="name_s" id="org_rep2_name" value="<?php echo ($membersapp->name_s ? $membersapp->name_s : '')?>" />
	</div>
</li>

<li>
	<label for="org_rep2_position" class="notbold">
		Position <span>*</span>
	</label>
	<div class="input">
		<input class="required" rel="Secondary nomination representative position" data-validation-engine="validate[required]" type="text" name="designation_s" id="org_rep2_position" value="<?php echo ($membersapp->designation_s ? $membersapp->designation_s : '')?>" />
	</div>
</li>

<li>
	<label for="org_rep2_phone" class="notbold">
		Telephone <span>*</span>
		<small>Include country code</small>
	</label>
	<div class="input">
		<input class="required" rel="Secondary nomination representative phone number" data-validation-engine="validate[required]" type="text" name="telephone_s" id="org_rep2_phone" value="<?php echo ($membersapp->telephone_s ? $membersapp->telephone_s : '')?>" />
	</div>
</li>

<li>
	<label for="org_rep2_fax" class="notbold">
		Fax
		<small>Include country code</small>
	</label>
	<div class="input">
		<input type="text" name="fax_s" id="org_rep2_fax" value="<?php echo ($membersapp->fax_s ? $membersapp->fax_s : '')?>" />
	</div>
</li>

<li>
	<label for="org_rep2_email" class="notbold">
		Email <span>*</span>
	</label>
	<div class="input">
		<input class="email required" rel="Secondary nomination representative email" data-validation-engine="validate[custom[notEqual[org_rep1_email,org_email]]]" type="text" name="email_s" id="org_rep2_email" value="<?php echo ($membersapp->email_s ? $membersapp->email_s : '')?>" />
	</div>
</li>

</ul>
</fieldset>


<fieldset id="contact_person">
<legend>Contact person</legend>
<ul>

<li>
	<label for="org_contact_name" class="notbold">
		Full name <span>*</span>
	</label>
	<div class="input">
		<input class="required" rel="Contact person full name" data-validation-engine="validate[required]" type="text" name="contact_person" id="org_contact_name" value="<?php echo ($membersapp->contact_person ? $membersapp->contact_person : '')?>" />
	</div>
</li>

<li>
	<label for="org_contact_position" class="notbold">
		Position <span>*</span>
	</label>
	<div class="input">
		<input class="required" rel="Contact person position" data-validation-engine="validate[required]" type="text" name="designation" id="org_contact_position" value="<?php echo ($membersapp->designation ? $membersapp->designation : '')?>" />
	</div>
</li>

<li>
	<label for="org_contact_phone" class="notbold">
		Telephone <span>*</span>
		<small>Include country code</small>
	</label>
	<div class="input">
		<input class="required" rel="Contact person phone number" data-validation-engine="validate[required]" type="text" name="contact_tel" id="org_contact_phone" value="<?php echo ($membersapp->contact_tel ? $membersapp->contact_tel : '')?>" />
	</div>
</li>

<li>
	<label for="org_contact_fax" class="notbold">
		Fax
		<small>Include country code</small>
	</label>
	<div class="input">
		<input type="text" name="contact_fax" id="org_contact_fax" value="<?php echo ($membersapp->contact_fax ? $membersapp->contact_fax : '')?>" />
	</div>
</li>

<li>
	<label for="org_contact_email" class="notbold">
		Email <span>*</span>
	</label>
	<div class="input">
		<input class="email required" rel="Contact person email" data-validation-engine="validate[funcCall[checkEmail]]" type="text" name="contact_email" id="org_contact_email" value="<?php echo ($membersapp->contact_email ? $membersapp->contact_email : '')?>" />
	</div>
</li>

</ul>
</fieldset>

<fieldset id="finance_person">
<legend>Finance contact for membership fee</legend>
<ul>
<li>
	<label for="org_finance_name" class="notbold">
		Full name <span>*</span>
	</label>
	<div class="input">
		<input class="required" rel="Finance contact person full name" data-validation-engine="validate[required]" type="text" name="name_f" id="org_finance_name" value="<?php echo ($membersapp->name_f ? $membersapp->name_f : '')?>" />
	</div>
</li>

<li>
	<label for="org_finance_position" class="notbold">
		Position <span>*</span>
	</label>
	<div class="input">
		<input class="required" rel="Finance contact person position" data-validation-engine="validate[required]" type="text" name="designation_f" id="org_finance_position" value="<?php echo ($membersapp->designation_f ? $membersapp->designation_f : '')?>" />
	</div>
</li>

<li>
	<label for="org_finance_phone" class="notbold">
		Telephone <span>*</span>
		<small>Include country code</small>
	</label>
	<div class="input">
		<input class="required" rel="Finance contact person phone number" data-validation-engine="validate[required]" type="text" name="telephone_f" id="org_finance_phone" value="<?php echo ($membersapp->telephone_f ? $membersapp->telephone_f : '')?>" />
	</div>
</li>

<li>
	<label for="org_finance_fax" class="notbold">
		Fax
		<small>Include country code</small>
	</label>
	<div class="input">
		<input type="text" name="fax_f" id="org_finance_fax" value="<?php echo ($membersapp->fax_f ? $membersapp->fax_f : '')?>" />
	</div>
</li>

<li>
	<label for="org_finance_email" class="notbold">
		Email <span>*</span>
	</label>
	<div class="input">
		<input class="email required" rel="Finance contact person email" data-validation-engine="validate[funcCall[checkEmail]]" type="text" name="email_f" id="org_finance_email" onBlur="$('#next').focus(); return false;" value="<?php echo ($membersapp->email_f ? $membersapp->email_f : '')?>" />
	</div>
</li>

</ul>
</fieldset>


