<style>
.input-group-addon {
	display: table-cell;
	z-index: 0;
}
input.mobile-number {
	width: 219px !important;
}
input.org_children {
	width: 250px;
	margin-top: 6px;
}

.remove_child {
	margin: 0;
	padding: 2px 5px;
}
.tlp-code {
	width: 105px !important;
}
.intl-tel-input {
	width: 105px !important;
}
.intl-tel-input .country-list {
	width: auto;
}
.intl-tel-input input, .intl-tel-input input[type="text"], .intl-tel-input input[type="tel"] {
    position: relative;
    z-index: 0;
    margin-top: 0px !important;
    margin-bottom: 0px !important;
    padding-left: 35px;
    margin-left: 0px;
}
.form_inputs .input > input {
    min-width: 210px !important;
    margin-left: -5px;
}
.intl-tel-input .selected-flag {
    z-index: 1;
    position: relative;
    width: auto;
    height: 100%;
    padding: 0px 0px 0px 8px;
}
.intl-tel-input .country-list {
    width: 250px;
}
</style>
<section class="title">
<?php if ($this->method == 'create'): ?>
	<h4><?php echo lang('members:create_title'); ?></h4>
<?php else: ?>
	<h4><?php echo sprintf(lang('members:edit_title'), $membersapp->name); ?> <?php echo $membersapp->formerly_known_as ? '| Formerly Known As: '.$membersapp->formerly_known_as : '' ?></h4>
<?php endif; ?>
</section>



<?php $top_text_form = '<p>Please fill in all the fields in the application form. Optional items are marked below.</p>'?>

<section class="item">
<div class="content">

<!--
<pre>
$membersapp:
<?php print_r($membersapp) ?>
</pre>
-->

<?php echo form_open_multipart(uri_string(), 'class="crud" name="memberApplication" id="memberApplication"'); ?>
<?php //echo form_open_multipart($this->uri->uri_string(), 'id="frmApply" name="frmApply"') ?>

<div class="tabs">

	<ul class="tab-menu">
		<li><a href="#status-tab"><span><?php echo lang('members:tab_status'); ?></span></a></li>
		<li><a href="#about-tab"><span><?php echo lang('members:tab_about'); ?></span></a></li>
		<li><a href="#contact-tab"><span><?php echo lang('members:tab_contact'); ?></span></a></li>
		<li><a href="#questions-tab"><span><?php echo lang('members:tab_questions'); ?></span></a></li>
		<li><a href="#documents-tab"><span><?php echo lang('members:tab_documents'); ?></span></a></li>
		<li><a href="#other-tab"><span>Other Info</span></a></li>
	</ul>

	<div class="form_inputs" id="status-tab">

		<fieldset>
			<ul>

				<li class="li_member_detail">
					<label for="approved_date">Applied Date</label>
					<div class="input" style="padding-top:9px;">
						<?php echo form_input('approved_date', $membersapp->applied_date ? date('Y-m-d', $membersapp->applied_date) : '', 'id="applied_date" class="datepicker"'); ?>
					</div>
				</li>

				<li>
					<label for="mstatus">Membership status</label>
					<div class="input" style="padding-top:9px;">

						<?php echo form_dropdown('status', $membership_status, $membersapp->status, 'onChange="displayExpiry(this.value);" id="mstatus"'); ?>
					</div>
				</li>

				<li id="li_expiry_date" style="display:<?php echo $membersapp->status=='Call for Comment' ? 'block' : 'none'; ?>;">
					<div style="display:block;float:left;margin-right:10px;">
						<label for="expiry_date">Call for Comment Start Date</label>
						<div class="input" style="padding-top:9px;">
							<?php echo form_input('public_comment_start', $membersapp->public_comment_start ? date('Y-m-d', $membersapp->public_comment_start) : '', 'class="datepicker"'); ?>
						</div>
					</div>

					<div style="display:block;float:left;">
						<label for="expiry_date">Call for Comment Deadline</label>
						<div class="input" style="padding-top:9px;">
							<?php echo form_input('expiry_date', $membersapp->expiry_date ? date('Y-m-d', $membersapp->expiry_date) : '', 'class="datepicker"'); ?>
						</div>
					</div>
					<div class="clearfix"></div>
				</li>

				<li class="li_member_detail" style="display:<?php echo $membersapp->status=='Approved' ? 'block' : 'none'; ?>;">
					<label for="approved_date">Approved Date</label>
					<div class="input" style="padding-top:9px;">
						<?php echo form_input('approved_date', $membersapp->approved_date ? date('Y-m-d', $membersapp->approved_date) : '', 'id="approved_date" class="datepicker"'); ?>
					</div>
				</li>

				<li class="li_member_detail" style="display:<?php echo $membersapp->status=='Approved' ? 'block' : 'none'; ?>;">
					<label for="member_num">Membership Number</label>
					<div class="input" style="padding-top:9px;">
						<?php echo form_input('member_num', $membersapp->member_num, 'id="member_num"'); ?>
					</div>
				</li>

				<li>
					<label for="remarks">Remarks</label>
					<div class="input" style="padding-top:9px;">
						<textarea name="remarks" id="remarks" class="wysiwyg-simple"><?php echo $membersapp->remarks ?></textarea>
					</div>
				</li>

				<li>
					<label for="admin_comment">Admin Comment</label>
					<div class="input" style="padding-top:9px;">
						<textarea name="admin_comment" id="admin_comment" class="wysiwyg-simple"><?php echo $membersapp->admin_comment ?></textarea>
					</div>
				</li>

				<li>
					<label>Account SF ID</label>
					<div class="input">
						<?php echo $membersapp->account_sf_id; ?>
					</div>
				</li>

				<li>
					<label>Application SF ID</label>
					<div class="input">
						<?php echo $membersapp->application_sf_id; ?>
					</div>
				</li>

			</ul>
		</fieldset>
	</div>

	<div class="form_inputs" id="about-tab">
	<br />

		<fieldset>
			<legend>ORGANISATION DETAIL</legend>

			<ul>

				<li>
					<label>Membership Category:</label>
					<div class="input"><?php echo form_dropdown('type', $types, $membersapp->type ? (!empty($types_reversed[$membersapp->type])?$types_reversed[$membersapp->type]:'') : '', 'onchange="dropdowncat(this.value);"') ?></div>

				</li>

				<li>
					<label for="category">Membership Sector:</label>
					<div class="input">

						<?php
						if ( !empty($membersapp->category) && !empty($types_reversed[$membersapp->type]) )
						{
							foreach($categories[$types_reversed[$membersapp->type]] as $mcc)
							{
								$mcat[$mcc] = $mcc;
							}
							echo form_dropdown('category', $mcat, $membersapp->category, 'onchange="dropdownlist(this.value);" id="category"');
						}
						else
						{
							echo form_dropdown('category', array(), $membersapp->category, 'onchange="dropdownlist(this.value);" id="category"');
						}
						?>
					</div>
				</li>

<?php if (!empty($membersapp->category) && array_key_exists($membersapp->category, $member_subcategories)): ?>
				<li>
					<label>Select the organisation's sub-sector?</label>
					<div class="input">

						<?php
							$subcats = array();
							$subcats = array(""=>"Please select");
							foreach($member_subcategories[$membersapp->category] as $ms)
							{
								$subcats[$ms] = $ms;
							}

							if ($membersapp->category=='Oil Palm Growers')
								$subcategory_required = '';
							elseif ($membersapp->category=='Consumer Goods Manufacturers' OR $membersapp->category=='Palm Oil Processors and Traders')
								$subcategory_required = 'required';
							echo form_dropdown('profession', $subcats, $membersapp->profession, 'class="selectpicker form-control '.$subcategory_required.'" id="profession"');
							echo form_error('profession') ? '<div class="alert alert-danger">'.form_error('profession').'</div>' : '';
						?>
					</div>
				<div id="sub_category_other_div" style="display:<?php echo ($membersapp->profession=='others' OR $membersapp->profession=='other' ) ? 'block' : 'none' ?>">
					<input type="text" style="width:220px;" name="sub_category_other" id="sub_category_other" value="<?php $membersapp->sub_category_other ?>" />
				</div>
				</li>
<?php else: ?>

			<li id="subcategory" style="display:<?php echo $membersapp->profession ? 'block' : 'none' ?>;">
			<?php if ($membersapp->category): ?>
				<script>$(document).ready(function(){ dropdownlist('<?php echo $membersapp->category; ?>') });</script>
			<?php endif; ?>
			<div>	
				<label for="profession">
					Select the organisation's sub-category?
				</label>
				<div class="input">
					<select name="profession" id="profession" class="fixedWidth">
						<option value="">Select subcategory</option>
					</select>
				</div>
				<div id="sub_category_other_div" style="display:<?php echo ($membersapp->profession=='others' OR $membersapp->profession=='other' ) ? 'block' : 'none' ?>">
					<input type="text" style="width:220px;" name="sub_category_other" id="sub_category_other" value="<?php $membersapp->sub_category_other ?>" />
				</div>
			</div>
			</li>

<?php endif; ?>

				<li>
					<label>Organisation's Name</label>
					<div class="input"><?php echo form_input('org_name', htmlspecialchars_decode($membersapp->name), 'class="form-control required"'); ?></div><br />
					<?php echo $membersapp->formerly_known_as ? 'Formerly known as: '.$membersapp->formerly_known_as : '' ?>
				</li>

				<li>
					<label>Are you a parent/subsidiary company?</label><br/>
					<?php
						$parent_companies = array(
							"" => "Please select",
							"yes" => "I am a parent company",
							"sub" => "I am a subsidiary company",
							"none" => "None of the above"
						);
					?>
					<div class="input"><?php echo form_dropdown('parent_company', $parent_companies, $membersapp->parent_company, 'class="selectpicker form-control required" id="parentCompany" onchange="displaychildfields(this.value);" title="Please select"'); ?></div>
				</li>

				<li id="parent_company_div" style="display:<?php echo $membersapp->parent_company == 'yes' ? 'block' : 'none' ?>;">
				<!-- <li id="parent_company_div" style="display:block;"> -->

					<label>Subsidiary company/companies <small>Click <b>Add more</b> if you have more than one subsidiary companies</small></label>

					<div class="input">

						<div id="childfields">

							<ul>
							<?php $org_children = unserialize($membersapp->sub_company); ?>
							<?php if (!empty($org_children) && $membersapp->parent_company == 'yes'): ?>
								<?php foreach($org_children as $org_child): ?>
									<?php if ($org_child['name']): ?>
										<li>
											<!-- <div class="input-group no-margin"> -->
												<input class="org_children" type="text" name="sub_company[name][]" value="<?php echo htmlspecialchars_decode($org_child['name']); ?>" />
												<input rel="" class="org_children_id" type="hidden" name="sub_company[id][]" value="<?php echo !empty($org_child['id'])?$org_child['id']:''; ?>" />
												<a href="#" tabindex="-1" class="btn small red remove_child"> &nbsp;x&nbsp; </a>
											<!-- </div> -->
										</li>
									<?php endif; ?>
								<?php endforeach; ?>
							<?php else: ?>
								<li>
									<!-- <div class="input-group no-margin"> -->
										<input class="org_children" type="text" name="sub_company[name][]" value="" />
										<input class="org_children_id" type="hidden" name="sub_company[id][]" value="" />
										<a href="#" tabindex="-1" class="btn small red remove_child"> &nbsp;x&nbsp; </a>
									<!-- </div> -->
								</li>
							<?php endif; ?>
							</ul>

						</div> <!-- #childfields -->
						<div><a class="add-more" href="#" onclick="add_more_child(); return false;">Add more</a></div>

					</div> <!-- .input -->

				</li>

				<li id="sub_company_div" style="display:<?php echo $membersapp->parent_company == 'sub' ? 'block' : 'none' ?>;">
				<!-- <li id="sub_company_div"> -->
					<label>Parent Company</label>
					<div class="input">
						<?php if (!empty($org_children) && $membersapp->parent_company == 'sub'): ?>
							<?php foreach($org_children as $org_child): ?>
								<?php if ($org_child['name']): ?>
								<input type="text" class="org_children form-control" name="sub_company[name][]" value="<?php echo htmlspecialchars_decode($org_child['name']); ?>">
								<input class="org_children_id" type="hidden" name="sub_company[id][]" value="<?php echo !empty($org_child['id'])?$org_child['id']:''; ?>" />
	
								<?php endif; ?>
							<?php endforeach; ?>
						<?php else: ?>
	
							<input type="text" class="org_children form-control" name="sub_company[name][]" value="">
							<input class="org_children_id" type="hidden" name="sub_company[id][]" value="" />
	
						<?php endif; ?>
					</div>
				</li>

						<script>
							function displaychildfields(v)
							{

								if (v=='yes')
								{
									$('#parent_company_div').fadeIn('fast');
									$('#sub_company_div').fadeOut('fast', function(){
										$('input', this).each(function(){
											$(this).val('');
										});
									});
								}
								else if (v=='sub')
								{
									$('#sub_company_div').fadeIn('fast');
									$('#parent_company_div').fadeOut('fast', function(){
										$('input', this).each(function(){
											$(this).val('');
										});
									});
								}
								else
								{
									$('#parent_company_div').fadeOut('fast', function(){
										$('input', this).each(function(){
											$(this).val('');
										});
									});
									$('#sub_company_div').fadeOut('fast', function(){
										$('input', this).each(function(){
											$(this).val('');
										});
									});
								}
							}
							function add_more_child()
							{
								var newfield = $("#tocopy").html();
								$("#childfields").append(newfield);
								var ht2 = $("#tocopy").height();
								var pheight = $("#form-slider").parent().height();
								var pheight2 = $("#step1").height();
								$("#form-slider").parent().height(pheight2+ht2);
								return false;
							}
						</script>

				<li>
					<label>Address</label>
					<div class="input"><?php echo form_input('address', htmlspecialchars_decode($membersapp->address), 'class="form-control required"') ?></div>
					<?php //echo form_error('address') ? '<div class="alert alert-danger">'.form_error('address').'</div>' : ''; ?>
					<!-- <input type="text" class="form-control" name="address" value=""> -->
				</li>
				
						<li>
							<label>City</label>
							<div class="input"><?php echo form_input('address_city', htmlspecialchars_decode($membersapp->address_city), 'class="form-control required"') ?></div>
							<?php //echo form_error('address_city') ? '<div class="alert alert-danger">'.form_error('address_city').'</div>' : ''; ?>
							<!-- <input type="text" class="form-control" name="address_city"> -->
						</li>

						<li>
							<label>State/Province</label>
							<div class="input"><?php echo form_input('address_state', htmlspecialchars_decode($membersapp->address_state), 'class="form-control required"') ?></div>
							<?php //echo form_error('address_state') ? '<div class="alert alert-danger">'.form_error('address_state').'</div>' : ''; ?>
							<!-- <input type="text" class="form-control" name="address_state"> -->
						</li>
				
						<li>
							<label>Country</label>
							<div class="input">
								<?php echo form_dropdown('country', $country_arrays, $membersapp->country ) ?>
							</div>
						</li>

						<li>
							<label>ZIP/Post code</label>
							<div class="input"><?php echo form_input('address_zip', htmlspecialchars_decode($membersapp->address_zip), 'class="form-control required"') ?></div>
							<?php //echo form_error('address_zip') ? '<div class="alert alert-danger">'.form_error('address_zip').'</div>' : ''; ?>
							<!-- <input type="text" class="form-control" name="address_zip"> -->
						</li>
				
				<li>
					<label>Telephone</label>
					<div class="input">
						<?php //echo form_input('code_telephone', $membersapp->code_telephone,'class="mobile-number tlp-code required"') ?>
						<?php echo form_input('telephone', $membersapp->telephone, 'class="mobile-number tlp-code form-control required"') ?>
					</div>
						<?php //echo form_error('telephone') ? '<div class="alert alert-danger">'.form_error('telephone').'</div>' : ''; ?>
				</li>
				
				<li>
					<label>Fax <small>(Optional)</small></label>
					<div class="input">
						<!-- <input class="mobile-number tlp-code" type="tel" name="code_telephone"> -->
						<?php //echo form_input('code_fax', $membersapp->code_fax, 'class="mobile-number tlp-code"') ?>
						<?php echo form_input('fax', $membersapp->fax, 'class="mobile-number tlp-code"') ?>
					</div>
				</li>
				
				<li>
					<label>Email</label>
					<div class="input"><?php echo form_input('email', $membersapp->email, 'class="form-control required"') ?></div>
				</li>
				
				<li>
					<label>Website <small>(Optional)</small></label>
					<div class="input"><?php echo form_input('website', $membersapp->website, 'class="form-control"') ?></div>
				</li>
				
				<li>
					<label>Registration Number <small>(please use the full legal entity number)</small></label>
					<div class="input"><?php echo form_input('registration_number', htmlspecialchars_decode($membersapp->registration_number), 'class="form-control required"') ?></div>
				</li>

				<?php
				$display_primary_market = 'none';
				if ($membersapp->category == 'Oil Palm Growers')
				{
					$display_primary_market = 'block';
				}
				?>
				<li id="primary_market" class="opg" style="display:<?php echo $display_primary_market ?>">
					<label>Primary Market Operations</label>
					<div class="input">
						<label class="normal"><?php echo form_radio('primary_market_ops', 'Indonesia', $membersapp->primary_market_ops == 'Indonesia', 'class="form-control"') ?> <span>Indonesia</span></label>
						<label class="normal"><?php echo form_radio('primary_market_ops', 'Malaysia', $membersapp->primary_market_ops == 'Malaysia', 'class="form-control"') ?> <span>Malaysia</span></label>
						<label class="normal"><?php echo form_radio('primary_market_ops', 'Rest of the World', $membersapp->primary_market_ops == 'Rest of the World', 'class="form-control"') ?> <span>Rest of the World</span></label>
					</div>
				</li>

				<li id="other_market" class="opg" style="display:<?php echo $display_primary_market ?>">
					<label>Other Market Operations <small>(Please separate country names with comas)</small></label> 
					<textarea name="other_market_ops" class="form-control" rows="5" style="height:100px;" id="other_market_ops"><?php echo htmlspecialchars_decode($membersapp->other_market_ops); ?></textarea>
				</li>

				<li>
					<label>Organisation's Logo<small>(PNG, JPG, or GIF and no more than 1.5MB)</small></label>
					<div class="input">
						<input type="file" name="logo" onchange="copyfname(this.value, $(this), 'image')">
						<input type="hidden" />
						<?php if (!empty($membersapp->logo)): ?>
							<?php echo form_hidden('upload_logo', $membersapp->logo); ?>
							<div class="clear"></div>
							<label class="inline">Filename: </label> <?php echo $membersapp->logo; ?>
							<div class="clear"></div>
							<?php

								if ( $membersapp->logo )
								{
									if (strstr($membersapp->logo, '/sites/default/files/'))
									{
										echo '<img width="200" class="img-responsive" src="http://www.rspo.org'.$membersapp->logo.'" />'.PHP_EOL;
									}
									elseif(strstr($membersapp->logo, 'ma/logo/'))
									{
										echo '<img width="200" class="img-responsive" src="http://www.rspo.org/'.$membersapp->logo.'" />'.PHP_EOL;
									}
									else
									{
										echo '<img width="200" class="img-responsive" src="'.site_url(UPLOAD_PATH).'/memberlogos/'.$membersapp->logo.'" />'.PHP_EOL;
									}
								}
								else
								{ ?>
									{{theme:image file="generic-member.jpg"}}
								<? }

							?>
						<?php endif; ?>
					</div>
					
					<?php //echo form_error('upload_logo') ? '<div class="alert alert-danger">'.form_error('upload_logo').'</div>' : ''; ?>

				</li>
				
				<li>
					<label class="mb-0">Description</label>
					
					<textarea class="form-control" rows="5" name="profile" placeholder="Please provide some background information on your organisation in less than 250 words" style="height:200px;"><?php echo htmlspecialchars_decode(strip_tags(str_ireplace(array("<br>","<br/>","<br />"), "\n", $membersapp->profile))); ?></textarea>
					<?php echo form_error('profile') ? '<div class="alert alert-danger">'.form_error('profile').'</div>' : ''; ?>
				</li>

			</ul>

		</fieldset>
	</div>

<div class="form_inputs" id="contact-tab">

<br />	
<fieldset>
	<legend>PRIMARY NOMINATION OF REPRESENTATIVE <small>SF ID: <?php echo $membersapp->primary_sf_id ? $membersapp->primary_sf_id : '--' ?></legend>
</h4>
	<ul>
					<li>
						<div class="one_third">
							<label>First Name</label>
							<div class="input"><?php echo form_input('name_p', htmlspecialchars_decode($membersapp->name_p), 'class="form-control required"') ?></div>
						</div>
						<div class="one_third">
							<label>Last Name</label>
							<div class="input"><?php echo form_input('name_last_p', htmlspecialchars_decode($membersapp->name_last_p), 'class="form-control required"') ?></div>
						</div>
						<div class="clearfix"></div>
					</li>
					<li>
						<label>Position</label>
						<div class="input"><?php echo form_input('designation_p', htmlspecialchars_decode($membersapp->designation_p), 'class="form-control required" rel="designation_s"') ?></div>
					</li>
					<li>
						<label>Telephone</label>
						<div class="input">
							<?php //echo form_input('code_tel_p', $membersapp->code_tel_p, 'class="mobile-number tlp-code"') ?>
							<?php echo form_input('telephone_p', $membersapp->telephone_p, 'class="mobile-number tlp-code form-control required"') ?>
						</div>
					</li>
					<li>
						<label>Fax</label>
						<div class="input">
						<?php //echo form_input('code_fax_p', $membersapp->code_fax_p, 'class="mobile-number tlp-code"') ?>
						<?php echo form_input('fax_p', $membersapp->fax_p, 'class="form-control mobile-number tlp-code"') ?>
						</div>
					</li>
					<li>
						<label>Email</label>
							<div class="input"><?php echo form_input('email_p', $membersapp->email_p, 'class="form-control checkuse" rel="email_s"') ?></div>
					</li>
					<li>
						<label>Country</label>
						<div class="input"><?php echo $membersapp->country_p?$membersapp->country_p:'--' ?></div>
					</li>

	</ul>
</fieldset>

<fieldset>
	<legend>SECONDARY NOMINATION OF REPRESENTATIVE <small>SF ID: <?php echo $membersapp->secondary_sf_id ? $membersapp->secondary_sf_id : '--' ?></legend>

	<ul>
					<li>
						<div class="one_third">
							<label>First Name</label>
							<div class="input"><?php echo form_input('name_s', htmlspecialchars_decode($membersapp->name_s), 'class="form-control required"') ?></div>
						</div>
						<div class="one_third">
							<label>Last Name</label>
							<div class="input"><?php echo form_input('name_last_s', htmlspecialchars_decode($membersapp->name_last_s), 'class="form-control required"') ?></div>
						</div>
						<div class="clearfix"></div>
					</li>
					<li>
						<label>Position</label>
						<div class="input"><?php echo form_input('designation_s', htmlspecialchars_decode($membersapp->designation_s), 'class="form-control required" rel="designation_p"') ?></div>
					</li>
					<li>
						<label>Telephone</label>
						<div class="input">
							<?php //echo form_input('code_tel_s', $membersapp->code_tel_s, 'class="mobile-number tlp-code"') ?>
							<?php echo form_input('telephone_s', $membersapp->telephone_s, 'class="mobile-number tlp-code form-control required"') ?>
						</div>
						<?php //cho form_error('telephone_s') ? '<div class="alert alert-danger">'.form_error('telephone_s').'</div>' : ''; ?>
					</li>
					<li>
						<label>Fax</label>
						<div class="input">
							<?php //echo form_input('code_fax_s', $membersapp->code_fax_s, 'class="mobile-number tlp-code"') ?>
							<?php echo form_input('fax_s', $membersapp->fax_s, 'class="mobile-number tlp-code form-control"') ?>
						</div>
					</li>
					<li>
						<label>Email</label>
							<div class="input"><?php echo form_input('email_s', $membersapp->email_s, 'class="form-control checkuse" rel="email_p"') ?></div>
					</li>
					<li>
						<label>Country</label>
						<div class="input"><?php echo $membersapp->country_s?$membersapp->country_s:'--' ?></div>
					</li>
	</ul>
</fieldset>

<fieldset>

	<legend>CONTACT PERSON OF REPRESENTATIVE <small>SF ID: <?php echo $membersapp->contact_sf_id ? $membersapp->contact_sf_id : '--' ?></legend>
				
	<ul>

				<li>
					<div class="one_third">
						<label>First Name</label>
						<div class="input"><?php echo form_input('contact_person', htmlspecialchars_decode($membersapp->contact_person), 'class="form-control required"') ?></div>
					</div>
					<div class="one_third">
						<label>Last Name</label>
						<div class="input"><?php echo form_input('contact_lname', htmlspecialchars_decode($membersapp->contact_lname), 'class="form-control required"') ?></div>
					</div>
					<div class="clearfix"></div>
				</li>
				<li>
					<label>Position</label>
					<div class="input"><?php echo form_input('designation', htmlspecialchars_decode($membersapp->designation), 'class="form-control required"') ?></div>
					<?php //echo form_error('designation') ? '<div class="alert alert-danger">'.form_error('designation').'</div>' : ''; ?>
				</li>
				<li>
					<label>Telephone</label>
					<div class="input">
						<?php //echo form_input('code_contact_tel', $membersapp->code_contact_tel, 'class="mobile-number tlp-code"') ?>
						<?php echo form_input('contact_tel', $membersapp->contact_tel, 'class="mobile-number tlp-code form-control required"') ?>
					</div>
					<?php //echo form_error('contact_tel') ? '<div class="alert alert-danger">'.form_error('contact_tel').'</div>' : ''; ?>
				</li>
				<li>
					<label>Fax</label><br/><i>(Optional)</i> 
					<div class="input">
						<?php //echo form_input('code_contact_fax', $membersapp->code_contact_fax, 'class="mobile-number tlp-code"') ?>
						<?php echo form_input('contact_fax', $membersapp->contact_fax, 'class="mobile-number tlp-code form-control"') ?>
					</div>
				</li>
				<li>
					<label>Email</label>
					<div class="input"><?php echo form_input('contact_email', $membersapp->contact_email, 'class="form-control required"') ?></div>
						<?php //echo form_error('contact_email') ? '<div class="alert alert-danger">'.form_error('contact_email').'</div>' : ''; ?>
				</li>
					<li>
						<label>Country</label>
						<div class="input"><?php echo $membersapp->country_c?$membersapp->country_c:'--' ?></div>
					</li>
	</ul>
</fieldset>


<fieldset>

	<legend>FINANCE CONTACT FOR MEMBERSHIP FEE <small>SF ID: <?php echo $membersapp->finance_sf_id ? $membersapp->finance_sf_id : '--' ?></legend>

	<ul>				
				<li>
					<div class="one_third">
						<label>First Name</label>
						<div class="input"><?php echo form_input('name_f', htmlspecialchars_decode($membersapp->name_f), 'class="form-control required"') ?></div>
					</div>
					<div class="one_third">
						<label>Last Name</label>
						<div class="input"><?php echo form_input('name_last_f', htmlspecialchars_decode($membersapp->name_last_f), 'class="form-control required"') ?></div>
					</div>
					<div class="clearfix"></div>
				</li>
				<li>
					<label>Position</label>
					<div class="input"><?php echo form_input('designation_f', htmlspecialchars_decode($membersapp->designation_f), 'class="form-control required"') ?></div>
				</li>
				<li>
					<label>Telephone</label>
					<div class="input">
						<?php //echo form_input('code_tel_f', $membersapp->code_tel_f, 'class="mobile-number tlp-code"') ?>
						<?php echo form_input('telephone_f', $membersapp->telephone_f, 'class="mobile-number tlp-code form-control required"') ?>
					</div>
				</li>
				<li>
					<label>Fax</label><br/><i>(Optional)</i> 
					<div class="input">
						<?php //echo form_input('code_fax_f', $membersapp->code_fax_f, 'class="mobile-number tlp-code"') ?>
						<?php echo form_input('fax_f', $membersapp->fax_f, 'class="mobile-number tlp-code form-control"') ?>
					</div>
				</li>
				<li>
					<label>Email</label>
					<div class="input"><?php echo form_input('email_f', $membersapp->email_f, 'class="form-control required"') ?></div>
				</li>
					<li>
						<label>Country</label>
						<div class="input"><?php echo $membersapp->country_f?$membersapp->country_f:'--' ?></div>
					</li>
	</ul>	

</fieldset>
</div>

<div class="form_inputs" id="questions-tab">
<br />	
<fieldset>

	<legend>QUESTIONS</legend>

	<ul>				

				<?php if ($membersapp->type == 'Affiliate Members'): ?>

					<li id="q_am">
						<label class="mb-0">Any other information that would support the application such as what your organisation hopes gain from joining the RSPO. </label>
						<br />
						<div class="input">
						<textarea class="form-control required" rows="5" name="q4" placeholder="" style="height:200px;"><?php echo htmlspecialchars_decode($membersapp->q4) ?></textarea>
						</div>
					</li>

					<li id="q_om1" style="display:none;">
						<label class="mb-0">How will your organisation promote the RSPO internally and to other stakeholders?</label>
						<textarea class="form-control required" rows="5" name="q1" placeholder="" style="height:200px;"></textarea>
					</li>

					<li id="q_om2" style="display:none;">
						<label class="mb-0">Where relevant, what processes is the organisation establishing to engage with interested parties, for example to resolve conflict or to use sustainably produced palm oil? </label>
						<textarea class="form-control required" rows="5" name="q2" placeholder="" style="height:200px;"></textarea>
					</li>

					<li id="q_om3" style="display:none;">
						<label class="mb-0">Where relevant, how will your organisation work towards implementing the RSPO Principles and Criteria or assessing supplier performance against these criteria?</label>
						<textarea class="form-control required" rows="5" name="q3" placeholder="" style="height:200px;"></textarea>
					</li>

					<li id="q_sca" style="display:none;">
						<label>Please state your annual usage of palm oil and palm derivatives in metric tonnes</label>
						<input type="text" class="form-control required" name="q_usage" value="">
					</li>

				<?php elseif ($membersapp->type && $membersapp->type<>'Supply Chain Associates' && $membersapp->category<>'Organisation'): ?>

<!--
					<li id="q_am">
						<label class="mb-0">Any other information that would support the application such as what your organisation hopes gain from joining the RSPO. </label>
						<br />
						<div class="input">
						<textarea class="form-control required" rows="5" name="q4" placeholder="" style="height:200px;"></textarea>
						</div>
					</li>
-->

					<li id="q_om1">
						<label class="mb-0">How will your organisation promote the RSPO internally and to other stakeholders?</label>
						<textarea class="form-control required" rows="5" name="q1" placeholder="" style="height:200px;"><?php echo htmlspecialchars_decode($membersapp->q1) ?></textarea>
					</li>

					<li id="q_om2">
						<label class="mb-0">Where relevant, what processes is the organisation establishing to engage with interested parties, for example to resolve conflict or to use sustainably produced palm oil? </label>
						<textarea class="form-control required" rows="5" name="q2" placeholder="" style="height:200px;"><?php echo htmlspecialchars_decode($membersapp->q2) ?></textarea>
					</li>

					<li id="q_om3">
						<label class="mb-0">Where relevant, how will your organisation work towards implementing the RSPO Principles and Criteria or assessing supplier performance against these criteria?</label>
						<textarea class="form-control required" rows="5" name="q3" placeholder="" style="height:200px;"><?php echo htmlspecialchars_decode($membersapp->q3) ?></textarea>
					</li>

					<li id="q_om4">
						<label class="mb-0">Any other information that would support the application such as what your organisation hopes gain from joining the RSPO. </label>
						<textarea class="form-control required" rows="5" name="q4" placeholder="" style="height:200px;"><?php echo htmlspecialchars_decode($membersapp->q4) ?></textarea>
					</li>

					<li id="q_sca" style="display:none;">
						<label>Please state your annual usage of palm oil and palm derivatives in metric tonnes</label>
						<input type="text" class="form-control required" name="q_usage" value="">
					</li>

				<?php elseif ($membersapp->type && $membersapp->type<>'Ordinary Members' AND $membersapp->type<>'Affiliate Members'): ?>

<!--
					<li id="q_am" style="display:none;">
						<label class="mb-0">Any other information that would support the application such as what your organisation hopes gain from joining the RSPO. </label>
						<br />
						<div class="input">
						<textarea class="form-control required" rows="5" name="q4" placeholder="" style="height:200px;"></textarea>
						</div>
					</li>
-->

					<li id="q_om1" style="display:none;">
						<label class="mb-0">How will your organisation promote the RSPO internally and to other stakeholders?</label>
						<textarea class="form-control required" rows="5" name="q1" placeholder="" style="height:200px;"></textarea>
					</li>

					<li id="q_om2" style="display:none;">
						<label class="mb-0">Where relevant, what processes is the organisation establishing to engage with interested parties, for example to resolve conflict or to use sustainably produced palm oil? </label>
						<textarea class="form-control required" rows="5" name="q2" placeholder="" style="height:200px;"></textarea>
					</li>

					<li id="q_om3" style="display:none;">
						<label class="mb-0">Where relevant, how will your organisation work towards implementing the RSPO Principles and Criteria or assessing supplier performance against these criteria?</label>
						<textarea class="form-control required" rows="5" name="q3" placeholder="" style="height:200px;"></textarea>
					</li>

					<li id="q_om4" style="display:none;">
						<label class="mb-0">Any other information that would support the application such as what your organisation hopes gain from joining the RSPO. </label>
						<textarea class="form-control required" rows="5" name="q4" placeholder="" style="height:200px;"></textarea>
					</li>

					<li id="q_sca">
						<label>Please state your annual usage of palm oil and palm derivatives in metric tonnes</label>
						<input type="text" class="form-control required" name="q_usage" value="<?php echo $membersapp->q_usage; ?>">
					</li>

				<?php else: ?>

<!--
					<li id="q_am" style="display:none;">
						<label class="mb-0">Any other information that would support the application such as what your organisation hopes gain from joining the RSPO. </label>
						<br />
						<div class="input">
						<textarea class="form-control required" rows="5" name="q4" placeholder="" style="height:200px;"></textarea>
						</div>
					</li>
-->

					<li id="q_om1" style="display:none;">
						<label class="mb-0">How will your organisation promote the RSPO internally and to other stakeholders?</label>
						<textarea class="form-control required" rows="5" name="q1" placeholder="" style="height:200px;"></textarea>
					</li>

					<li id="q_om2" style="display:none;">
						<label class="mb-0">Where relevant, what processes is the organisation establishing to engage with interested parties, for example to resolve conflict or to use sustainably produced palm oil? </label>
						<textarea class="form-control required" rows="5" name="q2" placeholder="" style="height:200px;"></textarea>
					</li>

					<li id="q_om3" style="display:none;">
						<label class="mb-0">Where relevant, how will your organisation work towards implementing the RSPO Principles and Criteria or assessing supplier performance against these criteria?</label>
						<textarea class="form-control required" rows="5" name="q3" placeholder="" style="height:200px;"></textarea>
					</li>

					<li id="q_om4" style="display:none;">
						<label class="mb-0">Any other information that would support the application such as what your organisation hopes gain from joining the RSPO. </label>
						<textarea class="form-control required" rows="5" name="q4" placeholder="" style="height:200px;"></textarea>
					</li>

					<li id="q_sca" style="display:none;">
						<label>Please state your annual usage of palm oil and palm derivatives in metric tonnes</label>
						<input type="text" class="form-control required" name="q_usage" value="">
					</li>

				<?php endif; ?>
	</ul>
</fieldset>
</div>

<div class="form_inputs" id="documents-tab">
<br />	
<fieldset>

	<legend>SUPPORTING DETAIL</legend>
					
	<ul>
		<li>
			<h3 class="subsection-heading">DOCUMENTS</h3>

			<div class="form-group" id="org_certificate_fields">

				<p style="font-size:14px;">For all applicants - attach a copy of the certificate of incorporation of your organisation</p>

				<div id="sca_add_docs" style="display:<?php echo $membersapp->type == 'Supply Chain Associate' ? 'block' : 'none' ?>;">

					<p>Supply Chain Associate:</p>

					<ul class="normal">
								<?php if ($membersapp->category == 'Supply Chain Group Manager'): ?>
									Please attach documents to proof the legal and/or contractual relationship between each member and the Supply Chain Group Manager.
								<?php else: ?>
									Please attach a signed copy of the RSPO Agreement – <a href="/file/downloads/SCA%20Agreement.pdf" target="_blank" >Click here to download</a>. This should be at the bottom of the final page & accompanied by your organisation’s logo/stamp.
								<?php endif; ?>
					</ul>
				</div>

				<input type="file" name="file_certificates[]" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">
					  
				<input id="org_cert_1" rel="Copy of the certificate of incorporation of your organisation" data-validation-engine="validate[required]" type="hidden" name="div_files_cert[]" value="" />

				<div id="more_certificates" style="display:none;"></div>
				<br />
				<a href="#" id="add_more_certs">Add more file</a>
	
				<div class="hidden" style="display:none;">
					<div id="div_more_certificates"> 
						<input type="file" name="file_certificates[]" class="required" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">
						
						<input id="org_cert_1" rel="Copy of the certificate of incorporation of your organisation" data-validation-engine="validate[required]" type="hidden" name="div_files_cert[]" value="" />
					</div>
				</div>

				<?php if (!empty($membersapp->file_certificates)): ?>

					<?php echo form_hidden('uploaded_files_cert', $membersapp->file_certificates); ?>
					<?php echo form_hidden('uploaded_files_cert1', $membersapp->file_certificates); ?>

					<br />
					<div class="clearfix"><br /></div>

					<label>Current file(s)</label>
					<div class="clearfix"><br /></div>

					<?php $upfiles_cert = explode(',', $membersapp->file_certificates); ?>
					  
					<div class="one_half">

						<table class="table table-striped table-supplychain" style="border:1px solid #ddd;">
							<thead>
								<tr>
								   <th style="width:10%;">Delete</th>
								   <th>Filename</th>
								</tr>
							</thead>

							<tbody>
								<?php foreach($upfiles_cert as $f): ?>
								<?php if ($f): ?>
								<tr>
									<td style="padding-left:28px; padding-top:0px; padding-bottom:0px;">
										<input type="checkbox" name="remove_uploaded_cert[]" value="<?php echo $f; ?>" style="margin-top:6px;"/>
									</td>
									<td style="vertical-align:middle; padding-top:0px; padding-bottom:0px;">
									<?php
										if (strrpos($f, '/'))
										{
											$fc = substr(strrchr($f, "/"), 1);
											$fc_url = site_url($f);
										}
										else
										{
											$fc = $f;
											$fc_url = site_url(UPLOAD_PATH . 'memberlogos/'.$f);
										}
									?>
										<a href="<?php echo $fc_url; ?>" target="_blank"><?php echo $fc; ?></a>
									</td>
								</tr>
								<?php endif; ?>
								<?php endforeach; ?>
							</tbody>
						</table><br />
						<p><i>Check the delete box and click save to delete your uploaded document(s)</i></p>

					</div>
					<div class="clearfix"></div>

				<?php else: ?>

					<div class="clearfix"><br /></div>

				<?php endif; ?>

			</div> <!-- // #org_certificate_fields -->
					
					
			<?php
				$additional_docs = false;
				if ($membersapp->category == 'Oil Palm Growers' && ($membersapp->profession == 1 OR $membersapp->profession == 0) )
					$additional_docs = true;
			?>

			<div id="additional_docs" style="display:<?php echo $additional_docs ? 'block' : 'none' ?>">
				<hr />

						Provide some additional information/documents such as:
						<ul class="normal">
							<li>Organisation status (corporate and ownership structure).</li>
							<li>Disclosure of plans to implement the RSPO Principles and Criteria (P&C).</li>
							<li>Disclosure of existing field practices and policies of Corporate Social Responsibility (CSR)/ sustainability policy.</li>
							<li>Estate location and concession maps in KML format (including for subsidiary if any).</li>
							<li>Additional information such as legally set aside area (eg. riparian, hill slope, deep peat etc.) and settlements within their concession (if any).</li>
						</ul>
						<br />

				<div id="more_file_additionals">
					<input type="file" name="file_additionals[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')"  class="required filestyle">	
					<input data-validation-engine="validate[required]" type="hidden" name="div_file_additionals[]" value=""/>
				</div>			
				<a href="#" id="add_file_additionals">Add more file</a>

				<div class="clearfix"><br /></div>

				<!-- add more file -->
				<div style="display:none;">
					<div id="div_file_additionals">
						<input type="file" name="file_additionals[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')"  class="required">
						<input data-validation-engine="validate[required]" type="hidden" name="div_file_additionals[]" value=""/>
					</div>
				</div>

				<?php if (!empty($membersapp->file_additionals)): ?>

					<?php echo form_hidden('uploaded_file_additionals', $membersapp->file_additionals); ?>

					<label>Current file(s)</label>
					<div class="clearfix"><br /></div>

					<?php $upfiles_cert = explode(',', $membersapp->file_additionals); ?>
						<div class="one_half">
							<table class="table table-striped table-supplychain" style="border:1px solid #ddd;">
								<thead>
									<tr>
										<th style="width:10%;">Delete</th>
										<th>Filename</th>
									</tr>
								</thead>
								<tbody>
								<?php foreach($upfiles_cert as $f): ?>
									<?php if ($f): ?>
									<?php
										if (strrpos($f, '/'))
										{
											$fc = substr(strrchr($f, "/"), 1);
											$fc_url = site_url($f);
										}
										else
										{
											$fc = $f;
											$fc_url = site_url(UPLOAD_PATH . 'memberlogos/'.$f);
										}
									?>
									<tr>
										<td style="padding-left:28px; padding-top:0px; padding-bottom:0px;">
											<input type="checkbox" name="remove_uploaded_additionals[]" value="<?php echo $f; ?>" style="margin-top:6px;"/>
										</td>
										<td style="vertical-align:middle; padding-top:0px; padding-bottom:0px;">
											<a href="<?php echo $fc_url; ?>" target="_blank"><?php echo $fc; ?></a>
										</td>
									</tr>
									<?php endif; ?>
								<?php endforeach; ?>
								</tbody>
							</table><br />
							<p><i>Check the delete box and click save to delete your uploaded document(s)</i></p>
							<div class="clearfix"></div>
						</div>

						<div class="clearfix"></div>
				<?php else: ?>

					<div class="clearfix"><br /></div>

				<?php endif; ?>

			</div> <!-- // #additional_docs -->

						<?php
							$additional_docs2 = false;
							if ($membersapp->category == 'Oil Palm Growers' && $membersapp->profession == 'Smallholder Group Manager')
								$additional_docs2 = true;
						?>
						<div id="additional_docs2" style="display:<?php echo $additional_docs2 ? 'block' : 'none' ?>">
							<p>Furnish documents/information to proof the applicant as an appointed Smallholder Group Manager.</p>
							<ul class="normal">
								<li>Please attach clear evidence that the members of the smallholders group has agreed to appoint the applicant to act as their group manager.</li>
								<li>Please attach the proof of appointment which can be in the form of Official Minutes of Meeting among the smallholders and/or a letter from the smallholders with original signatures. It should list the name of the smallholders, with individual land details (size of land, legality of land ownership, status of oilpalm planted, etc), and with their original signatures.</li>
								<li>Please attach a declaration of all units under your management and the Time Bound Plan when these will be certified.</li>
							</ul><br />
								<p>Please also be informed that as the appointed Group Manager, you will also responsible for managing the trade of the certified products produced by the smallholder, either in virtual (greenpalm) or physical form (FFB physical trade).</p>

							<input rel="Copy of the certificate of incorporation of your organisation" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')" type="file" name="file_sh_group_manager[]" class="required filestyle" >
							
							<input id="org_cert_1" rel="Copy of the certificate of incorporation of your organisation" data-validation-engine="validate[required]" type="hidden" name="div_file_sh_group_manager[]" value="" />

							<?php echo form_error('div_file_sh_group_manager[]') ? '<div class="alert alert-danger">'.form_error('div_file_sh_group_manager[]').'</div>' : ''; ?>

							<div id="more_file_sh_group_manager" class="multiple" style="display:none;"></div>
							<br />
							<a href="#" id="add_file_sh_group_manager">Add more file</a>

				<!-- add more file -->
				<div style="display:none;">
					<div id="div_file_sh_group_manager">
						<input type="file" name="file_sh_group_manager[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')"  class="required">
						<input data-validation-engine="validate[required]" type="hidden" name="div_file_sh_group_manager[]" value=""/>
					</div>
				</div>


					<?php if (!empty($membersapp->file_sh_group_manager)): ?>
						<?php echo form_hidden('uploaded_file_sh_group_manager', htmlspecialchars_decode($membersapp->file_sh_group_manager)); ?>

						<div class="form-group">
						<br />

						<label>Current file(s)</label>
						<div class="clearfix"><br /></div>

						<?php $upfiles_cert = explode(',', $membersapp->file_sh_group_manager); ?>
						
							<div class="one_half">
								<table class="table table-striped table-supplychain" style="border:1px solid #ddd;">
									<thead>
										<tr>
											<th style="width:10%;">Delete</th>
											<th>Filename</th>
										</tr>
									</thead>
									<tbody>
						
							<?php foreach($upfiles_cert as $f): ?>
								<?php if ($f): ?>
									<?php
										if (strrpos($f, '/'))
										{
											$fc = substr(strrchr($f, "/"), 1);
											$fc_url = site_url($f);
										}
										else
										{
											$fc = $f;
											$fc_url = site_url(UPLOAD_PATH . 'memberlogos/'.$f);
										}
									?>
										<tr>
											<td style="padding-left:28px; padding-top:0px; padding-bottom:0px;">
												<input type="checkbox" name="remove_file_sh_group_manager[]" value="<?php echo $f; ?>" style="margin-top:6px;"/>
											</td>
											<td style="vertical-align:middle; padding-top:0px; padding-bottom:0px;">
												<a href="<?php echo $fc_url; ?>" target="_blank"><?php echo $fc; ?></a>
											</td>
										</tr>


								<?php endif; ?>
							<?php endforeach; ?>
									</tbody>
								</table>
								<div class="clearfix"><br /></div>
							</div>
								<div class="clearfix"><br /></div>
								<p><i>Check the delete box and click save to delete your uploaded document(s)</i></p>
						<!-- </div> -->

						<div class="clearfix"></div>
					<?php else: ?>

							<div class="clearfix"><br /></div>


					<?php endif; ?>


						
		</li>
	</ul>
</fieldset>

<fieldset>

	<legend>MEMBERSHIP APPLICATION IS MADE BY</legend>

	<ul>
		<li>
			<label>Full Name</label>
			<div class="input"><?php echo form_input('name_a', htmlspecialchars_decode($membersapp->name_a), 'class="form-control required"') ?></div>
			<?php //echo form_error('name_a') ? '<div class="alert alert-danger">'.form_error('name_a').'</div>' : ''; ?>
		</li>
		<li>
			<label>Position</label>
			<div class="input"><?php echo form_input('designation_a', htmlspecialchars_decode($membersapp->designation_a), 'class="form-control required"') ?></div>
			<?php //echo form_error('designation_a') ? '<div class="alert alert-danger">'.form_error('designation_a').'</div>' : ''; ?>
		</li>
		<li>
			<label>Email</label>
			<div class="input"><?php echo form_input('email_a', $membersapp->email_a, 'class="form-control required"') ?></div>
			<?php echo form_error('email_a') ? '<div class="alert alert-danger">'.form_error('email_a').'</div>' : ''; ?>
		</li>

		<li>
			<label class="inline"><?php echo form_checkbox('newsletter', 'y', $membersapp->newsletter=='y'); ?>Also sign me up to the RSPO email newsletter</label>
		</li>

<!--
		<li>
			<label>Country</label>
			<div class="input">
				<?php //echo form_dropdown('application_country', array(''=>'Select')+$country_arrays, $membersapp->application_country ) ?>
			</div>
		</li>
-->

	</ul>
</fieldset>
</div>

	<div class="form_inputs" id="other-tab">
		<h3>Other Information - Read only</h3>
		<fieldset>
			<ul>

				<li>
					<label>Date Document Completed</label>
					<div class="input"><?php echo $membersapp->complete_document_received ? date('d F Y', $membersapp->complete_document_received) : '--' ?></div>
				</li>

				<li>
					<label>Document Incomplete</label>
					<div class="input">
						<?php echo nl2br($membersapp->document_incomplete); ?>
					</div>
				</li>

				<li>
					<label>Submission for Approval Date</label>
					<div class="input"><?php echo $membersapp->applied_date ? date('d F Y', $membersapp->applied_date) : '--' ?></div>
				</li>

				<li>
					<label>Suspended Date</label>
					<div class="input"><?php echo $membersapp->suspended_date ? date('d F Y', $membersapp->suspended_date) : '--' ?></div>
				</li>

				<li>
					<label>Date Terminated/Resigned</label>
					<div class="input"><?php echo $membersapp->terminated_resigned_on ? date('d F Y', $membersapp->terminated_resigned_on) : '--' ?></div>
				</li>

				<li>
					<label>Rev Notification of Terminated/Resigned</label>
					<div class="input"><?php echo $membersapp->rev_notification ? date('d F Y', $membersapp->rev_notification) : '--' ?></div>
				</li>

				<li>
					<label>Acknowledgement</label>
					<div class="input"><?php echo $membersapp->acknowledgement ? date('d F Y', $membersapp->acknowledgement) : '--' ?></div>
				</li>

			</ul>
		</fieldset>

		<fieldset>
			<ul>

				<li>
					<label>Total Amount Due (in <?php echo ($membersapp->account_currency?$membersapp->account_currency:'EUR') ?>)</label>
					<div class="input"><?php echo ($membersapp->total_amount_due ? ($membersapp->account_currency?$membersapp->account_currency:'EUR') . number_format($membersapp->total_amount_due, 2) : '--') ?></div>
				</li>

				<li>
					<label>Proforma Invoice Date</label>
					<div class="input"><?php echo $membersapp->proforma_invoice_date ? date('d F Y', $membersapp->proforma_invoice_date) : '--' ?></div>
				</li>

				<li>
					<label>Payment Status</label>
					<div class="input"><?php echo $membersapp->payment_status ? $membersapp->payment_status : 'Unpaid' ?></div>
				</li>

				<li>
					<label>Payment Received Date</label>
					<div class="input"><?php echo $membersapp->payment_received_on ? date('d F Y', $membersapp->payment_received_on) : '--' ?></div>
				</li>

			</ul>
		</fieldset>
	</div>

</div>

<div class="buttons">
	<?php $this->load->view('admin/partials/buttons', array('buttons' => array('save', 'save_exit'))) ?>
	<?php //if (!$membersapp->application_sf_id): ?>
		<button type="submit" name="btnAction" value="sync" class="btn orange"><span>Save and Push to SalesForce</span></button>
		<button type="submit" name="btnAction" value="send_files" class="btn orange"><span>Push Files to SalesForce</span></button>
	<?php //endif; ?>
	<?php $this->load->view('admin/partials/buttons', array('buttons' => array('cancel'))) ?>
</div>


<!-- </div> -->
</section>

<!-- end of form -->
</form>	

<script>
var SITE_URL = '<?php echo site_url(); ?>';
	(function($) {
		$(function(){

			$(".mobile-number").intlTelInput({
				//autoFormat: false,
		        autoHideDialCode: true,
		        //defaultCountry: "jp",
		        //nationalMode: true,
		        //onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
		        //preferredCountries: ['cn', 'jp'],
		        //responsiveDropdown: true,
		        utilsScript: "utils.js"
			})

			$('a#add_more_certs').click(function(e){
				e.preventDefault();
				var h = $('#div_more_certificates').html();
				$('#more_certificates').append(h);
				$('#more_certificates').fadeIn();
			});

			$('a#add_file_additionals').click(function(e){
				e.preventDefault();
				var h = $('#div_file_additionals').html();
				$('#more_file_additionals').append(h);
				$('#more_file_additionals').fadeIn();

			});

			$('a#add_file_sh_group_manager').click(function(e){
				e.preventDefault();
				var h = $('#div_file_sh_group_manager').html();
				$('#more_file_sh_group_manager').append(h);
				$('#more_file_sh_group_manager').fadeIn();
			});


			$( ".org_children" ).livequery(function(){
				$(this).autocomplete({
					source: SITE_URL + 'members/pick',
					minLength: 2,
					height: "200px",
					select: function( event, ui ) {
						var n = $(this).next('input[name="sub_company[id][]"]');
						//$(this).next('.org_children_id').val(ui.item.id);
						n.val(ui.item.id);
					}
				});
			});

			$(".remove_child").livequery('click', function(e){
				e.preventDefault();
				if (confirm('Are you sure you want to remove this subsidiary?'))
				{
					var $this = $(this).parent();
					$this.fadeOut('slow', function(){
						$this.empty().remove();
					});
				}
				else
				{
					return false;
				}
			});

		});
	})(jQuery);

	$('.nav-tabs a').click(function() {
		$('.nav-tabs a.active').removeClass('active');
		$(this).addClass('active');
	});
	
	$('#bullet2').click(function() {
		$('#bullet1').addClass('active');
		$('#garischange_member_application').addClass('member_application_step2');
		$('#garischange_member_application').removeClass('id-organisation');
		$('#garischange_member_application').removeClass('member_application_step3');
		$('#garischange_member_application').removeClass('member_application_step4');
	});
	
	$('#bullet3').click(function() {
		$('#bullet1').addClass('active');
		$('#bullet2').addClass('active');
		$('#garischange_member_application').addClass('member_application_step3');
		$('#garischange_member_application').removeClass('id-organisation');
		$('#garischange_member_application').removeClass('member_application_step2');
		$('#garischange_member_application').removeClass('member_application_step4');
	});
	
	$('#bullet4').click(function() {
		$('#bullet1').addClass('active');
		$('#bullet2').addClass('active');
		$('#bullet3').addClass('active');
		$('#garischange_member_application').addClass('member_application_step4');
		$('#garischange_member_application').removeClass('id-organisation');
		$('#garischange_member_application').removeClass('member_application_step2');
		$('#garischange_member_application').removeClass('member_application_step3');
	});
	
	$('#bullet1').click(function() {
		$('#bullet2').removeClass('active');
		$('#bullet3').removeClass('active');
		$('#bullet4').removeClass('active');
		$('#garischange_member_application').addClass('id-organisation');
		$('#garischange_member_application').removeClass('member_application_step2');
		$('#garischange_member_application').removeClass('member_application_step3');
		$('#garischange_member_application').removeClass('member_application_step4');
	});

	// sub-category dropdown
	$('#profession').on('change', function(){

		var v = $(this).val();

		if (v=='Smallholder Group Manager')
		{
			$('#additional_docs').show();
			$('#additional_docs2').show();
			$('#sub_category_other_div').fadeOut(function(){
				$('#sub_category_other_div input').val('');
			});
		}

		if (v && v=='1')
		{
			$('#additional_docs').show();
			$('#additional_docs2').hide();
			$('#sub_category_other_div').fadeOut(function(){
				$('#sub_category_other_div input').val('');
			});
		}
		else if (v && v=='Smallholder Group Manager')
		{
			$('#additional_docs').show();
			$('#additional_docs2').show();
			$('#sub_category_other_div').fadeOut(function(){
				$('#sub_category_other_div input').val('');
			});
		}
		else if (v && v=='Others')
		{
			$('#sub_category_other_div').fadeIn(function(){
				$('#sub_category_other_div input').focus();
			});
		}
		else
		{
			$('#additional_docs').hide();
			$('#additional_docs2').hide();
			$('#sub_category_other_div').fadeOut(function(){
				$('#sub_category_other_div input').val('');
			});
		}
	});

	$( '#myTab a' ).click( function ( e ) {
        e.preventDefault();
        $( this ).tab( 'show' );
	} );

	$( '#moreTabs a' ).click( function ( e ) {
        e.preventDefault();
        $( this ).tab( 'show' );
      } );

	$('#next_1').click(function(e){
		e.preventDefault();
		$('#bullet2').trigger('click');
		$('html, body').animate({
			scrollTop: ($("#myTab").offset().top * 1) - 150
		}, 200);
	});

	$('#next_2').click(function(e){
		e.preventDefault();
		$('#bullet3').trigger('click');
		$('html, body').animate({
			scrollTop: ($("#myTab").offset().top * 1) - 150
		}, 200);
	});

	$('#next_3').click(function(e){
		e.preventDefault();
		$('#bullet4').trigger('click');
		$('html, body').animate({
			scrollTop: ($("#myTab").offset().top * 1) - 150
		}, 200);
	});

	$('#prev_1').click(function(e){
		e.preventDefault();
		$('#bullet1').trigger('click');
		$('html, body').animate({
			scrollTop: ($("#myTab").offset().top * 1) - 150
		}, 200);
	});

	$('#prev_2').click(function(e){
		e.preventDefault();
		$('#bullet2').trigger('click');
		$('html, body').animate({
			scrollTop: ($("#myTab").offset().top * 1) - 150
		}, 200);
	});

	$('#prev_3').click(function(e){
		e.preventDefault();
		$('#bullet3').trigger('click');
		$('html, body').animate({
			scrollTop: ($("#myTab").offset().top * 1) - 150
		}, 200);
	});


	//( function( $ ) {
          // Test for making sure event are maintained
      //    $( '.js-alert-test' ).click( function () {
          //  alert( 'Button Clicked: Event was maintained' );
        //  } );
          //fakewaffle.responsiveTabs( [ 'xs', 'sm' ] );
      //} )( jQuery );

function in_array (needle, haystack, argStrict) {
	var key = '', strict = !!argStrict;

	if (strict) {
		for (key in haystack) {
			if (haystack[key] === needle) {
				return true;
			}
		}
	} else {
		for (key in haystack) {
			if (haystack[key] == needle) {
				return true;
			}
		}
	}

	return false;
}

function copyfname(v,divname,t)
{
	var ftocheck = (t==undefined) ? ftocheck = 'doc' : t;


	var id = divname.attr('id');

	if (ftocheck != "" && ftocheck == 'image')
	{
		var e = ['gif','jpg','jpeg', 'png'];
		var msg = 'GIF, JPG, JPEG, PNG';
	}
	else if (ftocheck != "" && ftocheck == 'all')
	{
		var e = ['pdf','doc','xls','docx','xlsx','gif','jpg','jpeg', 'png','kml','kmz'];
		var msg = 'PDF, DOC, DOCX, XLS, XLSX, GIF, JPG, JPEG, PNG, KML, KMZ';
	}
	else
	{
		var e = ['pdf','doc','xls','docx','xlsx'];
		var msg = 'PDF, DOC, DOCX, XLS, XLSX';
	}

	if (v)
	{
		// check for extension
		var ext = v.substr((~-v.lastIndexOf(".") >>> 0) + 2);
		//if (ext.toLowerCase() == 'pdf')
		if (in_array(ext.toLowerCase(), e))
		{
			var nextdiv = $(":input:eq(" + ($(":input").index(divname) + 1) + ")");
			if (v)
				nextdiv.val(v);
		}
		else
		{

			divname.wrap('<form>').closest('form').get(0).reset();
			divname.unwrap();

			alert('Please upload only '+msg+' format file.\nThank you...');

			return false;
		}
	}
}

function dropdowncat(v)
{
	var ht2 = 0;
	var ht3 = 0;

	switch (v)
	{
		case 'om_subcat':
		case 'om':
			document.memberApplication.category.options.length = 0;
			document.memberApplication.category.options[0]=new Option("Select Category","");
			<?php foreach($categories['om'] as $k=>$v): ?>
			document.memberApplication.category.options[<?php echo $k+1 ?>]=new Option("<?php echo $v ?>","<?php echo $v ?>");
			<?php endforeach; ?>
			$("#subcategory").slideDown();
			$("#primary_market").slideDown();
			$('#q_sca').hide();
			$('#q_om1, #q_om2, #q_om3, #q_om4').show();
			var pheight = $("#step1").height();
		break;

		case 'am_subcat':
		case 'am':
			document.memberApplication.category.options.length = 0;
			document.memberApplication.category.options[0]=new Option("Select Category","");
			<?php foreach($categories['am'] as $k=>$v): ?>
			document.memberApplication.category.options[<?php echo $k+1 ?>]=new Option("<?php echo $v ?>","<?php echo $v ?>");
			<?php endforeach; ?>
			$("#subcategory").slideUp();
			$("#primary_market").slideUp();
			$("#other_market").slideUp();
			$('#q_om1, #q_om2, #q_om3, #q_om4, #q_sca').hide();
			$('#q_am').show();
		break;

		case 'sca_subcat':
		case 'sca':
			document.memberApplication.category.options.length = 0;
			document.memberApplication.category.options[0]=new Option("Select Category","");
			<?php foreach($categories['sca'] as $k=>$v): ?>
			document.memberApplication.category.options[<?php echo $k+1 ?>]=new Option("<?php echo $v ?>","<?php echo $v ?>");
			<?php endforeach; ?>
			$("#subcategory").slideUp();
		 	$("#primary_market").slideUp();
			$("#other_market").slideUp();
			$('#q_sca').show();
			$('#q_om1, #q_om2, #q_om3, #q_om4, #q_am').hide();
		break;
	}
	document.memberApplication.category.options[0].selected=true;
	$('#category').trigger("liszt:updated");
	$("#membercategory div:first span").html("Select Category");
}

function dropdownlist(listindex)
{
	$select = $("#profession");
	switch (listindex)
	{
		case "Oil Palm Growers":
			//document.memberApplication.profession.options.length = 0;
			$select.find('option').remove().end();
			$select.append('<option value="Select subcategory" >Select subcategory</option>');
			<?php foreach($subcat_growers as $s): ?>
				$select.append('<option value="<?php echo $s; ?>" > <?php echo $s; ?></option>');
			<?php endforeach; ?>
			$select.trigger("liszt:updated");

			$("#subcategory div:first span").html("Select subcategory");
			$("#subcategory").show();
			$("#primary_market").slideDown();
			$("#other_market").slideDown();
		break;
		case "Consumer Goods Manufacturers":
		case "Palm Oil Processors and Traders":
			$select.find('option').remove().end();
			//document.memberApplication.profession.options.length = 0;
			$select.append('<option value="Select subcategory" >Select subcategory</option>');
			<?php foreach($subcat_popt as $s): ?>
				$select.append('<option value="<?php echo $s; ?>" > <?php echo $s; ?></option>');
			<?php endforeach; ?>
			$("#subcategory div:first span").html("Select subcategory");
			$("#subcategory").show();
			$select.trigger("liszt:updated");
		 	$("#primary_market").slideUp();
			$("#other_market").slideUp();
		break;
		default:
			 if (document.memberApplication.profession != undefined)
			 {
				$select.find('option').remove().end();
				$select.trigger("liszt:updated");
				$("#subcategory").slideUp();
				 //$("#primary_market").slideUp();
			 }
		 	$("#primary_market").slideUp();
			$("#other_market").slideUp();
		break;
	}
	return true;
}


var approved_date_ori = $('#approved_date').val();
var member_num_ori = $('#member_num').val();

function displayExpiry(v)
{
	if (v && v=='Call for Comment')
	{
		approved_date_ori = $('#approved_date').val();
		member_num_ori = $('#member_num').val();
		$('.li_member_detail').fadeOut(function(){
			$('#approved_date').val('');
			$('#member_num').val('');
		});
		$('#li_expiry_date').fadeIn();
	}
	else if (v && v=='Approved')
	{
		$('.li_member_detail').fadeIn(function(){
			$('#approved_date').val(approved_date_ori);
			$('#member_num').val(member_num_ori);
		});
		$('#li_expiry_date').fadeOut();
	}
	else
	{
		approved_date_ori = $('#approved_date').val();
		member_num_ori = $('#member_num').val();
		$('.li_member_detail').fadeOut(function(){
			$('#approved_date').val('');
			$('#member_num').val('');
		});
		$('#li_expiry_date').fadeOut();
	}
}

</script>

						<div id="tocopy-container" style="display:none;">
							<div id="tocopy">
								<li>
									<!-- <div class="input-group no-margin"> -->
										<input class="org_children" type="text" name="sub_company[name][]" value="" />
										<input class="org_children_id" type="hidden" name="sub_company[id][]" value="" />
										<a href="#" tabindex="-1" class="btn small red remove_child"> &nbsp;x&nbsp; </a>
									<!-- </div> -->
								</li>
							</div>
						</div>

