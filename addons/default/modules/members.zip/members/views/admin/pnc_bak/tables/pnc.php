<!--<small>Number of data: <?php //echo number_format($count); ?></small>-->
	
	<table>
		<thead>
			<tr>
				<th width="20"><?php echo form_checkbox(array('name' => 'action_to_all', 'class' => 'check-all')); ?></th>
				<th width="100" class="collapse">Date</th>
				<th width="150">Member</th>
				<th class="collapse">Mill</th>
				<th class="collapse">Certification Body</th>
				<th class="collapse">Assessment Type</th>
				<th class="collapse">Assessment Status</th>
				<th class="collapse">Status</th>
				<th width="200">Actions</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="9">
					<div class="inner"><?php $this->load->view('admin/partials/pagination'); ?></div>
				</td>
			</tr>
		</tfoot>
		<tbody>
			<?php foreach ($pncs as $pnc) : ?>
				<tr>
					<?php $date = date_create($pnc->date);?>
					<td><?php echo form_checkbox('action_to[]', $pnc->id); ?></td>
					<td class="collapse"><?php echo date_format($date, 'Y-m-d');?></td>
					<td><?php echo $pnc->member_name; ?></td>
					<td class="collapse" width="210">
						<?php echo $pnc->mill ?>
						<?php //if (!empty($pnc->mill)): ?>
							<?php //foreach($pnc->mill as $mill): ?>
								<?php //echo $mill->mill ?>
							<?php //endforeach; ?>
						<?php //endif; ?>
					</td>
					<td class="collapse"><?php echo $pnc->cb_name; ?></td>
					<td class="collapse"><?php echo $pnc->assessment_type ? $assessment_type[$pnc->assessment_type] : '--'; ?></td>
					<td class="collapse"><?php echo $pnc->status ? ucwords($pnc->status) : '--'; ?></td>
					<td class="collapse"><?php if($pnc->isUp == '1'){ echo 'Live'; } else echo 'Draft'; ?></td>
					<td>
						<?php
						echo anchor('admin/members/pncassessment/view/'.$pnc->id, lang('global:view'), 'class="btn xsmall blue modal" target="_blank"').' ';
						echo anchor('admin/members/pncassessment/edit/'.$pnc->id, lang('global:edit'), 'class="btn xsmall blue"').' ';
						echo anchor('admin/members/pncassessment/delete/'.$pnc->id, lang('global:delete'), 'class="btn red xsmall confirm"').' ';
						?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<div class="table_action_buttons">
		<button disabled="" type="submit" name="btnAction" value="delete" class="btn red confirm">
			<span>Delete</span>
		</button>
	</div>