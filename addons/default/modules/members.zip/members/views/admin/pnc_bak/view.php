<!--
<section class="title">
</section>
-->

<!-- <section class="item"> -->
<div class="content">

	<h4><?php echo $pnc->mill;?></h4>

<?php if (!empty($pnc)) : ?>

<form class="crud" action="">
<div class="form_inputs">
<fieldset>
<ul>

	<li>
		<div class="one_half">
			<label>Member </label>
			<div class="input"><?php echo $pnc->member_name; ?></div>
		</div>
		<div class="one_half">
			<label>Certification Body </label>
			<div class="input"><?php echo $pnc->certification_body; ?></div>
		</div>
		<div class="clearfix"></div>
	</li>
	
	<li>
		<div class="one_half">
			<label>Assessment Type</label>
			<div class="input"><?php echo $pnc->assessment_type ? $assessment_type[$pnc->assessment_type] : '--'; ?></div>
		</div>
		<div class="one_half">
			<label>Assessment Status</label>
			<div class="input"><?php echo $pnc->status; ?></div>
		</div>
		<div class="clearfix"></div>
	</li>
	
	<li>
		<div class="one_half">
			<label>Notification Date</label>
			<?php $date = date_create($pnc->date);?>
			<div class="input"><?php echo date_format($date, 'Y-m-d') ?></div>
		</div>
		<div class="one_half">
			<label>Assessment Date</label>
			<div class="input"><?php echo date('Y-m-d', $pnc->assessment_date) ?></div>
		</div>
		<div class="clearfix"></div>
	</li>
	
	<li>
		<div class="one_half">
			<label>Remarks</label>
			<div class="input"><?php echo $pnc->remarks; ?></div>
		</div>
		<div class="one_half">
			<label>Report Accepted Date</label>
			<div class="input"><?php echo $pnc->report_accepted_date ? date('Y-m-d', $pnc->report_accepted_date) : ''?></div>
		</div>
		<div class="clearfix"></div>
	</li>
	
	<li>
		<div class="one_half">
			<label>Final Report Date</label>
			<div class="input"><?php echo $pnc->final_report_date ? date('Y-m-d', $pnc->final_report_date) : '' ?></div>
		</div>
		<div class="clearfix"></div>
	</li>
	
	<li>
		<div class="one_half">
			<label>file</label>
			<div class="input">
			<?php
								$ff = ($pnc->uploaded ? ','.$pnc->uploaded:'') .
									($pnc->notification ? ','.$pnc->notification:'') .
									($pnc->notification_2 ? ','.$pnc->notification_2:'') .
									($pnc->notification_3 ? ','.$pnc->notification_3:'');
								$files = explode(',' , $ff);
								$certfile = $certname = '';
								if ($pnc->certificate_file)
									{
										if ($pos = strpos($pnc->certificate_file, '/', 1))
										{
											$certname = substr(strrchr($pnc->certificate_file, '/'), 1);
											$certfile = '<b>'.$certname.'</b><br />';
											$file_href = site_url($pnc->certificate_file);
										}
										else
										{
											$certname = $pnc->certificate_file;
											$certfile = '<b>'.$certname.'</b><br />';
											$file_href = site_url(UPLOAD_PATH.'pnc/'.$pnc->certificate_file);
										}

										if (strlen($certname) > 30)
											$certfile = "<a title=\"".$certname."\" target='_blank' href='".$file_href."'><b>".substr($certname,0,30)."..</b></a><br/>";
										else
											$certfile = "<a title=\"".$certname."\" target='_blank' href='".$file_href."'><b>".$certname."</b></a><br/>";
									}
									echo ''.PHP_EOL;
									echo $certfile ? $certfile : '';
									foreach($files as $key => $file){
										if ($file)
										{
											$pos = strpos($file, '/', 1);
											if ($pos OR $pos === 0)
											{
												$fname = substr(strrchr($file, "/"), 1);
												$file_href = site_url($file);
											}
											else
											{
												$fname = $file;
												$file_href = site_url(UPLOAD_PATH.'pnc/'.$fname);
											}

											if (strlen($fname) > 30)
												echo "<a title=\"".$fname."\" target='_blank' href='".$file_href."'>".substr($fname,0,30)."..</a><br/>";
											else
												echo "<a title=\"".$fname."\" target='_blank' href='".$file_href."'>".$fname."</a><br/>";
										}
										else
											continue;
									}
									echo '</div>'.PHP_EOL;
									//$item = '<ul class="list-group"><li>'.$certfile.'</li><li>'.implode('</li><li>', $files).'</li></ul>';
									//$item =  
								//echo $item;
								?>
			</div>
		</div>
		<div class="clearfix"></div>
	</li>
</ul>

	<div class="table_action_buttons">
		<?php echo anchor('admin/members/pncassessment/delete/'.$pnc->id, lang('global:delete'), 'class="btn red confirm"').' '; ?>
	</div>

</fieldset>
</div>
</form>

<?php else : ?>
	<div class=" alert error"><p>Error retrieving pnc</p></div>
<?php endif; ?>

</div>
<!-- </section> -->

<div class="clearfix"><br /></div>