<section class="title">
<?php if ($this->method == 'create'): ?>
	<h4><?php echo lang('members:create_title'); ?></h4>
<?php else: ?>
	<h4><?php echo sprintf(lang('members:edit_title'), $membersapp->name); ?></h4>
<?php endif; ?>
</section>

<section class="item">
<div class="content">

<?php echo form_open_multipart($this->uri->uri_string(), 'class="crud" id="member_applications"'); ?>	
<?php if (!empty($error)): ?>
	<div class="alert alert-danger alert-dismissible"><?php echo $error; ?></div>
<?php endif; ?>

	<div class="tabs">

		<ul class="tab-menu">
			<li><a href="#1"><span><?php echo lang('members:tab_about'); ?></span></a></li>
			<li><a href="#2"><span><?php echo lang('members:tab_contact'); ?></span></a></li>
			<li><a href="#3"><span><?php echo lang('members:tab_questions'); ?></span></a></li>
			<li><a href="#4"><span><?php echo lang('members:tab_documents'); ?></span></a></li>
		</ul>

			<div class="form_inputs" id="1">
				<fieldset>
                <h2 class="titleapp">About Your Organisation</h2>
                <ul>
				<li>
					<label for="type">Membership type <span class="requiredfill">*</span></label>
					<?php echo form_input('type', $membersapp->type, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('type') ? '<div class="alert alert-danger">'.form_error('type').'</div>' : ''; ?>
				</li>
				<li>
					<label for="category">What is your organisation's category? <span class="requiredfill">*</span></label>
					<?php echo form_input('category', $membersapp->category, 'class="form-control input-lg required" placeholder=""'); ?>
					
					<?php echo form_error('category') ? '<div class="alert alert-danger">'.form_error('category').'</div>' : ''; ?>
					<p></p>
					
					<select class="form-control" style="border-color:black;" name="org_subcategory" id="org_subcategory">
						<option value="<?php echo $membersapp->org_subcategory?>"><?php if(!empty($membersapp->org_subcategory)){ echo $membersapp->org_subcategory;} else echo 'Select Sub Category';?></option>
						<option value="Small Growers">Small Growers</option>
						<option value="Smallholders">Smallholders</option>
					</select>
					
					<?php echo form_error('org_subcategory') ? '<div class="alert alert-danger">'.form_error('org_subcategory').'</div>' : ''; ?>
				</li>
				<li>
					<label for="name">What is your organisation's name? <span class="requiredfill">*</span></label>
					<?php echo form_input('name', $membersapp->name, 'class="form-control  input-lg required" placeholder=""'); ?>
					
					<?php echo form_error('name') ? '<div class="alert alert-danger">'.form_error('name').'</div>' : ''; ?>
				</li>
				<li>
					<label for="address">Street name and number <span class="requiredfill">*</span></label>
					<?php echo form_input('address', $membersapp->address, 'class="form-control  input-lg required" placeholder=""'); ?>
					
					<?php echo form_error('address') ? '<div class="alert alert-danger">'.form_error('address').'</div>' : ''; ?>
				</li>
				<li>
					<label for="address_city">City <span class="requiredfill">*</span></label>
					<?php echo form_input('address_city', $membersapp->address_city,'class="form-control  input-lg required" placeholder=""'); ?>
					
					<?php echo form_error('address_city') ? '<div class="alert alert-danger">'.form_error('address_city').'</div>' : ''; ?>
				</li>
				<li>
					<label for="address_state">State/Province <span class="requiredfill">*</span></label>
					<?php echo form_input('address_state', $membersapp->address_state, 'class="form-control  input-lg required" placeholder=""'); ?>
					
					<?php echo form_error('address_state') ? '<div class="alert alert-danger">'.form_error('address_state').'</div>' : ''; ?>
				</li>
				<li>
					<label for="address_zip">Postal/Zip Code <span class="requiredfill">*</span></label>
					<?php echo form_input('address_zip', $membersapp->address_zip, 'class="form-control  input-lg required" placeholder=""'); ?>
					
					<?php echo form_error('address_state') ? '<div class="alert alert-danger">'.form_error('address_state').'</div>' : ''; ?>
				</li>
				<li>
					<label for="country">Country <span class="requiredfill">*</span></label><br/>
					<?php echo form_dropdown('country', array(""=>"Select country") + $country_arrays, $membersapp->country, 'class="form-control required"'); ?>
					
					<?php echo form_error('country') ? '<div class="alert alert-danger">'.form_error('country').'</div>' : ''; ?>
				</li>
				<li>
					<label for="telephone">Telephone <span class="requiredfill">*</span></label>
					<?php echo form_input('telephone', $membersapp->telephone, 'class="form-control input-lg required" placeholder=""'); ?>
					
					<?php echo form_error('telephone') ? '<div class="alert alert-danger">'.form_error('telephone').'</div>' : ''; ?>
				</li>
				<li>
					<label for="fax">Fax </label>
					<?php echo form_input('fax', $membersapp->fax, 'class="form-control input-lg" placeholder=""'); ?>
				</div>
				<hr/>	
				<li>
				<label for="email">Email <span class="requiredfill">*</span></label>
					<?php echo form_input('email', $membersapp->email, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('email') ? '<div class="alert alert-danger">'.form_error('email').'</div>' : ''; ?>
				</div>
				
				<hr/>
				<li>
					<label for="website">Website </label>
					<?php echo form_input('website', $membersapp->website, 'class="form-control  input-lg" placeholder=""'); ?>
				</li>
				<li>
					<label for="registration_number">What is your registration number? <span class="requiredfill">*</span></label>
					<?php echo form_input('registration_number', $membersapp->registration_number, 'class="form-control input-lg required" placeholder=""'); ?>
					
					<?php echo form_error('registration_number') ? '<div class="alert alert-danger">'.form_error('registration_number').'</div>' : ''; ?>
				</li>
				<li>
					<label for="parent_company">Are you a parent company? </label>
					<br/>
					<select class="form-control" style="border-color:black;" name="parent_company" id="parent_company">
						<option value="<?php echo $membersapp->parent_company?>">Yes Or No</option>
						<option value="Yes">Yes</option>
						<option value="No">No</option>
					</select>
				</li>
				<li>
					<label for="primary_market_ops">Primary market operations </label><br/>
				   
					<label>
					<input <?php echo $membersapp->primary_market_ops == 'Indonesia' ? 'checked="checked"' : ''; ?> name="primary_market_ops" type="radio" value="Indonesia" >
					</label>
					<label> Indonesia </label>
					<br/>
						
					<label>
					<input <?php echo $membersapp->primary_market_ops == 'Malaysia' ? 'checked="checked"' : ''; ?> name="primary_market_ops" type="radio" value="Malaysia">
					</label>
					<label> Malaysia </label>
					<br/>
						
					<label>
					<input <?php echo $membersapp->primary_market_ops == 'World' ? 'checked="checked"' : ''; ?> name="primary_market_ops" type="radio" value="World">
					</label>
					<label> The rest of the world </label>
						
				</li>
				<li>
					<label for="other_market_ops">Other market operations </label><br/>
					<textarea class="form-control input-lg" name="other_market_ops" rows="5" id="other_market_ops"><?php echo $membersapp->other_market_ops; ?></textarea>
				</li>
				<li>
					<label for="logo">Upload your organisation logo <span class="requiredfill">*</span></label>
					<input type="file" name="logo" id="logo" style="border:none;" class="required" onchange="copyfname(this.value, $(this))">
					
					<?php echo $membersapp->logo?>
					
					<?php if (!empty($membersapp->logo)): ?>
						<?php echo form_hidden('upload_logo', $membersapp->logo, 'class="required"'); ?>
						<div class="clear"></div>
						<label class="inline">Filename: </label> <?php echo $membersapp->upload_logo; ?>
					<?php endif; ?>
					
					<?php echo form_error('upload_logo') ? '<div class="alert alert-danger">'.form_error('upload_logo').'</div>' : ''; ?>
				</li>
				<li>
					<label for="profile">Tell us about your organisation </label><br/>
					<textarea class="form-control input-lg" name="profile" rows="5" id="profile"><?php echo $membersapp->profile; ?></textarea>
				</li>
				</ul>
				</fieldset>				
			</div>
			
			<div class="form_inputs" id="2">
				
				<h2 class="titleapp">Contact Details</h2>

				<h4>Primary nomination of representative</h4>
				<li>
					<label for="name_p">Full name <span class="requiredfill">*</span></label>
					<?php echo form_input('name_p', $membersapp->name_p, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('name_p') ? '<div class="alert alert-danger">'.form_error('name_p').'</div>' : ''; ?>
				</li>
				<li>
					<label for="designation_p">Position <span class="requiredfill">*</span></label>
					<?php echo form_input('designation_p', $membersapp->designation_p, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('designation_p') ? '<div class="alert alert-danger">'.form_error('designation_p').'</div>' : ''; ?>
				</li>
				<li>
					<label for="telephone_p">Telephone <span class="requiredfill">*</span></label>
					<?php echo form_input('telephone_p', $membersapp->telephone_p, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('telephone_p') ? '<div class="alert alert-danger">'.form_error('telephone_p').'</div>' : ''; ?>
				</li>
				<li>
					<label for="fax_p">Fax </label>
					<?php echo form_input('fax_p', $membersapp->fax_p, 'class="form-control  input-lg" placeholder=""'); ?>
				</li>
				<li>
					<label for="email_p">Email <span class="requiredfill">*</span></label>
					<?php echo form_input('email_p', $membersapp->email_p, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('email_p') ? '<div class="alert alert-danger">'.form_error('email_p').'</div>' : ''; ?>
				</div>
				<hr/>

				<h4>Secondary nomination of representative</h4>
				<li>
					<label for="name_s">Full name <span class="requiredfill">*</span></label>
					<?php echo form_input('name_s', $membersapp->name_s, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('name_s') ? '<div class="alert alert-danger">'.form_error('name_s').'</div>' : ''; ?>
				</li>
				<li>
					<label for="designation_s">Position <span class="requiredfill">*</span></label>
					<?php echo form_input('designation_s', $membersapp->designation_s, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('designation_s') ? '<div class="alert alert-danger">'.form_error('designation_s').'</div>' : ''; ?>
				</li>
				<li>
					<label for="telephone_s">Telephone <span class="requiredfill">*</span></label>
					<?php echo form_input('telephone_s', $membersapp->telephone_s, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('telephone_s') ? '<div class="alert alert-danger">'.form_error('telephone_s').'</div>' : ''; ?>
				</li>
				<li>
					<label for="fax_s">Fax </label>
					<?php echo form_input('fax_s', $membersapp->fax_s, 'class="form-control  input-lg" placeholder=""'); ?>
				</li>
				<li>
					<label for="email_s">Email <span class="requiredfill">*</span></label>
					<?php echo form_input('email_s', $membersapp->email_s, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('email_s') ? '<div class="alert alert-danger">'.form_error('email_s').'</div>' : ''; ?>
				</div>
				<hr/>

				<h4>Contact person</h4>
				<li>
					<label for="contact_person">Full name <span class="requiredfill">*</span> </label>
					<?php echo form_input('contact_person', $membersapp->contact_person, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('contact_person') ? '<div class="alert alert-danger">'.form_error('contact_person').'</div>' : ''; ?>
				</li>
				<li>
					<label for="designation">Position <span class="requiredfill">*</span></label>
					<?php echo form_input('designation', $membersapp->designation, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('designation') ? '<div class="alert alert-danger">'.form_error('designation').'</div>' : ''; ?>
				</li>
				<li>
					<label for="contact_tel">Telephone <span class="requiredfill">*</span></label>
					<?php echo form_input('contact_tel', $membersapp->contact_tel, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('contact_tel') ? '<div class="alert alert-danger">'.form_error('contact_tel').'</div>' : ''; ?>
				</li>
				<li>
					<label for="contact_fax">Fax </label>
					<?php echo form_input('contact_fax', $membersapp->contact_fax, 'class="form-control  input-lg" placeholder=""'); ?>
				</li>
				<li>
					<label for="contact_email">Email <span class="requiredfill">*</span></label>
					<?php echo form_input('contact_email', $membersapp->contact_email, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('contact_email') ? '<div class="alert alert-danger">'.form_error('contact_email').'</div>' : ''; ?>
				</div>
				<hr/>

				<h4>Finance contact for membership fee</h4>
				<li>
					<label for="name_f">Full name <span class="requiredfill">*</span></label>
					<?php echo form_input('name_f', $membersapp->name_f, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('name_f') ? '<div class="alert alert-danger">'.form_error('name_f').'</div>' : ''; ?>
				</li>
				<li>
					<label for="designation_f">Position <span class="requiredfill">*</span></label>
					<?php echo form_input('designation_f', $membersapp->designation_f, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('designation_f') ? '<div class="alert alert-danger">'.form_error('designation_f').'</div>' : ''; ?>
				</li>
				<li>
					<label for="telephone_f">Telephone <span class="requiredfill">*</span></label>
					<?php echo form_input('telephone_f', $membersapp->telephone_f, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('telephone_f') ? '<div class="alert alert-danger">'.form_error('telephone_f').'</div>' : ''; ?>
				</li>
				<li>
					<label for="fax_f">Fax </label>
					<?php echo form_input('fax_f', $membersapp->fax_f, 'class="form-control  input-lg" placeholder=""'); ?>
				</li>
				<li>
					<label for="email_f">Email <span class="requiredfill">*</span></label>
					<?php echo form_input('email_f', $membersapp->email_f, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('email_f') ? '<div class="alert alert-danger">'.form_error('email_f').'</div>' : ''; ?>
				</div>
			</div>
			
			<div class="form_inputs" id="3">
				
				<h2 class="titleapp">Questions</h2>
				<p>Please respond to all items marked with an asterisk (<span class="requiredfill">*</span>). You can save the application at any stage by clicking on the SAVE button below, and resume later from <span class="requiredfill">Member application homepage</span></p><br/>				
									
				<li>
					<label for="q1"> How will your organisation promote the RSPO internally and to other stakeholders? <span class="requiredfill">*</span></label><br/>
					<textarea class="form-control input-lg required" name="q1" rows="5" id="q1"><?php echo $membersapp->q1; ?></textarea>
					
					<?php echo form_error('q1') ? '<div class="alert alert-danger">'.form_error('q1').'</div>' : ''; ?>
				</li>
				<li>
					<label for="q2"> Where relevant, what processes is the organisation establishing to engage with interested parties, for example to resolve conflict or to use sustainably produced palm oil? <span class="requiredfill">*</span></label><br/>
					<textarea class="form-control input-lg required" name="q2" rows="5" id="q2"><?php echo $membersapp->q2; ?></textarea>
					
					<?php echo form_error('q2') ? '<div class="alert alert-danger">'.form_error('q2').'</div>' : ''; ?>
				</li>
				<li>
					<label for="q3"> Where relevant, how will your organisation work towards implementing the RSPO Principles and Criteria or assessing supplier performance against these criteria? <span class="requiredfill">*</span></label><br/>
					<textarea class="form-control input-lg required" name="q3" rows="5" id="q3"><?php echo $membersapp->q3; ?></textarea>
					
					<?php echo form_error('q3') ? '<div class="alert alert-danger">'.form_error('q3').'</div>' : ''; ?>
				</li>
				<li>
					<label for="q4"> Any other information that would support the application such as what your organisation hopes gain from joining the RSPO. </label><br/>
					<textarea class="form-control input-lg" name="q4" rows="5" id="q4"><?php echo $membersapp->q4; ?></textarea>
				</li>
				<li>
					<label for="q_usage">Please state your annual usage of palm oil and palm derivatives in metric tonnes</label>
					<?php echo form_input('q_usage', $membersapp->q_usage, 'class="form-control  input-lg" placeholder=""'); ?>
				</div>
			</div>
			
			<div class="form_inputs" id="4">
				
				<h2 class="titleapp">Supporting Documents</h2>
				<p>Please respond to all items marked with an asterisk (<span class="requiredfill">*</span>). You can save the application at any stage by clicking on the SAVE button below, and resume later from <span class="requiredfill">Member application homepage</span></p><br/>
	
				<h4>For all applicants - please attach a copy of the certificate of incorporation of your organisation</h4>
				
				<li>
					<label for="file_certificates">Your file should be in either PDF, PNG, JPG, or GIF format and no more than 2MB in size</label>
					
					<input type="file" multiple name="file_certificates[]" id="file_certificates[]" style="border:none;" onchange="copyfname(this.value, $(this))">

					<br/>

					<?php if (!empty($membersapp->file_certificates)): ?>
						<?php echo form_hidden('uploaded_files_cert', $membersapp->file_certificates); ?>
						<?php echo form_hidden('uploaded_files_cert1', $membersapp->file_certificates); ?>
						<div class="input">
						<?php $upfiles_cert = explode(',', $membersapp->file_certificates); ?>
						<table class="one_half" style="border:1px solid black;">
							<thead style="border:1px solid black;">
								<tr>
									<th style="border:1px solid black; padding:5px;">Remove</th>
									<th style="border:1px solid black; padding:5px;">Current file</th>
								</tr>
							</thead>
							<tbody style="border:1px solid black;">
							<?php foreach($upfiles_cert as $f): ?>
								<?php if ($f): ?>
								<tr>
									<td style="border:1px solid black;  padding:5px;"><input type="checkbox" name="remove_uploaded_cert[]" class="remove_uploaded_cert" value="<?php echo $f; ?>" /></td>
									<td style="border:1px solid black;  padding:5px;"><?php echo $f; ?></td>
								</tr>
								<?php endif; ?>
							<?php endforeach; ?>
							</tbody>
						</table>
						</div>
					<?php endif; ?>
				</div>
				
				<!--
				<br/>
				
				<div id="org_certificate_fields"></div>
				
				<div style="clear:both;display:block;">
					<a class="add-more-file" href="#" onclick="add_more_certificate(); return false;">Add more files</a>
				</div>
				<div id="more-certificate-container" style="display:none;">
					<div id="more-certificate">
						<input class="no-uniform" onchange="copyfname(this.value, $(this))" type="file" name="org_certificate[]" >
						<input type="hidden" name="t_org_certificate_div[]" value="" />
					</div>
				</div>
				<script>
					function add_more_certificate()
					{
						var newfield = $("#more-certificate").html();
						$("#org_certificate_fields").append(newfield);
						//$("#org_certificate_fields input[type=hidden]:last-child").addClass("required");
						var ht = $("#step4").height();
						var ht2 = $("#more-certificate").height();
						$("#form-slider").parent().height(ht+ht2);
						return false;
					}
				</script>
				-->
				
				<hr/>
				<li>
					<label>For Ordinary Members - "Growers" category only: </label>
					<label>1. Organisation status (corporate and organization chart) </label><br/>
					<label>2. Disclosure of plans to implement the RSPO P&C </label><br/>
					<label>3. Estate location and map</label><br/>
					<label>4. Disclosure of existing field practices and policies of CSR/ sustainability policy </label>
				</li>
				<li>
					<label for="file">Your file should be in either PDF, PNG, JPG, or GIF format and no more than 2MB in size</label>
					<input type="file" multiple name="file[]" id="file[]" style="border:none;" onchange="copyfname(this.value, $(this))">
					
					<br/>

					<?php if (!empty($membersapp->file)): ?>
						<?php echo form_hidden('grower_file', $membersapp->file); ?>
						<?php echo form_hidden('grower_file1', $membersapp->file); ?>
						<div class="input">
						<?php $upfiles_grower = explode(',', $membersapp->file); ?>
						<table class="one_half" style="border:1px solid black;">
							<thead style="border:1px solid black;">
								<tr>
									<th style="border:1px solid black; padding:5px;">Remove</th>
									<th style="border:1px solid black; padding:5px;">Current file</th>
								</tr>
							</thead>
							<tbody style="border:1px solid black;">
							<?php foreach($upfiles_grower as $g): ?>
								<?php if ($g): ?>
								<tr>
									<td style="border:1px solid black;  padding:5px;"><input type="checkbox" name="remove_uploaded_grower[]" class="remove_uploaded_grower" value="<?php echo $g; ?>" /></td>
									<td style="border:1px solid black;  padding:5px;"><?php echo $g; ?></td>
								</tr>
								<?php endif; ?>
							<?php endforeach; ?>
							</tbody>
						</table>
						</div>
					<?php endif; ?>
				</li>
				<li>
					<label for="InputPassword">I agree to the following by checking the box below: <span class="requiredfill">*</span></label>
					<br/>
					<input type="checkbox" style="border:none;" class="required" onclick="agree(this);"> I hereby acknowledge that I have read and understand all of my obligations, duties and responsibilities under each principle and provision of RSPO's Code of Conduct and will accept the future amendments and modifications to the Code of Conduct.
				</div>
				<hr/>

				<h4>Membership application is made by:</h4>
				<li>
					<label for="name_a">Full name <span class="requiredfill">*</span></label>
					<?php echo form_input('name_a', $membersapp->name_a, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('name_a') ? '<div class="alert alert-danger">'.form_error('name_a').'</div>' : ''; ?>
				</li>
				<li>
					<label for="designation_a">Position <span class="requiredfill">*</span></label>
					<?php echo form_input('designation_a', $membersapp->designation_a, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('designation_a') ? '<div class="alert alert-danger">'.form_error('designation_a').'</div>' : ''; ?>
				</li>
				<li>
					<label for="name_a">Email address <span class="requiredfill">*</span></label>
					<?php echo form_input('name_a', $membersapp->name_a, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('name_a') ? '<div class="alert alert-danger">'.form_error('name_a').'</div>' : ''; ?>
				</li>
				<li>
					<label for="date_2">Applied date <span class="requiredfill">*</span></label>
					<?php echo form_input('date_2', $membersapp->date_2, 'class="form-control required input-lg" placeholder=""'); ?>
					
					<?php echo form_error('date_2') ? '<div class="alert alert-danger">'.form_error('date_2').'</div>' : ''; ?>
				</div>
				<br/>
				
				<input name="membership_submit" type="submit" class="btn btn-lg" value="Submit" />
			</div>
		</div>
    
<?php echo form_close(); ?>

</div>
</section>