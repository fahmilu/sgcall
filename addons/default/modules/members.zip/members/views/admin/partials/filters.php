
<fieldset id="filters">
	
	<legend><?php echo lang('global:filters'); ?></legend>
	
	<?php echo form_open('admin/members/index'); ?>

	<?php echo form_hidden('f_module', $module_details['slug']); ?>
		<ul>  
			<li>
				<div class="one_quarter">
	        		<?php echo lang('members:status_label', 'f_status'); ?>
	        		<?php echo form_dropdown('f_status', $membership_status); ?>
				</div>
				<div class="one_quarter">
	        		<?php echo lang('members:type_label', 'f_type'); ?>
	        		<?php echo form_dropdown('f_type', $member_types, 'id="filter_type" onchange="getMCategory(this.value)"'); ?>
				</div>
				<div class="one_quarter">
	        		<?php echo lang('members:category_label', 'f_category'); ?>
	        		<span id="mcategory">
	        			<select name="f_category" id="f_category">
	        				<option value="">Select category</option>
	        				<optgroup label="Ordinary Members">
	        					<option value="Banks and Investors">Banks and Investors</option>
	        					<option value="Consumer Goods Manufacturers">Consumer Goods Manufacturers</option>
	        					<option value="Environmental and Conservation NGOs">Environmental and Conservation NGOs</option>
	        					<option value="Oil Palm Growers">Oil Palm Growers</option>
	        					<option value="Palm Oil Processors and Traders">Palm Oil Processors and Traders</option>
	        					<option value="Retailers">Retailers</option>
	        					<option value="Social and Developmental NGOs"></option>
	        				</optgroup>
	        				<optgroup label="Affiliate Members">
	        					<option value="Association">Association</option>
	        					<option value="Individuals">Individuals</option>
	        					<option value="Organisation">Organisation</option>
	        				</optgroup>
	        				<optgroup label="Supply Chain Associate">
	        					<option value="Organisations">Organisations</option>
	        					<option value="Supply Chain Group Manager">Supply Chain Group Manager</option>
	        				</optgroup>
	        			</select>
	        		<?php //echo form_dropdown('f_category', array(''=>'Select category')+$member_categories); ?>
	        		</span>
				</div>
				<div class="one_quarter">
	        		<label style="margin-bottom:5px;">Keywords:</label> <?php echo form_input('f_keywords'); ?>
				</div>
				<div class="clearfix"><br /></div>
				<div class="one_quarter">
					<?php echo anchor(current_url() . '#', "Clear", 'class="cancel"'); ?>
				</div>
    		</li>
		</ul>
	<?php echo form_close(); ?>
</fieldset>

<script>
function getMCategory(v)
{
		if (v)
		{
alert('v: '+v);
		}
		else
		{
			alert('no value..');
		}
}
</script>