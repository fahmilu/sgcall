<fieldset id="filters">
	<legend><?php echo lang('global:filters'); ?></legend>
	
	<?php echo form_open('admin/members/scc/index'); ?>

	<?php echo form_hidden('f_module', $module_details['slug']); ?>
		<div style="display:block;width:22%;float:left;">
        	<label for="f_status">Status</label><br/>
        	<?php echo form_dropdown('f_status', array('all' => 'All', 'draft'=>'Draft', 'live'=>'Live')); ?>
    	</div>
		
		<div style="display:block;width:16%;float:left;">
        	<?php echo lang('scc:keywords_label', 'f_keywords'); ?><br/>
			<?php echo form_input('f_keywords'); ?>
    	</div>
		
		<div style="display:block;width:5%;float:left; margin-top:10px;">
			<label for="f_keywords"></label><br/>
			<?php echo anchor(current_url() . '#', lang('buttons:cancel'), 'class="cancel"'); ?>
		</div>
		
		<div style="display:block;width:35%;float:left; margin-left:20px;">
	        <label style="margin-bottom:5px;">Supply Options</label><br/>
			<?php echo form_input('f_supplyoption','','id="chcbxso" style="width:70%;"'); ?>
			
			<!--<div style="margin-top:8px;">
				<label class="inline"><input id="B&amp;C" type="checkbox" name="BC" /> Book &amp; Claim</label>
				<label class="inline"><input id="MB" type="checkbox" name="MB" /> Mass Balance</label>
				<label class="inline"><input id="SG" type="checkbox" name="SG" /> Segregated</label>
				<label class="inline"><input id="IP" type="checkbox" name="IP" /> Identity Preserved</label>
			</div>-->
			
		</div>
		
		<script>
		var arr = [];
		remove_item = function(arr,value){
			for(b in arr ){
				if(arr[b] == value){
					arr.splice(b,1);
					break;
				}
			}
			return arr;
		}
		var inputs = document.getElementsByTagName("input");
		for(var i=0;i<inputs.length;i++)
		{
			if(inputs[i].getAttribute('type') == 'checkbox')
			{  inputs[i].addEventListener("change",function() {
				if(this.checked)
					arr.push(this.id);
				else
				{
					remove_item(arr,this.id);
				}
					console.log(arr);  document.getElementById("chcbxso").value = arr.join(",");
				},false);
			}
		}
		</script>
		
	<?php echo form_close(); ?>
</fieldset>