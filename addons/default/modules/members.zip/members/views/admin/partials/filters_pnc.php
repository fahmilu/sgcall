

<fieldset id="filters">
	
	<legend><?php echo lang('global:filters'); ?></legend>
	
	<?php echo form_open('admin/members/pncassessment/index'); ?>

	<?php echo form_hidden('f_module', $module_details['slug']); ?>
		<div style="display:block;width:22%;float:left;">
        	<?php echo lang('pnc:assessment_type_label', 'f_assessment_type'); ?><br/>
        	<?php echo form_dropdown('f_assessment_type', array(0 => lang('global:select-all'))+$assessment_type); ?>
    	</div>

		<div style="display:block;width:22%;float:left;">
        	<?php echo lang('pnc:assessment_status_label', 'f_assessment_type'); ?><br/>
        	<?php echo form_dropdown('f_assessment_status', array(0 => lang('global:select-all'))+$assessment_status); ?>
    	</div>

		<div style="display:block;width:22%;float:left;">
        	<label for="f_status">Status</label><br/>
        	<?php echo form_dropdown('f_status', array('all' => 'All', 'draft'=>'Draft', 'live'=>'Live')); ?>
    	</div>

		<div style="display:block;width:16%;float:left;">
        	<?php echo lang('pnc:keywords_label', 'f_keywords'); ?><br/>
			<?php echo form_input('f_keywords'); ?>
		</div>

		<div style="display:block;width:5%;float:left; margin-top:10px;">
			<label for="f_keywords"></label><br/>
			<?php echo anchor(current_url() . '#', lang('buttons:cancel'), 'class="cancel"'); ?>
		</div>
	<?php echo form_close(); ?>
</fieldset>
