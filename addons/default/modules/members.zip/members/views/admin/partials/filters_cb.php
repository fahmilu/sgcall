<style>
#filters form ul {
	display: block;
	clear: both;
}
#filters form ul li {
	min-width: 150px !important;
	line-height: normal;
	vertical-align: middle;
/* border: 1px solid red; */
}
#filters form ul li label {
	max-width: 250px !important;
	display: block;
	clear: both;
}
</style>

<fieldset id="filters">
	
	<legend><?php echo lang('global:filters'); ?></legend>
	
	<?php echo form_open('admin/members/cb/index'); ?>

	<?php echo form_hidden('f_module', $module_details['slug']); ?>
		<div style="display:block;width:25%;float:left;">
			<label for="f_status">Status</label><br/>
        	<?php echo form_dropdown('f_status', array(0 => 'All', 'draft'=>'Draft', 'live'=>'Live')); ?>
		</div>
		
		<div style="display:block;width:16%;float:left;">
        	<label for="f_keywords">Search</label><br/>
			<?php echo form_input('f_keywords'); ?>
		</div>
		
		<div style="display:block;width:25%;float:left; margin-top:10px;">
			<label for="f_keywords"></label><br/>
			<?php echo anchor(current_url() . '', lang('buttons:cancel'), 'class="cancel"'); ?>
		</div>
	<?php echo form_close(); ?>
</fieldset>