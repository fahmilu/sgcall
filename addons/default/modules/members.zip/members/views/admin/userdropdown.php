<?php echo form_dropdown('MemberID_2', $users, '', 'id="userunlink"'); ?>
<!--
	<br />
	<a title="Are you sure you want to unlink this user?" href="admin/members/userunlink/<?php echo $intID ?>" class="btn red xsmall unlinkuser">Unlink</a>
-->
