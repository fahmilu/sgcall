<style>
table td {vertical-align: top;}
</style>
<section class="title">
	<h4><?php echo lang('pnc:nav_pnc_assessment'); ?></h4>
	<div style="float: right;"><a href="#" id="poptest" class="btn blue">Left Nav.</a></div>
</section>

<section class="item">
<div class="content">

<?php if (!empty($pncs)) : ?>

	<?php echo $this->load->view('admin/partials/filters_pnc'); ?>

	<?php echo form_open('admin/members/pncassessment/action'); ?>
	<div id="filter-stage">

		<?php echo $this->load->view('admin/pnc/tables/pnc'); ?>
	
	</div>
	<?php echo form_close(); ?>

<?php else : ?>
	<div class="no_data"><?php echo lang('members:empty_membership_msg'); ?></div>
<?php endif; ?>

</div>
</section>

<div style="display:none;">
	<div id="coba">
		<ul>
			<li>
				R3P1 1
				<ul>
					<li><label><input name="leftnav" type="radio">About RSPO</label></li>
					<li><label><input name="leftnav" type="radio">Membership</label></li>
					<li><label><input name="leftnav" type="radio">Certification</label></li>
					<li>...</li>
				</ul>
			</li>
		</ul>
		<a class="btn green" href="#">Save</a>
	</div>
</div>

<script>
$('#poptest').colorbox({
	inline: true,
	href: '#coba',
	width: "600px",
	height: "600px"
});
</script>