<section class="title">
<?php if ($this->method == 'create'): ?>
	<h4><?php echo lang('pnc:create_title') . (!empty($member_name) ? ' - ' . $member_name : ''); ?></h4>
<?php else: ?>
	<h4><?php echo sprintf(lang('pnc:edit_title'), (!empty($member_name) ? $member_name : '') ); ?></h4>
<?php endif; ?>
</section>

<section class="item">
<div class="content">

<?php echo form_open_multipart(uri_string(), 'class="crud" name="pncForm" id="pncForm"'); ?>

<div class="tabs">

	<ul class="tab-menu">
		<li><a href="#pnc-info"><span>P&amp;C Info</span></a></li>
<!--		<li><a href="#pnc-stats"><span>P&amp;C Data</span></a></li>-->
	</ul>

<div class="form_inputs" id="pnc-info">
<fieldset>

	<ul>
		<li>
			<label for="online_status"><?php echo lang('pnc:status_label'); ?></label><br/>
			
			<label class="inline"><input name="online_status" value="draft" type="radio" <?php if($pnc->isUp == '0'){echo "checked = 'checked'";} elseif($pnc->isUp == ''){echo "checked = 'checked'";} else ''?>> Draft</label>
			<label class="inline"><input name="online_status" value="live" type="radio" <?php if($pnc->isUp == '1'){echo "checked = 'checked'";} else ''?>> Live</label>
			
			<!--<div class="input"><?php //echo form_dropdown('online_status', array('draft'=>'Draft', 'live'=>'Live'), $pnc->isUp ? 'live' : 'draft', 'id="online_status"') ?></div>-->
		</li>

		<li id="mill_info">
			<div class="mill_row" style="display:block;width:100%;clear:both;margin-bottom:10px;">
			<?php if (!empty($pnc->mill)): ?>
				<?php foreach($pnc->mill as $i=>$mill): ?>
					<div class="one_full" style="margin-bottom:0px;">
						<div class="one_half">
							<?php if ($i===0): ?><label for="nothing"><?php echo lang('pnc:mill_label'); ?></label><?php endif; ?>
							<div class="input"><?php echo form_input('mill[]', $mill['mill'], 'style="width:90%"') ?></div>
						</div>
						<div class="one_quarter">
							<?php if ($i===0): ?><label for="nothing">Mill's Country</label><?php endif; ?>
							<div class="input one_full" style="margin-bottom:0px;">
								<?php echo form_dropdown('mill_country[]', array(''=>'Please select')+$countries, $mill['mill_country']) ?>
							</div>
						</div>
						<div class="one_quarter">
							<div class="input" style="padding-top:8px;">
								<?php if ($i!==0): ?><a href="#" class="btn small inline red remove_mill" style="padding:2px 8px 5px;font-size:1.2em;">&times;</a><?php endif; ?>
							</div>
						</div>
					</div>
					<div class="clearfix"></div>
				<?php endforeach; ?>
			<?php else: ?>
				<div class="one_full" style="margin-bottom:0px;">
					<div class="one_half">
						<label for="nothing"><?php echo lang('pnc:mill_label'); ?></label>
						<div class="input"><?php echo form_input('mill[]', '', 'style="width:90%"') ?></div>
					</div>
					<div class="one_quarter">
						<label for="nothing">Mill's Country</label>
						<div class="input">
							<?php echo form_dropdown('mill_country[]', array(''=>'Please select')+$countries, '') ?>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
			<?php endif; ?>
			</div>
			<!-- <div class="clearfix"></div> -->
			<a href="#" class="btn small green add_mill">Add more mill &raquo;</a>
		</li>

		<li>
			<label for="member_name"><?php echo lang('pnc:member_label'); ?></label>
			<br /><small>Start typing below for auto-suggest</small>
			<div class="input">
				<?php echo form_input('member_name', !empty($member_name) ? $member_name : $pnc->member_name, 'id="member_name" style="width:50%"') ?>
				<input type="hidden" name="mid" value="<?php echo !empty($member_id) ? $member_id : $pnc->mid?>" id="member_id" />
			</div>
		</li>	

		<li>
			<label for="certification_body"><?php echo lang('pnc:cb_label'); ?></label>
			<br /><small>Start typing below for auto-suggest</small>
			<div class="input">
				<?php echo form_input('certification_body', $pnc->cb_id ? ($pnc->cb_name?$pnc->cb_name:$pnc->certification_body) : $pnc->certification_body, 'id="certification_body" style="width:50%"') ?>
				<input type="hidden" name="cb_id" value="<?php echo $pnc->cb_id?>" id="cb_id" />
			</div>
		</li>

		<li>
			<label for="assessment_type"><?php echo lang('pnc:assessment_type_label'); ?></label>
			<div class="input"><?php echo form_dropdown('assessment_type', array(''=>'Select type')+$assessment_type, $pnc->assessment_type, 'id="assessment_type"') ?><br />
				[ <a href="#" id="addnewtype">Add new type</a> ]
			</div>
		</li>

		<li>
			<label for="status"><?php echo lang('pnc:assessment_status_label'); ?><small>P&amp;C with "Notification" or "Both" status will appear on Public Announcement</small></label>
			<div class="input">
				<label class="inline"><input name="status" <?php echo $pnc->status=='notification'?'checked="checked"':'' ?> type="radio" value="notification">&nbsp;Notification</label>
				<label class="inline"><input name="status" <?php echo $pnc->status=='assessment'?'checked="checked"':'' ?> type="radio" value="assessment">&nbsp;Assessment</label>
				<label class="inline"><input name="status" <?php echo $pnc->status=='both'?'checked="checked"':'' ?> type="radio" value="both">&nbsp;Both Notification &amp; Assessment</label>
				<label class="inline"><input name="status" <?php echo $pnc->status=='terminated'?'checked="checked"':'' ?> type="radio" value="terminated"> Terminated</label>
				<label class="inline"><input name="status" <?php echo $pnc->status=='suspended'?'checked="checked"':'' ?> type="radio" value="suspended"> Suspended</label>
			<?php //echo form_dropdown('status', array(''=>'Select status')+$assessment_status, $pnc->status, 'id="status"') ?>
			</div>
		</li>

		<li>
			<?php $date = date_create($pnc->date);

			
			?>
			
			<div class="one_third">
				<label for="notification_date"><?php echo lang('pnc:date_notification_label'); ?></label>
				<div class="input"><?php echo form_input('notification_date', $pnc->notification_date ? date('Y-m-d', $pnc->notification_date) : '', 'id="notification_date" class="datepicker"') ?></div>
			</div>
			<div class="one_third">
				<label for="notification_date"><?php echo lang('pnc:end_notification_label'); ?></label>
				<div class="input"><?php echo form_input('notification_end', $pnc->notification_end ? date('Y-m-d', $pnc->notification_end) : '', 'id="notification_end" class="datepicker"') ?></div>
			</div>
			<div class="clearfix"></div>
		</li>
		
		<li>
			
			<div class="one_third">
				<label for="assessment_date"><?php echo lang('pnc:date_assessment_label'); ?></label>
				<div class="input"><?php echo form_input('assessment_date', $pnc->assessment_date ? date('Y-m-d', $pnc->assessment_date) : '', 'id="assessment_date" class="datepicker"') ?></div>
			</div>
			<div class="one_third">
				<label for="assessment_date"><?php echo lang('pnc:end_assessment_label'); ?></label>
				<div class="input"><?php echo form_input('assessment_end', $pnc->assessment_end ? date('Y-m-d', $pnc->assessment_end) : '', 'id="assessment_end" class="datepicker"') ?></div>
			</div>
			<div class="clearfix"></div>
		</li>
		
		<!--
		<li>
			<label for="subremarks"><?php echo lang('pnc:sub_remarks_label'); ?></label>
			<div class="input"><textarea name="subremarks" id="subremarks" class="one_half"><?php echo $pnc->subremarks; ?></textarea></div>
			<div class="clearfix"></div>
		</li>
		--> 
		
		<li>
			<label for="certificate"><?php echo lang('pnc:file_certificate_label'); ?></label>
			<div class="input"><?php echo form_upload('certificate'); ?></div>
			<?php if ($pnc->certificate_file): ?>
				<div class="input">Current certificate: <?php echo $pnc->certificate_file; ?></div>
				<?php echo form_hidden('certificate_file', $pnc->certificate_file); ?>
			<?php endif; ?>
		</li>

		<li>
			<label for="notification"><?php echo lang('pnc:file_notification_label'); ?></label>
			<div class="input">
				<div class="one_third">
					<?php echo form_upload('notification_file'); ?>
					<?php if ($pnc->notification): ?>
						<table>
							<thead>
							<tr>
								<th width="30">Del</th>
								<th>Current file</th>
							</tr>
							</thead>
							<tbody>
							
								<tr>
									<td><input type="checkbox" name="remove_notification_1" class="remove_uploaded" value="<?php echo $pnc->notification; ?>" /></td>
									<td>
										<?php echo wordwrap($pnc->notification, 25, "<br />\n", true); ?>
										<?php echo form_hidden('notification', $pnc->notification); ?>
										
									</td>
								</tr>
								
							</tbody>
						</table>
						<!-- <b>Current file:</b><br /><?php //echo wordwrap($pnc->notification, 30, "<br />\n", true); ?> -->

						<?php echo form_hidden('notification', $pnc->notification); ?>
					<?php endif; ?>
					<?php 
						if (isset($pnc->notification_old)) {
							echo form_hidden('notification_old', $pnc->notification_old); 
						}
					?>
				</div>

				<div class="one_third">
					<?php echo form_upload('notification_file_2'); ?>
					<?php if ($pnc->notification_2): ?>
						<table>
							<thead>
							<tr>
								<th width="30">Del</th>
								<th>Current file</th>
							</tr>
							</thead>
							<tbody>
							
								<tr>
									<td><input type="checkbox" name="remove_notification_2" class="remove_uploaded" value="<?php echo $pnc->notification_2; ?>" /></td>
									<td>
										<?php echo wordwrap($pnc->notification_2, 25, "<br />\n", true); ?>
										<?php echo form_hidden('notification_2', $pnc->notification_2); ?>
									</td>
								</tr>
								
							</tbody>
						</table>
						<!-- <b>Current file:</b><br /><?php //echo wordwrap($pnc->notification_2, 30, "<br />\n", true); ?> -->
						<?php echo form_hidden('notification_2', $pnc->notification_2); ?>
					<?php endif; ?>
					<?php 
						if (isset($pnc->notification_2_old)) {
							echo form_hidden('notification_2_old', $pnc->notification_2_old); 
						}
					?>
				</div>

				<div class="one_third">
					<?php echo form_upload('notification_file_3'); ?>
					<?php if ($pnc->notification_3): ?>
						<table>
							<thead>
							<tr>
								<th width="30">Del</th>
								<th>Current file</th>
							</tr>
							</thead>
							<tbody>
							
								<tr>
									<td><input type="checkbox" name="remove_notification_3" class="remove_uploaded" value="<?php echo $pnc->notification_3; ?>" /></td>
									<td>
										<?php echo wordwrap($pnc->notification_3, 25, "<br />\n", true); ?>
										<?php echo form_hidden('notification_3', $pnc->notification_3); ?>
									</td>
								</tr>
								
							</tbody>
						</table>
						
					<?php endif; ?>
					<?php 
						if (isset($pnc->notification_3_old)) {
							echo form_hidden('notification_3_old', $pnc->notification_3_old); 
						}
					?>
				</div>

			</div>
			<div class="clearfix"></div>
		</li>

		<li>
			<label for="uploaded"><?php echo lang('pnc:file_public_summary_report_label'); ?></label>
			<!-- <div class="input">
				<ul>
					<li><small>You can select more than one file. Press Ctrl (or Cmd on Mac) while selecting the files you want to upload.</small><br /><input type="file" multiple="multiple" name="uploaded_files[]" multiple />
					</li>
				</ul>
			</div> -->
			

			<?php //if (!empty($pnc->uploaded)): ?>
				<?php //echo form_hidden('uploaded', $pnc->uploaded); ?>
				<!-- <div class="input"> -->
				<?php //$upfiles = explode(',', $pnc->uploaded); ?>
				<!-- <table class="one_half">
					<thead>
					<tr>
						<th width="30">Remove</th>
						<th>Current file</th>
					</tr>
					</thead>
					<tbody> -->
					<?php //foreach($upfiles as $f): ?>
						<?php //if ($f): ?>
						<!-- <tr>
							<td><input type="checkbox" name="remove_uploaded[]" class="remove_uploaded" value="<?php //echo $f; ?>" /></td>
							<td> -->
								<?php //echo str_ireplace('/sites/default/files/', '', $f); ?>
<!-- 								<input type="hidden" name="uploaded[]" value="<?php echo $f ?>" /> -->
							<!-- </td>
						</tr> -->
						<?php //endif; ?>
					<?php //endforeach; ?>
					<!-- </tbody>
				</table>
				</div> -->
			<?php //endif; ?>
			<!-- <div class="clearfix"></div> -->


			<div class="uploaded_row" style="display:block;width:100%;clear:both;margin-bottom:10px;">
				<?php if (!empty($pnc->uploaded)): ?>
					<?php echo form_hidden('uploaded', $pnc->uploaded); ?>

					<?php $upfiles = explode(',', $pnc->uploaded); ?>

					<div class="wrap_uploaded one_full" style="margin-bottom:0px;">
						<input type="file" multiple="multiple" name="uploaded_files[]" multiple />
					</div>
					
					<div style="width: 100%; margin: 5px 0 5px">
						<table class="one_half">
							<thead>
							<tr>
								<th width="30">Remove</th>
								<th>Current file</th>
							</tr>
							</thead>
							<tbody>
					<?php foreach($upfiles as $f): ?>
						<?php if ($f): ?>
										<tr>
											<td>
												<input type="checkbox" name="remove_uploaded[]" class="remove_uploaded" value="<?php echo $f; ?>" />
												<input type="hidden" name="old_uploaded[]" value="<?php echo $f; ?>" />
											</td>
											<td>
												<?php echo str_ireplace('/sites/default/files/', '', $f); ?>
											</td>
										</tr>
										
						<?php endif; ?>
					<?php endforeach; ?>
							</tbody>
						</table>
					</div>	
					<div class="clearfix"></div>
					<div class="clearfix"></div>
				<?php else: ?>
					<div class="wrap_uploaded one_full" style="margin-bottom:0px;">
						<input type="file" multiple="multiple" name="uploaded_files[]" multiple />
					</div>
				<?php endif; ?>
			</div>
			<a href="#" class="btn small green add_uploaded">Add more Summary Report &raquo;</a>


		</li>

		<li>
			<label for="final_report_date"><?php echo lang('pnc:date_final_report_label'); ?></label>
			<div class="input"><?php echo form_input('final_report_date', $pnc->final_report_date ? date('Y-m-d', $pnc->final_report_date) : '', 'id="final_report_date" class="datepicker"') ?></div>
		</li>

		<li>
			<label for="remarks"><?php echo lang('pnc:remarks_label'); ?></label>
			<div class="input"><textarea name="remarks" id="remarks" class="one_half"><?php echo $pnc->remarks; ?></textarea></div>
			<div class="clearfix"></div>
		</li>

		<li>
			<label for="report_accepted_date"><?php echo lang('pnc:date_report_accepted'); ?></label>
			<div class="input"><?php echo form_input('report_accepted_date', $pnc->report_accepted_date ? date('Y-m-d', $pnc->report_accepted_date) : '', 'id="report_accepted_date" class="datepicker"') ?></div>
		</li>

	</ul>

</fieldset>
</div>

<!--<div class="form_inputs" id="pnc-stats">-->
<!--<fieldset>-->
<!--	<ul>-->
<!---->
<!--		<li>-->
<!--			<label for="scc_model">Supply Option</label>-->
<!--			<div class="input">-->
<!--				--><?php //$pnc_so = explode(',', $pnc->scc_model); ?>
<!--				--><?php //if ($supply_options): ?>
<!--					--><?php //foreach($supply_options as $so): ?>
<!--						--><?php //$checked = in_array($so, $pnc_so)  ? 'checked="checked"' : ''; ?>
<!--						<label class="inline"><input --><?php //echo $checked ?><!-- type="checkbox" name="scc_model[]" value="--><?php //echo $so?><!--"> --><?php //echo $so?><!--</label>-->
<!--					--><?php //endforeach; ?>
<!--				--><?php //endif;?>
<!--			</div>-->
<!--		</li>-->
<!---->
<!--		<li>-->
<!--			<label for="certified_area">Certified Area</label>-->
<!--			<div class="input">--><?php //echo form_input('certified_area', $pnc->certified_area<>'0.00'?$pnc->certified_area:'', 'id="certified_area"') ?><!-- (ha)</div>-->
<!--		</li>-->
<!---->
<!--		<li>-->
<!--			<label for="production_area">Production Area</label>-->
<!--			<div class="input">--><?php //echo form_input('production_area', $pnc->production_area<>'0.00'?$pnc->production_area:'', 'id="production_area"') ?><!-- (ha)</div>-->
<!--		</li>-->
<!---->
<!--		<li>-->
<!--			<label for="cspo">Certified Volume (CSPO)</label>-->
<!--			<div class="input">--><?php //echo form_input('cspo', $pnc->cspo<>'0.00'?$pnc->cspo:'', 'id="cspo"') ?><!-- (tonnes)</div>-->
<!--		</li>-->
<!---->
<!--		<li>-->
<!--			<label for="cspk">Certified Volume (CSPK)</label>-->
<!--			<div class="input">--><?php //echo form_input('cspk', $pnc->cspk<>'0.00'?$pnc->cspk:'', 'id="cspk"') ?><!-- (tonnes)</div>-->
<!--		</li>-->
<!---->
<!--	</ul>-->
<!--</fieldset>-->
<!--</div>-->

</div>

<div class="buttons">
	<?php $this->load->view('admin/partials/buttons', array('buttons' => array('save', 'save_exit', 'cancel'))) ?>
</div>

<?php echo form_close(); ?>

<!-- Add More Summary -->
<div style="display: none;">
	<div id="more_uploaded">
		<div class="wrap_uploaded one_full" style="margin-bottom:0px;">
			<div style="float: left; width: 40%">
				<div class="input">
					<input type="file" multiple="multiple" name="uploaded_files[]" multiple />
				</div>
			</div>
			<div style="width: auto; float: left">
				<div class="input" style="padding-top:8px;">
					<a href="#" class="btn small inline red remove_uploaded" style="padding:3px 9px 6px;font-size:1.2em;">&times;</a>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!-- /Add More Summary -->

<script>
(function($) {
	$(function(){

		$('.datepicker').datepicker({
			dateFormat: 'yy-mm-dd'
		})

		$( "#member_name" ).autocomplete({
			source: SITE_URL + 'admin/members/pick',
			minLength: 2,
			select: function( event, ui ) {
				$('#member_id').val(ui.item.id);
			}
		});

		$('#notification_date').change(function() {
			var notification_date = new Date($('#notification_date').val());

			notification_date.setMonth(notification_date.getMonth() + 1);
			var notification_date_next = notification_date.getFullYear() + '-' + (notification_date.getMonth() + 1) + '-' + notification_date.getDate();
			var new_notification_date = new Date(notification_date_next);

			$('#notification_end').val(new_notification_date.toString('yyyy-MM-dd'));
		});

		$('#assessment_date').change(function() {
			if ($('#assessment_date').val())
			{
				var assessment_date = new Date($('#assessment_date').val());
				var assessment_date_next = (assessment_date.getFullYear() + 1) + '-' + (assessment_date.getMonth()+1) + '-' + assessment_date.getDate();
				var new_assessment_date = new Date(assessment_date_next);
				$('#assessment_end').val(new_assessment_date.toString('yyyy-MM-dd'));
			}
			else
			{
				$('#assessment_end').val('');
			}
		});

		$( "#certification_body" ).autocomplete({
			source: SITE_URL + 'admin/members/cb/pick',
			minLength: 1,
			select: function( event, ui ) {
				$('#cb_id').val(ui.item.id);
			},
			change: function( event, ui ) {
				if (ui.item==undefined)
					$('#cb_id').val('');
				else
					$('#cb_id').val(ui.item.id);
			},
		});

		// Summary Report
		$('a.remove_uploaded').livequery('click', function(e){
				e.preventDefault();
				if (confirm('Are you sure you want to delete this file?'))
				{
					$(this).parent().parent().parent().fadeOut('fast', function(){
						$(this).remove().empty();
					});
				}
				else
				{
					return false;
				}
		});

		$('a.add_uploaded').click(function(e){
				e.preventDefault();
				var h = $('#more_uploaded').html();
				$('.uploaded_row').append(h);
				
		});

		// add upload file
		$('a.addrow').on('click', function(e){
			e.preventDefault();
			var li = $(this).prev().children('li').html();
			$(this).prev().append('<li>'+li+'<a href="#" class="btn small red removerow">[-]</a></li>');
		});

		$('a.removerow').livequery('click', function(e){
			e.preventDefault();
			$(this).parent().fadeOut('slow', function(){
				$(this).empty().remove();
			})
		});

		$('.removefile').click(function(e){
			var c = $(this).is(':checked');
			var u = $(this).parent().parent().children('.uploadfield');
			if (c)
			{
				$('input', u).fadeTo('fast', 1);
			}
			else
			{
				$('input', u).fadeTo('fast', 0);
			}
		});

		$('a.add_mill').click(function(e){
			e.preventDefault();
			var h = $('#more_mill').html();
			$('.mill_row').append(h);
			var s = $('.mill_row select[name="mill_country[]"]');
			s.each(function(){
				$(this).removeClass('skip');
			});
			s.trigger("liszt:updated");
		});

		$('a.remove_mill').livequery('click', function(e){
			e.preventDefault();
			if (confirm('Are you sure you want to delete this mill?'))
			{
				$(this).parent().parent().parent().fadeOut('fast', function(){
					$(this).remove().empty();
				});
			}
			else
			{
				return false;
			}
		});


	});
})(jQuery);
</script>

<div style="display:none">

	<div id="more_mill">
					<div class="one_full" style="margin-bottom:0px;">
						<div class="one_half">
<!-- 							<label for="nothing"><?php echo lang('pnc:mill_label'); ?></label> -->
							<div class="input"><?php echo form_input('mill[]', '', 'style="width:90%"') ?></div>
						</div>
						<div class="one_quarter">
<!-- 							<label for="nothing">Mill's Country</label> -->
							<div class="input" style="margin-bottom:0px;">
								<?php echo form_dropdown('mill_country[]', array(''=>'Please select')+$countries, '', 'class="skip mill_country"') ?>
							</div>
						</div>
						<div class="one_quarter">
							<div class="input" style="padding-top:8px;">
								<a href="#" class="btn small inline red remove_mill" style="padding:3px 9px 6px;font-size:1.2em;">&times;</a>
							</div>
						</div>
					</div>
					<div class="clearfix"></div>
	</div>

</div>

</div>
</section>