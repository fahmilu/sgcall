<style>
tr.deleted_members td {
	color: #888 !important;
	font-style: italic;
}
tr.pending_members td {
	color: #888 !important;
}
</style>
<section class="title">
	<h4>Member Survey Statistics</h4>
</section>

<section class="item">
<div class="content">

<div class="three_quarter">
<div class="one_half">

	<h3>Registration</h3>

	<h4>Total registration by Category:</h4>

<?php
		if (!empty($tr_category))
		{
			$tr_category_total = 0;
			foreach($tr_category as $m)
			{
				echo $m->thekey . ': '.$m->total_members.'<br />'.PHP_EOL;
				$tr_category_total += $m->total_members;
			}
			echo '<hr style="width:250px;margin:5px 0;" />'.PHP_EOL;
			echo "<b>Total: $tr_category_total</b><br />";
		}
?>

	<h4>Total registration by Sector:</h4>

<?php
		if (!empty($tr_sector))
		{
			$tr_sector_total = 0;
			foreach($tr_sector as $m)
			{
				echo $m->thekey . ': '.$m->total_members.'<br />'.PHP_EOL;
				$tr_sector_total += $m->total_members;
			}
			echo '<hr style="width:250px;margin:5px 0;" />'.PHP_EOL;
			echo "<b>Total: $tr_sector_total</b><br />";
		}
?>

	<h4>Total registration by Country:</h4>

<?php
		if (!empty($tr_country))
		{
			$tr_country_total = 0;
			foreach($tr_country as $m)
			{
				echo $m->thekey . ': '.$m->total_members.'<br />'.PHP_EOL;
				$tr_country_total += $m->total_members;
			}
			echo '<hr style="width:250px;margin:5px 0;" />'.PHP_EOL;
			echo "<b>Total: $tr_country_total</b><br />";
		}
?>

</div>

<div class="one_half">

	<h3>Completed Surveys</h3>

	<h4>Survey completed by Category:</h4>

<?php
		if (!empty($sc_category))
		{
			$sc_category_total = 0;
			foreach($sc_category as $m)
			{
				echo $m->thekey . ': '.$m->total_members.'<br />'.PHP_EOL;
				$sc_category_total += $m->total_members;
			}
			echo '<hr style="width:250px;margin:5px 0;" />'.PHP_EOL;
			echo "<b>Total: $sc_category_total</b><br />";
		}
?>

	<h4>Survey completed by Sector:</h4>

<?php
		if (!empty($sc_sector))
		{
			$sc_sector_total = 0;
			foreach($sc_sector as $m)
			{
				echo $m->thekey . ': '.$m->total_members.'<br />'.PHP_EOL;
				$sc_sector_total += $m->total_members;
			}
			echo '<hr style="width:250px;margin:5px 0;" />'.PHP_EOL;
			echo "<b>Total: $sc_sector_total</b><br />";
		}
?>

	<h4>Survey completed by Country:</h4>

<?php
		if (!empty($sc_country))
		{
			$sc_country_total = 0;
			foreach($sc_country as $m)
			{
				echo $m->thekey . ': '.$m->total_members.'<br />'.PHP_EOL;
				$sc_country_total += $m->total_members;
			}
			echo '<hr style="width:250px;margin:5px 0;" />'.PHP_EOL;
			echo "<b>Total: $sc_country_total</b><br />";
		}
?>

</div>

<div class="clearfix"></div>

<hr />

<div class="one_half">

	<h3>Completed Surveys as Parent</h3>

	<h4>Survey completed as Parent by Category:</h4>

<?php
		if (!empty($sc_parent_category))
		{
			$sc_parent_category_total = 0;
			foreach($sc_parent_category as $m)
			{
				echo $m->thekey . ': '.$m->total_members.'<br />'.PHP_EOL;
				$sc_parent_category_total += $m->total_members;
			}
			echo '<hr style="width:250px;margin:5px 0;" />'.PHP_EOL;
			echo "<b>Total: $sc_parent_category_total</b><br />";
		}
?>

	<h4>Survey completed as Parent by Sector:</h4>

<?php
		if (!empty($sc_parent_sector))
		{
			$sc_parent_sector_total = 0;
			foreach($sc_parent_sector as $m)
			{
				echo $m->thekey . ': '.$m->total_members.'<br />'.PHP_EOL;
				$sc_parent_sector_total += $m->total_members;
			}
			echo '<hr style="width:250px;margin:5px 0;" />'.PHP_EOL;
			echo "<b>Total: $sc_parent_sector_total</b><br />";
		}
?>

	<h4>Survey completed as Parent by Country:</h4>

<?php
		if (!empty($sc_parent_country))
		{
			$sc_parent_country_total = 0;
			foreach($sc_parent_country as $m)
			{
				echo $m->thekey . ': '.$m->total_members.'<br />'.PHP_EOL;
				$sc_parent_country_total += $m->total_members;
			}
			echo '<hr style="width:250px;margin:5px 0;" />'.PHP_EOL;
			echo "<b>Total: $sc_parent_country_total</b><br />";
		}
?>

</div>


<div class="one_half">

	<h3>Draft Surveys as Parent</h3>

	<h4>Draft Survey as Parent by Category:</h4>

<?php
		if (!empty($draft_category))
		{
			$draft_category_total = 0;
			foreach($draft_category as $m)
			{
				echo $m->thekey . ': '.$m->total_members.'<br />'.PHP_EOL;
				$draft_category_total += $m->total_members;
			}
			echo '<hr style="width:250px;margin:5px 0;" />'.PHP_EOL;
			echo "<b>Total: $draft_category_total</b><br />";
		}
?>

	<h4>Draft Survey as Parent by Sector:</h4>

<?php
		if (!empty($draft_sector))
		{
			$draft_sector_total = 0;
			foreach($draft_sector as $m)
			{
				echo $m->thekey . ': '.$m->total_members.'<br />'.PHP_EOL;
				$draft_sector_total += $m->total_members;
			}
			echo '<hr style="width:250px;margin:5px 0;" />'.PHP_EOL;
			echo "<b>Total: $draft_sector_total</b><br />";
		}
?>

	<h4>Draft Survey as Parent by Country:</h4>

<?php
		if (!empty($draft_country))
		{
			$draft_country_total = 0;
			foreach($draft_country as $m)
			{
				echo $m->thekey . ': '.$m->total_members.'<br />'.PHP_EOL;
				$draft_country_total += $m->total_members;
			}
			echo '<hr style="width:250px;margin:5px 0;" />'.PHP_EOL;
			echo "<b>Total: $draft_country_total</b><br />";
		}
		else
		{
			if (!empty($draft_sector_error))
			{
				echo '<div class="alert error"><pre>';
				print_r($draft_sector_error);
				echo'</pre></div>'.PHP_EOL;
			}
			else
				echo '<div class="alert warning">Sorry we were unable to extract the data</div>'.PHP_EOL;
		}
?>

</div>

</div>

<div class="clearfix"></div>

</div>
</section>