<?php
$additional_files_list = array(
    'Latest Annual Report or Shareholder documents (required document for subsidiary inclusion in Group Membership).',
    'Organisation status (corporate and ownership structure).',
    'Disclosure of existing field practices and policies of Corporate Social Responsibility (CSR)/ sustainability policy.',
    'Additional information such as legally set aside area (eg. riparian, hill slope, deep peat etc.) and settlements within their concession (if any).',
);
?><!-- docs opg_sm_business_registration -->
<p style="font-size:14px;">Please attach proof of business registration (e.g. certificate of incorporation, certificate of good standing, article of incorporation or other similar documents)</p>

<?php if (!empty($membersapp->opg_sm_business_registration)): ?>
    <?php echo form_hidden('opg_sm_business_registration', $membersapp->opg_sm_business_registration); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sm_business_registration))) ?>" target="_blank"><?php echo $membersapp->opg_sm_business_registration; ?></a>
    <div class="clear"></div>
<?php endif; ?>

<input type="file" name="opg_sm_business_registration" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">

<!-- docs opg_sm_disclosure_cleared_area -->
<p style="font-size:14px;">Reporting Template for Disclosure of Areas Cleared without Prior HCV Assessment since November 2005 (Smallholders). Click here to download template.</p>

<?php if (!empty($membersapp->opg_sm_disclosure_cleared_area)): ?>
    <?php echo form_hidden('opg_sm_disclosure_cleared_area', $membersapp->opg_sm_disclosure_cleared_area); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sm_disclosure_cleared_area))) ?>" target="_blank"><?php echo $membersapp->opg_sm_disclosure_cleared_area; ?></a>
    <div class="clear"></div>
<?php endif; ?>

<input type="file" name="opg_sm_disclosure_cleared_area" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">

<!-- docs opg_sm_sg_agreed -->
<p style="font-size:14px;">Please attach clear evidence that members of the Smallholders Group has agreed to appoint the applicant to act as their Group Manager (e.g Official minutes of meeting)</p>

<?php if (!empty($membersapp->opg_sm_sg_agreed)): ?>
    <?php echo form_hidden('opg_sm_sg_agreed', $membersapp->opg_sm_sg_agreed); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sm_sg_agreed))) ?>" target="_blank"><?php echo $membersapp->opg_sm_sg_agreed; ?></a>
    <div class="clear"></div>
<?php endif; ?>

<input type="file" name="opg_sm_sg_agreed" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">

<!-- docs opg_sm_gm_statement -->
<p style="font-size:14px;">The Group Manager to provide a statement to declare that they will represent the Smallholders Group with integrity and commit to the RSPO standards.</p>

<?php if (!empty($membersapp->opg_sm_gm_statement)): ?>
    <?php echo form_hidden('opg_sm_gm_statement', $membersapp->opg_sm_gm_statement); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sm_gm_statement))) ?>" target="_blank"><?php echo $membersapp->opg_sm_gm_statement; ?></a>
    <div class="clear"></div>
<?php endif; ?>

<input type="file" name="opg_sm_gm_statement" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">

<!-- docs opg_sm_sg_list -->
<p style="font-size:14px;">Provide a list of all members in the Smallholder Group with their individual land details (size of land and land registration number). This list must be signed by the appointed Group Manager.</p>

<?php if (!empty($membersapp->opg_sm_sg_list)): ?>
    <?php echo form_hidden('opg_sm_sg_list', $membersapp->opg_sm_sg_list); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sm_sg_list))) ?>" target="_blank"><?php echo $membersapp->opg_sm_sg_list; ?></a>
    <div class="clear"></div>
<?php endif; ?>

<input type="file" name="opg_sm_sg_list" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">

<!-- docs opg_sm_names_reff -->
<p style="font-size:14px;">For internal review purposes, please provide 2 names for your membership application reference. Please download Reference Template <a href="{{ url:site }}files/download/d0f2eb950a48044">here</a>*.</p>

<?php if (!empty($membersapp->opg_sm_names_reff)): ?>
    <?php echo form_hidden('opg_sm_names_reff', $membersapp->opg_sm_names_reff); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sm_names_reff))) ?>" target="_blank"><?php echo $membersapp->opg_sm_names_reff; ?></a>
    <div class="clear"></div>
<?php endif; ?>

<input type="file" name="opg_sm_names_reff" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">
