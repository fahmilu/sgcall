<?php
// additional file list sector Ordinary
$additional_files_list = array(
    'Latest Annual Report or Shareholder documents (required document for subsidiary inclusion in Group Membership).',
    'Organisation status (corporate and ownership structure).',
    'Disclosure of existing field practices and policies of Corporate Social Responsibility (CSR)/ sustainability policy.',
); ?>
<!-- docs sector_business_registration -->
<p style="font-size:14px;">Please attach proof of business registration (e.g. certificate of incorporation, certificate of good standing, article of incorporation or other similar documents)</p>

<?php if (!empty($membersapp->sector_business_registration)): ?>
    <?php echo form_hidden('sector_business_registration', $membersapp->sector_business_registration); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->sector_business_registration))) ?>" target="_blank"><?php echo $membersapp->sector_business_registration; ?></a>
    <div class="clear"></div>
<?php endif; ?>

<input type="file" name="sector_business_registration" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">