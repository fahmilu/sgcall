<section class="title">
    <?php if ($this->method == 'create'): ?>
        <h4><?php echo lang('score:create_title') . (!empty($member_name) ? ' - ' . $member_name : ''); ?></h4>
    <?php else: ?>
        <h4><?php echo sprintf(lang('score:edit_title'), word_limiter($member_name, 30)); ?></h4>
    <?php endif; ?>
</section>

<style>
    .required_field{
        color:red;
    }
</style>

<section class="item">
    <div class="content">

        <?php echo form_open_multipart(uri_string(), 'class="crud" name="scoreForm" id="scoreForm"'); ?>

        <fieldset>
            <div class="form_inputs">

                <ul>

                    <li>
                        <label for="member_name"><?php echo lang('score:member_label'); ?><span class="required_field">*</span></label>
                        <br /><small>Start typing below for auto-suggest</small>
                        <div class="input">
                            <?php echo form_input('member_name', !empty($member_name) ? $member_name : set_value('member_name'), 'id="member_name"') ?>
                            <input type="hidden" name="member_id" value="<?php echo !empty($member_id) ? $member_id : set_value('member_id') ?>" id="member_id" />
                        </div>
                    </li>
                    <li>
                        <label for="notification"><?php echo lang('score:files_label'); ?></label>
                        <div class="clearfix"><br /></div>
                        <div class="input">
                            <div class="third score_card_row">
                                <?php if (!empty($member->acop_score_card)): ?>
                                    <?php foreach (explode(';', $member->acop_score_card) as $score): ?>
                                        <?php if (!empty($score)): ?>
                                        <div class="one_full"  style="margin-bottom: 0px">
                                            <div class="input">
                                                Current file: <a href="<?php echo site_url('uploads/default/members_score/'.$score) ?>" target="_blank"><?php echo $score ?></a>
                                                &nbsp;<a href="#" class="remove_score_card"> [X]</a>
                                                <?php echo form_hidden('acop_score_card[]', $score); ?>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                      <?php endif; ?>
                                    <?php endforeach; ?>
                                    <?php else: ?>
                                    <?php echo form_upload('scores[]'); ?>
                                <?php endif;  ?>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </li>
                    <a href="#" class="btn small green add_score_card">Add more file</a>
                </ul>

            </div>
        </fieldset>

        <div class="buttons">
            <?php $this->load->view('admin/partials/buttons', array('buttons' => array('save', 'save_exit', 'cancel'))) ?>
        </div>

        <?php echo form_close(); ?>

        <div style="display:none">
            <div id="more_score_card">
                <div class="one_full"  style="margin-bottom: 0px">
                    <div class="input">
                        <?php echo form_upload('scores[]'); ?>
                        &nbsp;<a href="#" class="remove_score_card"> [X]</a>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>

        <style>
            ul.ui-autocomplete.ui-menu.ui-widget-content {
                max-height: 200px;
                overflow-y: auto;
                overflow-x: hidden;
            }
        </style>
        <script>
            (function($) {

                $('a.add_score_card').click(function(e){
                    e.preventDefault();

                    var h = $('#more_score_card').html();

                    $('.score_card_row').append(h);
                });

                $('a.remove_score_card').livequery('click', function(e){
                    e.preventDefault();
                    if (confirm('Are you sure you want to delete this score_card?'))
                    {
                        $(this).parent().parent().fadeOut('fast', function(){
                            $(this).remove().empty();
                        });
                    }
                    else
                    {
                        return false;
                    }
                });

                $(function(){
                    $( "#member_name" ).autocomplete({
                        source: SITE_URL + 'admin/members/score/pick',
                        minLength: 2,
                        maxHeight: "250px",
                        select: function( event, ui ) {
                            $('#member_id').val(ui.item.id);
                        }
                    });

                });
            })(jQuery);
        </script>

    </div>
</section>