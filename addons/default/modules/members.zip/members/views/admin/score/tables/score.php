<?php if (!empty($members)) : ?>
    <table border="0" class="table-list">
        <thead>
        <tr>
            <th class="collapse">Member's Name</th>
            <th class="collapse">Score Card</th>
            <th class="collapse">Add Date</th>
            <th class="collapse">Modified Date</th>
            <th><?php echo lang('global:actions') ?></th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <td colspan="8">
                <div class="inner"><?php $this->load->view('admin/partials/pagination'); ?></div>
            </td>
        </tr>
        </tfoot>
        <tbody>
        <?php foreach ($members as $member) : ?>
            <tr>
                <td class="collapse"><?php echo $member->title ?></td>
                <td class="collapse">
                <?php foreach (explode(';', $member->acop_score_card) as $score): ?>
                    <li><a href="<?php echo site_url('uploads/default/members_score/'.$score) ?>" target="_blank"><?php echo $score ?></a></li>
                <?php endforeach; ?>
                </td>
                <td class="collapse"><?php echo date('d-M-Y G:i:s', $member->acop_score_card_addDate) ?></td>
                <td class="collapse"><?php echo date('d-M-Y G:i:s', $member->acop_score_card_modifiedDate) ?></td>
                <td style="padding-top:10px;">
                    <?php echo anchor('admin/members/score/edit/'.$member->intID, 'Edit', 'class="button"').' '; ?>
                    <?php echo anchor('admin/members/score/delete/'.$member->intID, 'Delete', 'class="button confirm"').' '; ?>
                </td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>
<?php else : ?>
    <div class="no_data">No Score Card found</div>
<?php endif ?>