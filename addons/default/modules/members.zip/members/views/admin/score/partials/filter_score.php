<fieldset id="filters">
    <legend><?php echo lang('global:filters'); ?></legend>

    <?php echo form_open('admin/members/score/index'); ?>

    <?php echo form_hidden('f_module', $module_details['slug']); ?>

    <div style="display:block;width:16%;float:left;">
        <?php echo lang('score:keywords_label', 'f_keywords'); ?><br/>
        <?php echo form_input('f_keywords'); ?>
    </div>

    <div style="display:block;width:5%;float:left; margin-top:10px;">
        <label for="f_keywords"></label><br/>
        <?php echo anchor(current_url() . '#', lang('buttons:cancel'), 'class="cancel"'); ?>
    </div>
    <?php echo form_close(); ?>
</fieldset>