<section class="title">
	<h4><?php echo lang('score:nav_score'); ?></h4>
</section>

<section class="item">
<div class="content">
    <?php echo $this->load->view('admin/score/partials/filters'); ?>
	<div id="filter-stage">
		<?php echo $this->load->view('admin/score/tables/score'); ?>
	</div>

</div>
</section>