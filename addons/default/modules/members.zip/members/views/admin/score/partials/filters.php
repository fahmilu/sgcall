<fieldset id="filters">
    <legend><?php echo lang('global:filters'); ?></legend>
    <?php echo form_open(''); ?>
        <div style="display:block;width:20%;float:left;">
            <label for="f_keywords"><?php echo lang('score:keywords_label', 'f_keywords'); ?></label><br/>
            <?php echo form_input('f_keywords'); ?>
        </div>
        <div style="display:block;width:5%;float:left; margin-top:25px;">
            <?php echo anchor(current_url(), lang('buttons:cancel'), 'class="cancel"'); ?>
        </div>
    <?php echo form_close(); ?>
    <br class="clear-both">
</fieldset>
