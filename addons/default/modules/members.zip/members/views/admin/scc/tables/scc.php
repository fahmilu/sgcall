<!--<small>Number of data: <?php //echo number_format($count); ?></small>-->

	<table>
		<thead>
			<tr>
				<th width="20"><?php echo form_checkbox(array('name' => 'action_to_all', 'class' => 'check-all')); ?></th>
				<th width="50" class="collapse">Date</th>
				<th width="150" class="collapse">Member's Name</th>
				<th class="collapse">Facility</th>
				<th width="100" class="collapse">Supply Options</th>
				<!--<th class="collapse">File(s)</th>-->
				<th width="100" class="collapse">Approval Date</th>
				<th width="100" class="collapse">Expiry Date</th>
				<th class="collapse">Status</th>
				<th width="200">Actions</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="9">
					<div class="inner"><?php $this->load->view('admin/partials/pagination'); ?></div>
				</td>
			</tr>
		</tfoot>
		<tbody>
			<?php foreach ($sccs as $scc) : ?>
				<tr>
					<td><?php echo form_checkbox('action_to[]', $scc->id); ?></td>
					<td class="collapse"><?php echo $scc->strModifyDate; ?></td>
					<td class="collapse"><?php echo $scc->member_name; ?></td>
					<td class="collapse" width="250"><?php echo $scc->facility; ?></td>
					<td class="collapse" width="250">
					<?php
						$scc_so2 = str_ireplace(array("\r", "\n"), ",", $scc->supply_option);
						$scc_so1 = str_ireplace(",,", ",", $scc_so2);
						
						$scc_so3 = explode(',', $scc_so1);
						
						//$scc_so = array_filter( $scc_so );
						
						foreach ($scc_so3 as $id => $name):
							if($name == 'MB'){ echo 'Mass Balance, ';}
							if($name == 'SG'){ echo 'Segregated, ';}
							if($name == 'IP'){ echo 'Identity Preserved, ';}
							if($name == 'B&C'){ echo 'Book &amp; Claim, ';}
							
							if($name == 'Mass Balance'){ echo 'Mass Balance, ';}
							if($name == 'Segregated'){ echo 'Segregated, ';}
							if($name == 'Identity Preserved'){ echo 'Identity Preserved, ';}
							if($name == 'Book &amp; Claim'){ echo 'Book &amp; Claim, ';}
						endforeach;
					?>
					</td>
					<td class="collapse"><?php echo $scc->approval_date ? date('d-M-Y', $scc->approval_date) : '--'; ?></td>
					<td><?php echo $scc->certification_expiry_date ? date('d-M-Y', $scc->certification_expiry_date) : '--'; ?></td>
					
					<!--<td class="collapse">
					<ul>
						<?php
						if ($scc->file)
						{
							$ff = ($scc->file ? ','.$scc->file:'')
							.($scc->file_2 ? ','.$scc->file_2:'') .($scc->file_3 ? ','.$scc->file_3:'') 
							;
							$files = explode(',' , $ff);
							//echo ''.PHP_EOL;

							foreach($files as $key => $file){
								if ($file)
								{
									$pos = strpos($file, '/', 1);
									//$pos = 1;
				                	if ($pos OR $pos === 0)
				                	{
				                		$fname = substr(strrchr($file, "/"), 1);
				                		$furl = $file;
				                		//$fname = ltrim($file, "/");
				                	}
				                	else
				                	{
				                		$fname = $file;
				                		$furl = site_url(UPLOAD_PATH.'scc/'.$fname);
				                		//$fname = ltrim($file, "/");
				                	}

									$filesize = '';

/*
									if (file_exists($fullname.$fname) && is_file($fullname.$fname))
									{
										$filesize = ' ('.human_filesize(filesize($fullname.$fname)).')';
									}
									else
										$filesize = '';
*/
		
									$charlimit = 18;
									if (strlen($fname) > $charlimit)
										$fnamev = substr($fname, 0, $charlimit) . '&#8230;';
									else
										$fnamev = $fname;
		
									//echo "<a title=\"".$fname."$filesize\" target='_blank' href='".site_url(UPLOAD_PATH.'scc/'.$fname)."'>View ".$filesize."</a>";
									//echo "<a title=\"".$fname."$filesize\" target='_blank' href='".site_url($fname)."'>$fname ".$filesize."</a><br />";
									echo "<li><a title=\"".$fname."$filesize\" target='_blank' href='".$furl."'> ".$fnamev." ".$filesize."</a></li>";
								}
								else
									continue;
			                }

			                //$item = '<ul class="list-group"><li>'.$certfile.'</li><li>'.implode('</li><li>', $files).'</li></ul>';
			                //$item =  
						//echo $item;
						}
						else
						{
							echo "--";
						}
						?>

					</ul>
					</td>-->
					<td class="collapse"><?php echo $scc->isUp ? 'Live' : 'Draft'; ?></td>
					<td>
						<?php
						echo anchor('admin/members/scc/view/'.$scc->id, lang('global:view'), 'class="button modal" target="_blank"').' ';
						echo anchor('admin/members/scc/edit/'.$scc->id, lang('global:edit'), 'class="button"').' ';
						echo anchor('admin/members/scc/delete/'.$scc->id, lang('global:delete'), 'class="button confirm"').' ';
						?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<div class="table_action_buttons">
		<?php $this->load->view('admin/partials/buttons', array('buttons' => array('delete'))) ?>
	</div>