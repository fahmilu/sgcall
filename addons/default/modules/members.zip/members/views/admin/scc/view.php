<!--
<section class="title">
</section>
-->

<!-- <section class="item"> -->
<div class="content">

	<h4><?php echo $scc->member_name;?></h4>

<?php if (!empty($scc)) : ?>

<form class="crud" action="">
<div class="form_inputs">
<fieldset>
<ul>

	<li>
		<div class="one_half">
			<label>Member </label>
			<div class="input"><?php echo $scc->member_name; ?></div>
		</div>
		<div class="one_half">
			<label>Certified unit/facility</label>
			<div class="input"><?php echo $scc->facility; ?></div>
		</div>
		<div class="clearfix"></div>
	</li>
	
	<li>
		<div class="one_half">
			<label>Supply options</label>
			<div class="input">
			<?php
						$scc_so2 = str_ireplace(array("\r", "\n"), ",", $scc->supply_option);
						$scc_so1 = str_ireplace(",,", ",", $scc_so2);
						
						$scc_so3 = explode(',', $scc_so1);
						
						//$scc_so = array_filter( $scc_so );
						
						foreach ($scc_so3 as $id => $name):
							if($name == 'MB'){ echo 'Mass Balance, ';}
							if($name == 'SG'){ echo 'Segregated, ';}
							if($name == 'IP'){ echo 'Identity Preserved, ';}
							if($name == 'B&C'){ echo 'Book &amp; Claim, ';}
						endforeach;
					?>
			</div>
		</div>
		<div class="one_half">
			<label>Approval date</label>
			<div class="input"><?php echo $scc->approval_date ? date('Y-m-d', $scc->approval_date) : '' ?></div>
		</div>
		<div class="clearfix"></div>
	</li>
	
	<li>
		<div class="one_half">
			<label>Expiry date</label>
			<?php $date = date_create($scc->date);?>
			<div class="input"><?php echo $scc->certification_expiry_date ? date('Y-m-d', $scc->certification_expiry_date) : '' ?></div>
		</div>
		
		<div class="one_half">
			<label>Date</label>
			<div class="input"><?php echo $scc->application_date ? date('Y-m-d', $scc->application_date) : '' ?></div>
		</div>
		<div class="clearfix"></div>
	</li>
	
	<li>
		<div class="">
			<label>File attachment</label>
			<div class="input">
			<?php
						if ($scc->file)
						{
							$ff = ($scc->file ? ','.$scc->file:'')
							.($scc->file_2 ? ','.$scc->file_2:'') .($scc->file_3 ? ','.$scc->file_3:'') 
							;
							$files = explode(',' , $ff);
							//echo ''.PHP_EOL;

							foreach($files as $key => $file){
								if ($file)
								{
									$pos = strpos($file, '/', 1);
									//$pos = 1;
				                	if ($pos OR $pos === 0)
				                	{
				                		$fname = substr(strrchr($file, "/"), 1);
				                		$furl = $file;
				                		//$fname = ltrim($file, "/");
				                	}
				                	else
				                	{
				                		$fname = $file;
				                		$furl = site_url(UPLOAD_PATH.'scc/'.$fname);
				                		//$fname = ltrim($file, "/");
				                	}

									$filesize = '';

/*
									if (file_exists($fullname.$fname) && is_file($fullname.$fname))
									{
										$filesize = ' ('.human_filesize(filesize($fullname.$fname)).')';
									}
									else
										$filesize = '';
*/
		
									$charlimit = 18;
									if (strlen($fname) > $charlimit)
										$fnamev = substr($fname, 0, $charlimit) . '&#8230;';
									else
										$fnamev = $fname;
	
									echo "<a title=\"".$fname."$filesize\" target='_blank' href='".$furl."'> ".$fnamev." ".$filesize."</a>";
								}
								else
									continue;
			                }

			                //$item = '<ul class="list-group"><li>'.$certfile.'</li><li>'.implode('</li><li>', $files).'</li></ul>';
			                //$item =  
						//echo $item;
						}
						else
						{
							echo "--";
						}
						?>
			</div>
		</div>
		<div class="clearfix"></div>
	</li>
</ul>

	<div class="table_action_buttons">
		<?php echo anchor('admin/members/scc/delete/'.$scc->id, lang('global:delete'), 'class="btn red confirm"').' '; ?>
	</div>

</fieldset>
</div>
</form>

<?php else : ?>
	<div class=" alert error"><p>Error retrieving scc</p></div>
<?php endif; ?>

</div>
<!-- </section> -->

<div class="clearfix"><br /></div>