<section class="title">
	<h4><?php echo lang('scc:nav_scc'); ?></h4>
</section>

<section class="item">
<div class="content">

<?php if (!empty($sccs)) : ?>

	<?php echo $this->load->view('admin/partials/filters_scc'); ?>

	<?php echo form_open('admin/members/scc/action'); ?>
	<div id="filter-stage">

		<?php echo $this->load->view('admin/scc/tables/scc'); ?>
	
	</div>
	<?php echo form_close(); ?>

<?php else : ?>
	<div class="no_data"><?php echo lang('members:empty_membership_msg'); ?></div>
<?php endif; ?>

</div>
</section>