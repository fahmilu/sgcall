<section class="title">
<?php if ($this->method == 'create'): ?>
	<h4><?php echo lang('scc:create_title') . (!empty($member_name) ? ' - ' . $member_name : ''); ?></h4>
<?php else: ?>
	<h4><?php echo sprintf(lang('scc:edit_title'), word_limiter($scc->facility, 30)); ?></h4>
<?php endif; ?>
</section>

<style>
.required_field{
	color:red;
}
</style>

<section class="item">
<div class="content">

<?php echo form_open_multipart(uri_string(), 'class="crud" name="sccForm" id="sccForm"'); ?>

<fieldset>
<div class="form_inputs">

	<ul>
		<li>
			<label for="online_status"><?php echo lang('scc:status_label'); ?><span class="required_field">*</span></label><br/>
			
			<div class="input">
				<label class="inline"><input name="online_status" value="draft" type="radio" <?php echo $scc->online_status == 'draft' ? 'checked="checked"' : '' ?> > Draft</label>
				<label class="inline"><input name="online_status" id="online_status" value="live" type="radio" <?php echo $scc->online_status == 'live' ? 'checked="checked"' : '' ?> > Live</label>
			</div>
		</li>

		<li>
			<label for="member_name"><?php echo lang('scc:member_label'); ?><span class="required_field">*</span></label>
			<br /><small>Start typing below for auto-suggest</small>
			<div class="input">
				<?php echo form_input('member_name', !empty($member_name) ? $member_name : $scc->member_name, 'id="member_name"') ?>
				<input type="hidden" name="member_id" value="<?php echo !empty($member_id) ? $member_id : $scc->mid?>" id="member_id" />
			</div>
		</li>

		<li>
			<label for="facility"><?php echo lang('scc:facility_label'); ?><span class="required_field">*</span></label>
			<div class="input">
				<textarea name="facility" id="facility" rows="5" cols="60" style="max-width:450px;"><?php echo $scc->facility; ?></textarea>
			</div>
		</li>

		<li>
			<label for="supply_option"><?php echo lang('scc:supply_option_label'); ?><span class="required_field">*</span></label>
			<div class="input">
				<?php
					$scc_so = str_ireplace(array("\r", "\n"), ",", $scc->supply_option);
					$scc_so = explode(',', $scc_so);
					$scc_so = array_filter( $scc_so );
				?>
				<?php foreach($supply_options as $ss=>$so): ?>
					<label class="inline"><?php echo form_checkbox('supply_options[]', $ss, in_array($ss, $scc_so)); ?> <?php echo $so?></label>
				<?php endforeach; ?>
			</div>
		</li>

		<li style="display:none;">
			<label for="application_date"><?php echo lang('scc:application_date_label'); ?></label>
			<div class="input"><?php echo form_input('application_date', $scc->application_date ? date('Y-m-d', $scc->application_date) : '', 'id="application_date" class="datepicker"') ?></div>
		</li>

		<li>
			<label for="approval_date"><?php echo lang('scc:approval_date_label'); ?></label>
			<div class="input"><?php echo form_input('approval_date', $scc->approval_date ? date('Y-m-d', $scc->approval_date) : '', 'id="approval_date" class="datepicker2"') ?></div>
		</li>

		<li>
			<label for="certification_expiry_date"><?php echo lang('scc:expiry_date_label'); ?></label>
			<div class="input"><?php echo form_input('certification_expiry_date', $scc->certification_expiry_date ? date('Y-m-d', $scc->certification_expiry_date) : '', 'id="certification_expiry_date" class="datepicker"') ?></div>
		</li>

		<li>
			<label for="notification"><?php echo lang('scc:files_label'); ?></label>
			<div class="clearfix"><br /></div>
			<div class="input">

				<div class="third">
					<?php echo form_upload('file'); ?>
					<?php if ($scc->file): ?>
						<br/>
						Current file: <?php echo $scc->file; ?><br />
						<label class="inline"><input type="checkbox" name="remove_file_2" class="remove_uploaded" value="<?php echo $scc->file; ?>" /> Remove file</label>
						<?php echo form_hidden('file_text_1', $scc->file_text_1); ?>
					<?php endif; ?>
				</div>

				<div class="third">
					<?php echo form_upload('file_2'); ?>
					<?php if ($scc->file_2): ?>
						<br/>
						Current file: <?php echo $scc->file_2; ?><br />
						<label class="inline"><input type="checkbox" name="remove_file_2" class="remove_uploaded" value="<?php echo $scc->file_2; ?>" /> Remove file</label>
						<?php echo form_hidden('file_text_2', $scc->file_text_2); ?>
					<?php endif; ?>
				</div>

				<div class="third">
					<?php echo form_upload('file_3'); ?>
					<?php if ($scc->file_3): ?>
						<br/>
						Current file: <?php echo $scc->file_3; ?><br />
						<label class="inline"><input type="checkbox" name="remove_file_3" class="remove_uploaded" value="<?php echo $scc->file_3; ?>" /> Remove file</label>
						<?php echo form_hidden('file_text_3', $scc->file_text_3); ?>
					<?php endif; ?>
				</div>

			</div>
			<div class="clearfix"></div>
		</li>

	</ul>

</div>
</fieldset>

<div class="buttons">
	<?php $this->load->view('admin/partials/buttons', array('buttons' => array('save', 'save_exit', 'cancel'))) ?>
</div>

<?php echo form_close(); ?>

<div style="display:none;">

	<div id="div_upload_file1">
		<?php echo form_upload('file[]'); ?>
	</div>

</div>

<style>
ul.ui-autocomplete.ui-menu.ui-widget-content {
	max-height: 200px;
	overflow-y: auto;
	overflow-x: hidden;
}
</style>
<script>

function calcExpiryDate(v)
{
}

(function($) {
	$(function(){

		$('#add_file1').click(function(e){
			e.preventDefault();
			$('#upload_file1').append($('#div_upload_file1').html());
		});

		$('#approval_date').datepicker({
			dateFormat: 'yy-mm-dd',
			onClose: function(v){
				if (v)
				{
					var yt = v.split("-");
					y = yt[0] * 1;

					var ed = yt[1] + "/" + yt[2] + "/" + (y+5);
					var d = new Date((y+5), yt[1], yt[2]-1);
					var nm = d.getMonth();
					var nd = d.getDate();
					var ny = d.getYear();
					$('#certification_expiry_date').val((y+5)+"-"+nm+"-"+nd);
				}
			}
		});

		$('.datepicker').datepicker({
			dateFormat: 'yy-mm-dd'
		})

		$( "#member_name" ).autocomplete({
			source: SITE_URL + 'admin/members/sccpick',
			minLength: 2,
			maxHeight: "250px",
			select: function( event, ui ) {
				$('#member_id').val(ui.item.id);
			}
		});

	});
})(jQuery);
</script>

</div>
</section>