<!-- docs scgm_business_registration -->
<p style="font-size:14px;">Please attach proof of business registration (e.g. certificate of incorporation, certificate of good standing, article of incorporation or other similar documents)</p>

<?php if (!empty($membersapp->scgm_business_registration)): ?>
    <?php echo form_hidden('scgm_business_registration', $membersapp->scgm_business_registration); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->scgm_business_registration))) ?>" target="_blank"><?php echo $membersapp->scgm_business_registration; ?></a>
    <div class="clear"></div>
<?php endif; ?>
<input type="file" name="scgm_business_registration" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">

<!-- docs scgm_agreement -->
<p style="font-size:14px;">Please attach proof of business registration (e.g. certificate of incorporation, certificate of good standing, article of incorporation or other similar documents)</p>

<?php if (!empty($membersapp->scgm_agreement)): ?>
    <?php echo form_hidden('scgm_agreement', $membersapp->scgm_agreement); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->scgm_agreement))) ?>" target="_blank"><?php echo $membersapp->scgm_agreement; ?></a>
    <div class="clear"></div>
<?php endif; ?>

<input type="file" name="scgm_agreement" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">