<?php
$additional_files_list = array(
    'Latest Annual Report or Shareholder documents (required document for subsidiary inclusion in Group Membership).',
    'Organisation status (corporate and ownership structure).',
    'Disclosure of existing field practices and policies of Corporate Social Responsibility (CSR)/ sustainability policy.',
    'Additional information such as legally set aside area (eg. riparian, hill slope, deep peat etc.) and settlements within their concession (if any).',
);
?>
    <!-- docs opg_sg_principles_criteria -->
    <p style="font-size:14px;">Please attach proof of business registration (e.g. certificate of incorporation, certificate of good standing, article of incorporation or other similar documents)</p>

<?php if (!empty($membersapp->opg_sg_principles_criteria)): ?>
    <?php echo form_hidden('opg_sg_principles_criteria', $membersapp->opg_sg_principles_criteria); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sg_principles_criteria))) ?>" target="_blank"><?php echo $membersapp->opg_sg_principles_criteria; ?></a>
    <div class="clear"></div>
<?php endif; ?>

    <input type="file" name="opg_sg_principles_criteria" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">

    <!-- docs opg_sg_business_registration -->
    <p style="font-size:14px;">Disclosure of plans to implement the RSPO Principles and Criteria (P&C). Click here to download template.</p>

<?php if (!empty($membersapp->opg_sg_business_registration)): ?>
    <?php echo form_hidden('opg_sg_business_registration', $membersapp->opg_sg_business_registration); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sg_business_registration))) ?>" target="_blank"><?php echo $membersapp->opg_sg_business_registration; ?></a>
    <div class="clear"></div>
<?php endif; ?>

    <input type="file" name="opg_sg_business_registration" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">

    <!-- docs opg_sg_disclosure_cleared_area -->
    <p style="font-size:14px;">Reporting Template for Disclosure of Areas Cleared without Prior HCV Assessment since November 2005. Click here to download template.</p>

<?php if (!empty($membersapp->opg_sg_disclosure_cleared_area)): ?>
    <?php echo form_hidden('opg_sg_disclosure_cleared_area', $membersapp->opg_sg_disclosure_cleared_area); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sg_disclosure_cleared_area))) ?>" target="_blank"><?php echo $membersapp->opg_sg_disclosure_cleared_area; ?></a>
    <div class="clear"></div>
<?php endif; ?>

    <input type="file" name="opg_sg_disclosure_cleared_area" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">

    <!-- docs opg_sg_estate_location -->
    <p style="font-size:14px;">Estate location and concession maps in Shapefile format (.shp) with polygon geometry dimension (including subsidiary, if any).</p>

<?php if (!empty($membersapp->opg_sg_estate_location)): ?>
    <?php echo form_hidden('opg_sg_estate_location', $membersapp->opg_sg_estate_location); ?>
    Filename: <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sg_estate_location))) ?>" target="_blank"><?php echo $membersapp->opg_sg_estate_location; ?></a>
    <div class="clear"></div>
<?php endif; ?>

    <input type="file" name="opg_sg_estate_location" class="required filestyle" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')">