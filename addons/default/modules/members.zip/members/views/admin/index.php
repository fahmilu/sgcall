<style>
tr.deleted_members td {
	color: #888 !important;
	font-style: italic;
}
tr.pending_members td {
	color: #888 !important;
}
</style>
<section class="title">
	<h4><?php echo lang('members:members_label'); ?> <small>- <?php echo number_format($count); ?> data</small></h4>
</section>

<section class="item">
<div class="content">

<?php if (!empty($members)) : ?>

	<?php echo $this->load->view('admin/partials/filters'); ?>

	<?php echo form_open('admin/members/action'); ?>
	<div id="filter-stage">

		<?php echo $this->load->view('admin/tables/members'); ?>
	
	</div>
	<?php echo form_close(); ?>

<?php else : ?>
	<div class="no_data"><?php echo lang('members:empty_membership_msg'); ?></div>
<?php endif; ?>

</div>
</section>