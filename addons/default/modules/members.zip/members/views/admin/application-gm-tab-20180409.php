		<fieldset id="subs_container">

<!--
		<ul>
			<li>
					<label for="is_survey">Has this member completed the survey?</label>
					<div class="input">
						<label class="inline"><?php //echo form_checkbox('survey', 'yes', $membersapp->survey==1); ?> Yes</label>
					</div>
			</li>
		</ul>
-->

<p>
	<a href="#" class="btn green small" onclick="addGM();return false;">Add new Group Member</a><br />
</p>

<?php if ($subsidiaries): ?>

	<?php foreach($subsidiaries as $sub): ?>

		<fieldset id="sub_<?php echo $sub->id ?>">
			<legend id="legend_<?php echo $sub->id ?>"><?php echo $sub->name ?></legend>
			<a href="#" class="btn red xsmall remove_subsidiary" rel="<?php echo $sub->id ?>" style="position:relative; z-index: 9999 !important;padding-top: 0;float: right;" >&times;</a>
			<input type="hidden" name="sub_id[]" value="<?php echo $sub->id ?>" />
			<input type="hidden" name="remove_sub_id[]" id="remove_sub_id_<?php echo $sub->id ?>" />

			<ul>
				<li>
					<label for="gm_name_<?php echo $sub->id ?>">Group Member Name</label>
					<div class="input">
						<?php echo form_input('gm_name[]', $sub->name, 'class="gm_name" rel="'.$sub->id.'" id="gm_name_'.$sub->id.'"'); ?>
					</div>
				</li>

				<li>
					<div class="one_full">
						<div class="one_third">
							<label for="gm_type_<?php echo $sub->id ?>">Group Member Type</label>
							<div class="input">
								<?php echo form_dropdown('gm_type[]', array(''=>'Select')+$subsidiary_types, $sub->type, 'class="gm_type" rel="'.$sub->id.'" id="gm_name_'.$sub->id.'"'); ?>
								<div id="sub_type_other_<?php echo $sub->id ?>" style="display:<?php echo $sub->type=='other'?'block':'none' ?>">
									<br /><label for="gm_type_other_<?php echo $sub->id ?>">Please specify:</label>
									<?php echo form_input('gm_type_other[]', $sub->other_type, 'rel="'.$sub->id.'" class="gm_type_other" id="gm_type_other_'.$sub->id.'"'); ?>
								</div>
							</div>
						</div>
						<div class="one_third">
							<label for="gm_nature_of_business_<?php echo $sub->id ?>">Nature of business</label>
							<div class="input">
								<?php echo form_dropdown('gm_nature_of_business[]', array(''=>'Select')+$subsidiary_nature_of_business, $sub->nature_of_business, 'class="gm_nature_of_business" rel="'.$sub->id.'" id="gm_nature_of_business'.$sub->id.'"'); ?>
							</div>
						</div>
					</div>
					<div class="clearfix clear"></div>
				</li>

				<li>
					<div class="one_full">
						<div class="one_third">
							<label for="gm_country_<?php echo $sub->id ?>">Country</label>
							<div class="input">
								<?php echo form_dropdown('gm_country[]', array(''=>'Select')+$new_country_arrays, $sub->country, 'class="gm_country" rel="'.$sub->id.'" id="gm_country_'.$sub->id.'"'); ?>
							</div>
						</div>
						<div class="one_third">
							<label for="gm_region_<?php echo $sub->id ?>">Region</label>
							<div class="input">
								&nbsp;<?php echo form_input('gm_region[]', $sub->region, 'readonly class="gm_region" rel="'.$sub->id.'" id="gm_region_'.$sub->id.'"'); ?>
							</div>
						</div>
					</div>
					<div class="clearfix clear"></div>
				</li>

				<li>
					<label for="gm_is_rspo_num_<?php echo $sub->id ?>">Is this group member an RSPO member?</label>
					<div class="input">
						<label class="inline"><?php echo form_checkbox('gm_is_rspo_num[]', 'yes', $sub->is_rspo_num=='yes', 'class="gm_rspo_member" rel="'.$sub->id.'" id="gm_is_rspo_num_'.$sub->id.'_yes"'); ?> Yes</label>

							<input type="hidden" name="gm_is_rspo_num_dummy[]" value="<?php echo $sub->is_rspo_num=='yes'?'yes':'no' ?>" id="gm_is_rspo_num_<?php echo $sub->id ?>_no" />

						<?php //echo form_hidden('gm_is_rspo_num_dummy[]', $sub->is_rspo_num=='yes'?'yes':'no', 'class="gm_rspo_member_dummy" rel="'.$sub->id.'" id="gm_is_rspo_num_'.$sub->id.'_no"'); ?>

						<div id="gm_rspo_member_yes_<?php echo $sub->id ?>" style="display:<?php echo $sub->is_rspo_num=='yes'?'block':'none' ?>;">
							<br /><label for="member_num_<?php echo $sub->id ?>">Enter its RSPO membership number</label><br />
							<?php echo form_input('rspo_membership_num[]', $sub->rspo_membership_num, 'id="member_num_'.$sub->id.'"'); ?>
						</div>
					</div>
				</li>

				<li>
					<h5>Contact information</h5>
					<div>
						<div class="one_full">
							<div class="one_third">
								<label for="gm_firstname_<?php echo $sub->id ?>">First name</label>
								<div class="input">
									&nbsp;<?php echo form_input('gm_firstname[]', $sub->firstname, 'class="gm_contact_name" rel="'.$sub->id.'" id="gm_firstname_'.$sub->id.'"'); ?>
								</div>
							</div>
							<div class="one_third">
								<label for="gm_lastname_<?php echo $sub->id ?>">Last name</label>
								<div class="input">
									&nbsp;<?php echo form_input('gm_lastname[]', $sub->lastname, 'class="gm_contact_name" rel="'.$sub->id.'" id="gm_lastname_'.$sub->id.'"'); ?>
								</div>
							</div>
						</div>
						<div class="clearfix clear"></div>
					</div>
				</li>

				<li>
						<div class="one_full">
							<div class="one_third">
								<label for="gm_email_<?php echo $sub->id ?>">Email</label>
								<div class="input">
									<?php echo form_input('gm_email[]', $sub->email, 'class="gm_email" rel="'.$sub->id.'" id="gm_email_'.$sub->id.'"'); ?>
								</div>
							</div>
							<div class="one_third">
								<label style="display:block; margin-bottom:5px;" for="gm_lastname_<?php echo $sub->id ?>">Phone</label>
								<div class="input">
									<?php echo form_input('gm_phone[]', $sub->phone, 'class="gm_phone mobile-number tlp-code form-control" rel="'.$sub->id.'" id="gm_phone_'.$sub->id.'"'); ?>
								</div>
							</div>
						</div>
						<div class="clearfix clear"></div>
				</li>

			</ul>
		</fieldset>


	<?php endforeach; ?>

<?php else: ?>

	<div class="no_data">This member does not have Group Members</div>

<?php endif; ?>

		</fieldset>

<?php if ($subsidiaries): ?>
	<a href="#" class="btn green small" onclick="addGM();return false;">Add new Group Member</a>
<hr />
<?php endif; ?>

<div id="country_dropdown" style="display:none;">
	<?php echo form_dropdown('gm_country[]', array(''=>'Select')+$new_country_arrays, NULL, 'class="gm_country gm_refresh skip" rel=""'); ?>
</div>

<div id="gm_notification" style="display:none;">
	<div class="" style="display:none;">
		Group member "<b><span></span></b>" has been removed. Click <a href="#" rel="" class="restore_gm" onclick="RestoreGM($(this)); return false;"><b>Undo</b></a> to restore it. Please note that you <b>cannot</b> undo when you save this member.
	</div>
</div>

<script>

$(document).ready(function(){

	$('.gm_type').livequery('change', function(){
		var v = $(this).val();
		var i = $(this).attr('rel');

		if (v=='other')
		{
			$('#sub_type_other_'+i).slideDown();
		}
		else
		{
			$('#sub_type_other_'+i).slideUp(function(){
				$('#gm_type_other_'+i).val('');
			});
		}
	});

	$('input.gm_name').livequery('blur', function(){
		var i = $(this).attr('rel');
		if (i)
		{
			$('legend#legend_'+i).text($(this).val());
		}
	});

	$('input.gm_rspo_member').livequery('click', function(){
		var i = $(this).attr('rel');
		if ($(this).is(':checked'))
		{
			$('#gm_rspo_member_yes_'+i).slideDown();
			$('#gm_is_rspo_num_'+i+'_no').val('yes')
		}
		else
		{
			$('#gm_rspo_member_yes_'+i).slideUp();
			$('#gm_is_rspo_num_'+i+'_no').val('no')
		}
	});

	$('select.gm_country').livequery('change', function(){

		var i = $(this).attr('rel');
        var country = $("#gm_country_"+i).val();

		$.get( "/admin/members/get_region/"+encodeURI(country), function( obj ) {
			var data = JSON.parse(obj);
		    if (data.status == true) {
		        $("#gm_region_"+i).val(data.data);
		    }
		});

		$.get( "/admin/members/countrycode/"+encodeURI(country), function( obj ) {
			$('#gm_phone_'+i).intlTelInput("selectCountry", obj);
		});
		
	});

	$('select.gm_countryXYZ').livequery('change', function(){

		var i = $(this).attr('rel');
        var country = $("#gm_country_"+i).val();
        var post_data = {c: country};
        $.ajax({
            url: "<?php echo site_url('admin/members/get_region/'); ?>/"+encodeURIComponent(country),
            //method: "GET",
            //data: post_data,
            type: "json",
            success: function(obj){
                var data = JSON.parse(obj);
                if (data.status == true) {
                    $("#gm_region_"+i).val(data.data);
                }
            }
        });

        $.ajax({
            url: "<?php echo site_url('admin/members/countrycode'); ?>/"+encodeURIComponent(country),
            //method: "GET",
            //data: {c: country},
            type: "json",
            success: function(obj){
                $('#gm_phone_'+i).intlTelInput("selectCountry", obj);
            }
        });

	});

	$('a.remove_subsidiary').livequery('click', function(){
		if (confirm("Are you sure you want to remove this Group Member?"))
		{
			var i = $(this).attr('rel');
			if (i)
			{
				$("#remove_sub_id_"+i).val(i);


				$('#sub_'+i).fadeOut('slow', function(){
					var h = $('#gm_notification').html();
					var t = $('#legend_'+i).text();
					if (t=="Add New Group Member")
						t="Untitled"
					$(h).insertBefore('#sub_'+i);
					$('#sub_'+i).prev('div').addClass('alert warning');
					$('#sub_'+i).prev('.alert').find('span').html(t);
					$('#sub_'+i).prev('.alert').find('a.restore_gm').attr('rel', i);
					//$(this).prev('.alert').fadeIn('slow');
				});
				return false;
			}
		}
		else
		{
			$("#remove_sub_id_"+i).val('');
			return false;
		}
	});

});

function RestoreGM(d)
{
	if (d)
	{
		var i = d.attr('rel');
		$('#sub_'+i).fadeIn('slow', function(){
			$(this).prev('.alert').fadeOut('slow', function(){
				$(this).remove();
			});
			$("#remove_sub_id_"+i).val('');
		});
	}
}

function addGM()
{
	// get the last div id
	// ...
	var t_new_id = Date.now();
	var new_id = stringGen(3)+t_new_id;

	var blank_form = ''+
	'	<fieldset id="sub_'+new_id+'">'+
	'		<legend id="legend_'+new_id+'">Add New Group Member</legend>'+
	'		<a href="#" class="btn red xsmall remove_subsidiary" rel="'+new_id+'" style="position:relative; z-index: 9999 !important;padding-top: 0;float: right;" >&times;</a>'+
	'		<input type="hidden" name="sub_id[]" value="'+new_id+'" />'+
	'		<input type="hidden" name="remove_sub_id[]" id="remove_sub_id_'+new_id+'" />'+
	''+
	'		<ul>'+
	'			<li>'+
	'				<label for="gm_name_'+new_id+'">Group Member Name</label>'+
	'				<div class="input">'+
	'					<input type="text" name="gm_name[]" value="" class="gm_name" rel="'+new_id+'" id="gm_name_'+new_id+'" />'+
	'				</div>'+
	'			</li>'+
	''+
	'			<li>'+
	'				<div class="one_full">'+
	'					<div class="one_third">'+
	'						<label for="gm_type_'+new_id+'">Group Member Type</label>'+
	'						<div class="input">'+
	'							<select name="gm_type[]" class="gm_type gm_refresh" rel="'+new_id+'" id="gm_type_'+new_id+'">'+
	'								<option value="">Select</option>'+
	'								<option value="subsidiary" selected="selected">Subsidiary</option>'+
	'								<option value="management_unit">Management Unit</option>'+
	'								<option value="supply_chain_group_manager">Supply Chain Group Manager</option>'+
	'								<option value="other">Other</option>'+
	'							</select>'+
	'							<div id="sub_type_other_'+new_id+'" style="display:none;">'+
	'								<br /><label for="gm_type_other_'+new_id+'">Please specify:</label>'+
	'									<input type="text" name="gm_type_other[]" value="" class="gm_type_other" rel="'+new_id+'" id="gm_type_other_'+new_id+'" />'+
	'							</div>'+
	'						</div>'+
	'					</div>'+
	'					<div class="one_third">'+
	'						<label for="gm_nature_of_business_'+new_id+'">Nature of business</label>'+
	'						<div class="input">'+
	'							<select name="gm_nature_of_business[]" class="gm_nature_of_business gm_refresh" rel="'+new_id+'" id="gm_nature_of_business_'+new_id+'">'+
	'								<option value="">Select</option>'+
	'								<option value="Consumer Goods Manufacturers">Consumer Goods Manufacturers</option>'+
	'								<option value="Growers">Growers</option>'+
	'								<option value="Processors and Traders">Processors and Traders</option>'+
	'								<option value="Retailers" selected="selected">Retailers</option>'+
	'							</select>'+
	'						</div>'+
	'					</div>'+
	'				</div>'+
	'				<div class="clearfix clear"></div>'+
	'			</li>'+
	''+
	'			<li>'+
	'				<div class="one_full">'+
	'					<div class="one_third">'+
	'						<label for="gm_country_'+new_id+'">Country</label>'+
	'						<div class="input" id="country_dd_container_'+new_id+'">'+
	'							<?php //echo form_dropdown('gm_country[]', array(''=>'Select')+$country_arrays, $sub->country, 'class="gm_country" rel="'.$sub->id.'" id="gm_country_'.$sub->id.'"'); ?>'+
	'						</div>'+
	'					</div>'+
	'					<div class="one_third">'+
	'						<label for="gm_region_'+new_id+'">Region</label>'+
	'						<div class="input">'+
	'							<input type="text" name="gm_region[]" readonly value="" class="gm_region" rel="'+new_id+'" id="gm_region_'+new_id+'" />'+
	'							&nbsp;<?php //echo form_input('gm_region[]', $sub->region, 'readonly class="gm_region" rel="'.$sub->id.'" id="gm_region_'.$sub->id.'"'); ?>'+
	'						</div>'+
	'					</div>'+
	'				</div>'+
	'				<div class="clearfix clear"></div>'+
	'			</li>'+
	''+
	'			<li>'+
	'				<label for="gm_is_rspo_num_'+new_id+'">Is this group member an RSPO member?</label>'+
	'				<div class="input">'+
	'					<label class="inline"><input type="checkbox" name="gm_is_rspo_num[]" value="yes" class="gm_rspo_member" rel="'+new_id+'" id="gm_is_rspo_num_'+new_id+'" /> Yes</label>'+
	'						<input type="hidden" name="gm_is_rspo_num_dummy[]" id="gm_is_rspo_num_'+new_id+'_no" />'+
	'					<div id="gm_rspo_member_yes_'+new_id+'" style="display:none;">'+
	'						<br /><label for="member_num_'+new_id+'">Enter its RSPO membership number</label><br />'+
	'						<input type="text" name="rspo_membership_num[]" value="" rel="'+new_id+'" id="member_num_'+new_id+'" />'+
	'						<?php //echo form_input('rspo_membership_num', $sub->rspo_membership_num, 'id="member_num_'.$sub->id.'"'); ?>'+
	'					</div>'+
	'				</div>'+
	'			</li>'+
	''+
	'			<li>'+
	'				<h5>Contact information</h5>'+
	'				<div>'+
	'					<div class="one_full">'+
	'						<div class="one_third">'+
	'							<label for="gm_firstname_'+new_id+'">First name</label>'+
	'							<div class="input">'+
	'								<input type="text" name="gm_firstname[]" value="" class="gm_contact_name" rel="'+new_id+'" id="gm_firstname_'+new_id+'" />'+
	'								&nbsp;<?php //echo form_input('gm_firstname[]', $sub->firstname, 'class="gm_name" rel="'.$sub->id.'" id="gm_firstname_'.$sub->id.'"'); ?>'+
	'							</div>'+
	'						</div>'+
	'						<div class="one_third">'+
	'							<label for="gm_lastname_'+new_id+'">Last name</label>'+
	'							<div class="input">'+
	'								<input type="text" name="gm_lastname[]" value="" class="gm_contact_name" rel="'+new_id+'" id="gm_lastname_'+new_id+'" />'+
	'								&nbsp;<?php //echo form_input('gm_lastname[]', $sub->lastname, 'class="gm_name" rel="'.$sub->id.'" id="gm_lastname_'.$sub->id.'"'); ?>'+
	'							</div>'+
	'						</div>'+
	'					</div>'+
	'					<div class="clearfix clear"></div>'+
	'				</div>'+
	'			</li>'+
	''+
	'			<li>'+
	'					<div class="one_full">'+
	'						<div class="one_third">'+
	'							<label for="gm_email_'+new_id+'">Email</label>'+
	'							<div class="input">'+
	'								<input type="text" name="gm_email[]" value="" class="gm_email" rel="'+new_id+'" id="gm_email_'+new_id+'" />'+
	'								<?php //echo form_input('gm_email[]', $sub->email, 'class="gm_email" rel="'.$sub->id.'" id="gm_email_'.$sub->id.'"') ?>'+
	'							</div>'+
	'						</div>'+
	'						<div class="one_third">'+
	'							<label style="display:block; margin-bottom:5px;" for="gm_lastname_'+new_id+'">Phone</label>'+
	'							<div class="input">'+
	'								<input type="text" name="gm_phone[]" value="" class="gm_phone  mobile-number tlp-code form-control" rel="'+new_id+'" id="gm_phone_'+new_id+'" />'+
	'								<?php //echo form_input('gm_phone[]', $sub->phone, 'class="gm_phone mobile-number tlp-code form-control" rel="'.$sub->id.'" id="gm_phone_'.$sub->id.'"'); ?>'+
	'							</div>'+
	'						</div>'+
	'					</div>'+
	'					<div class="clearfix clear"></div>'+
	'			</li>'+
	''+
	'		</ul>'+
	'	</fieldset>'+
	'';


	$('#subs_container .no_data').fadeOut('fast');

	$('#subs_container').append(blank_form);
	$('#country_dd_container_'+new_id).html($('#country_dropdown').html());
	$('#country_dd_container_'+new_id+' select').removeClass('skip')
	$('#country_dd_container_'+new_id+' > select').attr('id', 'gm_country_'+new_id).attr('rel', new_id);

	$('#sub_'+new_id+' #gm_phone_'+new_id).intlTelInput();

	var $select = $('select.gm_refresh');
	$select.trigger("liszt:updated");

	$('html, body').animate({
		scrollTop: $('#sub_'+new_id).offset().top-25
	}, 1000);

}

function stringGen(len)
{
	var text = " ";
	var charset = "abcdefghijklmnopqrstuvwxyz";

	for( var i=0; i < len; i++ )
		text += charset.charAt(Math.floor(Math.random() * charset.length));

	return text.trim();
}
</script>