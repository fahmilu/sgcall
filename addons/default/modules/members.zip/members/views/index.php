	<!-- Full Page Image Background Carousel Header -->
    <header>
        <div class="row">
            <div class="container text-center" id="header-white">
                <?php if(SITE_REF=='bcn'):?>
				<?php else:?>
				<h1>MEMBERS</h1>
				<?php endif;?>
            </div>
        </div>
        <div id="myCarousel">
            <!-- Wrapper for Slides -->
            <div class="carousel-inner">
                <div class="item active" style="background:url('{{ theme:image_path file='member_banner2.jpg' }}') no-repeat left center;background-size: cover;">
					<div class="carousel-caption">
					<div class="contain800">
                        <a href="#"><h2>TURNING STANDARDS INTO ACTION</h2></a>
                        <a href="#">
                            <p>Members of the RSPO represent all stages in the supply chain and the world's largest palm oil producing regions. As members, they have a say in the RSPO's decision-making, shaping efforts to make sustainable palm oil the norm.</p>
                        </a>
					<div class="image-credit">Credit: NBPOL</div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

	<?php $this->load->view('partials/search-bar'); ?>
	
    {{ pages:display slug="members" }}
		{{custom_fields}}
			{{body}}
		{{/custom_fields}}
	{{ /pages:display }}
	
<?php if (!empty($membersX)): ?>
<section>
<div class="container">
<div class="row">
<div class="col-lg-12">

<table class="table">
	<thead>
		<tr>
			<th>Name</th>
			<th>Country/Region</th>
			<th>Status</th>
			<th>Member Since</th>
			<th>Membership Type</th>
		</tr>
	</thead>

	<tbody>
	<?php foreach($members as $m): ?>
		<tr>
			<td><a href="<?php echo site_url( 'members/'.$m->intID.'/'.url_title($m->title) ); ?>"><?php echo $m->title ?></a></td>
			<td><?php echo $m->country ?></td>
			<td><?php echo $m->status ?></td>
			<td><?php echo $m->approved_date; ?></td>
			<td><?php echo $m->type ?></td>
		</tr>
	<?php endforeach; ?>
	</tbody>

</table>
</div>
</div>
</div>

<div class="text-right pad-top-20">
<?php echo $pagination['links']; ?>
</div>

</section>

<?php else: ?>
<?php endif; ?>