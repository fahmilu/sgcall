<style>
	.info-tooltips{
		cursor:pointer;
		outline:none;
	}
	.datepicker.dropdown-menu {
		margin-left: 3px;
	}
	.box-contact-form, box-contact-form.contact {
		height: auto;
		min-height: 570px;
	}
	.box-contact-form .input-group-addon {
		background: none repeat scroll 0% 0% #FFF;
		border-radius: 0px;
		cursor: pointer;
	}
	.box-contact-form .form-group .input-group span.remove {
		height: 45px;
		padding: 0;
		vertical-align: middle;
		line-height: 45px;
		margin: 0 auto;
	}
	.box-contact-form .form-group .input-group span.remove label.remove input {
		padding: 0;
		margin: 0;
		line-height: normal;
		font-size: 12px;
		outline: none;
	}
	.box-contact-form .form-group .input-group span.remove label.remove {
		padding: 2px;
		margin: 0;
		height: auto;
		float: right;
		line-height: 1;
		vertical-align: middle;
	}
	.dropdown-menu {
		position: absolute;
		/* top: 45px; */
		left: 0px;
		z-index: 1000;
		display: none;
		float: left;
		min-width: 160px;
		/* padding: 0px; */
		margin: 2px 0px 0px;
		font-size: 14px;
		text-align: left;
		list-style: none outside none;
		background-color: #FFF;
		background-clip: padding-box;
		border: 1px solid rgba(0, 0, 0, 0.15);
		border-radius: 0px;
		box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.176);
	}
	.btn {
		border-radius: 0px;
		/* line-height:43px; */
		padding: 0px 12px;
		border: 1px solid #D5CEC8;
		text-transform: none;
	}
	.group-span-filestyle .btn {
		line-height:43px;
	}
	button.selectpicker.has-error {
		border-color: #a94442 !important;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
	.input-group-addon {
		font-size: 14px;
	}
	.input-group-btn > .btn {
		position: relative;
		height: 45px;
	}
	
	.nav-tabs a:hover .bullets-zero, .nav-tabs a:focus .bullets-zero, .nav-tabs a:active .bullets-zero, .nav-tabs a.active .bullets-zero{
		background:#ED7A1D;
		border:2px solid #ED7A1D;
	}
	
	a.active > label, a.active > label:hover, a.active > label:focus {
		color: #000;
		text-decoration:none;
		cursor:default;
	}
	
	a label:hover {
		text-decoration: underline;
	}
	
	a label:hover, .a label:focus {
		text-decoration: underline;
		color:#ED7A1D;
		cursor:pointer;
	}
	.remove_child {
		color: #fff;
		background: red !important;
	}
	.remove_child:hover {
		background: #ED7A1D !important;
	}
	.bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
		width: 100%;
	}
	.multiple {
		display: block;
	}
	.multiple a.remove_file {
		text-align: center;
		margin: 0;
		padding: 10px 19px !important;
		position: absolute;
	}
	.multiple .bootstrap-filestyle input {
		width: 90%;
		float: right;
	}
	label.normal {
		font-weight: normal;
		vertical-align: middle;
		height: 30px;
		line-height: 30px;
		text-align: left;
		display: block;
		float: left;
		margin-right: 20px;
	}
	label.normal input {
		line-height: normal;
		padding: 0;
		padding-left: 20px;
		margin: 0;
		float: left;
		width: 20px;
		outline: none;
	}
	label.normal input:focus, label.normal input:active {
		outline: none;
		box-shadow: none;
	}
	label.normal span {
		display: block;
		padding-left: 5px;
		float: left;
	}
	.half-width, .half-width-right {
		width: 43%;
		float: left;
	}
	.half-width-right {
		float: right;
		margin-left: 5%;
	}
	.ui-autocomplete {
		max-height: 250px;
		max-width: 450px;
		margin: 3px;
		padding: 0;
		overflow-y: auto;
		/* prevent horizontal scrollbar */
		overflow-x: hidden;
	}
	.ui-autocomplete.ui-widget-content ul {
		margin-left: 0;
		padding-left: 5px;
	}
	.ui-autocomplete.ui-widget-content li {
		list-style: none;
		padding: 3px 5px;
		line-height: 1.2;
		margin-left: 0;
		border: 1px solid transparent;
		cursor: pointer;
	}

	.ui-widget {
		font-family: inherit;
		font-size: 1.1em;
	}
	.ui-widget .ui-widget {
		font-size: 1em;
	}
	.ui-widget input,
	.ui-widget select,
	.ui-widget textarea,
	.ui-widget button {
		font-family: inherit;
		font-size: 1em;
	}
	.ui-widget-content {
		border: 1px solid #dddddd;
		background: #f4f3f5; /* url("images/ui-bg_highlight-soft_100_eeeeee_1x100.png") 50% top repeat-x;*/
		color: #333333;
	}
	.ui-widget-content a {
		color: #333333;
	}
	.ui-widget-header {
		border: 1px solid #e78f08;
		background: #f6a828; /* url("images/ui-bg_gloss-wave_35_f6a828_500x100.png") 50% 50% repeat-x; */
		color: #ffffff;
		font-weight: bold;
	}
	.ui-widget-header a {
		color: #ffffff;
	}

	/* Interaction states
	----------------------------------*/
	.ui-state-default,
	.ui-widget-content .ui-state-default,
	.ui-widget-header .ui-state-default {
		border: 1px solid #cccccc;
		background: red; /*#f6f6f6 url("images/ui-bg_glass_100_f6f6f6_1x400.png") 50% 50% repeat-x;*/
		font-weight: bold;
		color: #1c94c4;
	}
	.ui-state-default a,
	.ui-state-default a:link,
	.ui-state-default a:visited {
		color: #1c94c4;
		text-decoration: none;
	}
	.ui-state-hover,
	.ui-widget-content .ui-state-hover,
	.ui-widget-header .ui-state-hover,
	.ui-state-focus,
	.ui-widget-content .ui-state-focus,
	.ui-widget-header .ui-state-focus {
		/* border: 1px solid #fbcb09; */
		border: 1px solid transparent;
		background: #ffffff; /*#fdf5ce url("images/ui-bg_glass_100_fdf5ce_1x400.png") 50% 50% repeat-x;*/
		color: #f26522;
		font-weight: normal;
	}
	.ui-state-hover a,
	.ui-state-hover a:hover,
	.ui-state-hover a:link,
	.ui-state-hover a:visited,
	.ui-state-focus a,
	.ui-state-focus a:hover,
	.ui-state-focus a:link,
	.ui-state-focus a:visited {
		color: #c77405;
		text-decoration: none;
	}
	.ui-state-active,
	.ui-widget-content .ui-state-active,
	.ui-widget-header .ui-state-active {
		border: 1px solid #fbd850;
		background: #ffffff; /*url("images/ui-bg_glass_65_ffffff_1x400.png") 50% 50% repeat-x;*/
		font-weight: bold;
		color: #eb8f00;
	}
	.ui-state-active a,
	.ui-state-active a:link,
	.ui-state-active a:visited {
		color: #eb8f00;
		text-decoration: none;
	}
	.alert-success{
		margin-bottom:0px; 
		margin-top:20px;
	}
	.intl-tel-input .selected-flag {
		z-index: 1;
	}
	.country_region .bootstrap-select.form-control:not([class*="col-"]) {
		max-width: 252px;
	}
</style>

<section class="contain800 member_applications_notify_screen_size" style="display:none;">
	<p>The RSPO membership application form is not supported for this screen size. If you are seeing this message, please open the form on devices with screens larger than 1024 pixels (desktops, laptops or larger tablets).</p>
</section>

<?php echo form_open_multipart($this->uri->uri_string(), 'id="frmApply" name="frmApply"') ?>
<section class="first-section">
	<div class="container text-center">
		<div class="row">
			<h1 style="font-weight: bold; margin-top:24px; margin-bottom:25px; font-size: 25px; padding-top:3px; text-transform:uppercase;">MEMBERSHIP APPLICATION</h1>
		</div>
		
		<div class="row tml-contact id-organisation" id="garischange_member_application">
			<div class="col-lg-3 col-md-3 col-sm-3 text-left Map-left-status-category">
				<font style="font-size:10px; letter-spacing:2px;">APPLYING AS</font><br/>
				<h5><?php echo $membersapp->type; ?></h5>
				<h5><?php echo $membersapp->category; ?></h5>
			</div>
			
			<div class="col-lg-6 col-md-6 col-sm-6 nav-tabs tab-point-MAP" id="myTab">
				<div class="col-am-5-contain contain-point-map-am-1">
					<a href="#1" class="active" id="bullet1">
						<div class="bullets-zero"></div>
						<label class="membershipstep">1. Organisation Details</label>
					</a>
				</div>
				<div class="col-am-5-contain contain-point-map-am-2">
					<a href="#2" id="bullet2">
						<div class="bullets-zero"></div>
						<label class="membershipstep">2. Contact Details</label>
					</a>
				</div>
				<div class="col-am-5-contain contain-point-map-am-3">
					<a href="#3" id="bullet3" disabled="disabled">
						<div class="bullets-zero"></div>
						<label class="membershipstep">3. Group Membership</label>
					</a>
				</div>
				<div class="col-am-5-contain contain-point-map-am-4">
					<a href="#4" id="bullet4">
						<div class="bullets-zero"></div>
						<label class="membershipstep">4. Questions</label>
					</a>
				</div>
				<div class="col-am-5-contain contain-point-map-am-5">
					<a href="#5" id="bullet5">
						<div class="bullets-zero" id="garis4"></div>
						<label class="membershipstep">5. Supporting Details</label>
					</a>
				</div>
			</div>
		</div>
	</div>
</section>

<section>
	<div class="contain800">
		{{ session:messages success="alert alert-success alert-dismissible" notice="alert alert-info alert-dismissible" error="alert alert-danger alert-dismissible" }}

		<?php if (!empty($error)): ?>
			<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><?php echo $error['error'] ?></div>
		<?php endif; ?>
	</div>
</section>

<?php if (validation_errors()): ?>
<section>
	<div class="contain800">
		<p class="alert alert-warning">
			<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
			Kindly check the form for missing fields.
			<?php //echo validation_errors();?>
		</p>
	</div>
</section>
<?php else:?>
	<script type="text/javascript"> gaProcess('members/application', 'Submit', 'submitted'); </script>
<?php endif; ?>

<div class="members_applications tab-content responsive">

<!-- organisation detail -->
<div id="1" class="tab-pane active">
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading title_forms">1. ORGANISATION DETAIL</h3>
	</div>
	<div class="container">
	<div class="row">
		
		<div class="col-md-3 col-md-3 col-sm-3 contain-sidebar-MAP"></div>
		<div class="col-lg-6 col-md-6 col-sm-6 container-MAP-AM">
			<div class="box-contact-form">
				
				<?php if (!empty($member_subcategories[$membersapp->category])): ?>
				<div class="form-group">
					<label>Select if you are one of the following</label>
						<?php
							if ($membersapp->category=='Oil Palm Growers')
								$subcategory_required = '';
							elseif ($membersapp->category=='Consumer Goods Manufacturers' OR $membersapp->category=='Palm Oil Processors and/or Traders')
								$subcategory_required = 'required';
							echo form_dropdown('profession', array(""=>"Please select")+$member_subcategories[$membersapp->category], $membersapp->profession, 'class="selectpicker form-control '.$subcategory_required.'" id="dd_profession"');
							echo form_error('profession') ? '<div class="alert alert-danger">'.form_error('profession').'</div>' : '';
						?>
					<br />&nbsp;
				</div>
				<?php endif; ?>
				
				<div class="form-group">
					<label>Organisation's Name</label>
					<?php echo form_input('org_name', htmlspecialchars_decode($membersapp->name), 'class="form-control required"'); ?>
					<?php echo form_error('org_name') ? '<div class="alert alert-danger">'.form_error('org_name').'</div>' : ''; ?>
				</div>

				<?php if ( $membersapp->category <> 'Environmental or Nature Conservation Organisations (Non Governmental Organisation)' && $membersapp->category <> 'Social or Development Organisations (Non Governmental Organisation)' && ($membersapp->type <> 'Affiliate' && $membersapp->category <> 'Individual')  && $membersapp->category <> 'Smallholder Group Manager' ): ?>
				<div class="form-group" id="divsubparent" style="margin-bottom:0px;">
					<label>Are you a parent/subsidiary company?</label><br/>
					<?php
						$parent_companies = array(
							"" => "Not applicable",
							"yes" => "Parent company",
							"sub" => "Group member",
						);
					?>
					<?php echo form_dropdown('parent_company', $parent_companies, $membersapp->parent_company, 'class="selectpicker form-control required" id="parentCompany" title="Please select" onchange="displaychildfields(this.value);"'); ?>
					<br />&nbsp;
				</div>
				<?php endif; ?>
				
				<?php if ($this->current_user->greenpalm == 'y'): ?>
					<div class="form-group">
						<label for="greenpalm_member_num">Greenpalm Member Account Number</label>
						<?php echo form_input('greenpalm_member_num', $membersapp->greenpalm_member_num, 'class="form-control required" id="greenpalm_member_num"') ?>
						<?php echo form_error('greenpalm_member_num') ? '<div class="alert alert-danger">'.form_error('greenpalm_member_num').'</div>' : ''; ?>
						<!-- <input type="text" class="form-control" name="reg-number"> -->
					</div>
				<?php endif; ?>

				<div class="form-group">
					<label>Address</label>
					<?php echo form_input('address', htmlspecialchars_decode($membersapp->address), 'class="form-control required"') ?>
					<?php echo form_error('address') ? '<div class="alert alert-danger">'.form_error('address').'</div>' : ''; ?>
				</div>
				
				<div>
					<div class="form-group half-width">
						<label>City</label>
						<?php echo form_input('address_city', htmlspecialchars_decode($membersapp->address_city), 'class="form-control required"') ?>
						<?php echo form_error('address_city') ? '<div class="alert alert-danger">'.form_error('address_city').'</div>' : ''; ?>
					</div>
					<div class="form-group half-width-right">
						<label>State/Province</label>
						<?php echo form_input('address_state', htmlspecialchars_decode($membersapp->address_state), 'class="form-control required"') ?>
						<?php echo form_error('address_state') ? '<div class="alert alert-danger">'.form_error('address_state').'</div>' : ''; ?>
					</div>
					<div class="clearfix"></div>
				</div>
				
				<div>
					<div class="form-group half-width">
						<label>Country</label><br/>
						{{dropdowns:countries class="selectpicker required" id="mcountry" value="<?php echo $membersapp->country ?>" }}
						<?php echo form_error('country') ? '<div class="alert alert-danger">'.form_error('country').'</div>' : ''; ?>
						<script type="text/javascript">
						$(document).ready(function(){
							$('#mcountry').on('change', function(){
								$.ajax({
									url: SITE_URL + 'members/countrycode',
									data: {c: $(this).val()},
									method: "POST",
									success: function(html){
										if (html && html.length == 2)
										{
											$('.tlp-code').intlTelInput("selectCountry", html);
										}
									}
								});
							});
						});
						</script>
					</div>
					<div class="form-group half-width-right">
						<label>ZIP/Post code</label>
						<?php echo form_input('address_zip', htmlspecialchars_decode($membersapp->address_zip), 'class="form-control required"') ?>
						<?php echo form_error('address_zip') ? '<div class="alert alert-danger">'.form_error('address_zip').'</div>' : ''; ?>
						<!-- <input type="text" class="form-control" name="address_zip"> -->
					</div>
					<div class="clearfix"></div>
				</div>
				
				<div class="form-group">
					<label>Telephone</label>
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" value="<?php echo $membersapp->telephone?>" name="telephone">
						</div>
						<?php //echo form_input('telephone', $membersapp->telephone, 'class="form-control required required2"') ?>
					</div>
					<?php echo form_error('telephone') ? '<div class="alert alert-danger">'.form_error('telephone').'</div>' : ''; ?>
				</div>
				
				<div class="form-group">
					<label>Fax</label>  <i>(Optional)</i>
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input value="<?php echo $membersapp->fax?>" class="mobile-number tlp-code" type="tel" name="fax">
						</div>
						<?php //echo form_input('fax', $membersapp->fax, 'class="form-control"') ?>
					    <!-- <input class="form-control" type="text"> -->
					</div>
				</div>
				
				<div class="form-group">
					<label>Email</label>
					<?php echo form_input('email', $membersapp->email, 'class="form-control required"') ?>
					<?php echo form_error('email') ? '<div class="alert alert-danger">'.form_error('email').'</div>' : ''; ?>
					<!-- <input type="text" class="form-control" name="fullname"> -->
				</div>
				
				<div class="form-group">
					<label>Website</label> <i>(Optional)</i>
					<?php echo form_input('website', $membersapp->website, 'class="form-control"') ?>
					<?php echo form_error('website') ? '<div class="alert alert-danger">'.form_error('website').'</div>' : ''; ?>
					<!-- <input type="text" class="form-control" name="web"> -->
				</div>
				
				<div class="form-group">
					<label>Business Registration Number</label><i> (please use the full legal entity number)</i>
					<?php echo form_input('registration_number', $membersapp->registration_number, 'class="form-control required"') ?>
					<?php echo form_error('registration_number') ? '<div class="alert alert-danger">'.form_error('registration_number').'</div>' : ''; ?>
					<!-- <input type="text" class="form-control" name="reg-number"> -->
				</div>

				<?php if ($membersapp->category == 'Oil Palm Growers'): ?>
				<div class="form-group">
					<label>Primary Market Operations</label>
					<div class="clearfix">
						<label class="normal"><?php echo form_radio('primary_market_ops', 'Indonesia', $membersapp->primary_market_ops == 'Indonesia', 'class="form-control"') ?> <span>Indonesia</span></label>
						<label class="normal"><?php echo form_radio('primary_market_ops', 'Malaysia', $membersapp->primary_market_ops == 'Malaysia', 'class="form-control"') ?> <span>Malaysia</span></label>
						<label class="normal"><?php echo form_radio('primary_market_ops', 'World', $membersapp->primary_market_ops == 'World', 'class="form-control"') ?> <span>Rest of the World</span></label>
					</div>
				</div>

				<div class="form-group">
					<label>Other Market Operations</label> <i>(Please separate country names with comas)</i>
					<textarea name="other_market_ops" class="form-control" rows="5" style="height:100px;" id="other_market_ops"><?php echo htmlspecialchars_decode($membersapp->other_market_ops); ?></textarea>
				</div>
				<?php endif; ?>

				<div class="form-group">
					<label>Organisation's Logo</label> <i>(PNG, JPG, or GIF and no more than 1.5MB)</i>
					<input type="file" id="logo" class="filestyle" name="logo" onchange="copyfname(this.value, $(this), 'image')">
					<input type="hidden" />
					<?php if (!empty($membersapp->logo)): ?>
						<?php echo form_hidden('upload_logo', $membersapp->logo); ?>
						<div class="clear"></div>
						<label class="inline">Filename: </label> <?php echo $membersapp->logo; ?>
						<div class="clear"></div>
						<img src="<?php echo site_url(UPLOAD_PATH.'memberlogos/'.$membersapp->logo); ?>" width="200" />
					<?php endif; ?>
					
					<?php echo form_error('upload_logo') ? '<div class="alert alert-danger">'.form_error('upload_logo').'</div>' : ''; ?>
				</div>

				<div class="form-group">
					<label class="mb-0">Organization details</label>
					<textarea id="profile_text" onKeyUp="limitText(this.form.profile,this.form.countdown,500);" class="form-control" maxlength="500" rows="5" name="profile" placeholder="Please provide some background information on your organisation in less than 500 words" style="height:200px;"><?php echo htmlspecialchars_decode($membersapp->profile); ?></textarea><br />
					<small>You have <b id="countdown">500</b> characters left.</small>
					<?php echo form_error('profile') ? '<div class="alert alert-danger">'.form_error('profile').'</div>' : ''; ?>

					<script type="text/javascript">
						$(document).ready(function(){
							limitText(document.frmApply.profile,document.frmApply.countdown,500)
						});
						var profile_text = document.getElementById("profile_text");
						profile_text.onpaste = function(e){
							//do some IE browser checking for e
							var max = profile_text.getAttribute("maxlength");
							e.clipboardData.getData('text/plain').slice(0, max);
							limitText(this.form.profile,this.form.countdown, max);
						};

						function limitText(limitField, limitCount, limitNum) {
							if (limitField.value.length > limitNum) {
								$('#countdown').text(limitField.value.substring(0, limitNum));
							} else {
								$('#countdown').text(limitNum - limitField.value.length);
							}
						}
					</script>
				</div>
				<div class="form-group text-right" style="margin-bottom:0px;">
					<button name="btnSave" type="submit" class="btn btn-lg btn-orange btn-save" value="1">SAVE</button>
					<input type="submit" value="NEXT" id="next_1" class="btn btn-lg btn-orange btn-next" style="border: 1px solid #ED7B1C;">
				</div>
			</div>
		</div>
		<div class="col-md-3 col-md-3 col-sm-3 contain-sidebar-MAP"></div>
	</div>
	</div>
</section>
</div>

<!-- contact detail -->
<div id="2" class="tab-pane">
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<div>
			<h3 class="subsection-heading" style="margin-top:6px;">2. CONTACT DETAIL <a href="#" tabindex="0" id ="pop-info" data-html="true" data-toggle="popover" data-trigger="focus" data-content="<p>
			The membership application should be endorsed and signed off
			by a senior member of the organisation who will also be accountable in
			ensuring the organisation conforms to the <a href='{{url:site}}publications/download/cf2467a9f48dd7b'>RSPO Statutes,</a>
			and <a href='{{url:site}}publications/download/cbb1628a5688f20'>Code of Conduct</a>.</p>"><img style="margin-top:-5px;" src="{{ theme:image_path file='oval-information.png' }}"></a></h3>
		</div>
	</div>
	
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6 container-MAP-AM"> 
				<div class="box-contact-form " style="margin-top:10px;">
					<h3 class="subsection-heading">PRIMARY REPRESENTATIVE</h3>
					<div class="form-group">
						<label>First Name</label>
						<?php echo form_input('name_p', htmlspecialchars_decode($membersapp->name_p), 'class="form-control  checkuse" rel="name_s"') ?>
						<?php echo form_error('name_p') ? '<div class="alert alert-danger">'.form_error('name_p').'</div>': ''; ?>
					</div>
					<div class="form-group">
						<label>Last Name</label>
						<?php echo form_input('name_last_p', htmlspecialchars_decode($membersapp->name_last_p), 'class="form-control  checkuse" rel="name_s"') ?>
						<?php echo form_error('name_last_p') ? '<div class="alert alert-danger">'.form_error('name_last_p').'</div>': ''; ?>
					</div>
					<div class="form-group">
						<label>Position</label>
						<?php echo form_input('designation_p', htmlspecialchars_decode($membersapp->designation_p), 'class="form-control required" rel="designation_s"') ?>
						<?php echo form_error('designation_p') ? '<div class="alert alert-danger">'.form_error('designation_p').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Telephone</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->telephone_p?>" class="mobile-number tlp-code" type="tel" name="telephone_p">
							</div>
							<?php //echo form_input('telephone_p', $membersapp->telephone_p, 'class="form-control required required2"') ?>
						</div>
						<?php echo form_error('telephone_p') ? '<div class="alert alert-danger">'.form_error('telephone_p').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Fax</label> <i>(Optional)</i>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->fax_p?>" class="mobile-number tlp-code" type="tel" name="fax_p">
							</div>
						<?php //echo form_input('fax_p', $membersapp->fax_p, 'class="form-control"') ?>
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<?php echo form_input('email_p', $membersapp->email_p, 'class="form-control checkuse" rel="email_s"') ?>
						<div class="alert alert-danger" style="display:<?php echo form_error('email_p') ? 'block' : 'none'; ?>;">
							<?php echo form_error('email_p') ? form_error('email_p') : ''; ?>
						</div>
						<?php //echo form_error('email_p') ? '<div class="alert alert-danger">'.form_error('email_p').'</div>' : ''; ?>
					</div>
					
					<br/>
					<h3 class="subsection-heading">SECONDARY REPRESENTATIVE</h3>
					<div class="form-group">
						<label>First Name</label>
						<?php echo form_input('name_s', htmlspecialchars_decode($membersapp->name_s), 'class="form-control checkuse" rel="name_p"') ?>
						<?php echo form_error('name_s') ? '<div class="alert alert-danger">'.form_error('name_s').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>last Name</label>
						<?php echo form_input('name_last_s', htmlspecialchars_decode($membersapp->name_last_s), 'class="form-control checkuse" rel="name_p"') ?>
						<?php echo form_error('name_last_s') ? '<div class="alert alert-danger">'.form_error('name_last_s').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Position</label>
						<?php echo form_input('designation_s', htmlspecialchars_decode($membersapp->designation_s), 'class="form-control required" rel="designation_p"') ?>
						<div class="alert alert-danger" style="display:none;"></div>
						<?php echo form_error('designation_s') ? '<div class="alert alert-danger">'.form_error('designation_s').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Telephone</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->telephone_s?>" class="mobile-number tlp-code" type="tel" name="telephone_s">
							</div>
							<?php //echo form_input('telephone_s', $membersapp->telephone_s, 'class="form-control required required2"') ?>
						</div>
						<?php echo form_error('telephone_s') ? '<div class="alert alert-danger">'.form_error('telephone_s').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Fax</label> <i>(Optional)</i>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->fax_s?>" class="mobile-number tlp-code" type="tel" name="fax_s">
							</div>
							<?php //echo form_input('fax_s', $membersapp->fax_s, 'class="form-control"') ?>
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<?php echo form_input('email_s', $membersapp->email_s, 'class="form-control checkuse" rel="email_p"') ?>
						<div class="alert alert-danger" style="display:<?php echo form_error('email_s') ? 'block' : 'none'; ?>;">
							<?php echo form_error('email_s') ? form_error('email_s') : ''; ?>
						</div>
						<?php //echo form_error('email_s') ? '<div class="alert alert-danger">'.form_error('email_s').'</div>' : ''; ?>
					</div>
				</div>
			</div>
		
			<div class="col-md-6 col-sm-6 container-MAP-AM"> 
				<div class="box-contact-form " style="margin-top:10px;">
					<h3 class="subsection-heading">CONTACT PERSON</h3>
					<div class="form-group">
						<label>First Name</label>
							<?php echo form_input('contact_person', htmlspecialchars_decode($membersapp->contact_person), 'class="form-control required"') ?>
							<?php echo form_error('contact_person') ? '<div class="alert alert-danger">'.form_error('contact_person').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Last Name</label>
							<?php echo form_input('contact_lname', htmlspecialchars_decode($membersapp->contact_lname), 'class="form-control required"') ?>
							<?php echo form_error('contact_lname') ? '<div class="alert alert-danger">'.form_error('contact_lname').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Position</label>
							<?php echo form_input('designation', htmlspecialchars_decode($membersapp->designation), 'class="form-control required"') ?>
							<?php echo form_error('designation') ? '<div class="alert alert-danger">'.form_error('designation').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Telephone</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->contact_tel?>" class="mobile-number tlp-code" type="tel" name="contact_tel">
							</div>
							<?php //echo form_input('contact_tel', $membersapp->contact_tel, 'class="form-control required required2"') ?>
						</div>
						<?php echo form_error('contact_tel') ? '<div class="alert alert-danger">'.form_error('contact_tel').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Fax</label> <i>(Optional)</i> 
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->contact_fax?>" class="mobile-number tlp-code" type="tel" name="contact_fax">
							</div>
							<?php //echo form_input('contact_fax', $membersapp->contact_fax, 'class="form-control"') ?>
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<?php echo form_input('contact_email', $membersapp->contact_email, 'class="form-control required"') ?>
						<?php echo form_error('contact_email') ? '<div class="alert alert-danger">'.form_error('contact_email').'</div>' : ''; ?>
					</div>
					
					<br/>
					<h3 class="subsection-heading">FINANCE CONTACT</h3>
					<H5>FOR MEMBERSHIP FEE</h5>
					
					<div class="form-group">
						<label>First Name</label>
							<?php echo form_input('name_f', htmlspecialchars_decode($membersapp->name_f), 'class="form-control required"') ?>
							<?php echo form_error('name_f') ? '<div class="alert alert-danger">'.form_error('name_f').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Last Name</label>
							<?php echo form_input('name_last_f', htmlspecialchars_decode($membersapp->name_last_f), 'class="form-control required"') ?>
							<?php echo form_error('name_last_f') ? '<div class="alert alert-danger">'.form_error('name_last_f').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Position</label>
							<?php echo form_input('designation_f', htmlspecialchars_decode($membersapp->designation_f), 'class="form-control required"') ?>
							<?php echo form_error('designation_f') ? '<div class="alert alert-danger">'.form_error('designation_f').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Telephone</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->telephone_f?>" class="mobile-number tlp-code" type="tel" name="telephone_f">
							</div>
							<?php //echo form_input('telephone_f', $membersapp->telephone_f, 'class="form-control required required2"') ?>
						</div>
						<?php echo form_error('telephone_f') ? '<div class="alert alert-danger">'.form_error('telephone_f').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Fax</label> <i>(Optional)</i> 
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->fax_f?>" class="mobile-number tlp-code" type="tel" name="fax_f">
							</div>
							<?php //echo form_input('fax_f', $membersapp->fax_f, 'class="form-control"') ?>
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<?php echo form_input('email_f', $membersapp->email_f, 'class="form-control required"') ?>
						<?php echo form_error('email_f') ? '<div class="alert alert-danger">'.form_error('email_f').'</div>' : ''; ?>
					</div>
					
					<div class="form-group text-right" style="margin-bottom:0px;">
						<input type="submit" value="PREV" id="prev_1" class="btn btn-lg btn-orange btn-prev" style="border: 1px solid #ED7B1C;">
						<button name="btnSave" type="submit" class="btn btn-lg btn-orange btn-save" value="2">SAVE</button>
						<!-- <input type="submit" value="SAVE" name="btnSave" class="btn btn-lg btn-orange btn-save" style="border: 1px solid #ED7B1C;"> -->
						
						<!-- check go to step3 or step4 -->
						<input type="submit" value="NEXT" id="next_2" class="btn btn-lg btn-orange btn-next c_next2" style="border: 1px solid #ED7B1C;">
						<input type="submit" value="NEXT" id="next_3_1" class="btn btn-lg btn-orange btn-next c_next3" style="border: 1px solid #ED7B1C;">
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
</div>

<!-- group membership -->
<div id="3" class="tab-pane group_membership">
<?php $this->load->view('/applications/group-membership.php'); ?>
</div>

<!-- question -->
<div id="4" class="tab-pane">
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading title_forms">4. QUESTIONS</h3>
	</div>
	<div class="container">
		<div class="row">
		
		<div class="col-md-3 col-md-3 col-sm-3 contain-sidebar-MAP"></div>
		<div class="col-lg-6 col-md-6 col-sm-6 container-MAP-AM">
			<div class="box-contact-form organisation">
				<?php if ($membersapp->category=='Supply Chain Group Manager'): ?>
				<?php
					$scg_manager_members = null;
					if ($membersapp->scg_manager_members)
					{
						$scg_manager_members = unserialize($membersapp->scg_manager_members);
					}
				?>
				<div class="form-group">
					<label>Supply Chain Group Manager</label>
					<p>List of members under the manager, with Palm Oil consumption for each member</p>
					<table width="100%" cellspacing="1" id="scgm_table">
						<thead>
							<tr>
								<th>Member Name</th>
								<th>Palm Oil Consumption (MT)</th>
							</tr>
						</thead>
						<tbody>
						<?php if ($membersapp->scg_manager_members && is_array($scg_manager_members)): ?>
							<tr>
								<td style="width:70%;padding-right:5px;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control required" value="<?php echo $scg_manager_members[0] ?>"/></td>
								<td style="width:30%;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control max500 required" value="<?php echo $scg_manager_members[1] ?>" /></td>
							</tr>
							<?php if (count($scg_manager_members) > 2): ?>
								<?php for ($i=2; $i<count($scg_manager_members); $i+=2): ?>
									<tr>
										<td style="width:70%;padding-right:5px;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control required" value="<?php echo $scg_manager_members[$i] ?>"/></td>
										<td style="width:30%;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control max500 required" style="float:left;width:75%;" value="<?php echo $scg_manager_members[$i+1] ?>" /><a href="#" class="btn btn-lg btn-orange remove_scgm" style="width:25%;">x</a></td>
									</tr>
								<?php endfor; ?>
							<?php endif; ?>
						<?php else: ?>
							<tr>
								<td style="width:70%;padding-right:5px;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control required" /></td>
								<td style="width:30%;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control max500 required" /></td>
							</tr>
						<?php endif; ?>
						</tbody>
						<tfoot>
							<tr>
								<td colspan="2"><a href="#" id="add_scgm">Add more</a></td>
							</tr>
						</tfoot>
					</table>
					<?php echo form_error('scg_manager_members[]') ? '<div class="alert alert-danger">'.form_error('scg_manager_members[]').'</div>' : ''; ?>
				</div>
				<?php endif; ?>
				
				<?php if( 
					$membersapp->category 	== 'Consumer Goods Manufacturers' or 
					$membersapp->category 	== 'Retailers' or 
					$membersapp->category 	== 'Palm Oil Processors and/or Traders' or 
					$membersapp->category 	== 'Banks and Investors' or 
					$membersapp->category 	== 'Environmental or Nature Conservation Organisations (Non Governmental Organisation)' or 
					$membersapp->category 	== 'Oil Palm Growers' or 
					$membersapp->category 	== 'Social or Development Organisations (Non Governmental Organisation)' or 
					$membersapp->category 	== 'Supply Chain Group Manager' or 
					$membersapp->type		== 'Associate' or
					$membersapp->type		== 'Supply Chain Associate' or
					$membersapp->type 		== 'Affiliate' or 
					$membersapp->type 		== 'Affiliate Members'
				): ?>
					<div class="form-group">
						<label class="mb-0">How will your organisation promote the RSPO internally and to other stakeholders?</label>
						<textarea class="form-control required" rows="5" name="q1" placeholder="" style="height:200px;"><?php echo htmlspecialchars_decode($membersapp->q1) ?></textarea>
                        <?php echo form_error('q1') ? '<div class="alert alert-danger">'.form_error('q1').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label class="mb-0">Where relevant, what processes is the organisation establishing to engage with interested parties, for example to resolve conflict or to use sustainably produced palm oil? </label>
						<textarea class="form-control required" rows="5" name="q2" placeholder="" style="height:200px;"><?php echo htmlspecialchars_decode($membersapp->q2) ?></textarea>
                        <?php echo form_error('q2') ? '<div class="alert alert-danger">'.form_error('q2').'</div>' : ''; ?>
					</div>
				<?php endif; ?>
				
				<?php if( 
					$membersapp->category 	== 'Banks and Investors' or 
					$membersapp->category 	== 'Environmental or Nature Conservation Organisations (Non Governmental Organisation)' or 
					$membersapp->category 	== 'Oil Palm Growers' or 
					$membersapp->category 	== 'Social or Development Organisations (Non Governmental Organisation)' or 
					$membersapp->category 	== 'Supply Chain Group Manager' or 
					$membersapp->category 	== 'Consumer Goods Manufacturers' or 
					$membersapp->category 	== 'Retailers' or 
					$membersapp->category 	== 'Palm Oil Processors and/or Traders' or 
					$membersapp->type		== 'Associate' or 
					$membersapp->type		== 'Supply Chain Associate'
				): ?>
					<div class="form-group">
						<label class="mb-0">Where relevant, how will your organisation work towards implementing the RSPO Principles and Criteria or assessing supplier performance against these criteria?</label>
						<textarea class="form-control required" rows="5" name="q3" placeholder="" style="height:200px;"><?php echo htmlspecialchars_decode($membersapp->q3) ?></textarea>
                        <?php echo form_error('q3') ? '<div class="alert alert-danger">'.form_error('q3').'</div>' : ''; ?>
					</div>
				<?php endif; ?>
				
				<?php if( 
					$membersapp->category 	== 'Consumer Goods Manufacturers' or 
					$membersapp->category 	== 'Retailers' or 
					$membersapp->category 	== 'Palm Oil Processors and/or Traders' or 
					$membersapp->type 		== 'Affiliate' or 
					$membersapp->type 		== 'Affiliate Members'
				): ?>
					<div class="form-group">
						<label>Please state your annual usage of palm oil and palm derivatives in metric tonnes</label>
						<input type="text" class="form-control required" name="q_usage" value="<?php echo $membersapp->q_usage; ?>">
						<?php echo form_error('q_usage') ? '<div class="alert alert-danger">'.form_error('q_usage').'</div>' : ''; ?>
					</div>
				<?php endif; ?>
				
				<?php if ($membersapp->category=='Oil Palm Growers'): ?>
				<div class="form-group">
					<label>Total Land Area</label> <i>(in hectares)</i>
					<?php echo form_input('production_area', $membersapp->production_area, 'class="form-control required"') ?>
					<?php echo form_error('production_area') ? '<div class="alert alert-danger">'.form_error('production_area').'</div>' : ''; ?>
					<!-- <input type="text" class="form-control" name="address" value=""> -->
				</div>
				<?php endif; ?>
				
				<?php if( 
					$membersapp->category 	== 'Consumer Goods Manufacturers' or 
					$membersapp->category 	== 'Retailers' or 
					$membersapp->category 	== 'Palm Oil Processors and/or Traders' or 
					$membersapp->category 	== 'Banks and Investors' or 
					$membersapp->category 	== 'Environmental or Nature Conservation Organisations (Non Governmental Organisation)' or 
					$membersapp->category 	== 'Oil Palm Growers' or 
					$membersapp->category 	== 'Social or Development Organisations (Non Governmental Organisation)' or 
					$membersapp->category 	== 'Supply Chain Group Manager' or 
					$membersapp->type		== 'Associate' or
					$membersapp->type		== 'Supply Chain Associate' or
					$membersapp->type 		== 'Affiliate' or 
					$membersapp->type 		== 'Affiliate Members'
				): ?>
					<!-- <div class="form-group">
						<label class="mb-0">Any other information that would support the application such as what your organisation hopes to gain from joining the RSPO. </label>
						<textarea class="form-control required" rows="5" name="remarks" placeholder="" style="height:200px;"><?php echo htmlspecialchars_decode($membersapp->remarks) ?></textarea>
					</div> -->
					
					<div class="form-group">
						<label class="mb-0">Any other information that would support the application such as what your organisation hopes to gain from joining the RSPO. </label>
						<textarea class="form-control required" rows="5" name="q4" placeholder="" style="height:200px;"><?php echo htmlspecialchars_decode($membersapp->q4) ?></textarea>
					</div>
				<?php endif; ?>	
					
				<div class="form-group text-right" style="margin-bottom:0px;">
					<!-- check prev step3 or step2 -->
					<input type="submit" value="PREV" id="prev_2_1" class="btn btn-lg btn-orange btn-prev c_prev_2" style="border: 1px solid #ED7B1C;">
					<input type="submit" value="PREV" id="prev_3" class="btn btn-lg btn-orange btn-prev c_prev_3" style="border: 1px solid #ED7B1C;">
					
					<button name="btnSave" type="submit" class="btn btn-lg btn-orange btn-save" value="4">SAVE</button>
					<!-- <input type="submit" value="SAVE" name="btnSave" class="btn btn-lg btn-orange" style="border: 1px solid #ED7B1C;"> -->
					<input type="submit" value="NEXT" id="next_4" class="btn btn-lg btn-orange" style="border: 1px solid #ED7B1C;">
				</div>	
			</div>
		</div>
		<div class="col-md-3 col-md-3 col-sm-3 contain-sidebar-MAP"></div>
	</div>
	</div>
</section>
</div>

<!-- supporting detail -->
<div id="5" class="tab-pane">
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading title_forms">5. SUPPORTING DETAIL</h3>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6 container-MAP-AM">
				<div class="box-contact-form">
					
					<h3 class="subsection-heading">DOCUMENTS</h3>
                    <?php if ($membersapp->category == 'Consumer Goods Manufacturers'): ?>
                        <!-- docs sector CGM -->
						<?php $this->load->view('/applications/application-cgm.php'); ?>
						
                    <?php elseif ($membersapp->category == 'Banks and Investors'): ?>
                        <!-- docs sector BI -->
						<?php $this->load->view('/applications/application-bi.php'); ?>
						
                    <?php elseif ($membersapp->category == 'Retailers'): ?>
                        <!-- docs sector RETAILER -->
						<?php $this->load->view('/applications/application-retailer.php'); ?>
						
                    <?php elseif ($membersapp->category == 'Environmental or Nature Conservation Organisations (Non Governmental Organisation)'): ?>
                        <!-- docs sector ENGO -->
						<?php $this->load->view('/applications/application-engo.php'); ?>
						
                    <?php elseif ($membersapp->category == 'Social or Development Organisations (Non Governmental Organisation)'): ?>
                        <!-- docs sector SNGO -->
						<?php $this->load->view('/applications/application-sngo.php'); ?>
						
                    <?php elseif ($membersapp->category == 'Palm Oil Processors and/or Traders'): ?>
                        <!-- docs sector PNT -->
						<?php $this->load->view('/applications/application-pnt.php'); ?>
						
                    <?php elseif ($membersapp->type == 'Associate' or $membersapp->type == 'Supply Chain Associate'): ?>
                        <!-- docs sector SCA -->
						<?php $this->load->view('/applications/application-sca.php'); ?>
						
                    <?php elseif ($membersapp->category == 'Supply Chain Group Manager'): ?>
                        <!-- docs sector SCGM -->
						<?php $this->load->view('/applications/application-scgm.php'); ?>
						
                    <?php elseif ($membersapp->type == 'Affiliate' or $membersapp->type == 'Affiliate Members'): ?>
                        <!-- docs sector Affiliate -->
						<?php $this->load->view('/applications/application-affiliate.php'); ?>
                    <?php endif; ?>

					<?php
						$additional_docs = false;
						if ($membersapp->category == 'Oil Palm Growers' && ($membersapp->profession == 'Small growers' || $membersapp->category == 'Oil Palm Grower'))
							$additional_docs = true;
					?>
					<div id="additional_docs" style="display:<?php echo $additional_docs ? 'block' : 'none' ?>">
						<!-- docs sector opg and sub sector small growers -->
						<?php $this->load->view('/applications/application-opg-sg.php'); ?>
					</div>
					<?php // end of $additional_docs ?>
					
					<?php
						$additional_docs2 = false;
						if ($membersapp->category == 'Oil Palm Growers' && $membersapp->profession == 'Smallholder Group Manager')
							$additional_docs2 = true;
					?>
					<div id="additional_docs2" style="display:<?php echo $additional_docs2 ? 'block' : 'none' ?>">
						<!-- docs sector opg and sub sector smallholders -->
						<?php $this->load->view('/applications/application-opg-sh.php'); ?>
					</div>
					<?php // end of $additional_docs2 ?>
				</div>
			</div>
			
			<div class="col-md-6 col-sm-6 container-MAP-AM">
				<div class="box-contact-form">
					<h3 class="subsection-heading">MEMBERSHIP APPLICATION</h3>
					<h5>IS MADE BY</h5>
					
					<div class="form-group">
						<label>Full Name</label>
						<?php echo form_input('name_a', htmlspecialchars_decode($membersapp->name_a), 'class="form-control required"') ?>
						<?php echo form_error('name_a') ? '<div class="alert alert-danger">'.form_error('name_a').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Position</label>
						<?php echo form_input('designation_a', htmlspecialchars_decode($membersapp->designation_a), 'class="form-control required"') ?>
						<?php echo form_error('designation_a') ? '<div class="alert alert-danger">'.form_error('designation_a').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Email</label>
						<?php echo form_input('email_a', $membersapp->email_a, 'class="form-control required"') ?>
						<?php echo form_error('email_a') ? '<div class="alert alert-danger">'.form_error('email_a').'</div>' : ''; ?>
					</div>
					
					<!--
					<div class="form-group">
						<label>Application Date</label> <i>(dd/mm/yyyy)</i>
						<div class='input-group date datepicker'>
							<?php echo form_input('applied_date', $membersapp->applied_date ? date('d/m/Y', $membersapp->applied_date) : '', 'class="form-control"') ?>
							<span class="input-group-addon">
								<span class="glyphicon glyphicon-calendar rz-datepicker" style="font-size:20px;"></span>
							</span>
						</div>
					</div>
					-->
					
					<div class="row">
						<div class="form-group">
							<div class="col-md-1">
							<?php echo form_checkbox('newsletter', 'y', $membersapp->newsletter=='y', 'class="form-control" id="check_newsletter"'); ?>
							</div>
							<div class="col-md-11" style="padding-top: 15px;">
								<label for="check_newsletter">Also sign me up to the RSPO email newsletter</label>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-1">
							<!-- <input type="checkbox" name="newsletter"> -->
						</div>
						<div class="col-md-11" style="padding-left:0px;">
							
							<div style="float:right; margin-right:5px;"><br />&nbsp;
								<input type="submit" value="PREV" id="prev_4" class="btn btn-lg btn-orange btn-prev" style=" border: 1px solid #ED7B1C;">
								<button name="btnSave" type="submit" class="btn btn-lg btn-orange btn-save" value="5">SAVE</button>
								<!-- <input type="submit" value="SAVE" name="btnSave" class="btn btn-lg btn-orange" style=" border: 1px solid #ED7B1C;"> -->
								<input type="submit" value="SUBMIT" name="btnSubmit" class="btn btn-lg btn-orange" style="border: 1px solid #ED7B1C;">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<input type="hidden" name="category" value="<?php echo $membersapp->category; ?>" />
		<input type="hidden" name="type" value="<?php echo $membersapp->type; ?>" />
		<input type="hidden" name="draft_id" value="<?php echo $membersapp->intID; ?>" />
	</div>
</section>
</div>

</div>
</form>

<script type="text/javascript">
	// sub-category dropdown
	// variable $subcategories
	$('#dd_profession').on('change', function(){
		var v = $(this).val();

		if (v && v=='Small growers')
		{
			$('#divsubparent').fadeIn();
			$('#additional_docs').show();
			$('#additional_docs2').hide();
			// $('#opg_only').hide();
		}
		else if (v && v=='Oil Palm Grower')
		{
			$('#divsubparent').fadeIn();
			$('#additional_docs').show();
			$('#additional_docs2').hide();
			// $('#opg_only').hide();
		}
		else if (v && v=='Smallholder Group Manager')
		{
			$('#divsubparent').fadeOut();
			$('#additional_docs').hide();
			$('#additional_docs2').show();
			// $('#opg_only').hide();
		}
		else
		{
			$('#divsubparent').fadeIn();
			$('#additional_docs').hide();
			$('#additional_docs2').hide();
		}
	});
</script>
<script type="text/javascript">
	/* parent or group member */
	function displaychildfields(v)
	{
		console.log(v);
		if (v=='yes'){
			$('#bullet3').attr('disabled', false);
			$('#container_group_membership').show('fast');
			
			$('.c_next2, .c_prev_3').show('fast');
			$('.c_next3, .c_prev_2').hide('fast');
		}
		else if (v=='sub'){
			$('#bullet3').attr('disabled', true);
			$('#container_group_membership').hide('fast');
			
			$('.c_next3, .c_prev_2').show('fast');
			$('.c_next2, .c_prev_3').hide('fast');
		}
		else {
			$('#bullet3').attr('disabled', true);
			$('#container_group_membership').hide('fast');
			
			$('.c_next3, .c_prev_2').show('fast');
			$('.c_next2, .c_prev_3').hide('fast');
		}
	}
	
	/* enable or disable step3 */
	var cek_parent = $('#parentCompany').val();
		if (cek_parent=='yes'){
			$('#bullet3').attr('disabled', false);
			$('#container_group_membership').show('fast');
			
			$('.c_next2, .c_prev_3').show('fast');
			$('.c_next3, .c_prev_2').hide('fast');
		}
		else if (cek_parent=='sub'){
			$('#bullet3').attr('disabled', true);
			$('#container_group_membership').hide('fast');
			
			$('.c_next3, .c_prev_2').show('fast');
			$('.c_next2, .c_prev_3').hide('fast');  
		}
		else {
			$('#bullet3').attr('disabled', true);
			$('#container_group_membership').hide('fast');
			
			$('.c_next3, .c_prev_2').show('fast');
			$('.c_next2, .c_prev_3').hide('fast');
		}
	
	/* append next step2 */
</script>
<script type="text/javascript">
	var SITE_URL = '<?php echo site_url(); ?>';
	var checkObject = false;
	(function($) {
		$(function(){
            $(document).ready(function(){
             
                var hash = '<?php echo isset($first_step_err) ? $first_step_err : '' ?>';
                //console.log('<?php// echo validation_errors(); ?>');
                if(hash !== '') {
                    switch (hash) {
                        case '#step1' : $('#bullet1').trigger('click'); break;
                        case '#step2' : $('#bullet2').trigger('click'); break;
                        case '#step3' : $('#bullet3').trigger('click'); break;
                        case '#step4' : $('#bullet4').trigger('click'); break;
                        case '#step5' : $('#bullet5').trigger('click'); break;
                    }
                }
            });

			$('.tooltiptrigger').click(function(e){
				e.preventDefault();
				var d = $(this).attr('href');
				$.colorbox({
					width: "50%",
					inline: true,
					href: d,
					fixed: true
				})
			});

			$('a#btnLogout').click(function(e){
				var p = "Are you sure you want to log out? Unsaved changes you have made will be lost.";
				if (confirm(p))
				{
					return true;
				}
				return false;
			});

			$('a#add_more_certs').click(function(e){
				e.preventDefault();
				var h = '<input type="file" name="file_certificates[]" class="required" data-validation-engine="validate[funcCall[checkFile]]"  onchange="copyfname(this.value, $(this), \'all\')">'+
			'<input rel="Copy of the certificate of incorporation of your organisation" data-validation-engine="validate[required]" type="hidden" name="div_files_cert[]" value="" />';
				$('#more_certificates').append(h);
					$('#more_certificates input[type=file]').filestyle({
						iconName : '',
						buttonText : 'Browse',
					});
				var a = '<a href="#" class="btn btn-orange btn-lg remove_file" style="float:left;height:43px;">x</a>';
				$('#more_certificates').find('.bootstrap-filestyle:last').prepend(a);
				$('#more_certificates').fadeIn();
			});

			$('.remove_file').livequery('click', function(e){
				e.preventDefault();
				if (confirm('Are you sure you want to remove this row?'))
				{
					$(this).parent().fadeOut(function(){
						$(this).empty();
					});
				}
				return false;
			});

			$('a#add_file_additionals').click(function(e){
				e.preventDefault();
				//var h = $('#div_file_additionals').html();
				var h = '<input type="file" name="file_additionals[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), "all")"  class="required">'+
					'<input data-validation-engine="validate[required]" type="hidden" name="div_file_additionals[]" value=""/>';

				$('#div_file_additionals').append(h);
				$('#div_file_additionals input[type=file]').filestyle({
					iconName : '',
					buttonText : 'Browse',
				});
				var a = '<a href="#" class="btn btn-orange btn-lg remove_file" style="float:left;height:43px;">x</a>';
				$('#div_file_additionals').find('.bootstrap-filestyle:last').prepend(a);
				$('#div_file_additionals').fadeIn();

			});

			$('a#add_file_sh_group_manager').click(function(e){
				e.preventDefault();
				var h = '<input type="file" name="file_sh_group_manager[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), "all")" class="required">'+
					'<input rel="Copy of the certificate of incorporation of your organisation" data-validation-engine="validate[required]" type="hidden" name="div_file_sh_group_manager[]" value="" />'

				$('#more_file_sh_group_manager').append(h);
				$('#more_file_sh_group_manager input[type=file]').filestyle({
					iconName : '',
					buttonText : 'Browse',
				});
				var a = '<a href="#" class="btn btn-orange btn-lg remove_file" style="float:left;height:43px;">x</a>';
				$('#more_file_sh_group_manager').find('.bootstrap-filestyle:last').prepend(a);
				$('#more_file_sh_group_manager').fadeIn();
			});

			$('a#add_scgm').click(function(e){
				e.preventDefault();
				var h = '							<tr>'+
					'							<td style="width:70%;padding-right:5px;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control required" /></td>'+
					'							<td style="width:30%;padding-bottom:2px;"><input type="text" name="scg_manager_members[]" class="form-control max500 required" style="float:left;width:75%;" /><a href="#" class="btn btn-lg btn-orange remove_scgm" style="width:25%;">x</a></td>'+
					'						</tr>';

				$('#scgm_table > tbody:last').append(h);
			});

			$('.remove_scgm').livequery('click', function(e){
				if (confirm('Are you sure you want to delete this row?'))
				{
					var d = $(this).parent().parent();
					d.fadeOut('fast', function(e){
						d.remove().empty();
					});
					e.preventDefault();
				}
				return false;
			});

			$('.max500').livequery('blur', function(e){
				var v = $(this).val();
				var d = $('#scgm_table');
				if (v)
				{
					var n = $.isNumeric(v);
					if (!n)
					{
						$(this).val('');
						if (d.parent().find('div.alert').html()==undefined)
						{
							d.parent().append('<div class="alert alert-danger">Please enter Palm Oil Consumption in numbers (metric tonnes).</div>');
						}
						else
						{
							d.parent().find('div.alert').fadeTo('fast', 0, function(){
								$(this).html('Please enter Palm Oil Consumption in numbers (metric tonnes).').fadeTo('fast', 1);
							});
						}
					}
					else
					{
						if (v > 500)
						{
							$(this).val('');
							if (d.parent().find('div.alert').html()==undefined)
							{
								d.parent().append('<div class="alert alert-danger">Please enter a number less than 500.</div>');
							}
							else
							{
								d.parent().find('div.alert').fadeTo('fast', 0, function(){
									$(this).html('Please enter a number less than 500.').fadeTo('fast', 1);
								});
							}
						}
						else
						{
							d.parent().find('div.alert').fadeTo('fast', 0);
						}
					}
				}
			});

			var req_input = $('.form-group input, .form-group textarea');
			req_input.each(function(){
				if ($(this).hasClass('required'))
				{
					$(this).on('blur', function(){
						var nd;
						if ($(this).hasClass('required2'))
						{
							if ($(this).val())
							{
								$(this).parent().removeClass('has-error');
								if ($(this).parent().next('.alert').text() != "")
									$(this).parent().next('.alert').fadeTo('slow', 0);
							}
							else
							{
								if ($(this).parent().next('.alert').text() != "")
									$(this).parent().next('.alert').fadeTo('fast', 0.1).fadeTo('fast', 1);
								$(this).parent().addClass('has-error');
							}
						}
						else
						{
							if ($(this).val())
							{
								$(this).parent().removeClass('has-error');
								if ($(this).next('.alert').text() != "")
									$(this).next('.alert').fadeTo('slow', 0);
							}
							else
							{
								if ($(this).next('.alert').text() != "")
									$(this).next('.alert').fadeTo('fast', 0.1).fadeTo('fast', 1);
								$(this).parent().addClass('has-error');
							}
						}
					});
				}
			});

			var req_select = $('.form-group select');
			req_select.each(function(){
				if ($(this).hasClass('required'))
				{
					$(this).on('change blur', function(){
						if ($(this).val())
						{
							$(this).next('.selectpicker').removeClass('has-error');
							if ($(this).next('.alert').text() != "")
								$(this).next('.alert').fadeTo('slow', 0);
						}
						else
						{
							$(this).next('.selectpicker').addClass('has-error');
							if ($(this).next('.alert').text() != "")
								$(this).next('.alert').fadeTo('fast', 0.1).fadeTo('fast', 1);
						}
					});
				}
			});

			var req_select = $('.form-group button.selectpicker');
			req_select.each(function(){
				if ($(this).hasClass('required'))
				{
					$(this).on('change', function(){
						if ($(this).val())
						{
							$(this).next().removeClass('has-error');
							if ($(this).next('.alert').text() != "")
								$(this).next('.alert').fadeTo('slow', 0);
						}
						else
						{
							$(this).next().addClass('has-error');
							if ($(this).next('.alert').text() != "")
								$(this).next('.alert').fadeTo('fast', 0.1).fadeTo('fast', 1);
						}
					});
				}
			});

			$( ".org_children" ).livequery(function(){
				$(this).autocomplete({
					source: SITE_URL + 'members/pick',
					minLength: 2,
					height: "200px",
					select: function( event, ui ) {
						$(this).next('.org_children_id').val(ui.item.id);
					}
				});
			});

			$('.checkuse').on('blur', function(){
				var n = $(this).attr('name');
				var v = $(this).val();
				var c = $(this).attr('rel');
				var $this = $(this);
				var $that = $('input[name='+c+']');

						var v2 = $that.val(); //document.frmApply.name_s.value;
						if (v && v2 && v == v2)
						{
							$(this).parent().addClass('has-error');
							$this.next('.alert').fadeTo('fast', 0).html('Primary and Secondary Representative cannot be the same person.').fadeTo('fast', 1);
							$that.next('.alert').fadeTo('fast', 0).html('Primary and Secondary Representative cannot be the same person.').fadeTo('fast', 1);
						}
						else if (v == "")
						{
							$(this).parent().addClass('has-error');
						}
						else
						{
							$(this).parent().removeClass('has-error');
							$this.next('.alert').fadeTo('slow', 0);
							$that.next('.alert').fadeTo('slow', 0);
						}

				/*
				switch(n)
				{
					case 'name_p':
						var v2 = $that.val(); //document.frmApply.name_s.value;
						if (v2 && v == v2)
						{
							$this.addClass('has-error');
							$this.next('.alert').fadeTo(0, 'fast').html('Primary and Secondary Representative cannot be the same person.').fadeIn(600);
						}
						else
						{
							$this.next('.alert').fadeTo('slow', 0);
						}
						break;
				}
				*/
			});

			<?php
				$tab_number = $this->session->userdata('tab_number');
				 if (!empty($tab_number) && empty($first_step_err)): ?>
				$('#bullet<?php echo $tab_number?>').trigger('click');
			<?php endif; ?>

		});
	})(jQuery);

	$('input[type=file].filestyle').filestyle({
		iconName : '',
		buttonText : 'Browse',
	});
	
	$('.nav-tabs a').click(function() {
		$('.nav-tabs a.active').removeClass('active');
		$(this).addClass('active');
	});
	
	$('#bullet2').click(function(event) {
		$('#bullet1').addClass('active');
        window.location.hash = 'step2';
        checkStep(event);
        $('#garischange_member_application').addClass('member_application_step2');
		$('#garischange_member_application').removeClass('id-organisation');
		$('#garischange_member_application').removeClass('member_application_step3');
		$('#garischange_member_application').removeClass('member_application_step4');
		$('#garischange_member_application').removeClass('member_application_step5');
	});
	
	$('#bullet3').click(function() {
		$('#bullet1').addClass('active');
		$('#bullet2').addClass('active');
        window.location.hash = 'step3';
        checkObject = true;
		$('#garischange_member_application').addClass('member_application_step3');
		$('#garischange_member_application').removeClass('id-organisation');
		$('#garischange_member_application').removeClass('member_application_step2');
		$('#garischange_member_application').removeClass('member_application_step4');
		$('#garischange_member_application').removeClass('member_application_step5');
	});
	
	$('#bullet4').click(function(event) {
		$('#bullet1').addClass('active');
		$('#bullet2').addClass('active');
		$('#bullet3').addClass('active');
        window.location.hash = 'step4';
        checkStep(event);
        $('#garischange_member_application').addClass('member_application_step4');
		$('#garischange_member_application').removeClass('id-organisation');
		$('#garischange_member_application').removeClass('member_application_step2');
		$('#garischange_member_application').removeClass('member_application_step3');
		$('#garischange_member_application').removeClass('member_application_step5');
	});
	
	$('#bullet5').click(function(event) {
		$('#bullet1').addClass('active');
		$('#bullet2').addClass('active');
		$('#bullet3').addClass('active');
		$('#bullet4').addClass('active');
        window.location.hash = 'step5';
        checkStep(event);
        $('#garischange_member_application').addClass('member_application_step5');
		$('#garischange_member_application').removeClass('id-organisation');
		$('#garischange_member_application').removeClass('member_application_step2');
		$('#garischange_member_application').removeClass('member_application_step3');
		$('#garischange_member_application').removeClass('member_application_step4');
	});
	
	$('#bullet1').click(function(event) {
		$('#bullet2').removeClass('active');
		$('#bullet3').removeClass('active');
		$('#bullet4').removeClass('active');
        window.location.hash = 'step1';
        checkStep(event);
		$('#garischange_member_application').addClass('id-organisation');
		$('#garischange_member_application').removeClass('member_application_step2');
		$('#garischange_member_application').removeClass('member_application_step3');
		$('#garischange_member_application').removeClass('member_application_step4');
		$('#garischange_member_application').removeClass('member_application_step5');
	});

    function checkStep(event){
       if(checkObject){
           saveGM(event);
       }
    }

	$( '#myTab a' ).click( function ( e ) {
        e.preventDefault();
        $( this ).tab( 'show' );
	} );

	$( '#moreTabs a' ).click( function ( e ) {
        e.preventDefault();
        $( this ).tab( 'show' );
      } );

	$('#next_1').click(function(e){
		e.preventDefault();
        window.location.hash = 'step2';
		$('#bullet2').trigger('click');
		$('html, body').animate({
			scrollTop: 0
		}, 1000);
	});

	$('#next_2').click(function(e){
		e.preventDefault();
        window.location.hash = 'step3';
        $('#bullet3').trigger('click');
		$('html, body').animate({
			scrollTop: 0
		}, 1000);
	});

	$('#next_3, #next_3_1').click(function(e){
		e.preventDefault();
        window.location.hash = 'step4';
		checkStep(e);
		$('#bullet4').trigger('click');
		$('html, body').animate({
			scrollTop: 0
		}, 1000);
	});

	$('#next_4').click(function(e){
		e.preventDefault();
        window.location.hash = 'step5';
        $('#bullet5').trigger('click');
		$('html, body').animate({
			scrollTop: 0
		}, 1000);
	});

	$('#prev_1').click(function(e){
		e.preventDefault();
        window.location.hash = 'step1';
		$('#bullet1').trigger('click');
		$('html, body').animate({
			scrollTop: 0
		}, 1000);
	});

	$('#prev_2, #prev_2_1').click(function(e){
		e.preventDefault();
        window.location.hash = 'step2';
		$('#bullet2').trigger('click');
		$('html, body').animate({
			scrollTop: 0
		}, 1000);
	});

	$('#prev_3').click(function(e){
		e.preventDefault();
        window.location.hash = 'step3';
        checkStep(e);
		$('#bullet3').trigger('click');
		$('html, body').animate({
			scrollTop: 0
		}, 1000);
	});

	$('#prev_4').click(function(e){
        window.location.hash = 'step4';
		e.preventDefault();
		$('#bullet4').trigger('click');
		$('html, body').animate({
			scrollTop: 0
		}, 1000);
	});

function in_array (needle, haystack, argStrict) {
	var key = '', strict = !!argStrict;

	if (strict) {
		for (key in haystack) {
			if (haystack[key] === needle) {
				return true;
			}
		}
	} else {
		for (key in haystack) {
			if (haystack[key] == needle) {
				return true;
			}
		}
	}

	return false;
}

function copyfname(v,divname,t)
{
	var ftocheck = (t==undefined) ? ftocheck = 'doc' : t;

	var id = divname.attr('id');

	var d = document.getElementById(id);
	var fs = d.files[0].size;

	if (fs > 20000000)
	{
		divname.wrap('<form>').closest('form').get(0).reset();
		divname.unwrap();

		alert('You are trying to upload file over 20MB in size. Please upload a smaller one.\nThank you');

		return false;
	}


	if (ftocheck != "" && ftocheck == 'image')
	{
		var e = ['gif','jpg','jpeg', 'png'];
		var msg = 'GIF, JPG, JPEG, PNG';
	}
	else if (ftocheck != "" && ftocheck == 'all')
	{
		var e = ['pdf','doc','xls','docx','xlsx','gif','jpg','jpeg', 'png','kml','kmz'];
		var msg = 'PDF, DOC, DOCX, XLS, XLSX, GIF, JPG, JPEG, PNG, KML, KMZ';
	}
	else
	{
		var e = ['pdf','doc','xls','docx','xlsx'];
		var msg = 'PDF, DOC, DOCX, XLS, XLSX';
	}

	if (v)
	{
		//console.log('v: '+v);
		// check for extension
		var ext = v.substr((~-v.lastIndexOf(".") >>> 0) + 2);
		//if (ext.toLowerCase() == 'pdf')
		if (in_array(ext.toLowerCase(), e))
		{
			var nextdiv = $(":input:eq(" + ($(":input").index(divname) + 2) + ")");

			//console.log('rel: '+nextdiv.attr('rel'));
			//console.log('next div index: '+$(":input").index(divname));

			if (v)
			{
				//console.log('setting value for nextdiv');
				nextdiv.val(v);
			}
		}
		else
		{

			divname.wrap('<form>').closest('form').get(0).reset();
			divname.unwrap();

			alert('Please upload only '+msg+' format file.\nThank you...');

			return false;
		}
	}
}
</script>