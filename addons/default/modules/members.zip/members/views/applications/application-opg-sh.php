	<!-- required -->
	<ul style="padding-left:15px;">
		<li>
			Please attach proof of business registration (e.g. certificate of incorporation, certificate of good standing, article of incorporation or other similar documents)
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="opg_sm_business_registration" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->opg_sm_business_registration)): ?>
					<?php echo form_hidden('opg_sm_business_registration', $membersapp->opg_sm_business_registration); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sm_business_registration))) ?>" target="_blank"><?php echo $membersapp->opg_sm_business_registration; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('opg_sm_business_registration') ? '<div class="alert alert-danger">'.form_error('opg_sm_business_registration').'</div>' : ''; ?>
			</div>
		</li>
		<li>
			Reporting Template for Disclosure of Areas Cleared without Prior HCV Assessment since November 2005 (Smallholders).- Click <a href="{{url:site}}{{theme:path}}/files/MAP_supporting_details/Independent Smallholders - Disclosure Template.xlsx">here</a> to download.
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="opg_sm_disclosure_cleared_area" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->opg_sm_disclosure_cleared_area)): ?>
					<?php echo form_hidden('opg_sm_disclosure_cleared_area', $membersapp->opg_sm_disclosure_cleared_area); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sm_disclosure_cleared_area))) ?>" target="_blank"><?php echo $membersapp->opg_sm_disclosure_cleared_area; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('opg_sm_disclosure_cleared_area') ? '<div class="alert alert-danger">'.form_error('opg_sm_disclosure_cleared_area').'</div>' : ''; ?>
			</div>
		</li>
		<li>
			Please attach clear evidence that members of the Smallholders Group has agreed to appoint the applicant to act as their Group Manager (e.g Official minutes of meeting)
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="opg_sm_sg_agreed" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->opg_sm_sg_agreed)): ?>
					<?php echo form_hidden('opg_sm_sg_agreed', $membersapp->opg_sm_sg_agreed); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sm_sg_agreed))) ?>" target="_blank"><?php echo $membersapp->opg_sm_sg_agreed; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('opg_sm_sg_agreed') ? '<div class="alert alert-danger">'.form_error('opg_sm_sg_agreed').'</div>' : ''; ?>
			</div>
		</li>
		<li>
			The Group Manager to provide a statement to declare that they will represent the Smallholders Group with integrity and commit to the RSPO standards.
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="opg_sm_gm_statement" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->opg_sm_gm_statement)): ?>
					<?php echo form_hidden('opg_sm_gm_statement', $membersapp->opg_sm_gm_statement); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sm_gm_statement))) ?>" target="_blank"><?php echo $membersapp->opg_sm_gm_statement; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('opg_sm_gm_statement') ? '<div class="alert alert-danger">'.form_error('opg_sm_gm_statement').'</div>' : ''; ?>
			</div>
		</li>
		<li>
			Provide a list of all members in the Smallholders Group with their individual land details (size of land and land registration number). This list must be signed by the appointed Group Manager.
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="opg_sm_sg_list" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->opg_sm_sg_list)): ?>
					<?php echo form_hidden('opg_sm_sg_list', $membersapp->opg_sm_sg_list); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sm_sg_list))) ?>" target="_blank"><?php echo $membersapp->opg_sm_sg_list; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('opg_sm_sg_list') ? '<div class="alert alert-danger">'.form_error('opg_sm_sg_list').'</div>' : ''; ?>
			</div>
		</li>
		<!-- 
		<li>
			For due diligence purposes, please provide 2 names (either company or an individual) as reference. 
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="opg_sm_names_reff" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php //if (!empty($membersapp->opg_sm_names_reff)): ?>
					<?php //echo form_hidden('opg_sm_names_reff', $membersapp->opg_sm_names_reff); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <?php //echo $membersapp->opg_sm_names_reff; ?>
				<?php //endif; ?>
							
				<?php //echo form_error('opg_sm_names_reff') ? '<div class="alert alert-danger">'.form_error('opg_sm_names_reff').'</div>' : ''; ?>
			</div>
		</li>
		-->
	</ul>
	<!-- end required -->
	
	<!-- additional -->
	<ul style="padding-left:15px;">
		<li>For due diligence purposes, please provide 2 names (either company or an individual) as reference.</li>
	</ul>
	<div id="more_file_additionals">
		<input type="file" name="file_additionals[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')"  class="required filestyle">	
		<input data-validation-engine="validate[required]" type="hidden" name="div_opg_sh_additional[]" value=""/>
		<?php echo form_error('div_opg_sh_additional[]') ? '<div class="alert alert-danger">'.form_error('div_opg_sh_additional[]').'</div>' : ''; ?>
	</div>
	<div id="div_opg_sh_additional" class="multiple" style="display:none;"></div>
	<a href="#" id="add_opg_sh_additional">Add more file</a><br />
	<i>Maximum file size is 20MB</i>
	
	<?php if (!empty($membersapp->file_additionals)): ?>
		<?php echo form_hidden('file_additionals', htmlspecialchars_decode($membersapp->file_additionals)); ?>
		<div class="form-group"><br />		
			<label>Current file(s)</label>
			<?php $upfiles_cert = explode(',', $membersapp->file_additionals); ?>
			<div class="table-responsive">
			<table class="table table-striped table-supplychain" style="border:1px solid #ddd;">
				<thead>
					<tr>
						<th style="width:10%;">Delete</th>
						<th>Filename</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach($upfiles_cert as $f): ?>
					<?php if ($f): ?>
					<tr>
						<td style="padding-left:28px; padding-top:0px; padding-bottom:0px;">
							<input type="checkbox" name="remove_uploaded_additionals[]" value="<?php echo $f; ?>" style="margin-top:6px;"/>
						</td>
						<td style="vertical-align:middle; padding-top:0px; padding-bottom:0px;"><a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($f))) ?>" target="_blank"><?php echo $f; ?></a></td>
					</tr>
					<?php endif; ?>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
			<p><i>Check the delete box and click save to delete your uploaded document(s)</i></p>
		</div>
		<div class="clearfix"></div>
	<?php else: ?>
		<div class="clearfix"><br /></div>
	<?php endif; ?>
	<!-- end additional -->
<script type="text/javascript">
$('a#add_opg_sh_additional').click(function(e){
	e.preventDefault();
	//var h = $('#div_opg_sh_additional').html();
	var h = '<input type="file" name="file_additionals[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), "all")"  class="required">'+
		'<input data-validation-engine="validate[required]" type="hidden" name="file_additionals[]" value=""/>';

	$('#div_opg_sh_additional').append(h);
	$('#div_opg_sh_additional input[type=file]').filestyle({
		iconName : '',
		buttonText : 'Browse',
	});
	var a = '<a href="#" class="btn btn-orange btn-lg remove_file" style="float:left;height:43px;">x</a>';
	$('#div_opg_sh_additional').find('.bootstrap-filestyle:last').prepend(a);
	$('#div_opg_sh_additional').fadeIn();
});
</script>