<?php if (!empty($activated)): ?>

<style>
	.btn {
		border-radius: 0px;
		padding: 11.4px 12px;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
</style>
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading">ACCOUNT SUCCESSFULLY ACTIVATED</h3>	
	</div>
	<div class="container">
		<div class="row">
		<?php echo form_open('members/login', 'id="activate-user"') ?>
		<div class="col-md-offset-3 col-md-6 col-sm-12 col-xs-12">
			<div class="box-contact-form organisation">

                            <div class="form-group">
                            	<label>Email</label>
                                <input type="text" class="form-control" name="email" placeholder="Your email" />
                            </div>

                            <div class="form-group">
                            	<label>Password</label>
                                <input type="password" class="form-control" name="password" placeholder="Password" />
                            </div>

				<div class="form-group text-right" style="margin-bottom:0px;">
					<input type="hidden" name="redirect_to" value="/members/apply" />
					<input type="submit" value="LOGIN" class="btn btn-lg btn-orange" style="border-radius:3px;">
				</div>

			</div>
		</div>
		</form>
	</div>
</section>

<?php else: ?>

<style>
	.btn {
		border-radius: 0px;
		padding: 11.4px 12px;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
</style>
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading">ACCOUNT ACTIVATION</h3>	
	</div>
	<div class="container">
		<div class="row">

		<?php echo form_open('members/activate', 'id="activate-user"') ?>
		<div class="col-md-offset-3 col-md-6 col-sm-12 col-xs-12">

<?php if(!empty($error_string)): ?>
<div class="alert alert-danger">
	<?php echo $error_string ?>
</div>
<?php endif;?>

			<div class="box-contact-form organisation">

<p>Please enter your email and the verification code you received in your email.</p>

                            <div class="form-group">
                            	<label>Email</label>
                                <input type="text" class="form-control" name="email" placeholder="Your email" />
                            </div>

                            <div class="form-group">
                            	<label>Verification code</label>
                                <input type="text" class="form-control" name="activation_code" placeholder="Verification code" />
                            </div>

				<div class="form-group text-right" style="margin-bottom:0px;">
					<a href="<?php site_url('members/resend') ?>" class="btn btn-lg btn-orange" style="border-radius:3px;">Resend Code</a>
					<input type="submit" value="ACTIVATE" class="btn btn-lg btn-orange" style="border-radius:3px;">
				</div>

			</div>
		</div>
		</form>
	</div>
</section>


<?php endif; ?>