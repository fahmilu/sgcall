<div id="docs_sector_SCGM" style="display:block;">
	<!-- required -->
	<ul style="padding-left:15px;">
		<li>
			Please attach proof of business registration (e.g. certificate of incorporation, certificate of good standing, article of incorporation or other similar documents).
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="scgm_business_registration" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->scgm_business_registration)): ?>
					<?php echo form_hidden('scgm_business_registration', $membersapp->scgm_business_registration); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->scgm_business_registration))) ?>" target="_blank"><?php echo $membersapp->scgm_business_registration; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('scgm_business_registration') ? '<div class="alert alert-danger">'.form_error('scgm_business_registration').'</div>' : ''; ?>
			</div>
		</li>
		<li>
			Please attach a signed copy of the Supply Chain Group Manager Agreement – Click <a href="{{ url:site }}files/download/fa2c61037fa8130">here</a> to download.
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="scgm_agreement" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->scgm_agreement)): ?>
					<?php echo form_hidden('scgm_agreement', $membersapp->scgm_agreement); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->scgm_agreement))) ?>" target="_blank"><?php echo $membersapp->scgm_agreement; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('scgm_agreement') ? '<div class="alert alert-danger">'.form_error('scgm_agreement').'</div>' : ''; ?>
			</div>
		</li>
	</ul>
	<!-- end required -->
</div>