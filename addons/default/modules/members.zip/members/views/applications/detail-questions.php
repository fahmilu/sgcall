<style>
	.btn {
		border-radius: 0px;
		padding: 11.4px 12px;
		border: 1px solid #D5CEC8;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
</style>
<section class="first-section">
	<div class="container text-center">
		<div class="row">
			<h2 class="section-heading">MEMBERSHIP APPLICATION</h2>
		</div>
		
		<div class="row tml-contact id-organisation">
			<div class="col-md-3 text-left">
				Applying as
				<h5>Affiliate Members</h5>
				<h5>Organisation</h5>
			</div>
			<div class="col-md-6">
				<div class="col-md-3">
					<div class="bullets-orange"></div>
					<label class="orange">1. Organisation Details</label>
				</div>
				<div class="col-md-3">
					<div class="bullets-zero"></div>
					<label>2. Contact Details</label>
				</div>
				<div class="col-md-3">
					<div class="bullets-zero"></div>
					<label>3. Questions</label>
				</div>
				<div class="col-md-3">
					<div class="bullets-zero"></div>
					<label>4. Supporting Details</label>
				</div>
			</div>
		</div>
	</div>
</section>

<section id="contact_detail" class="border-top-gray">

	<div class="container text-center">
		<h3 class="subsection-heading">3. QUESTIONS</h3>	
	</div>

	<div class="container">
		<div class="row">

		<div class="col-md-offset-3 col-md-6 col-sm-12 col-xs-12">
			<div class="box-contact-form organisation">

				<h2 class="titleapp">Questions</h2>
				<p>Please respond to all items marked with an asterisk (<span class="requiredfill">*</span>). You can save the application at any stage by clicking on the SAVE button below, and resume later from <span class="requiredfill">Member application homepage</span></p><br/>				
									
				<div class="form-group">
					<label for="q1"> How will your organisation promote the RSPO internally and to other stakeholders? <span class="requiredfill">*</span></label><br/>
					<textarea class="form-control input-lg required" name="q1" rows="5" id="q1"><?php echo $membersapp->q1; ?></textarea>
					
					<?php echo form_error('q1') ? '<div class="alert alert-danger">'.form_error('q1').'</div>' : ''; ?>
				</div>
				<hr/>
				<div class="form-group">
					<label for="q2"> Where relevant, what processes is the organisation establishing to engage with interested parties, for example to resolve conflict or to use sustainably produced palm oil? <span class="requiredfill">*</span></label><br/>
					<textarea class="form-control input-lg required" name="q2" rows="5" id="q2"><?php echo $membersapp->q2; ?></textarea>
					
					<?php echo form_error('q2') ? '<div class="alert alert-danger">'.form_error('q2').'</div>' : ''; ?>
				</div>
				<hr/>
				<div class="form-group">
					<label for="q3"> Where relevant, how will your organisation work towards implementing the RSPO Principles and Criteria or assessing supplier performance against these criteria? <span class="requiredfill">*</span></label><br/>
					<textarea class="form-control input-lg required" name="q3" rows="5" id="q3"><?php echo $membersapp->q3; ?></textarea>
					
					<?php echo form_error('q3') ? '<div class="alert alert-danger">'.form_error('q3').'</div>' : ''; ?>
				</div>
				<hr/>
				<div class="form-group">
					<label for="q4"> Any other information that would support the application such as what your organisation hopes gain from joining the RSPO. </label><br/>
					<textarea class="form-control input-lg" name="q4" rows="5" id="q4"><?php echo $membersapp->q4; ?></textarea>
				</div>
				<hr/>
				<div class="form-group">
					<label for="q_usage">Please state your annual usage of palm oil and palm derivatives in metric tonnes</label>
					<?php echo form_input('q_usage', $membersapp->q_usage, 'class="form-control  input-lg" placeholder=""'); ?>
				</div>

			</div>
		</div>

		</div>
	</div>

</section>
<!--

<script type="text/javascript">
	$('#logo').filestyle({
		iconName : 'glyphicon-plus',
		buttonText : 'Browse',
	});
</script>
-->