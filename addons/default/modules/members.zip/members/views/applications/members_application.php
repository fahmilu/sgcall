<style>
	.info-tooltips{
		cursor:pointer;
		outline:none;
	}
	.datepicker.dropdown-menu {
		margin-left: 3px;
	}
	.box-contact-form .input-group-addon {
		background: none repeat scroll 0% 0% #FFF;
		border-radius: 0px;
		cursor: pointer;
	}
	.dropdown-menu {
		position: absolute;
		top: 45px;
		left: 0px;
		z-index: 1000;
		display: none;
		float: left;
		min-width: 160px;
		padding: 0px;
		margin: 2px 0px 0px;
		font-size: 14px;
		text-align: left;
		list-style: none outside none;
		background-color: #FFF;
		background-clip: padding-box;
		border: 1px solid rgba(0, 0, 0, 0.15);
		border-radius: 0px;
		box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.176);
	}
	.btn {
		border-radius: 0px;
		line-height:45px;
		padding: 0px 12px;
		border: 1px solid #D5CEC8;
		text-transform: none;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
	.input-group-addon {
		font-size: 14px;
	}
	.input-group-btn > .btn {
		position: relative;
		height: 45px;
	}
	
	.nav-tabs a:hover .bullets-zero, .nav-tabs a:focus .bullets-zero, .nav-tabs a:active .bullets-zero, .nav-tabs a.active .bullets-zero{
		background:#ED7A1D;
		border:3px solid #ED7A1D;
	}
	
	a.active > label, a.active > label:hover, a.active > label:focus {
		color: #000;
		text-decoration:none;
		cursor:default;
	}
	
	a label:hover {
		text-decoration: underline;
	}
	
	a label:hover, .a label:focus {
		text-decoration: underline;
		color:#ED7A1D;
		cursor:pointer;
	}
	.remove_child {
		color: #fff;
		background: red !important;
	}
	.remove_child:hover {
		background: #ED7A1D !important;
	}
</style>
<section class="first-section">
	<div class="container text-center">
		<div class="row">
			<h1 style="font-weight: bold; margin-top:24px; margin-bottom:25px; font-size: 25px; padding-top:3px; text-transform:uppercase;">MEMBERSHIP APPLICATION</h1>
		</div>
		
		<div class="row tml-contact id-organisation">
			<div class="col-md-3 text-left">
				Applying as
				<h5>Affiliate Members</h5>
				<h5>Organisation</h5>
			</div>
			
			<div class="col-md-6 nav-tabs" id="myTab">
				<div class="col-md-3">
				<a href="#1" class="active">
					<div class="bullets-zero"></div>
					<label class="membershipstep">1. Organisation Details</label>
				</a>
				</div>
				<div class="col-md-3">
				<a href="#2">
					<div class="bullets-zero"></div>
					<label class="membershipstep">2. Contact Details</label>
				</a>
				</div>
				<div class="col-md-3">
				<a href="#3">
					<div class="bullets-zero"></div>
					<label class="membershipstep">3. Questions</label>
				</a>
				</div>
				<div class="col-md-3">
				<a href="#4">
					<div class="bullets-zero"></div>
					<label class="membershipstep">4. Supporting Details</label>
				</a>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="tab-content responsive">
<div class="tab-pane active" id="1">
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading">1. ORGANISATION DETAIL</h3>	
	</div>
	<div class="container">
		<div class="row">
		<form action="#" method="post">
		<div class="col-md-offset-3 col-md-6 col-sm-12 col-xs-12">
			<div class="box-contact-form organisation">
				<div class="form-group">
					<label>Organisation's Name</label>
					<?php echo form_input('name', $membersapp->name, 'class="form-control required"'); ?>
					<?php echo form_error('name') ? '<div class="alert alert-danger">'.form_error('name').'</div>' : ''; ?>
				</div>
				
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label>Are you a parent/subsidiary company?</label><br/>
							<select class="selectpicker form-control required" name="parent_company" id="parentCompany" onchange="displaychildfields(this.value);" title="Please select">
								<option value="">I am...</option>
								<option value="yes">I am a parent company</option>
								<option value="sub">I am a subsidiary company</option>
								<option value="">None of the Above</option>
							</select>
							<br />&nbsp;
						</div>
					</div>
				</div>

				<?php $org_children = unserialize($membersapp->sub_company); ?>
			<!-- 	<div class="row" id="parent_company_div" style="display:<?php echo !empty($org_children) ? 'block' : 'none' ?>;"> -->
				<div class="row">

					<div class="col-md-12">
			
						<!-- <div class="input_row" id="org_subsidiaries"> -->
						<div id="parent_company_div" style="display:<?php echo !empty($org_children) ? 'block' : 'none' ?>;">
								Subsidiary company/companies<br />
								<small>Click <b>Add more</b> if you have more than one subsidiary companies</small>
							<div class="input">
								<div id="childfields">
								<?php if (!empty($org_children)): ?>
									<?php foreach($org_children as $org_child): ?>
										<?php if ($org_child['name']): ?>
											<div class="form-group">
												<label class="inline">Subsidiary name</label>
												<div class="input-group no-margin">
													<input class="org_children form-control" type="text" name="sub_company[name][]" value="<?php echo $org_child['name']; ?>" />
													<div class="input-group-addon remove_child"> &nbsp;x&nbsp; </div>
												</div>
												<input class="org_children_id" type="hidden" name="sub_company[id][]" value="<?php echo !empty($org_child['id'])?$org_child['id']:''; ?>" />
											</div>
										<?php endif; ?>
									<?php endforeach; ?>
								<?php else: ?>
									<div class="form-group">
										<label class="inline">Subsidiary name</label>
										<div class="input-group no-margin">
											<input class="org_children form-control" type="text" name="sub_company[name][]" value="" />
											<div href="#" class="input-group-addon remove_child"> &nbsp;x&nbsp; </div>
											<!-- <a href="#" tabindex="-1" class="btn small red remove_child"> &nbsp;x&nbsp; </a> -->
										</div>
										<input class="org_children_id" type="hidden" name="sub_company[id][]" value="" />
									</div>
								<?php endif; ?>
								</div>
								<div><a class="add-more" href="#" onclick="add_more_child(); return false;">Add more</a></div>
								<div id="tocopy-container" style="display:none;">
									<div id="tocopy">
									<div class="form-group">
										<label class="inline">Subsidiary name</label>
										<div class="input-group no-margin">
											<input class="org_children form-control" type="text" name="sub_company[name][]" value="" />
											<div href="#" class="input-group-addon remove_child"> &nbsp;x&nbsp; </div>
											<!-- <a href="#" tabindex="-1" class="btn small red remove_child"> &nbsp;x&nbsp; </a> -->
										</div>
										<input class="org_children_id" type="hidden" name="sub_company[id][]" value="" />
									</div>
									</div>
								</div>
							</div><br />
							<div class="clearboth"></div>
						</div>

						<div class="input_row" id="sub_company_div" style="display:none;">
							<div class="form-group">
								<label>Parent Company</label>
								<input type="text" class="org_children form-control" name="parent_name[name][]" value="">
								<input class="org_children_id" type="hidden" name="parent_name[id][]" value="" />
							</div>
						</div>

						<script>
							function displaychildfields(v)
							{

								if (v=='yes')
								{
									$('#parent_company_div').fadeIn('fast');
									$('#sub_company_div').fadeOut('fast', function(){
										$('input', this).each(function(){
											$(this).val('');
										});
									});
								}
								else if (v=='sub')
								{
									$('#sub_company_div').fadeIn('fast');
									$('#parent_company_div').fadeOut('fast', function(){
										$('input', this).each(function(){
											$(this).val('');
										});
									});
								}
								else
								{
									$('#parent_company_div').fadeOut('fast', function(){
										$('input', this).each(function(){
											$(this).val('');
										});
									});
									$('#sub_company_div').fadeOut('fast', function(){
										$('input', this).each(function(){
											$(this).val('');
										});
									});
								}
							}
							function add_more_child()
							{
								var newfield = $("#tocopy").html();
								$("#childfields").append(newfield);
								var ht2 = $("#tocopy").height();
								var pheight = $("#form-slider").parent().height();
								var pheight2 = $("#step1").height();
								$("#form-slider").parent().height(pheight2+ht2);
								return false;
							}
						</script>

					</div>

				</div>

				<!--
				<div class="row ">
					<div class="col-md-1 col-xs-1" style="padding-right:0px; width:35px;">
						<input type="radio" name="ok" style="margin-top:-12px">
					</div>
					<div class="col-md-5 col-xs-5" style="padding-left:0px;">
						Parent Company
					</div>
					<div class="col-md-1 col-xs-1" style="padding-right:0px; width:35px;">
						<input type="radio" name="ok" style="margin-top:-12px">
					</div>
					<div class="col-md-5 col-xs-5" style="padding-left:0px;">
						Subsidiary Company
					</div>
				</div>
				-->
				
				<div class="form-group">
					<label>Address</label>
					<input type="text" class="form-control" name="name">
				</div>
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>ZIP/Post code</label>
							<input type="text" class="form-control" name="zip">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>City</label>
							<input type="text" class="form-control" name="city">
						</div>
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>State/Province</label>
							<input type="text" class="form-control" name="province">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Countries/Regions</label><br/>
							<select class="selectpicker form-control" style="height:45px;">
								<option>Country/Region</option>
								<option>Indonesia</option>
							</select>
						</div>
					</div>
				</div>
				
				<div class="form-group">
					<label>Telephone</label>
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" name="code-telp">
						</div>
					    <input class="form-control" type="text">
					</div>
				</div>
				
				<div class="form-group">
					<label>Fax (Optional)</label>
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" name="code-telp">
						</div>
					    <input class="form-control" type="text">
					</div>
				</div>
				
				<div class="form-group">
					<label>Email</label>
					<input type="text" class="form-control" name="fullname">
				</div>
				
				<div class="form-group">
					<label>Website</label>
					<input type="text" class="form-control" name="web">
				</div>
				
				<div class="form-group">
					<label>Registration Number</label><i> (please use the full legal entity number)</i>
					<input type="text" class="form-control" name="reg-number">
				</div>
				
				<div class="form-group">
					<label>Organisation's Logo</label>
					<input type="file" id="logo" name="logo" placeholder="PNG, JPG, or GIF and no more than 1.5MB">
				</div>
				
				<div class="form-group">
					<label class="mb-0">Description</label>
					<textarea class="form-control" rows="5" name="reg-number2" placeholder="Please provide some background information on your organisation in less than 250 words" style="height:200px;"></textarea>
				</div>
				<div class="form-group text-right" style="margin-bottom:0px;">
					<input type="submit" value="SAVE" class="btn btn-lg btn-orange btn-save" style="border-radius:3px; border: 1px solid #ED7B1C;">
					<input type="submit" value="NEXT" class="btn btn-lg btn-orange btn-next" style="border-radius:3px; border: 1px solid #ED7B1C;">
				</div>
			</div>
		</div>
	</div>
	</div>
</section>
</div>

<div class="tab-pane" id="2">
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
	
		<div class="form-group">
			<h3 class="subsection-heading">2. CONTACT DETAIL <a href="#" tabindex="0" id ="pop-info" data-html="true" data-toggle="popover" data-trigger="focus" data-content="<p>
			The membership application should be endorsed and signed off
			by a senior member of the organisation who will also be accountable in
			ensuring the organisation conforms to the <a href='#'>RSPO Statuses, by-laws,</a>
			and <a href='#'>Code of Conduct</a>.</p>"><img style="margin-top:-15px;" src="{{ theme:image_path file='oval-information.png' }}"></a></h3>
		</div>
	</div>
	
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6"> 
				<div class="box-contact-form contact" style="margin-top:10px;">
					<h3 class="subsection-heading">PRIMARY NOMINATION</h3>
					<H5>OF REPRESENTATIVE</h5>
					
					<div class="form-group">
						<label>Full Name</label>
						<input type="text" class="form-control" name="fullname">
					</div>
					<div class="form-group">
						<label>Position</label>
						<input type="text" class="form-control" name="position">
					</div>
					<div class="form-group">
						<label>Telephone</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input class="mobile-number tlp-code" type="tel" name="code-telp">
							</div>
						  <input class="form-control" type="text">
						</div>
					</div>
					<div class="form-group">
						<label>Fax</label> (Optional)
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input class="mobile-number tlp-code" type="tel" name="code-telp">
							</div>
						  <input class="form-control" type="text">
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="text" class="form-control" name="fullname">
					</div>
					
					<br/>
					<h3 class="subsection-heading">SECONDARY NOMINATION</h3>
					<H5>OF REPRESENTATIVE</h5>
					
					<div class="form-group">
						<label>Full Name</label>
						<input type="text" class="form-control" name="fullname">
					</div>
					<div class="form-group">
						<label>Position</label>
						<input type="text" class="form-control" name="position">
					</div>
					<div class="form-group">
						<label>Telephone</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input class="mobile-number tlp-code" type="tel" name="code-telp">
							</div>
						  <input class="form-control" type="text">
						</div>
					</div>
					<div class="form-group">
						<label>Fax</label> (Optional)
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input class="mobile-number tlp-code" type="tel" name="code-telp">
							</div>
						  <input class="form-control" type="text">
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="text" class="form-control" name="fullname">
					</div>
			</div>
		</div>
		
		<div class="col-md-6 col-sm-6"> 
			<div class="box-contact-form contact" style="margin-top:10px;">
				<h3 class="subsection-heading">CONTACT PERSON</h3>
				<h5 style="opacity:0" >OF REPRESENTATIVE</h5>
				
				<div class="form-group">
					<label>Full Name</label>
					<input type="text" class="form-control" name="fullname">
				</div>
				<div class="form-group">
					<label>Position</label>
					<input type="text" class="form-control" name="position">
				</div>
				<div class="form-group">
					<label>Telephone</label>
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" name="code-telp">
						</div>
					    <input class="form-control" type="text">
					</div>
				</div>
				<div class="form-group">
					<label>Fax (Optional)</label> 
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" name="code-telp">
						</div>
					    <input class="form-control" type="text">
					</div>
				</div>
				<div class="form-group">
					<label>Email</label>
					<input type="text" class="form-control" name="fullname">
				</div>
				
				<br/>
				<h3 class="subsection-heading">FINANCE CONTACT</h3>
				<H5>FOR MEMBERSHIP FEE</h5>
				
				<div class="form-group">
					<label>Full Name</label>
					<input type="text" class="form-control" name="fullname">
				</div>
				<div class="form-group">
					<label>Position</label>
					<input type="text" class="form-control" name="position">
				</div>
				<div class="form-group">
					<label>Telephone</label>
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" name="code-telp">
						</div>
					    <input class="form-control" type="text">
					</div>
				</div>
				<div class="form-group">
					<label>Fax</label> (Optional)
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" name="code-telp">
						</div>
					    <input class="form-control" type="text">
					</div>
				</div>
				<div class="form-group">
					<label>Email</label>
					<input type="text" class="form-control" name="fullname">
				</div>
				
				<div class="form-group text-right" style="margin-bottom:0px;">
					<input type="submit" value="SAVE" class="btn btn-lg btn-orange btn-save" style="border-radius:3px; border: 1px solid #ED7B1C;">
					<input type="submit" value="NEXT" class="btn btn-lg btn-orange btn-next" style="border-radius:3px; border: 1px solid #ED7B1C;">
				</div>
				
			</div>
			</div>
		</div>
	</div>
	
</section>
</div>

<div class="tab-pane" id="3">
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading">3. QUESTIONS</h3>	
	</div>
	<div class="container">
		<div class="row">
		<div class="col-md-offset-3 col-md-6 col-sm-12 col-xs-12">
			<div class="box-contact-form organisation">
				
				<div class="form-group">
					<p>Please respond to all items marked with an asterisk (*). You can save the application at any stage by clicking on the SAVE button below, and resume later from Member application homepage</p>
				</div>
				
				<div class="form-group">
					<label class="mb-0">How will your organisation promote the RSPO internally and to other stakeholders?</label>
					<textarea class="form-control" rows="5" name="" placeholder="" style="height:200px;"></textarea>
				</div>
				
				<div class="form-group">
					<label class="mb-0">Where relevant, what processes is the organisation establishing to engage with interested parties, for example to resolve conflict or to use sustainably produced palm oil? </label>
					<textarea class="form-control" rows="5" name="" placeholder="" style="height:200px;"></textarea>
				</div>
				
				<div class="form-group">
					<label class="mb-0">Any other information that would support the application such as what your organisation hopes gain from joining the RSPO. </label>
					<textarea class="form-control" rows="5" name="" placeholder="" style="height:200px;"></textarea>
				</div>
				
				<div class="form-group">
					<label>Please state your annual usage of palm oil and palm derivatives in metric tonnes</label>
					<input type="text" class="form-control" name="name">
				</div>
				
				<div class="form-group text-right" style="margin-bottom:0px;">
					<input type="submit" value="SAVE" class="btn btn-lg btn-orange" style="border-radius:3px; border: 1px solid #ED7B1C;">
					<input type="submit" value="NEXT" class="btn btn-lg btn-orange" style="border-radius:3px; border: 1px solid #ED7B1C;">
				</div>
			</div>
		</div>
	</div>
	</div>
</section>
</div>

<div class="tab-pane" id="4">
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading">4. SUPPORTING DETAIL</h3>	
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<div class="box-contact-form supporting">
					<div class="form-group">
					Is there any other information that would support your application, such as what your 
					organisation hopes to gain by joining the RSPO
					<textarea class="form-control" rows="4" style="height:222px;"></textarea>
					</div>
					
					<h3 class="subsection-heading">DOCUMENTS</h3>
					<div class="form-group">
						<p style="font-size:14px;">For all applicants - please attach a copy of the certificate of incorporation of your organisation</p>
						<input type="file" name="documents" id="documents">
					</div>
<!--
					<div class="form-group">
						<div class="row">
							<div class="col-md-1" style="top:0">
								<input type="checkbox" name="ok">
							</div>
							<div class="col-md-11">
								I hereby acknowledge that I have read and understand all of my obligations, duties and responsibilities under each 
								principle and provision of RSPO's <a href="#">Code of Conduct</a> and will accept the future amendments and modifications
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-1" style="top:0">
								<input type="checkbox" name="ok">
							</div>
							<div class="col-md-11">
								I agree with the RSPO's <a href="{{ url:site }}files/download/49e1013ec4b2002">Privacy Policy</a>
							</div>
						</div>
					</div>
-->
				</div>
			</div>
			
			<div class="col-md-6 col-sm-6">
				<div class="box-contact-form supporting">
					<h3 class="subsection-heading">CONTACT PERSON</h3>
					<h5 style="opacity:0" >OF REPRESENTATIVE</h5>
					
					<div class="form-group">
						<label>Full Name</label>
						<input type="text" class="form-control" name="fullname">
					</div>
					<div class="form-group">
						<label>Position</label>
						<input type="text" class="form-control" name="position">
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="email" class="form-control" name="email">
					</div>
					
					<div class="form-group">
						<label>Application Date</label>
						<div class='input-group date datepicker'>
							<input type='text' class="form-control" data-placement="top"/>
							<span class="input-group-addon">
								<span class="glyphicon glyphicon-calendar rz-datepicker" style="font-size:20px;"></span>
							</span>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-1">
							<input type="checkbox" name="ok">
						</div>
						<div class="col-md-11" style="padding-left:0px;">
							Also sign me up to the RSPO email newsletter
							
							<div style="float:right; margin-right:5px;">
								<input type="submit" value="SAVE" class="btn btn-lg btn-orange" style="border-radius:3px; border: 1px solid #ED7B1C;">
								<input type="submit" value="SUBMIT" class="btn btn-lg btn-orange" style="border-radius:3px; border: 1px solid #ED7B1C;">
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</form>	
	</div>
</section>
</div>

<div style="display:none;">
<div id="mapp-announcement">

	<h3>Are you a parent company?</h3>
	<p></p>
	<p>If applicable, please declare your parent company / subsidiaries in the application for our recording purposes. Kindly be informed that RSPO encourages parent companies to apply for RSPO Membership as they will benefit from the following:</p>

	<ol>
		<li>The membership by the parent company will include all the subsidiaries i.e. only one application needs to be submitted and only one membership fee to be paid</li>
		<li>Only one submission of the Annual Communications of Progress (ACOP)</li>
		<li>More convenient and simpler certification application</li>
	</ol>

	<p>&nbsp;</p>
	<div class="none">
		<a href="#" class="btn btn-block btn-primary" onclick="$.colorbox.close();return false;">OK</a>
	</div>

</div>
</div>

<script>
var SITE_URL = '<?php echo site_url(); ?>';
	(function($) {
		$(function(){

			$.colorbox({
				inline: true,
				href: '#mapp-announcement',
				fixed: true,
				width: "500px",
				height: "500px",
				close: false
			})

			var req_input = $('.form-group input, .form-group textarea');
			req_input.each(function(){
				if ($(this).hasClass('required'))
				{
					$(this).blur(function(){
						if ($(this).val())
						{
							$(this).removeClass('alert-danger');
							$(this).next('.alert').fadeTo('slow', 0);
						}
						else
						{
							$(this).next('.alert').fadeTo('fast', 0.1).fadeTo('fast', 1);
							$(this).addClass('alert-danger');
						}
					});
				}
			});

			var req_select = $('.form-group select');
			req_select.each(function(){
				if ($(this).hasClass('required'))
				{
					$(this).on('change', function(){
						if ($(this).val())
						{
							$(this).removeClass('alert-danger');
							$(this).next('.alert').fadeTo('slow', 0);
						}
						else
						{
							$(this).addClass('alert-danger');
							$(this).next('.alert').fadeTo('fast', 0.1).fadeTo('fast', 1);
						}
					});
				}
			});

			$( ".org_children" ).livequery(function(){
				$(this).autocomplete({
					source: SITE_URL + 'members/pick',
					minLength: 2,
					select: function( event, ui ) {
						$(this).next('.org_children_id').val(ui.item.id);
					}
				});
			});

			$(".remove_child").livequery('click', function(e){
				e.preventDefault();
				if (confirm('Are you sure you want to remove this subsidiary?'))
				{
					var $this = $(this).parent().parent();
					$this.fadeOut('slow', function(){
						$this.empty().remove();
					});
				}
				else
				{
					return false;
				}
			});


		});
	})(jQuery);
	
	$('#logo').filestyle({
		iconName : '',
		buttonText : 'Browse',
	});
	
	$('#documents').filestyle({
		iconName : '',
		buttonText : 'Browse'
	});
	
	$('.nav-tabs a').click(function() {
		$('.nav-tabs a.active').removeClass('active');
		$(this).addClass('active');
	});
	
	$( '#myTab a' ).click( function ( e ) {
        e.preventDefault();
        $( this ).tab( 'show' );
	} );

	$( '#moreTabs a' ).click( function ( e ) {
        e.preventDefault();
        $( this ).tab( 'show' );
      } );

	//( function( $ ) {
          // Test for making sure event are maintained
      //    $( '.js-alert-test' ).click( function () {
          //  alert( 'Button Clicked: Event was maintained' );
        //  } );
          //fakewaffle.responsiveTabs( [ 'xs', 'sm' ] );
      //} )( jQuery );
</script>