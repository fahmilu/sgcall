<!-- Full Page Image Background Carousel Header -->
<div class="container">
	<div class="container text-center" id="header-white">
		<h1>MEMBERSHIP APPLICATION</h1>
	</div>
</div>

<!--
<section id="related">
<div class="container">
<div class="row text-center" style="height:300px;">
<p>Sorry, the online membership application is currently being upgraded. <br/><br/>Please <a href="mailto:membership@rspo.org">email us</a> or check back again soon.</p>
</div>
</div>
</section>
-->

<style>
	.requirement-list li a{
		font-size:14px;
	}
	.requirement-list li{
		font-size:14px;
	}
	p{
		padding-bottom:0px;
	}

	form#memRegister div {
		padding-bottom: 0px;
		margin-bottom: 0;
	}
	form#memRegister div input {
		margin-bottom: 13px;
	}
	form#memRegister div .col-sm-12 label {
		padding-top: 0;
		margin-top: 13px;
	}
	label.inline.with-padding {
		width: 100%;
		padding: 0;
		margin: 0;
		display: block;
	}
	label.inline.with-padding span.input-container {
		width: 20px;
		float: left;
		padding: 0;
		margin-right: 0;
	}
	label.inline.with-padding span.input-container input {
		outline: none;
	}

	/* override style.css starts */
	/* .container-step {
	    background-color: #ffffff;
	    border: none;
	    padding: 0 0px 20px 30px;
	    margin: 0;
	    min-height: 550px;
	} */
	.container-step p,
	.container-step div {
	    line-height: 1.85;
	}
	.container-step h2 {
		width: 100%;
		margin: 0 auto;
	    /* border-top: solid 1px #ededed; */
	    margin-left: 0;
	    padding: 30px 0 17px;
	}
	.container-step-mid {
		/* border-left: 1px solid #EDEDED; */
		margin: 0px 20px;
		padding: 0px 30px 30px 30px;
	}
	/* override style.css ends */
</style>
<!-- dual image Section -->
<section id="registration-step">
	<div class="container text-center">
		<div class="row">
			<!-- <h2 class="title-on-top" style="font-size:20px;">To become a RSPO member please follow these steps</h2> -->
			<div class="col-lg-4 area-step text-left" >
				<div class="row">
					<div class="container-step members-apply-out">
						<h2>WHY APPLY</h2>
						<p style="padding-bottom:5px;">As a RSPO member, you can contribute constructively towards promoting the growth and use of sustainable palm oil to protect people, planet and profit. <!-- <a href="#" id="showwhyapply" style="font-size:14px;">Continue reading...</a> --></p>
						<div class="whyapply">
							<ul class="requirement-list">
								<li>First step to show commitment towards embracing sustainable palm oil</li>
								<li>RSPO is recognized globally as a certification standard for sustainable palm oil</li>
								<li>For growers, certification of mills and supply base according to the RSPO Principles & Criteria demonstrates to customers that you are a responsible producer</li>
								<li>Active participation along the palm oil supply chain of RSPO's membership categories</li>
								<li>International market access</li>
								<li>Create and influence RSPO policies and key decisions</li>
								<li>Access to agricultural; environmental and social best practices</li>
								<li>Increased efficiency, productivity and profitability with sustainable palm oil practices</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 area-step text-left">
				<div class="row">
					<div class="container-step container-step-mid members-apply-out">
						<h2>REVIEW THE REQUIREMENTS</h2>
						<strong>Ordinary and Affiliate membership</strong><br/>
						<p style="line-height:1.5; font-size:14px; padding-bottom:5px;">My organisation is directly involved within the palm oil supply chain, or is an associated NGO, or I work with an organisation (or I am an individual) that is not directly involved in the palm oil supply chain.</p>
						<ul class="requirement-list">
							<!--<li><a href="{{ url:site }}publications/download/38f4e442f5bca05">RSPO Statutes</a></li>-->
							<li><a href="{{ url:site }}publications/download/cf2467a9f48dd7b">RSPO Statutes</a></li>
							<li>
								<a href="{{ url:site }}publications/download/ceb801de5c82d24">RSPO Code of Conduct</a>
								<!--<br /><a href="{{ url:site }}publications/download/27ab1cc4d14bef3">English<a/> | 
								<a href="{{ url:site }}publications/download/e04803ea0e25e35">Dutch</a> | 
								<a href="{{ url:site }}publications/download/71d6c0bd0e9caa3">French</a> | 
								<a href="{{ url:site }}publications/download/09d3de0492ada14">Spanish</a>-->
							</li>
							<li><a href="#" id="show_ordinary_affiliate_membership">Membership fees </a></li>
						</ul>
						<div class="ordinary_affiliate_membership" style="display:none; padding-left:15px;">
							<ul class="requirement-list">
								<li>&euro; 2,000 per year</li>
							</ul>
							<strong>Smallholder Group Manager</strong>
							<ul class="requirement-list">
								<li>&euro; 2,000 per year (More than 1,999 ha)</li>
								<li>&euro; 1,000 per year (1,000 to 1,999 ha)</li>
								<li>&euro; 250 per year (Less than 1,000 ha)</li>
							</ul>
							<strong>Outgrower</strong>
							<ul class="requirement-list">
								<li>&euro; 500 per year (500 ha and below)</li>
							</ul>
							<strong>Affiliate member</strong>
							<ul class="requirement-list">
								<li>&euro; 250 per year</li>
							</ul>
						</div>
						<hr style="margin-top:20px;">
						<strong>Supply Chain Associates membership</strong><br/>
						<p style="line-height:1.5; font-size:14px; padding-bottom:5px;">I work with an organisation that has business activities along the palm oil supply chain but limited to purchasing, using, or trading not more than 500 metric tonnes of palm oil and palm oil products annually.</p>
						<ul class="requirement-list">
							<!--<li><a href="{{ url:site }}publications/download/38f4e442f5bca05">RSPO Statutes</a></li>-->
							<li><a href="{{ url:site }}publications/download/cf2467a9f48dd7b">RSPO Statutes</a></li>
							<!--<li><a href="{{ url:site }}publications/download/cbb1628a5688f20">RSPO Code of Conduct</a></li>-->
							<li><a href="{{ url:site }}publications/download/39680063ec0b667">RSPO Code of Conduct</a></li>
							<li><a href="#" id="show_suppy_chain_associate_membership">Membership fees</a></li>
						</ul>
						<div class="suppy_chain_associate_membership" style="display:none; padding-left:15px;">
							<ul class="requirement-list" style="">
								<li>&euro; 100 per year</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4  area-step text-left">
				<div class="row">
					<div class="bg-light-gray container-step-third">
						<div style="display:none;" id="regAlert"></div>
						<div class="row step0 login-area" id="uregister">

							<div class="col-md-12" style="font-size:13px; border-bottom:1px solid #ededed; margin-bottom:10px;padding:0px;">
								Already started your application? <br/><a class="registershow2" style="cursor:pointer;" rel="ulogin">Log in</a> to resume.<br/><br/>
							</div>


							<script>
							var RecaptchaOptions = {
								theme : 'custom',
								custom_theme_widget: 'responsive_recaptcha'
							};
							</script>
							<form method="post" name="memRegister" id="memRegister" action="{{url:site}}members/register" accept-charset="utf-8">
								<div class="col-sm-12" style="padding:0px;">
									<label>Email</label>
									<input autocomplete="off" type="text" name="email" placeholder="email@domain.com" class="form-control input-sm height43" id="reg_email" />
								</div>
								<!-- <br/> -->
								<div class="col-sm-12" style="padding:0px;">
									<label>Name</label>
									<input autocomplete="off" type="text" class="form-control input-sm height43" name="full_name" id="full_name" />
								</div>
								<!-- <br/> -->
								<div class="col-sm-12" style="padding:0px;">
									<label>Password</label>
									<input type="password" class="form-control input-sm height43" name="password" id="password1" />
								</div>
								<!-- <br/> -->
								<div class="col-sm-12" style="padding:0px;">
									<label>Confirm password</label>
									<input type="password" class="form-control input-sm height43" name="password2" id="password2" />
								</div>

								<!-- <br/> -->
								<!-- <div class="form-group"> -->
									<div class="col-sm-12" style="padding:0px;">
										<label>Captcha</label>
										<span id="captcha_container">

											<div id="responsive_recaptcha" style="display:none">
											   <div id="recaptcha_image"></div>
											   <div class="recaptcha_only_if_incorrect_sol" style="color:red">Incorrect please try again</div>

												<div class="text-center">
												   <span>&nbsp;<a href="javascript:Recaptcha.reload()" title="Reload Image"><i class="fa fa-lg fa-refresh"></i></a></span>&nbsp;
												   <span class="recaptcha_only_if_image"><a title="Get an audio CAPTCHA" href="javascript:Recaptcha.switch_type('audio')"><i class="fa fa-lg fa-headphones"></i></a></span>&nbsp;
												   <span class="recaptcha_only_if_audio"><a title="Get an image CAPTCHA" href="javascript:Recaptcha.switch_type('image')"><i class="fa fa-lg fa-image"></i></a></span>
											
												   <span class="recaptcha_only_if_image">Enter the words you see:</span>
												   <span class="recaptcha_only_if_audio">Enter the numbers you hear:</span>
												</div>

											   <input type="text" id="recaptcha_response_field" name="recaptcha_response_field" />
											
											</div>

										<?php echo $recaptcha; ?>
										<?php echo !empty($recaptcha_error) ? $recaptcha_error : ''; ?>
										</span>
									</div>
								<!-- </div> -->

								<br/>
								<div class="col-sm-12" style="padding:0px;">
									<div class="form-group">
										<div class="row">
											<div class="col-md-12" style="padding:0;padding-bottom:10px;">
												<label class="inline with-padding" style="font-size:13px; font-weight:normal; padding-top:0px;">
													<span class="input-container"><input type="checkbox" name="agree_cod" class="shouldcheck" id="agree_cod" value="1"></span>
													<small>I have read and understood my obligations, duties and responsibilities under the RSPO's  <a href="{{url:site}}publications/download/cbb1628a5688f20">Code of Conduct</a> and will accept future modifications.</small>
												</label>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-12" style="padding:0;padding-bottom:10px;">
												<label class="inline with-padding" style="font-size:13px; font-weight:normal;">
												<span class="input-container"><input type="checkbox" name="agree_pp" class="shouldcheck" id="agree_pp" value="2"></span>
												<small>I agree with the RSPO's <a href="{{ url:site }}uploads/default/files/ea2fe53574e48e9f986557b9c749f5bd.pdf">Privacy Policy</a></small></label>
											</div>
										</div>
									</div>
								</div>
								<div class="col-sm-12" style="padding:0px;">
									<?php echo form_input('d0ntf1llth1s1n', ' ', 'class="default-form" style="display:none"') ?>
									<button type="submit" disabled="disabled" class="btn btn-primary" id="btnSubmit" name="btnSubmit">SUBMIT</button>
								</div>
							</form>

<!--
							<div class="col-sm-12" >
								<div style="font-size:13px; border-top:1px solid #ededed; margin-top:15px; padding-top:15px;">
									Already started your application? Log in to resume.<br/><br/>
									<button type="botton" class="btn btn-primary registershow2" rel="ulogin">LOG IN</button>
									<span style="text-align: right;"><a href="#" class="registershow3" rel="uforget">Forgot your password?</a></span>
								</div>
							</div>
-->

						</div>
						<div class="row step0 registerarea" style="display: none;" id="ulogin">
							<div class="col-sm-12" style="padding:0px;">
								<strong>LOGIN HERE TO RESUME</strong>
							</div>
							<div style="display:none;" id="loginAlert" style="margin-top:30px;"></div>
							<br/><br/>
							<form method="post" name="memLogin" id="memLogin" action="{{url:site}}members/login" accept-charset="utf-8">
								<div class="col-sm-12" style="padding:0px;">
									<label>Email</label>
									<input type="text" placeholder="Email address" onclick="return false;" name="email" id="loginEmail" class="form-control input-sm height43"/>
								</div>
								<br/>
								<div class="col-sm-12" style="padding:0px;">
									<label>Password</label>
									<input type="password" placeholder="Password" class="form-control input-sm height43" name="password" id="loginPass" />
								</div>
								<div class="col-sm-12" style="padding:0px;">
									<button type="submit" class="btn btn-primary" id="btnLogin">LOG IN</button>
									<span style="text-align: right;"><a href="#" class="registershow3" rel="uforget">Forgot your password?</a></span>
									<br/>
									<br/>
									<a href="#" class="registershow" style="color:#999999" rel="uregister">&laquo; back</a>
								</div>
							</form>
						</div>
						<div class="row step0 forgetarea" style="display: none;" id="uforget">
							<div class="col-sm-12" style="padding:0px;">
								<p><strong>FORGET YOUR PASSWORD?</strong><br />
								Having issues to access your membership application? No problem -- you'll just have to create a new password. Please enter the email address you used to start your application, and we will send you a verification email</p>
								<div class="clearfix"></div>
							</div>
							<br/><br/>
							<div style="display:none;" id="forgetAlert"></div>
							<form method="post" name="memForget" id="memForget" action="{{url:site}}members/forget" accept-charset="utf-8">
								<div class="col-sm-12" style="padding:0px;">
									<label>Email</label>
									<input type="text" placeholder="Email address" name="email" id="emailForget" class="form-control input-sm height43"/>
								</div>
								<div class="col-sm-12" style="padding:0px;">
									<button type="submit" class="btn btn-primary" id="btnForget">SUBMIT</button>
									<br/>
									<br/>
									<a href="#" class="registershow" style="color:#999999" rel="uregister">&laquo; back</a>
								</div>
							</form>
						</div>
					</div>
				</div>
				</div>
			</div>
		</div>
	</div>

</section>

<section class="section-no-title bg-light-gray">
	<div class="container text-center">
		<div class="contain800">
			<h2 class="section-heading">WHAT HAPPENS AFTER SUBMISSION</h2>
			<p class="whoweareabout" style="line-height:1.75">All membership applications go through a process whereby background research is undertaken. Submitted documents are reviewed; input is received from various stakeholders followed by a final approval from the RSPO Secretary General upon endorsement from the Board of Governors. Any appeals to applications declined will be handed by an Arbitration Board.</p>
			<p>Membership of the RSPO includes a 2-year commitment consecutively with membership fees payable annually. Membership is renewable annually thereafter.</p>
		</div>
	</div>
</section>

<script>

/*
     (function ($) {
         $.support.placeholder = ('placeholder' in document.createElement('input'));
     })(jQuery);


     //fix for IE7 and IE8
     $(function () {
         if (!$.support.placeholder) {
             $("[placeholder]").focus(function () {
                 if ($(this).val() == $(this).attr("placeholder")) $(this).val("");
             }).blur(function () {
                 if ($(this).val() == "") $(this).val($(this).attr("placeholder"));
             }).blur();

             $("[placeholder]").parents("form").submit(function () {
                 $(this).find('[placeholder]').each(function() {
                     if ($(this).val() == $(this).attr("placeholder")) {
                         $(this).val("");
                     }
                 });
             });
         }
     });
*/

</script>

<script>
	$(document).ready(function(){
			  
		$('#showwhyapply').click(function(e){
			e.preventDefault();
			$('.whyapply').slideToggle();
		});
	
		$('#show_what_happen_after_submission').click(function(e){
			e.preventDefault();
			$('.what_happen_after_submission').slideToggle();
		});
	
		$('#show_ordinary_affiliate_membership').click(function(e){
			e.preventDefault();
			$('.ordinary_affiliate_membership').slideToggle();
		});
						
		$('#show_suppy_chain_associate_membership').click(function(e){
			e.preventDefault();
			$('.suppy_chain_associate_membership').slideToggle();
		});
	
		$('.registershow,.registershow3').click(function(e){
			e.preventDefault();
			var d = $(this).attr('rel');
			$('.step0').slideUp(function(){
			});
				$('#'+d).fadeIn();
		});

		$('.registershow2').click(function(e){
			e.preventDefault();
			var d = $(this).attr('rel');
			$('.step0').slideUp(function(){
			});
				$('#'+d).fadeIn('fast', function(){
					$('html, body').animate({
						scrollTop: ($("#uregister").offset().top * 1) - 100
					}, 100);
				});

		});
	
		$('#agree_cod, #agree_pp').on('click', function(){
			if ($('#agree_pp').is(':checked') && $('#agree_cod').is(':checked'))
			{
				$('#btnSubmit').attr('disabled', false);
			}
			else
			{
				$('#btnSubmit').attr('disabled', true);
			}
		});
	
	
		$('form#memRegister').on('submit', function(e){
			e.preventDefault();
	
			if (!$('#reg_email').val())
			{
				alert('Please enter your email address');
				$('#reg_email').focus();
				return false;
			}
	
			if (!$('#full_name').val())
			{
				alert('Please enter your full name');
				$('#full_name').focus();
				return false;
			}
	
			if (!$('#password1').val())
			{
				alert('Please create a new password');
				$('#password1').focus();
				return false;
			}
	
			if (!$('#password2').val())
			{
				alert('Please reconfirm your new password');
				$('#password2').focus();
				return false;
			}
	
			if ($('#password2').val() != $('#password1').val())
			{
				alert('The password you entered do not match');
				$('#password1').focus();
				return false;
			}

			// recaptcha
			if ($('#recaptcha_response_field').val() == '')
			{
				alert('Please enter the text you see in the Captcha image.');
				$('#recaptcha_response_field').focus();
				return false;
			}

			if (!$('#agree_cod').is(':checked'))
			{
				alert("Please check to confirm that you agree to RSPO's Code of Conduct.");
				$('#agree_cod').focus();
				return false;
			}
	
			if (!$('#agree_pp').is(':checked'))
			{
				alert("Please check to confirm that you agree to RSPO's Privacy Policy.");
				$('#agree_pp').focus();
				return false;
			}
	
			var data = $('form#memRegister').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btnSubmit').text('Please wait...');
					$('#btnSubmit').attr('disabled', true);
				},
				url: '/members/register',
				data: data,
				dataType: 'json',
				method: 'post'
	
			}).error(function(){
				$('#btnSubmit').text('Submit');
				$('#btnSubmit').attr('disabled', false);
			}).done(function(html){
	
				$('#btnSubmit').text('Submit...');
				$('#btnSubmit').attr('disabled', false);
	
				if (html.status=='error')
				{
					$('#regAlert').html('<div class="alert alert-danger alert-dimissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#regAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#regAlert').fadeIn();
					});
					Recaptcha.reload();
/*
					if (html.recaptcha != undefined)
					{
						$('#captcha_container').fadeTo('fast', 0, function(){
							$(this).html(html.recaptcha).fadeTo('fast', 1);
						});
					}
*/
				}
				else if (html.status=='ok')
				{
					Recaptcha.reload();
					$('#regAlert').html('<div class="alert alert-success alert-dimissible" role="alert"  style="margin-top:30px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#regAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#regAlert').fadeIn(function(){
							$('form#memRegister')[0].reset();
							$('#btnSubmit').attr('disabled', true);
							gaProcess('members/apply', 'Register', 'User Registrations');
						});
					});
				}
	
			});
	
		});
	
	
		$('form#memForget').on('submit', function(e){
			e.preventDefault();
	
			if (!$('#emailForget').val())
			{
				alert('Please enter your email address');
				$('#emailForget').focus();
				return false;
			}
	
			var data = $('form#memForget').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btnForget').text('Please wait...');
					$('#btnForget').attr('disabled', true);
				},
				url: '/members/forget',
				data: data,
				dataType: 'json',
				method: 'post'
	
			}).error(function(){
				$('#btnForget').text('SUBMIT');
				$('#btnForget').attr('disabled', false);
			}).done(function(html){
	
				$('#btnForget').text('SUBMIT');
				$('#btnForget').attr('disabled', false);
	
				if (html.status)
				{
					$('#forgetAlert').html('<div class="clearfix"></div><div class="alert alert-success alert-dimissible" role="alert" style="margin-top:30px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#forgetAlert').fadeIn(function(){
							$('form#memForget')[0].reset();
							//window.location = '<?php echo site_url('members/application'); ?>';
						});
					});
				}
				else
				{
					$('#forgetAlert').html('<div class="clearfix"></div><div class="alert alert-danger alert-dimissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#forgetAlert').fadeIn();
					});
				}
	
			});
	
		});

		$('form#memLogin').on('submit', function(e){
			e.preventDefault();
	
			/* if (!$('#loginEmail').val())
			{
				alert('Please enter your email address');
				$('#reg_email').focus();
				return false;
			}
	
			if (!$('#loginPass').val())
			{
				alert('Please create a new password');
				$('#password1').focus();
				return false;
			} */
	
			var data = $('form#memLogin').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btnLogin').text('Please wait...');
					$('#btnLogin').attr('disabled', true);
				},
				url: '/members/login',
				data: data,
				dataType: 'json',
				method: 'post'
	
			}).error(function(){
				$('#btnLogin').text('LOGIN');
				$('#btnLogin').attr('disabled', false);
			}).done(function(html){
	
				$('#btnLogin').text('LOGIN');
				$('#btnLogin').attr('disabled', false);
				//return false;
				if (html.status)
				{
					$('#loginAlert').html('<div class="alert alert-success alert-dimissible" role="alert"  style="margin-top:30px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#loginAlert').fadeIn(function(){
							$('form#memLogin')[0].reset();
							if (html.redirect_to)
							{
								window.location = html.redirect_to;
							}
							else
							{
								gaProcess('members/apply', 'Login', 'Already started your application? Log in to resume.');
								window.location = '<?php echo site_url('members/selecttype'); ?>';
							}
						});
					});
				}
				else
				{
					$('#loginAlert').html('<div class="alert alert-danger alert-dimissible" role="alert" style="margin-top:30px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#loginAlert').fadeIn();
					});
				}
	
			});
	
		});

	});
</script>
