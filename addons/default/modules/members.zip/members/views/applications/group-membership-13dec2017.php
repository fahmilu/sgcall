					<section id="container_group_membership" class="border-top-gray">
						<h3 class="subsection-heading title_forms text-center">3. GROUP MEMBERSHIP</h3>

						<div class="container-820 s_group_membership" style="display:table; overflow:auto;">
							
							<!-- left menu -->
							<div id="list_gm_left">
								<div id="nav" class="nav left_m_group_memberships mCustomScrollbar affix-top" data-spy="affix">
									<ul class="GM_right">
										<?php
                                            if (!empty($subsidiaries)) {
                                                $i = 0;
                                                foreach ($subsidiaries as $subsidiary) { ?>
													<li id="cAsyncGMlist<?php echo $i; ?>">
														<a id="Agm_name<?php echo $i; ?>" href="#gm<?php echo $i; ?>"><?php echo $subsidiary->name?$subsidiary->name:'New Group Membership'; ?></a>
													</li>
												<?php
												$i++;
                                                }
                                            } else { ?>
												<li id="cAsyncGMlist0">
													<a id="Agm_name0" href="#gm0">New Group Membership</a>
												</li>
										<?php }?>
									</ul>
								</div>
							</div>

							<!-- SKENARIO 1 -->
							<div class="skenario_1_g_membership">
                                <input type="hidden" value="<?php echo $total_subs + 1; ?>" name="total" id="total" />
								<div class="c_form list_of_gm">
                                    <?php
                                    if (!empty($subsidiaries)) {
                                        $i = 0;
                                        foreach ($subsidiaries as $subsidiary) { ?>
                                            <?php // @todo c_form_list untuk counting GM pas delete ?>
                                            <div id="gm<?php echo $i; ?>" class="bg-f5f5f5 c_form_list">
                                                <a class="g_m_add" onClick="g_m_add(this); AnimateAddTarget(this);"><i class="fa fa-plus"></i> Add new group member</a>
                                                <a class="g_m_del delete" onclick="delGM('<?php echo $i; ?>', event)"><i class="fa fa-times"></i> Delete this group member</a>
                                                <div class="c_form_in">
                                                    <label>Group member name*</label>
                                                    <div class="input-group">
                                                        <input id="gm_name<?php echo $i; ?>"
                                                               autocomplete="off" type="text" class="form-control"
                                                               value="<?php echo $subsidiary->name; ?>" name="gm_name<?php echo $i; ?>"
                                                               placeholder="" onblur="syncGMlist(this);" onchange="syncGMlist(this);">
                                                        <input type="hidden" value="<?php echo $subsidiary->id; ?>"
                                                               name="gm_id<?php echo $i; ?>"
                                                               id="gm_id<?php echo $i; ?>">
                                                    </div>
                                                    <?php echo form_error('gm_name'.$i) ? '<div class="alert alert-danger">'.form_error('gm_name'.$i).'</div>' : ''; ?>
<!--													<div id="err_gm_name--><?php //echo $i; ?><!--" class="alert alert-danger" style="display:none"></div>-->

                                                    <label class="t_radio l_group_membership type_membership">
														Type* <i></i>
														<div class="tooltip_am">
															<div class="content_more">
																<p><span>Subsidiary</span> - An Entity where the Parent:</p>
																<ul>
																	<li>holds (whether as a legal owner or as a beneficiary) more than half of the issued share capital of that Entity (excluding any part thereof which consists of preference shares); or</li>
																	<li>controls more than half of the voting power of that Entity; or</li>
																	<li>controls the composition of the board of directors of that Entity.</li>
																</ul>
															</div>
														</div>
                                                    </label>
                                                    <div class="radio_custom_by_am t_group_membership">
														<div class="yn_left">
															<input id="gm_type<?php echo $i; ?>-r"
																name="gm_type<?php echo $i; ?>"
																value="subsidiary" type="radio" <?php echo ($subsidiary->type == 'management_unit' || $subsidiary->type == 'supply_chain_group_manager' || $subsidiary->type == 'subsidiary') ? 'checked="checked"' : ''; ?>
																class="type_sector_s3">
															<label for="gm_type<?php echo $i; ?>-r"><span><span></span></span>Subsidiary</label>
														</div>
														<div class="yn_right">
															<input id="gm_type<?php echo $i; ?>-o"
																name="gm_type<?php echo $i; ?>"
																value="other" type="radio" <?php echo ($subsidiary->type == 'other') ? 'checked="checked"' : ''; ?>
																class="type_sector_s3">
															<label for="gm_type<?php echo $i; ?>-o"><span><span></span></span>Other...</label>
														</div>
                                                    </div>

                                                    <div class="free_text_other_type" id="free_text_other_type<?php echo $i; ?>" >
                                                        <div class="input-group pad-top-17 pad-bottom-10">
                                                            <input autocomplete="off" type="text" class="form-control"
                                                                   value="<?php echo $subsidiary->other_type; ?>"
                                                                   name="gm_other_type<?php echo $i; ?>"
                                                                   id="gm_other_type<?php echo $i; ?>"
                                                                   placeholder="Enter custom group membership type">
                                                        </div>
                                                    </div>
                                                    <?php echo form_error('gm_other_type'.$i) ? '<div class="alert alert-danger" style="margin-top:-10px;">'.form_error('gm_other_type'.$i).'</div>' : ''; ?>
													<div id="err_gm_other_type<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>

													<label class="margin-top-12" style="width:100%;">Nature of business*</label>
                                                    <div class="input-group">
                                                        <select class="selectpicker show-tick form-control" title="Select nature of business"
                                                                name="gm_nature_of_business<?php echo $i; ?>"
                                                                id="gm_nature_of_business<?php echo $i; ?>">
                                                            <option value="Growers" <?php echo ($subsidiary->nature_of_business == 'Growers') ? 'selected="selected"' : ''; ?>>Growers</option>
                                                            <option value="Processors and Traders" <?php echo ($subsidiary->nature_of_business == 'Processors and Traders') ? 'selected="selected"' : ''; ?>>Processors and Traders</option>
                                                            <option value="Retailers" <?php echo ($subsidiary->nature_of_business == 'Retailers') ? 'selected="selected"' : ''; ?>>Retailers</option>
                                                            <option value="Consumer Goods Manufacturers" <?php echo ($subsidiary->nature_of_business == 'Consumer Goods Manufacturers') ? 'selected="selected"' : ''; ?>>Consumer Goods Manufacturers</option>
                                                        </select>
                                                    </div>
                                                    <?php echo form_error('gm_nature_of_business'.$i) ? '<div class="alert alert-danger">'.form_error('gm_nature_of_business'.$i).'</div>' : ''; ?>
													<div id="err_gm_nature_of_business<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>

                                                    <div class="c2_left">
                                                        <label>Country*</label>
                                                        <div class="country_region input-group">
                                                            <select class="selectpicker show-tick form-control" title="Select country"
                                                                    onchange="getRegion(<?php echo $i; ?>)"
                                                                    name="gm_country<?php echo $i; ?>"
                                                                    id="gm_country<?php echo $i; ?>">
                                                                <?php foreach ($new_country_arrays as $country => $region) { ?>
                                                                    <option value="<?php echo $country; ?>" <?php echo ($country == $subsidiary->country) ? 'selected' : ''; ?>><?php echo $country; ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                        <i style="position:absolute; margin-top:2px;">(The list of countries and regions are in accordance with the <a href="https://unstats.un.org/unsd/methodology/m49/" target="_blank">UN M49</a> standard)</i>
														<div style="display:none; margin-bottom:5px; margin-left:-1px; margin-top:18px;" id="err_gm_country<?php echo $i; ?>" class="alert alert-danger"></div>
                                                    </div>
                                                    <div class="c2_right">
                                                        <label>Region*</label>
                                                        <div class="input-group">
                                                            <input autocomplete="off" type="text" class="form-control"
                                                                   value="<?php echo $subsidiary->region; ?>"
                                                                   name="gm_region<?php echo $i; ?>"
                                                                   id="gm_region<?php echo $i; ?>"
                                                                   placeholder="" readonly="readonly"
                                                                   style="border-left:1px solid transparent!important;">
                                                        </div>
                                                    </div>

													<div style="display:inline-block; margin-top:18px;">
														<label class="t_radio l_group_membership">Is this group member an RSPO member?*</label>
														<div class="radio_custom_by_am t_group_membership_y_n">
															<div class="yn_left">
																<input id="gm_is_rspo_num<?php echo $i; ?>-y" name="gm_is_rspo_num<?php echo $i; ?>" value="yes" <?php echo (!empty($subsidiary->is_rspo_num) && $subsidiary->is_rspo_num == 'yes') ? 'checked="checked"' : ''; ?>
																	   type="radio" class="this_group_membership"><label
																		for="gm_is_rspo_num<?php echo $i; ?>-y"><span><span></span></span>Yes</label>
															</div>
															<div class="yn_right">
																<input id="gm_is_rspo_num<?php echo $i; ?>-n" name="gm_is_rspo_num<?php echo $i; ?>" value="no" <?php echo (empty($subsidiary->is_rspo_num) || $subsidiary->is_rspo_num == 'no') ? 'checked="checked"' : ''; ?>
																	   type="radio" class="this_group_membership"><label
																		for="gm_is_rspo_num<?php echo $i; ?>-n"><span><span></span></span>No</label>
															</div>
														</div>
                                                    </div>

                                                    <div class="show_rspo_membership_number" id="show_rspo_membership_number<?php echo $i; ?>" style="width:100%;">
                                                        <label class="margin-top-12">Please enter its RSPO membership number</label>
                                                        <?php
                                                        $num = ['0','0000','00','000','00'];
                                                        if (!empty($subsidiary->rspo_membership_num)) {
                                                            $str = explode('-',$subsidiary->rspo_membership_num);
                                                            for ($j = 0; $j < 5; $j++) {
                                                                if (isset($str[$j])) {
                                                                    $num[$j] = $str[$j];
                                                                }
                                                            }

                                                         } ?>
                                                        <div class="input-group membership_number">
                                                            <input autocomplete="off" class="form-control membership_number1" value="<?php echo $num[0]; ?>"
                                                                   id="num1<?php echo $i; ?>"
                                                                   onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                   name="num1<?php echo $i; ?>"
                                                                   placeholder="" maxlength="1" type="text">
                                                            <span>−</span>
                                                            <input autocomplete="off" class="form-control membership_number2" value="<?php echo $num[1]; ?>"
                                                                   id="num2<?php echo $i; ?>"
                                                                   onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                   name="num2<?php echo $i; ?>"
                                                                   placeholder="" maxlength="4" type="text">
                                                            <span>−</span>
                                                            <input autocomplete="off" class="form-control membership_number3" value="<?php echo $num[2]; ?>"
                                                                   id="num3<?php echo $i; ?>"
                                                                   onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                   name="num3<?php echo $i; ?>"
                                                                   placeholder="" maxlength="2" type="text">
                                                            <span>−</span>
                                                            <input autocomplete="off" class="form-control membership_number4" value="<?php echo $num[3]; ?>"
                                                                   id="num4<?php echo $i; ?>"
                                                                   onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                   name="num4<?php echo $i; ?>"
                                                                   placeholder="" maxlength="3" type="text">
                                                            <span>−</span>
                                                            <input autocomplete="off" class="form-control membership_number5" value="<?php echo $num[4]; ?>"
                                                                   id="num5<?php echo $i; ?>"
                                                                   onkeyup="implodeNumber(<?php echo $i; ?>);"
                                                                   name="num5<?php echo $i; ?>"
                                                                   placeholder="" maxlength="2" type="text">

                                                            <input name="gm_rspo_membership_num<?php echo $i; ?>"
                                                                   id="gm_rspo_membership_num<?php echo $i; ?>"
                                                                   value="<?php echo $subsidiary->rspo_membership_num; ?>" type="hidden">
                                                        </div>
                                                        <?php echo form_error('gm_rspo_membership_num'.$i) ? '<div class="alert alert-danger">'.form_error('gm_rspo_membership_num'.$i).'</div>' : ''; ?>
														<div id="err_gm_rspo_membership_num<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
                                                    </div>

                                                    <h2>Group member contact information</h2>
													<div id="gm_AUF_<?php echo $i; ?>" class="input-group">
														<div class="fl_name">
															<label for="" class="block">First name</label>
															<div class="input-group no-margin">
																<input autocomplete="off" type="text" class="form-control gm_firstname_add"
																	   value="<?php echo $subsidiary->firstname; ?>"
																	   name="gm_firstname<?php echo $i; ?>"
																	   id="gm_firstname<?php echo $i; ?>"
																	   placeholder="" style="border-right:none;">
															</div>
															<div id="err_gm_firstname<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
														</div>
														<div class="fl_name">
															<label for="" class="block">Last name</label>
															<div class="input-group no-margin">
																<input autocomplete="off" type="text" class="form-control gm_lastname_add"
																	   value="<?php echo $subsidiary->lastname; ?>"
																	   name="gm_lastname<?php echo $i; ?>"
																	   id="gm_lastname<?php echo $i; ?>"
																	   placeholder="">
															</div>
															<div id="err_gm_lastname<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
														</div>

														<div class="c2_left c2_e_p">
															<label for="" class="block">Email address</label>
															<div class="input-group no-margin">
																<input autocomplete="off" type="text" class="form-control gm_email_add"
																	   value="<?php echo $subsidiary->email; ?>"
																	   name="gm_email<?php echo $i; ?>"
																	   id="gm_email<?php echo $i; ?>"
																	   placeholder="">
															</div>
															<div id="err_gm_email<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
														</div>
														<div class="c2_right">
															<label class="add-pad-am">Phone number</label>
															<div class="input-group no-margin">
																<div class="input-group-addon no-padding">
																	<input class="mobile-number tlp-code form-control gm_phone_add"
																		   type="tel" value="<?php echo $subsidiary->phone; ?>"
																		   name="gm_phone<?php echo $i; ?>"
																		   id="gm_phone<?php echo $i; ?>">
																</div>
															</div>
															<div id="err_gm_phone<?php echo $i; ?>" class="alert alert-danger" style="display:none"></div>
														</div>
													</div>

                                                    <div class="align-right margin-top-20 g_membership_button">
                                                        <button onclick="silentDelGM('<?php echo $i; ?>')" id="silentDelGM<?php echo $i; ?>" class='btn btn-lg btn-gray margin-right-8'>Cancel</button>
                                                        <button onclick="saveGM(event)" id="saveGM<?php echo $i; ?>" class='btn btn-lg btn-black'>Save</button>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php $i++; }
                                    } else { ?>
										
												<div id="gm0" class="bg-f5f5f5 c_form_list">
													<a class="g_m_add" onClick="g_m_add(this); AnimateAddTarget(this);"><i class="fa fa-plus"></i> New group member name</a>
													<a class="g_m_del delete" onclick="delGM('0', event)"><i class="fa fa-times"></i> Delete this group member</a>
													<div class="c_form_in">
														<label>Group member name*</label>
														<div class="input-group">
															<input id="gm_name0"
																   autocomplete="off" type="text" class="form-control"
																   value="" name="gm_name0"
																   placeholder="" onkeyup="syncGMlist(this)">
															<input type="hidden" value="new"
																   name="gm_id0"
																   id="gm_id0">
														</div>
														<div id="err_gm_name0" class="alert alert-danger" style="display:none"></div>
														
														<label class="t_radio l_group_membership type_membership">
															Type* <i></i>
															<div class="tooltip_am">
																<div class="content_more">
																	<p><span>Subsidiary</span> - An Entity where the Parent:</p>
																	<ul>
																		<li>holds (whether as a legal owner or as a beneficiary) more than half of the issued share capital of that Entity (excluding any part thereof which consists of preference shares); or</li>
																		<li>controls more than half of the voting power of that Entity; or</li>
																		<li>controls the composition of the board of directors of that Entity.</li>
																	</ul>
																</div>
															</div>
														</label>
														<div class="radio_custom_by_am t_group_membership">
															<div class="yn_left">
																<input id="gm_type0-r"
																	name="gm_type0"
																	value="subsidiary" type="radio"
																	checked="checked"
																	class="type_sector_s3">
																<label for="gm_type0-r"><span><span></span></span>Subsidiary</label>
															</div>
															<div class="yn_right">
																<input id="gm_type0-o"
																	name="gm_type0"
																	value="other" type="radio" 
																	class="type_sector_s3">
																<label for="gm_type0-o"><span><span></span></span>Other...</label>
															</div>
														</div>

														<div class="free_text_other_type" id="free_text_other_type0" style="display: none;">
															<div class="input-group pad-top-17 pad-bottom-10">
																<input autocomplete="off" type="text" class="form-control"
																	   value=""
																	   name="gm_other_type0"
																	   id="gm_other_type0"
																	   placeholder="Enter custom group membership type">
															</div>
														</div>
														<div id="err_gm_other_type0" class="alert alert-danger" style="display:none"></div>

														<label class="margin-top-12" style="width:100%;">Nature of business*</label>
														<div class="input-group">
															<select class="selectpicker show-tick form-control" title="Select nature of business"
																	name="gm_nature_of_business0"
																	id="gm_nature_of_business0">
																<option value="Growers">Growers</option>
																<option value="Processors and Traders">Processors and Traders</option>
																<option value="Retailers">Retailers</option>
																<option value="Consumer Goods Manufacturers">Consumer Goods Manufacturers</option>
															</select>
														</div>
														<div id="err_gm_nature_of_business0" class="alert alert-danger" style="display:none"></div>

														<div class="c2_left">
															<label>Country*</label>
															<div class="country_region input-group">
																<select class="selectpicker show-tick form-control" title="Select country"
																		onchange="getRegion(0)"
																		name="gm_country0"
																		id="gm_country0">
																	<?php foreach ($new_country_arrays as $country => $region) { ?>
																		<option value="<?php echo $country; ?>"><?php echo $country; ?></option>
																	<?php } ?>
																</select>
															</div>
															<i style="position:absolute; margin-top:2px;">(The list of countries and regions are in accordance with the <a href="https://unstats.un.org/unsd/methodology/m49/" target="_blank">UN M49</a> standard)</i>
															<div style="display:none; margin-bottom:5px; margin-left:-1px; margin-top:18px;" id="err_gm_country0" class="alert alert-danger"></div>
														</div>
														<div class="c2_right">
															<label>Region*</label>
															<div class="input-group">
																<input autocomplete="off" type="text" class="form-control"
																	   value=""
																	   name="gm_region0"
																	   id="gm_region0"
																	   placeholder="" readonly="readonly"
																	   style="border-left:1px solid transparent!important;">
															</div>
														</div>

														<div style="display:inline-block; margin-top:18px;">
															<label class="t_radio l_group_membership">Is this group member an RSPO member?*</label>
															<div class="radio_custom_by_am t_group_membership_y_n">
																<div class="yn_left">
																	<input id="gm_is_rspo_num0-y" name="gm_is_rspo_num0" value="yes"
																		   type="radio" class="this_group_membership"><label
																			for="gm_is_rspo_num0-y"><span><span></span></span>Yes</label>
																</div>
																<div class="yn_right">
																	<input id="gm_is_rspo_num0-n" name="gm_is_rspo_num0" value="no" checked="checked"
																		   type="radio" class="this_group_membership"><label
																			for="gm_is_rspo_num0-n"><span><span></span></span>No</label>
																</div>
															</div>
														</div>

														<div class="show_rspo_membership_number" id="show_rspo_membership_number0" style="width:100%;">
															<label class="margin-top-12">Please enter its RSPO membership
																number</label>
															<div class="input-group membership_number">
																<input autocomplete="off" class="form-control membership_number1" value="0"
																	   id="num10"
																	   onkeyup="implodeNumber(0);"
																	   name="num10"
																	   placeholder="" maxlength="1" type="text">
																<span>−</span>
																<input autocomplete="off" class="form-control membership_number2" value="0000"
																	   id="num20"
																	   onkeyup="implodeNumber(0);"
																	   name="num20"
																	   placeholder="" maxlength="4" type="text">
																<span>−</span>
																<input autocomplete="off" class="form-control membership_number3" value="00"
																	   id="num30"
																	   onkeyup="implodeNumber(0);"
																	   name="num30"
																	   placeholder="" maxlength="2" type="text">
																<span>−</span>
																<input autocomplete="off" class="form-control membership_number4" value="000"
																	   id="num40"
																	   onkeyup="implodeNumber(0);"
																	   name="num40"
																	   placeholder="" maxlength="3" type="text">
																<span>−</span>
																<input autocomplete="off" class="form-control membership_number5" value="00"
																	   id="num50"
																	   onkeyup="implodeNumber(0);"
																	   name="num50"
																	   placeholder="" maxlength="2" type="text">

																<input name="gm_rspo_membership_num0"
																	   id="gm_rspo_membership_num0"
																	   value="" type="hidden">
															</div>
															<div id="err_gm_rspo_membership_num0" class="alert alert-danger" style="display:none"></div>
														</div>

														<h2>Group member contact information</h2>
														<div id="gm_AUF_0" class="input-group">
															<div class="fl_name">
																<label for="" class="block">First name*</label>
																<div class="input-group no-margin">
																	<input autocomplete="off" type="text" class="form-control gm_firstname_add"
																		   value=""
																		   name="gm_firstname0"
																		   id="gm_firstname0"
																		   placeholder="" style="border-right:none;">
																</div>
																<div id="err_gm_firstname0" class="alert alert-danger" style="display:none"></div>
															</div>
															<div class="fl_name">
																<label for="" class="block">Last name*</label>
																<div class="input-group no-margin">
																	<input autocomplete="off" type="text" class="form-control gm_lastname_add"
																		   value=""
																		   name="gm_lastname0"
																		   id="gm_lastname0"
																		   placeholder="">
																</div>
																<div id="err_gm_lastname0" class="alert alert-danger" style="display:none"></div>
															</div>

															<div class="c2_left c2_e_p">
																<label for="" class="block">Email address*</label>
																<div class="input-group no-margin">
																	<input autocomplete="off" type="text" class="form-control gm_email_add"
																		   value=""
																		   name="gm_email0"
																		   id="gm_email0"
																		   placeholder="">
																</div>
																<div id="err_gm_email0" class="alert alert-danger" style="display:none"></div>
															</div>
															<div class="c2_right">
																<label class="add-pad-am">Phone number*</label>
																<div class="input-group no-margin">
																	<div class="input-group-addon no-padding">
																		<input class="mobile-number tlp-code form-control gm_phone_add"
																			   type="tel" value=""
																			   name="gm_phone0"
																			   id="gm_phone0">
																	</div>
																</div>
																<div id="err_gm_phone0" class="alert alert-danger" style="display:none"></div>
															</div>
														</div>

														<div class="align-right margin-top-20 g_membership_button">
															<button onclick="silentDelGM('0')" id="silentDelGM0" class='btn btn-lg btn-gray margin-right-8'>Cancel</button>
															<button onclick="saveGM(event)" id="saveGM0" class='btn btn-lg btn-black'>Save</button>
														</div>
													</div>
												</div>
									<?php } ?>
								</div>
								
								<div class="form-group text-right" style="margin-bottom:0px; float:right; width:100%;">
									<input value="PREV" id="prev_2" class="btn btn-lg btn-orange btn-prev" style="border: 1px solid #ED7B1C;" type="submit">
									<button onclick="saveGM(event)" name="btnSave" type="submit" class="btn btn-lg btn-orange btn-save" value="3">SAVE</button>
									<input value="NEXT" id="next_3" class="btn btn-lg btn-orange" style="border: 1px solid #ED7B1C;" type="submit">
								</div>
								
								<div class="backtoTop" style="display:none;">
									<a class="btn btn-lg btn-gray">Back to top <i class="fa fa-arrow-up" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
					</section>

<!-- success message -->
<div style='display:none'>
	<div id='success_messages' class="popup_custom_by_am">
		<div class="t_popup">
			<h2>Thank you for updating your membership data. You can now proceed to ACOP 2016 and have full access to your MyRSPO profile.</h2>
		</div>
		<div class="c_popup">
			
			<p>Your membership data has been saved</p>
			
			<a class="btn btn-lg btn-black margin-right-8" href="http://acop-rspo.org/">Go to ACOP 2016</a>
			<a class="btn btn-lg btn-black" href="<?php echo base_url('members/profile') ?>">MyRSPO profile</a>
		</div>
	</div>
</div>
<div style='display:none'>
	<div id='success_messages_save' class="popup_custom_by_am">
		<div class="c_popup">
			<p class="no-margin">Your form has been successfully saved</p>
			<i class="fa fa-check" aria-hidden="true"></i>
		</div>
	</div>
</div>

<!-- delete confirm -->
<div style='display:none'>
	<div id='delete_confirm' class="popup_custom_by_am p_delete">
		<div class="c_popup">
			<p>Are you sure you want to delete this group member permanently?</p>
			
			<a class="btn btn-lg btn-gray margin-right-8 cancel_delete">Cancel</a>
			<a class="btn btn-lg btn-black process_delete">Yes, save all progress and delete</a>
		</div>
	</div>
</div>

<!-- append new form gm -->
<div style="display:none">
    <div id="componentGM1">
				<label>Group member name*</label>
				<div class="input-group">
					<input id="new_name"
						   autocomplete="off" type="text" class="form-control"
						   value="" name="new_name"
						   placeholder="" onblur="syncGMlist(this);" onchange="syncGMlist(this);">
					<input type="hidden" value="new"
						   name="new_id"
						   id="new_id">
				</div>
				<div id="err_new_name" class="alert alert-danger" style="display:none"></div>

				<label class="t_radio l_group_membership type_membership">
					Type* <i></i>
					<div class="tooltip_am">
						<div class="content_more">
							<p><span>Subsidiary</span> - An Entity where the Parent:</p>
							<ul>
								<li>holds (whether as a legal owner or as a beneficiary) more than half of the issued share capital of that Entity (excluding any part thereof which consists of preference shares); or</li>
								<li>controls more than half of the voting power of that Entity; or</li>
								<li>controls the composition of the board of directors of that Entity.</li>
							</ul>
						</div>
					</div>
				</label>
				<div class="radio_custom_by_am t_group_membership">
					<div class="yn_left">
						<input id="new_type_r"
							name="new_type"
							value="subsidiary" type="radio" checked="checked"
							class="type_sector_s3">
						<label id="new_label_r" for="new_type"><span><span></span></span>Subsidiary</label>
					</div>
					<div class="yn_right">
						<input id="new_type_o"
							name="new_type"
							value="other" type="radio"
							class="type_sector_s3">
						<label id="new_label_o" for="new_type"><span><span></span></span>Other...</label>
					</div>
				</div>
				<div id="err_new_type" class="alert alert-danger" style="display:none"></div>
				
				<div class="free_text_other_type" id="new_free_text_other_type" style="display:none;">
					<div class="input-group pad-top-17 pad-bottom-10">
						<input autocomplete="off" type="text" class="form-control"
							   value=""
							   name="new_other_type"
							   id="new_other_type"
							   placeholder="Enter custom group membership type">
					</div>
					<div id="err_new_other_type" class="alert alert-danger" style="display:none"></div>
				</div>
	</div>
	<div id="componentGM2">
						<option value="Growers">Growers</option>
						<option value="Processors and Traders">Processors and Traders</option>
						<option value="Retailers">Retailers</option>
						<option value="Consumer Goods Manufacturers">Consumer Goods Manufacturers</option>	
	</div>
	<div id="componentGM3">
							<?php foreach ($new_country_arrays as $country => $region) { ?>
								<option value="<?php echo $country; ?>"><?php echo $country; ?></option>
							<?php } ?>
	</div>
	<div id="componentGM4">
				<div class="c2_right">
					<label>Region*</label>
					<div class="input-group">
						<input autocomplete="off" type="text" class="form-control"
							   value=""
							   name="new_region"
							   id="new_region"
							   placeholder="" readonly="readonly"
							   style="border-left:1px solid transparent!important;">
					</div>
				</div>

				<div style="display:inline-block; margin-top:18px;">
					<label class="t_radio l_group_membership">Is this group member an RSPO member?*</label>
					<div class="radio_custom_by_am t_group_membership_y_n">
						<div class="yn_left">
							<input id="new_is_rspo_num-y" name="new_is_rspo_num" value="yes"
								   type="radio" class="this_group_membership"><label
									id="new_label_y"
									for="new_is_rspo_num-y"><span><span></span></span>Yes</label>
						</div>
						<div class="yn_right">
							<input id="new_is_rspo_num-n" name="new_is_rspo_num" value="no" checked="checked"
								   type="radio" class="this_group_membership"><label
									id="new_label_n"
									for="new_is_rspo_num-n"><span><span></span></span>No</label>
						</div>
					</div>
				</div>

				<div class="show_rspo_membership_number" id="new_show_rspo_membership_number" style="display:none; width:100%;">
					<label class="margin-top-12">Please enter its RSPO membership
						number</label>
					<div class="input-group membership_number">
						<input autocomplete="off" class="form-control membership_number1" value="0"
							   id="new_num1"
							   name="new_num1"
							   placeholder="" maxlength="1" type="text">
						<span>−</span>
						<input autocomplete="off" class="form-control membership_number2" value="0000"
							   id="new_num2"
							   name="new_num2"
							   placeholder="" maxlength="4" type="text">
						<span>−</span>
						<input autocomplete="off" class="form-control membership_number3" value="00"
							   id="new_num3"
							   name="new_num3"
							   placeholder="" maxlength="2" type="text">
						<span>−</span>
						<input autocomplete="off" class="form-control membership_number4" value="000"
							   id="new_num4"
							   name="new_num4"
							   placeholder="" maxlength="3" type="text">
						<span>−</span>
						<input autocomplete="off" class="form-control membership_number5" value="00"
							   id="new_num5"
							   name="new_num5"
							   placeholder="" maxlength="2" type="text">

						<input name="new_rspo_membership_num"
							   id="new_rspo_membership_num"
							   value="" type="hidden">
					</div>
					<div id="err_new_rspo_membership_num" class="alert alert-danger" style="display:none"></div>
				</div>
	</div>
	<div id="componentGM5">
					<h2>Group member contact information</h2>
	</div>
	<div id="componentGM6">
					<div class="fl_name">
						<label for="" class="block">First name</label>
						<div class="input-group no-margin">
							<input autocomplete="off" type="text" class="form-control gm_firstname_add"
								   value=""
								   name="new_firstname"
								   id="new_firstname"
								   placeholder="" style="border-right:none;">
						</div>
						<div id="err_new_firstname" class="alert alert-danger" style="display:none"></div>
					</div>
					<div class="fl_name">
						<label for="" class="block">Last name</label>
						<div class="input-group no-margin">
							<input autocomplete="off" type="text" class="form-control gm_lastname_add"
								   value=""
								   name="new_lastname"
								   id="new_lastname"
								   placeholder="">
						</div>
						<div id="err_new_lastname" class="alert alert-danger" style="display:none"></div>
					</div>

					<div class="c2_left c2_e_p">
						<label for="" class="block">Email address</label>
						<div class="input-group no-margin">
							<input autocomplete="off" type="text" class="form-control gm_email_add"
								   value=""
								   name="new_email"
								   id="new_email"
								   placeholder="">
						</div>
						<div id="err_new_email" class="alert alert-danger" style="display:none"></div>
					</div>
					<div class="c2_right">
						<label class="add-pad-am">Phone number</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input class="mobile-number tlp-code form-control gm_phone_add"
									   type="tel" value=""
									   name="new_phone"
									   id="new_phone">
							</div>
						</div>
						<div id="err_new_phone" class="alert alert-danger" style="display:none"></div>
					</div>
	</div>
	<div id="componentGM7">
				<div class="align-right margin-top-20 g_membership_button">
                    <button id="silentDelGM_new" class='btn btn-lg btn-gray margin-right-8'>Cancel</button>
					<button onclick="saveGM(event)" id="saveGM_new" class='btn btn-lg btn-black'>Save</button>
				</div>
	</div>
</div>

<script type="text/javascript">
    var old_object = {intID:<?php echo $membersapp->intID ?>};
    $(document).ready(function(){
        $("[id^='gm_']").each(function(data){
            temp = this.id.replace("gm_", "");
            temp = temp.replace("-y", "");
            temp = temp.replace("-n", "");
            temp = temp.replace("-r", "");
            temp = temp.replace("-o", "");
            if (this.type == 'radio') {
                if (this.checked) {
                    old_object[temp] = this.value;
                }
            } else {
                old_object[temp] = this.value;
            }
            old_object['total'] = $("#total").val();
        });

        console.log(JSON.stringify(old_object));

		/* Type sector */
        <?php if (!empty($subsidiaries)) {
            $counter = 0;
            foreach($subsidiaries as $sub) {
                if (!empty($sub->type == 'other')) { ?>
                    $("#free_text_other_type<?php echo $counter; ?>").slideDown('slow');
                <?php } else { ?>
                    $("#free_text_other_type<?php echo $counter; ?>").slideUp('slow');
                <?php }
                $counter++;
            }
        } ?>
		if($('.type_sector_s3').is(":checked")) {
			var cek_other_val = $('.type_sector_s3').val();
			if(cek_other_val == 'other'){
				$(this).closest(".c_form_list").find(".free_text_other_type").slideDown('slow');
			} else{
				$(this).closest(".c_form_list").find(".free_text_other_type").slideUp('slow');
			}
		} else {
			$('.free_text_other_type').slideUp('slow');
		}
		$(document).on('click','.type_sector_s3',function(){
			
			var get_val_type_sector_s3 = $(this).val();
			// alert(get_val_type_sector_s3);
			
			if(get_val_type_sector_s3 == 'other'){
				$(this).closest(".c_form_list").find(".free_text_other_type").slideDown('slow');
			} else{
				$(this).closest(".c_form_list").find(".free_text_other_type").slideUp('slow');
			}
			
		});

		/* Is this group member an RSPO member? */
		<?php
            if (!empty($subsidiaries)) {
                $counter = 0;
                foreach($subsidiaries as $sub) {
                    if (!empty($sub->is_rspo_num) && $sub->is_rspo_num == 'yes') { ?>
                        $("#show_rspo_membership_number<?php echo $counter; ?>").slideDown('slow');
                <?php } else { ?>
                        $("#show_rspo_membership_number<?php echo $counter; ?>").slideUp('slow');
                    <?php }
            $counter++;}
            } else { ?>
                $("#show_rspo_membership_number0").slideUp('slow');
            <?php } ?>
        if($('.this_group_membership').is(":checked")) {
			var cek_is_no_gm_number_val = $('.this_group_membership').val();
			if(cek_is_no_gm_number_val == 'yes'){
				$(this).closest(".c_form_list").find(".show_rspo_membership_number").slideDown('slow');
			} else{
				$(this).closest(".c_form_list").find(".show_rspo_membership_number").slideUp('slow');
			}
		} else {
			$('.show_rspo_membership_number').slideUp('slow');
		}
		$(document).on('click','.this_group_membership',function(){

			var get_val_this_group_membership = $(this).val();
			// alert(get_val_type_sector_s3);

			if(get_val_this_group_membership == 'yes'){
				$(this).closest(".c_form_list").find(".show_rspo_membership_number").slideDown('slow');
			} else{
				$(this).closest(".c_form_list").find(".show_rspo_membership_number").slideUp('slow');
			}

		});
	});

	/* add more GM form */
	function g_m_add(element){
		add_more();
	}
	
	var count_gm = <?php echo $total_subs+1; ?>; // ini kalau ada data GM dari db need count GM to start autonumber
	function add_more(){
			/* append gm form */
            var componentGM1 = $('#componentGM1').html();
            var componentGM2 = $('#componentGM2').html();
            var componentGM3 = $('#componentGM3').html();
            var componentGM4 = $('#componentGM4').html();
            var componentGM5 = $('#componentGM5').html();
            var componentGM6 = $('#componentGM6').html();
            var componentGM7 = $('#componentGM7').html();
            // $(".list_of_gm").append(componentGM1);
            $(".list_of_gm").append(' <div id="new_gm" class="bg-f5f5f5 c_form_list"><a class="g_m_add" onClick="g_m_add(this); AnimateAddTarget(this);"><i class="fa fa-plus"></i> Add new group member</a><a class="g_m_del delete" id="new_delete"><i class="fa fa-times"></i> Delete this group member</a><div class="c_form_in">'+componentGM1+'<label class="margin-top-12" style="width:100%;">Nature of business*</label><div class="input-group"><select class="selectpicker show-tick form-control" title="Select nature of business" name="new_nature_of_business" id="new_nature_of_business">'+componentGM2+'</select><div id="err_new_nature_of_business" class="alert alert-danger" style="display:none"></div></div><div class="c2_left"><label>Country*</label><div class="country_region input-group"><select class="selectpicker show-tick form-control" title="Select country" name="new_country" id="new_country">'+componentGM3+'</select></div><i style="position:absolute; margin-top:2px;">(The list of countries and regions are in accordance with the <a href="https://unstats.un.org/unsd/methodology/m49/" target="_blank">UN M49</a> standard)</i><div style="display:none; margin-bottom:5px; margin-left:-1px; margin-top:18px;" id="err_new_country" class="alert alert-danger"></div></div>'+componentGM4+'<div id="new_AUF" class="input-group">'+componentGM5+componentGM6+'</div>'+componentGM7+'</div></div> ');

            /* append anchor gm form */
            $(".GM_right").append('<li id="cAsyncGMlist'+ count_gm +'"><a id="Agm_name'+ count_gm +'" href="#gm'+ count_gm +'">New Group Membership</a></li>');

			$("#new_nature_of_business").prop({
                id: 'gm_nature_of_business'+count_gm,
                name: 'gm_nature_of_business'+count_gm
            });

            $("#err_new_nature_of_business").prop({
                id: 'err_gm_nature_of_business'+count_gm,
            });
			
			$('button[data-id="new_country"]').attr('data-id', 'gm_country'+count_gm );

            $("#new_country").prop({
                id: 'gm_country'+count_gm,
                name: 'gm_country'+count_gm
            }).attr('onchange', 'getRegion('+count_gm+')');

            $("#err_new_country").prop({
                id: 'err_gm_country'+count_gm,
            });
			
			$("#new_gm").prop({
                id: 'gm'+count_gm
            });
			
			$("#new_delete").attr({
                id: 'deleteGM'+count_gm,
                onClick: "delGM('"+count_gm+"', event)"
            });
			
			/* ================================ */

			$("#new_AUF").prop({
                id: 'gm_AUF_'+count_gm
            });
			
            $("#new_id").prop({
                id: 'gm_id'+count_gm,
                name: 'gm_id'+count_gm
            });

            $("#new_free_text_other_type").prop({
                id: 'free_text_other_type'+count_gm
            });

            $("#new_name").prop({
                id: 'gm_name'+count_gm,
                name: 'gm_name'+count_gm
            });

            $("#err_new_name").prop({
                id: 'err_gm_name'+count_gm,
            });

            $("#new_region").prop({
                id: 'gm_region'+count_gm,
                name: 'gm_region'+count_gm
            });
			
            $("#new_is_rspo_num-y").prop({
                id: 'gm_is_rspo_num'+count_gm+'-y',
                name: 'gm_is_rspo_num'+count_gm
            });

            $("#new_label_y").attr({
                id: 'g_is_rspo_num'+count_gm+'-y',
                for: 'gm_is_rspo_num'+count_gm+'-y'
            });

            $("#new_label_n").attr({
                id: 'g_is_rspo_num'+count_gm+'-n',
                for: 'gm_is_rspo_num'+count_gm+'-n'
            });

            $("#new_is_rspo_num-n").prop({
                id: 'gm_is_rspo_num'+count_gm+'-n',
                name: 'gm_is_rspo_num'+count_gm
            });

            var rand_r = 'gm_type'+count_gm+'-r';
            var rand_o = 'gm_type'+count_gm+'-o';

            $("#new_type_r").prop({
                id: rand_r,
                name: 'gm_type'+count_gm
            });

            $("#new_type_o").prop({
                id: rand_o,
                name: 'gm_type'+count_gm
            });

            $("#new_label_r").attr({
                id: 'g_type'+count_gm+'-r',
                for: rand_r
            });

            $("#new_label_o").attr({
                id: 'g_type'+count_gm+'-o',
                for: rand_o
            });

            $("#new_rspo_membership_num").prop({
                id: 'gm_rspo_membership_num'+count_gm,
                name: 'gm_rspo_membership_num'+count_gm
            });

            $("#err_new_rspo_membership_num").prop({
                id: 'err_gm_rspo_membership_num'+count_gm,
            });

            $("#new_other_type").prop({
                id: 'gm_other_type'+count_gm,
                name: 'gm_other_type'+count_gm
            });

            $("#err_new_other_type").prop({
                id: 'err_gm_other_type'+count_gm,
            });

            $("#new_num1").prop({
                id: 'num1'+count_gm,
                name: 'num1'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_num2").prop({
                id: 'num2'+count_gm,
                name: 'num2'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_num3").prop({
                id: 'num3'+count_gm,
                name: 'num3'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_num4").prop({
                id: 'num4'+count_gm,
                name: 'num4'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_num5").prop({
                id: 'num5'+count_gm,
                name: 'num5'+count_gm
            }).attr('onkeyup', 'implodeNumber('+count_gm+')');

            $("#new_firstname").prop({
                id: 'gm_firstname'+count_gm,
                name: 'gm_firstname'+count_gm
            });

            $("#err_new_firstname").prop({
                id: 'err_gm_firstname'+count_gm,
            });

            $("#new_lastname").prop({
                id: 'gm_lastname'+count_gm,
                name: 'gm_lastname'+count_gm
            });

            $("#err_new_lastname").prop({
                id: 'err_gm_lastname'+count_gm,
            });

            $("#new_email").prop({
                id: 'gm_email'+count_gm,
                name: 'gm_email'+count_gm
            });

            $("#err_new_email").prop({
                id: 'err_gm_email'+count_gm,
            });

            $("#new_phone").prop({
                id: 'gm_phone'+count_gm,
                name: 'gm_phone'+count_gm
            });

            $("#err_new_phone").prop({
                id: 'err_gm_phone'+count_gm,
            });

            $("#saveGM_new").prop({
                id: 'saveGM'+count_gm
            });

            $("#silentDelGM_new").attr({
                id: 'silentDelGM'+count_gm,
                onClick: "silentDelGM('"+count_gm+"')"
            });

            $("#total").val(count_gm);
            count_gm++;
            
			mobilenumber();
			$('.selectpicker').selectpicker('refresh');
	}
	
	/* animate */
	function AnimateAddTarget(curr_add_new_form) {
		/* scroll after add new form gm */
		var lastGMform = count_gm - 1;
		var curr_add_new_form = '#gm'+lastGMform;
		console.log('AnimateAddTarget() = '+curr_add_new_form);
		$('html, body').animate({
			scrollTop:( $(curr_add_new_form).offset().top * 1 ) - 150
		}, 800);
	}
	function AnimateScroll(){
		$('html, body').animate({
			scrollTop:( $('#line-steps').offset().top * 1 ) - 150
		}, 200);
	}
	function AnimateScroll190(){
		$('html, body').animate({
			scrollTop:( $('#line-steps').offset().top * 1 ) - 190
		}, 200);
	}
	
	/* delete form in target */
	function delGM(which, event){
		deleteColorboxConfirm();
			
		$('.process_delete').click(function(){
            var post_data = {id:$("#gm_id"+which).val()};
            $.ajax({
                url: "<?php echo site_url('members/delete_subsidiary'); ?>",
                method: "POST",
                data: post_data,
                type: "json",
                success: function(obj){
                    var data = JSON.parse(obj);
                    if (data.status == false) {
                        alert(data.message);
                    }
                }
            });
			$("#gm"+which).remove();
			$("#cAsyncGMlist"+which).remove();
			jQuery().colorbox.close();

			// next4(event);
			
			var CountOfGM = $('.list_of_gm .c_form_list').length;
			console.log(CountOfGM);
			if(CountOfGM > 0){
				
			} else{
				add_more();
			}
		});
		$('.cancel_delete').click(function(){
			jQuery().colorbox.close();
		});
	}

	function silentDelGM(which){
            var post_data = {id:$("#gm_id"+which).val()};
            $.ajax({
                url: "<?php echo site_url('members/delete_subsidiary'); ?>",
                method: "POST",
                data: post_data,
                type: "json",
                success: function(obj){
                    var data = JSON.parse(obj);
                    if (data.status == false) {
                        alert(data.message);
                    }
                }
            });
			$("#gm"+which).remove();
			$("#cAsyncGMlist"+which).remove();
	}
	
	/* delete confirm */
	var cboxOptions_deleteColorboxConfirm = {
		href: '#delete_confirm',
		inline:true, 
		width : '100%',
		maxWidth: "520px",
		maxHeight: "350px",
		fixed: true,
		close: false,
		onOpen: function(){
			$("#cboxClose").css("opacity", 0);
			$('#cboxOverlay').css({"background":"#000"});
		},
		onComplete: function(){
			$("#cboxClose").css({"opacity": 1});
			$('#cboxOverlay').css({"background":"#000"});
		},
		onClosed:function(){
			$("#cboxClose").css({"opacity": 0});
			$('#cboxOverlay').css({"background":"#000"});
		}
	}
	function deleteColorboxConfirm(){    
		$.colorbox(cboxOptions_deleteColorboxConfirm);
	}
	$(window).resize(function(){
		$.colorbox.resize({
			width: window.innerWidth > parseInt(cboxOptions_deleteColorboxConfirm.maxWidth) ? cboxOptions_deleteColorboxConfirm.maxWidth : cboxOptions_deleteColorboxConfirm.width,
			height: window.innerHeight > parseInt(cboxOptions_deleteColorboxConfirm.maxHeight) ? cboxOptions_deleteColorboxConfirm.maxHeight : cboxOptions_deleteColorboxConfirm.height
		});
	});
	
	/* success message submit */
	var cboxOptions_SuccessColorboxConfirm = {
		href: '#success_messages',
		inline:true, 
		width : '100%',
		maxWidth: "690px",
		maxHeight: "350px",
		fixed: true,
           escKey: false,
           overlayClose: false,
		onOpen: function(){
			$("#cboxClose").css("opacity", 0);
			$('#cboxOverlay').css({"background":"#000"});
		},
		onComplete: function(){
               $('#cboxClose').remove();
			$('#cboxOverlay').css({"background":"#000"});
		}
	}
	function SuccessColorboxConfirm(){    
		$.colorbox(cboxOptions_SuccessColorboxConfirm);
	}
	$(window).resize(function(){
		$.colorbox.resize({
			width: window.innerWidth > parseInt(cboxOptions_SuccessColorboxConfirm.maxWidth) ? cboxOptions_SuccessColorboxConfirm.maxWidth : cboxOptions_SuccessColorboxConfirm.width,
			height: window.innerHeight > parseInt(cboxOptions_SuccessColorboxConfirm.maxHeight) ? cboxOptions_SuccessColorboxConfirm.maxHeight : cboxOptions_SuccessColorboxConfirm.height
		});
	});

	/* success message save */
	var cboxOptions_SuccessColorboxConfirmSave = {
		href: '#success_messages_save',
		inline:true,
		width : '100%',
		maxWidth: "361px",
		maxHeight: "90px",
		fixed: true,
		bottom: 20, 
		right: 20,
		close: false,
		onOpen: function(){
			$("#cboxClose").css("opacity", 0);
			$('#cboxOverlay').css({"background":"transparent"});
		},
		onComplete: function(){
			$("#cboxClose").css({"opacity": 0});
			$('#cboxOverlay').css({"background":"transparent"});
		},
		onClosed:function(){
			$("#cboxClose").css({"opacity": 0});
			$('#cboxOverlay').css({"background":"transparent"});
		}
	}
	function SuccessColorboxConfirmSave(){
		$.colorbox(cboxOptions_SuccessColorboxConfirmSave);
	}
	$(window).resize(function(){
		$.colorbox.resize({
			width: window.innerWidth > parseInt(cboxOptions_SuccessColorboxConfirmSave.maxWidth) ? cboxOptions_SuccessColorboxConfirmSave.maxWidth : cboxOptions_SuccessColorboxConfirmSave.width,
			height: window.innerHeight > parseInt(cboxOptions_SuccessColorboxConfirmSave.maxHeight) ? cboxOptions_SuccessColorboxConfirmSave.maxHeight : cboxOptions_SuccessColorboxConfirmSave.height
		});
	});	
	
	/* sync GM list with anchor */
	function syncGMlist(getid) {
		var id = getid.getAttribute('id');
		var value = getid.value;
		
		/* text in a href */
		var string_anchor = document.getElementById("A"+id).innerHTML;
		if(string_anchor.length > 0){
			document.getElementById("A"+id).innerHTML = value;
		} else{
			document.getElementById("A"+id).innerHTML = 'New Group Membership';
		}
	}

    function saveGM(event){
        event.preventDefault();
        var post_data = {intID:<?php echo $membersapp->intID ?>, total:$("#total").val()};
        $("[id^='gm_']").each(function(data){
            temp = this.id.replace("gm_", "");
            temp = temp.replace("-y", "");
            temp = temp.replace("-n", "");
            temp = temp.replace("-r", "");
            temp = temp.replace("-o", "");
            if (this.type == 'radio') {
                if (this.checked) {
                    post_data[temp] = this.value;
                }
            } else {
                post_data[temp] = this.value;
            }
        });

        $.ajax({
            url: "<?php echo site_url('members/save_subsidiary'); ?>",
            method: "POST",
            data: post_data,
            type: "json",
            success: function(obj){
                var data = JSON.parse(obj);
                if (data.status == false) {
                    alert(data.message);
                } else {
                    $.each(data.data, function( index, value ) {
                        post_data[index] = value;
                        $("#gm_id"+index).prop({
                            value: value
                        });
                    });
                    old_object = post_data;
                    checkObject = false;

                    SuccessColorboxConfirmSave();
                    setTimeout(parent.$.colorbox.close, 1200);
                }
            }
        });
    }

    /*Scroll Spy*/
	$(document).ready(function(){
		var offset_top = 412;
		$('body').scrollspy({ target: '#list_gm_left', offset:offset_top});
		if (window.innerWidth <= 1100)
		{
			$('#nav').affix({
				offset: {
					top: $('#list_gm_left').offset().top + offset_top, // set left timeline sticky
					bottom: $('footer').outerHeight(true) + 80
				}
			});
		} else{
			$('#nav').affix({
				offset: {
					top: $('#list_gm_left').offset().top + offset_top, // set left timeline sticky
					bottom: $('footer').outerHeight(true) + 80
				}
			});
		}
		$(window).resize(function() {
			if (window.innerWidth <= 1100)
			{
				$('#nav').affix({
					offset: {
						top: $('#list_gm_left').offset().top + offset_top, // set left timeline sticky
						bottom: $('footer').outerHeight(true) + 80
					}
				});
			} else{
				$('#nav').affix({
					offset: {
						top: $('#list_gm_left').offset().top + offset_top, // set left timeline sticky
						bottom: $('footer').outerHeight(true) + 80
					}
				});
			}
		});

		$('html, body').animate({
			scrollTop: ($("#list_gm_left").offset().top * 1) - offset_top
		}, 200);
	});

	/* back to top */
	$(window).scroll(function(){
		if ($(this).scrollTop() > 514) {
			$('.backtoTop').fadeIn();
		} else {
			$('.backtoTop').fadeOut();
		}
	});
	$('.backtoTop a').click(function(){
		$('html, body').animate({scrollTop : 0},800);
		return false;
	});

    /*Smooth link animation*/
	// $('#list_gm_left a[href*=#]:not([href=#])').click(function() {
	$(document).on('click','#list_gm_left a[href*=#]:not([href=#])',function(){
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {

            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
				/* $('html,body').animate({
                    scrollTop: target.offset().top
                }, 1000); */
                $('html,body').animate({
                    scrollTop: target.offset().top  - 30
                }, 1000);
                return false;
            }
        }
    });

	/* get region */
	function getRegion(index){
		var country = $("#gm_country"+index).val();
		var post_data = {country: country};
		$.ajax({
			url: "<?php echo site_url('members/get_region'); ?>",
			method: "POST",
			data: post_data,
			type: "json",
			success: function(obj){
				var data = JSON.parse(obj);
				if (data.status == true) {
					$("#gm_region"+index).val(data.data);
				}
			}
		});

		$.ajax({
			url: "<?php echo site_url('members/countrycode'); ?>",
			method: "POST",
			data: {c: country},
			type: "json",
			success: function(obj){
				$('#gm_phone'+index).intlTelInput("selectCountry", obj);
			}
		});
	}

   function implodeNumber(counter) {
       var member_num = [
           $("#num1"+counter).val(),
           $("#num2"+counter).val(),
           $("#num3"+counter).val(),
           $("#num4"+counter).val(),
           $("#num5"+counter).val()
       ];
       $("#gm_rspo_membership_num"+counter).val(member_num.join("-"));
   }

    function implodeNumberQuestion(counter) {
        var member_num = [
            $("#num1"+counter).val(),
            $("#num2"+counter).val(),
            $("#num3"+counter).val(),
            $("#num4"+counter).val(),
            $("#num5"+counter).val()
        ];
        $("#deemed_complience_rspo_new_gm_parent_rspo_membership_number").val(member_num.join("-"));
    }

	$(document).ready(function(){
		/* membernumber next auto */
		$(document).on('keyup','.membership_number input',function(){
			if($(this).val().length==$(this).attr("maxlength")){
				$(this).next('span').next().focus();
			}
		});

		/* focus text clear val */
		$(document).on('focus','.membership_number input',function(){
			// pertama load, cek apa sudah ada val
			// kalau gak ada, simpen val sekrang ke data()
			if (!$(this).data('defaultText')) $(this).data('defaultText', $(this).val());

			// cek apakah data sama
			if ($(this).val()==$(this).data('defaultText')) $(this).val('');
		});

		$(document).on('blur','.membership_number input',function(){
			// jika gak ada val maka set defaultText
			if ($(this).val()=='') $(this).val($(this).data('defaultText'));
		});
	});
</script>