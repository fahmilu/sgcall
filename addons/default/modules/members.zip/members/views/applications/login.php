<style>
	.btn {
		border-radius: 0px;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
	.message{
		font-size: 14px;
		padding: 0px;
		border-radius: 2px;
		color: #000;
		margin-bottom: 30px;
	}
	.message a{
		/* color: #000!important; */
		font-weight:600;
	}
	.message p{
		margin-bottom: 0px;
		padding: 0px 30px 25px;
	}
	.error{
		background: #F2F2F2 none repeat scroll 0% 0%;
	}
	.steps-members-status-responsive{
		padding-left: 30px;
		padding-right: 22px;
		padding-top: 15px;
		margin-bottom: 22px;
		border-bottom: 1px solid #dedede;
		padding-bottom: 15px;
	}
</style>	
<section id="contact_detail" class="login_page">
	<div class="container text-center">
		<h1 style="font-weight:bold; margin-top:24px; margin-bottom:25px; font-size: 25px; padding-top:3px; text-transform:uppercase;">LOGIN</h1>	
	</div>	
	<div class="container">	
		<div class="row">
		<?php echo form_open('members/login', 'id="memLogin2"') ?>
		<div class="contain300">
			{{ session:messages success="message success" notice="message info" error="message error" }}
			
			<?php if(!empty($error_string)): ?>
			<div class="alert alert-danger">
				<?php echo $error_string ?>
			</div>
			<?php endif;?>

			<div class="box-contact-form organisation" style="margin-top:0px;">
				<div class="form-group" style="display: block;">
					<label>Email</label>
					<input type="text" class="form-control" name="email" placeholder="Your email" />
				</div>
				
				<div class="form-group"  style="display: block;">
					<label>Password</label>
					<span style="text-align: right;"><a href="<?php echo site_url('members/forget'); ?>" class="pull-right link-link" style="font-size: 12px;">Forgot password?</a></span>
					<input type="password" class="form-control" name="password" placeholder="Password" />
				</div>

				<div class="form-group" style="margin-bottom:0px; display: block;">
					<input type="hidden" name="redirect_to" value="members/application" />
					<input type="submit" value="SIGN IN" class="btn btn-lg btn-orange" style="border-radius:3px; width:48%; font-size:14px;">
					<label class="text-right checkbox-inline" style="width:50%; padding-left:0px; margin-bottom:4px;">
						<input type="checkbox" id="inlineCheckbox3" value="remember" style="margin-top: -12px; margin-left: -28px;">
						Remember Me
					</label>
				</div>
			</div>
			<div class="login_first_register bg-f2f2f2">
				<a href="{{url:site}}members/myrspo-registration" class="link-link">First time logging in? Register here.</a>
			</div>
		</div>
		</form>
	</div>
</section>

<script type="text/javascript">
	// login
	$(document).ready(function(){
		$('form#memLogin2').on('submit', function(e){
			e.preventDefault();
		
			var data = $('form#memLogin2').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btn-signin').text('Loading...');
					$('#btn-signin').attr('disabled', true);
				},
				url: '/members/login',
				data: data,
				dataType: 'json',
				method: 'post'
			}).error(function(){
				$('#btn-signin').text('LOGIN');
				$('#btn-signin').attr('disabled', false);
			}).done(function(html){
				$('#btn-signin').text('LOGIN');
				$('#btn-signin').attr('disabled', false);
				//return false;
				if (html.status == 'login')
				{
					//$('#loginAlert').html('<div class="alert alert-success alert-dimissible" role="alert"><div>'+html.message+'</div></div>').fadeIn();
					if (html.redirect_to)						
						window.location = html.redirect_to;
				}
				else if (html.status)
				{
					document.getElementById("statusMembers").innerHTML = html.message;
					
					//console.log('list members'+html.secondary_member);
					console.log('list members = '+html.is_multiple);
					
					var cek_is_multiple = html.is_multiple;
					if(cek_is_multiple >= 1){
						document.getElementById("multipleMembers").innerHTML = '<select id="change_membersOnNav" class="selectpicker form-control" name="change_membersOnNav" title="Change member(s)">'+html.secondary_member+'</select>';
						$("#change_membersOnNav").selectpicker("refresh");
						
						$("body").children().each(function() {
							$(this).html($(this).html().replace(/@/g,"<span class='desc_sector'>"));
							$(this).html($(this).html().replace(/##/g,"<p class='intIDmembers' style='display:none;'>"));
							$(this).html($(this).html().replace(/!!!/g,"<p class='titleOfMembers' style='display:none;'>"));
						});
					}
					
					if(cek_is_multiple == 0){
						//$('.modalfooterStatusMembers').hide('fast');
						$('#linkLogoutMstatus').hide('fast');
						$('#btnCloseMstatus').show('fast');
					} else{
						//$('.modalfooterStatusMembers').show('fast');
						$('#linkLogoutMstatus').show('fast');
						$('#btnCloseMstatus').hide('fast');
					}
					
					$('.steps-members-status').hide('fast');
					$('#message_login_status').modal('show');
					
					return false;
				}
				else
				{
					//$('#loginAlert').html('<div class="alert alert-danger alert-dimissible" role="alert"><div>'+html.message+'</div></div>').fadeIn();
					$('#password_alert').html('<div style="width:100%; float:left; color:red; margin-top:-10px; padding-bottom:10px;">Incorrect email or password</div>').fadeIn();
				}
			});
		});
	});
	// end login
</script>