<div id="docs_sector_RETAILER" style="display:block;">
	<!-- required -->
	<ul style="padding-left:15px;">
		<li>
			Please attach proof of business registration (e.g. certificate of incorporation, certificate of good standing, article of incorporation or other similar documents)
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="sector_business_registration" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->sector_business_registration)): ?>
					<?php echo form_hidden('sector_business_registration', $membersapp->sector_business_registration); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->sector_business_registration))) ?>" target="_blank"><?php echo $membersapp->sector_business_registration; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('sector_business_registration') ? '<div class="alert alert-danger">'.form_error('sector_business_registration').'</div>' : ''; ?>
			</div>
		</li>
	</ul>
	<!-- end required -->
	
	<!-- RETAILER additional -->
	<ul style="padding-left:15px;">
		<li>Latest Annual Report or Shareholder documents (required document for subsidiary inclusion in Group Membership).</li>
		<li>Organisation status (corporate and ownership structure).</li>
		<li>Disclosure of existing field practices and policies of Corporate Social Responsibility (CSR)/ sustainability policy.</li>
	</ul>
	<div id="more_file_additionals">
		<input type="file" name="file_additionals[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')"  class="required filestyle">	
		<input data-validation-engine="validate[required]" type="hidden" name="div_retailer_additional[]" value=""/>
		<?php echo form_error('div_retailer_additional[]') ? '<div class="alert alert-danger">'.form_error('div_retailer_additional[]').'</div>' : ''; ?>
	</div>
	<div id="div_retailer_additional" class="multiple" style="display:none;"></div>
	<a href="#" id="add_retailer_additional">Add more file</a><br />
	<i>Maximum file size is 20MB</i>
	
	<?php if (!empty($membersapp->file_additionals)): ?>
		<?php echo form_hidden('file_additionals', htmlspecialchars_decode($membersapp->file_additionals)); ?>
		<div class="form-group"><br />		
			<label>Current file(s)</label>
			<?php $upfiles_cert = explode(',', $membersapp->file_additionals); ?>
			<div class="table-responsive">
			<table class="table table-striped table-supplychain" style="border:1px solid #ddd;">
				<thead>
					<tr>
						<th style="width:10%;">Delete</th>
						<th>Filename</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach($upfiles_cert as $f): ?>
					<?php if ($f): ?>
					<tr>
						<td style="padding-left:28px; padding-top:0px; padding-bottom:0px;">
							<input type="checkbox" name="remove_uploaded_additionals[]" value="<?php echo $f; ?>" style="margin-top:6px;"/>
						</td>
						<td style="vertical-align:middle; padding-top:0px; padding-bottom:0px;"><a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($f))) ?>" target="_blank"><?php echo $f; ?></a></td>
					</tr>
					<?php endif; ?>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
			<p><i>Check the delete box and click save to delete your uploaded document(s)</i></p>
		</div>
		<div class="clearfix"></div>
	<?php else: ?>
		<div class="clearfix"><br /></div>
	<?php endif; ?>
	<!-- end additional -->
</div>

<script type="text/javascript">
$('a#add_retailer_additional').click(function(e){
	e.preventDefault();
	//var h = $('#div_retailer_additional').html();
	var h = '<input type="file" name="file_additionals[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), "all")"  class="required">'+
		'<input data-validation-engine="validate[required]" type="hidden" name="div_retailer_additional[]" value=""/>';

	$('#div_retailer_additional').append(h);
	$('#div_retailer_additional input[type=file]').filestyle({
		iconName : '',
		buttonText : 'Browse',
	});
	var a = '<a href="#" class="btn btn-orange btn-lg remove_file" style="float:left;height:43px;">x</a>';
	$('#div_retailer_additional').find('.bootstrap-filestyle:last').prepend(a);
	$('#div_retailer_additional').fadeIn();
});
</script>