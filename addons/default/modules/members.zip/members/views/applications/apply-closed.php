<!-- Full Page Image Background Carousel Header -->
<div class="container">
	<div class="container text-center" id="header-white">
		<h1>MEMBERSHIP APPLICATION</h1>
	</div>
</div>

<!--
<section id="related">
<div class="container">
<div class="row text-center" style="height:300px;">
<p>Sorry, the online membership application is currently being upgraded. <br/><br/>Please <a href="mailto:membership@rspo.org">email us</a> or check back again soon.</p>
</div>
</div>
</section>
-->

<style>
	.requirement-list li a{
		font-size:14px;
	}
	.requirement-list li{
		font-size:14px;
	}
	p{
		padding-bottom:0px;
	}

	form#memRegister div {
		padding-bottom: 0px;
		margin-bottom: 0;
	}
	form#memRegister div input {
		margin-bottom: 13px;
	}
	form#memRegister div .col-sm-12 label {
		padding-top: 0;
		margin-top: 13px;
	}
	label.inline.with-padding {
		width: 100%;
		padding: 0;
		margin: 0;
		display: block;
	}
	label.inline.with-padding span.input-container {
		width: 20px;
		float: left;
		padding: 0;
		margin-right: 0;
	}
	label.inline.with-padding span.input-container input {
		outline: none;
	}

	/* override style.css starts */
	/* .container-step {
	    background-color: #ffffff;
	    border: none;
	    padding: 0 0px 20px 30px;
	    margin: 0;
	    min-height: 550px;
	} */
	.container-step p,
	.container-step div {
	    line-height: 1.85;
	}
	.container-step h2 {
		width: 100%;
		margin: 0 auto;
	    /* border-top: solid 1px #ededed; */
	    margin-left: 0;
	    padding: 30px 0 17px;
	}
	.container-step-mid {
		/* border-left: 1px solid #EDEDED; */
		margin: 0px 20px;
		padding: 0px 30px 30px 30px;
	}
	/* override style.css ends */
</style>
<!-- dual image Section -->
<section id="registration-step">
	<div class="container text-center">
		<div class="contain800">

			<div class="alert alert-warning">
			The membership application is temporarily closed for upgrades until further notice.<br />
			We apologize for any inconvenience caused.
			</div>

		</div>
	</div>
</section>

<section class="section-no-title bg-light-gray">
	<div class="container text-center">
		<div class="contain800">
			<h2 class="section-heading">WHAT HAPPENS AFTER SUBMISSION</h2>
			<p class="whoweareabout" style="line-height:1.75">All membership applications go through a process whereby background research is undertaken. Submitted documents are reviewed; input is received from various stakeholders followed by a final approval from the RSPO Secretary General upon endorsement from the Board of Governors. Any appeals to applications declined will be handed by an Arbitration Board.</p>
			<p>Membership of the RSPO includes a 2-year commitment consecutively with membership fees payable annually. Membership is renewable annually thereafter.</p>
		</div>
	</div>

</section>

<script>

/*
     (function ($) {
         $.support.placeholder = ('placeholder' in document.createElement('input'));
     })(jQuery);


     //fix for IE7 and IE8
     $(function () {
         if (!$.support.placeholder) {
             $("[placeholder]").focus(function () {
                 if ($(this).val() == $(this).attr("placeholder")) $(this).val("");
             }).blur(function () {
                 if ($(this).val() == "") $(this).val($(this).attr("placeholder"));
             }).blur();

             $("[placeholder]").parents("form").submit(function () {
                 $(this).find('[placeholder]').each(function() {
                     if ($(this).val() == $(this).attr("placeholder")) {
                         $(this).val("");
                     }
                 });
             });
         }
     });
*/

</script>

<script>
	$(document).ready(function(){
			  
		$('#showwhyapply').click(function(e){
			e.preventDefault();
			$('.whyapply').slideToggle();
		});
	
		$('#show_what_happen_after_submission').click(function(e){
			e.preventDefault();
			$('.what_happen_after_submission').slideToggle();
		});
	
		$('#show_ordinary_affiliate_membership').click(function(e){
			e.preventDefault();
			$('.ordinary_affiliate_membership').slideToggle();
		});
						
		$('#show_suppy_chain_associate_membership').click(function(e){
			e.preventDefault();
			$('.suppy_chain_associate_membership').slideToggle();
		});
	
		$('.registershow,.registershow3').click(function(e){
			e.preventDefault();
			var d = $(this).attr('rel');
			$('.step0').slideUp(function(){
			});
				$('#'+d).fadeIn();
		});

		$('.registershow2').click(function(e){
			e.preventDefault();
			var d = $(this).attr('rel');
			$('.step0').slideUp(function(){
			});
				$('#'+d).fadeIn('fast', function(){
					$('html, body').animate({
						scrollTop: ($("#uregister").offset().top * 1) - 100
					}, 100);
				});

		});
	
		$('#agree_cod, #agree_pp').on('click', function(){
			if ($('#agree_pp').is(':checked') && $('#agree_cod').is(':checked'))
			{
				$('#btnSubmit').attr('disabled', false);
			}
			else
			{
				$('#btnSubmit').attr('disabled', true);
			}
		});
	
	
		$('form#memRegister').on('submit', function(e){
			e.preventDefault();
	
			if (!$('#reg_email').val())
			{
				alert('Please enter your email address');
				$('#reg_email').focus();
				return false;
			}
	
			if (!$('#full_name').val())
			{
				alert('Please enter your full name');
				$('#full_name').focus();
				return false;
			}
	
			if (!$('#password1').val())
			{
				alert('Please create a new password');
				$('#password1').focus();
				return false;
			}
	
			if (!$('#password2').val())
			{
				alert('Please reconfirm your new password');
				$('#password2').focus();
				return false;
			}
	
			if ($('#password2').val() != $('#password1').val())
			{
				alert('The password you entered do not match');
				$('#password1').focus();
				return false;
			}

			// recaptcha
			if ($('#recaptcha_response_field').val() == '')
			{
				alert('Please enter the text you see in the Captcha image.');
				$('#recaptcha_response_field').focus();
				return false;
			}

			if (!$('#agree_cod').is(':checked'))
			{
				alert("Please check to confirm that you agree to RSPO's Code of Conduct.");
				$('#agree_cod').focus();
				return false;
			}
	
			if (!$('#agree_pp').is(':checked'))
			{
				alert("Please check to confirm that you agree to RSPO's Privacy Policy.");
				$('#agree_pp').focus();
				return false;
			}
	
			var data = $('form#memRegister').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btnSubmit').text('Please wait...');
					$('#btnSubmit').attr('disabled', true);
				},
				url: '/members/register',
				data: data,
				dataType: 'json',
				method: 'post'
	
			}).error(function(){
				$('#btnSubmit').text('Submit');
				$('#btnSubmit').attr('disabled', false);
			}).done(function(html){
	
				$('#btnSubmit').text('Submit...');
				$('#btnSubmit').attr('disabled', false);
	
				if (html.status=='error')
				{
					$('#regAlert').html('<div class="alert alert-danger alert-dimissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#regAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#regAlert').fadeIn();
					});
					Recaptcha.reload();
/*
					if (html.recaptcha != undefined)
					{
						$('#captcha_container').fadeTo('fast', 0, function(){
							$(this).html(html.recaptcha).fadeTo('fast', 1);
						});
					}
*/
				}
				else if (html.status=='ok')
				{
					Recaptcha.reload();
					$('#regAlert').html('<div class="alert alert-success alert-dimissible" role="alert"  style="margin-top:30px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#regAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#regAlert').fadeIn(function(){
							$('form#memRegister')[0].reset();
							$('#btnSubmit').attr('disabled', true);
							gaProcess('members/apply', 'Register', 'User Registrations');
						});
					});
				}
	
			});
	
		});
	
	
		$('form#memForget').on('submit', function(e){
			e.preventDefault();
	
			if (!$('#emailForget').val())
			{
				alert('Please enter your email address');
				$('#emailForget').focus();
				return false;
			}
	
			var data = $('form#memForget').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btnForget').text('Please wait...');
					$('#btnForget').attr('disabled', true);
				},
				url: '/members/forget',
				data: data,
				dataType: 'json',
				method: 'post'
	
			}).error(function(){
				$('#btnForget').text('SUBMIT');
				$('#btnForget').attr('disabled', false);
			}).done(function(html){
	
				$('#btnForget').text('SUBMIT');
				$('#btnForget').attr('disabled', false);
	
				if (html.status)
				{
					$('#forgetAlert').html('<div class="clearfix"></div><div class="alert alert-success alert-dimissible" role="alert" style="margin-top:30px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#forgetAlert').fadeIn(function(){
							$('form#memForget')[0].reset();
							//window.location = '<?php echo site_url('members/application'); ?>';
						});
					});
				}
				else
				{
					$('#forgetAlert').html('<div class="clearfix"></div><div class="alert alert-danger alert-dimissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#forgetAlert').fadeIn();
					});
				}
	
			});
	
		});

		$('form#memLogin').on('submit', function(e){
			e.preventDefault();
	
			/* if (!$('#loginEmail').val())
			{
				alert('Please enter your email address');
				$('#reg_email').focus();
				return false;
			}
	
			if (!$('#loginPass').val())
			{
				alert('Please create a new password');
				$('#password1').focus();
				return false;
			} */
	
			var data = $('form#memLogin').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btnLogin').text('Please wait...');
					$('#btnLogin').attr('disabled', true);
				},
				url: '/members/login',
				data: data,
				dataType: 'json',
				method: 'post'
	
			}).error(function(){
				$('#btnLogin').text('LOGIN');
				$('#btnLogin').attr('disabled', false);
			}).done(function(html){
	
				$('#btnLogin').text('LOGIN');
				$('#btnLogin').attr('disabled', false);
				//return false;
				if (html.status)
				{
					$('#loginAlert').html('<div class="alert alert-success alert-dimissible" role="alert"  style="margin-top:30px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#loginAlert').fadeIn(function(){
							$('form#memLogin')[0].reset();
							if (html.redirect_to)
							{
								window.location = html.redirect_to;
							}
							else
							{
								gaProcess('members/apply', 'Login', 'Already started your application? Log in to resume.');
								window.location = '<?php echo site_url('members/selecttype'); ?>';
							}
						});
					});
				}
				else
				{
					$('#loginAlert').html('<div class="alert alert-danger alert-dimissible" role="alert" style="margin-top:30px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#loginAlert').fadeIn();
					});
				}
	
			});
	
		});

	});
</script>
