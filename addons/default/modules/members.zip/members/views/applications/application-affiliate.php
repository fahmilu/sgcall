<div id="docs_sector_AFFILIATE" style="display:block;">
	<!-- required -->
	<ul style="padding-left:15px;">
		<li>
			Please attach proof of business registration (e.g. certificate of incorporation, certificate of good standing, article of incorporation or other similar documents)
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="affiliate_business_registration" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->affiliate_business_registration)): ?>
					<?php echo form_hidden('affiliate_business_registration', $membersapp->affiliate_business_registration); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->affiliate_business_registration))) ?>" target="_blank"><?php echo $membersapp->affiliate_business_registration; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('affiliate_business_registration') ? '<div class="alert alert-danger">'.form_error('affiliate_business_registration').'</div>' : ''; ?>
			</div>
		</li>
	</ul>
	<!-- end required -->
</div>