
<pre>
<?
	echo "\$_POST\n";
	print_r($_POST);
	echo "<hr />\n";
	echo "\$_FILES\n";
	print_r($_FILES);
?>
</pre>


<?php echo form_open_multipart($this->uri->uri_string(), 'id="frmApply" name="frmApply"') ?>

<div id="testcoba">
	<input type="text" name="cbox[]" value="1" /> 1<br />
</div>

<a href="#" id="tambahin">Tambah</a>
<div id="cobacoba" style="display:none;">
	<input type="text" name="cbox[]" value="2" /> 2<br />
</div>
<script>
$(document).ready(function(){

	$('a#add_file_additionals').click(function(e){
		e.preventDefault();

		var h = $('#div_file_additionals').html();
		$('#more_file_additionals').append(h).fadeIn(function(){
			$('#more_file_additionals input[type=file]').filestyle({
				iconName : '',
				buttonText : 'Browse',
			});
		});

	});

	$('a#tambahin').click(function(e){
		e.preventDefault();
		var h = $('#cobacoba').html();
		$('#testcoba').append(h);
	});

	$('input[type=file].filestyle').filestyle({
		iconName : '',
		buttonText : 'Browse',
	});

});
</script>


							<div id="more_file_additionals" style="width:300px;">

								<input type="file" name="file_additionals[]"  class="required filestyle" >
								<input data-validation-engine="validate[required]" type="hidden" name="div_file_additionals[]" value="" />

							</div>
							<a href="#" id="add_file_additionals">Add more file</a>

<p><input type="submit"></p>
</form>

<pre>
<?php

if ($_POST)
{
	echo "\$_FILES\n";
	print_r($_FILES);
}

?>
</pre>

<div style="display:none;">
	<div id="div_file_additionals">
		<!-- <input data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this))" type="file" name="file_additionals[]" class="required" > -->
		<input type="file" name="file_additionals[]" class="required" >
		<input rel="Copy of the certificate of incorporation of your organisation" data-validation-engine="validate[required]" type="hidden" name="div_file_additionals[]" value="" />
	</div>
</div>

		<input type="hidden" name="category" value="<?php echo $membersapp->category; ?>" />
		<input type="hidden" name="type" value="<?php echo $membersapp->type; ?>" />
		<input type="hidden" name="draft_id" value="<?php echo $membersapp->intID; ?>" />
