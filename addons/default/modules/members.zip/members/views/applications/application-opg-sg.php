	<!-- required -->
	<ul style="padding-left:15px;">	
		<li>
			Please attach proof of business registration (e.g. certificate of incorporation, certificate of good standing, article of incorporation or other similar documents)
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="opg_sg_business_registration" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->opg_sg_business_registration)): ?>
					<?php echo form_hidden('opg_sg_business_registration', $membersapp->opg_sg_business_registration); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sg_business_registration))) ?>" target="_blank"><?php echo $membersapp->opg_sg_business_registration; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('opg_sg_business_registration') ? '<div class="alert alert-danger">'.form_error('opg_sg_business_registration').'</div>' : ''; ?>
			</div>
		</li>
		<li>
			Disclosure of plans to implement the RSPO Principles and Criteria (P&C) - Click <a href="{{url:site}}{{theme:path}}/files/MAP_supporting_details/Template on the Implementation of the RSPO P&C (TBP).xlsx">here</a> to download.
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="opg_sg_principles_criteria" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->opg_sg_principles_criteria)): ?>
					<?php echo form_hidden('opg_sg_principles_criteria', $membersapp->opg_sg_principles_criteria); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sg_principles_criteria))) ?>" target="_blank"><?php echo $membersapp->opg_sg_principles_criteria; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('opg_sg_principles_criteria') ? '<div class="alert alert-danger">'.form_error('opg_sg_principles_criteria').'</div>' : ''; ?>
			</div>
		</li>
		<li>
			Reporting Template for Disclosure of Areas Cleared without Prior HCV Assessment since November 2005 - Click <a href="{{url:site}}{{theme:path}}/files/MAP_supporting_details/Annex 2_Reporting_Template_for_Disclosure_of Non Compliant Land Clearing.xlsx">here</a> to download.
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="opg_sg_disclosure_cleared_area" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->opg_sg_disclosure_cleared_area)): ?>
					<?php echo form_hidden('opg_sg_disclosure_cleared_area', $membersapp->opg_sg_disclosure_cleared_area); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sg_disclosure_cleared_area))) ?>" target="_blank"><?php echo $membersapp->opg_sg_disclosure_cleared_area; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('opg_sg_disclosure_cleared_area') ? '<div class="alert alert-danger">'.form_error('opg_sg_disclosure_cleared_area').'</div>' : ''; ?>
			</div>
		</li>
        <li>
            Estate location and concession maps in Shapefile format (.shp) with polygon geometry dimension (including subsidiary, if any).
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="opg_sg_estate_location" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->opg_sg_estate_location)): ?>
					<?php echo form_hidden('opg_sg_estate_location', $membersapp->opg_sg_estate_location); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->opg_sg_estate_location))) ?>" target="_blank"><?php echo $membersapp->opg_sg_estate_location; ?></a>
				<?php endif; ?>

				<?php echo form_error('opg_sg_estate_location') ? '<div class="alert alert-danger">'.form_error('opg_sg_estate_location').'</div>' : ''; ?>
			</div>
		</li>
	</ul>
	<!-- end required -->
	
	<!-- additional -->
	<ul style="padding-left:15px;">
		<li>Latest Annual Report or Shareholder documents (required document for subsidiary inclusion in Group Membership).</li>
		<li>Organisation status (corporate and ownership structure).</li>
		<li>Disclosure of existing field practices and policies of Corporate Social Responsibility (CSR)/ sustainability policy.</li>
		<li>Additional information such as legally set aside area (eg. riparian, hill slope, deep peat etc.) and settlements within their concession (if any).</li>
	</ul>
	<div id="more_file_additionals">
		<input type="file" name="file_additionals[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')"  class="required filestyle">	
		<input data-validation-engine="validate[required]" type="hidden" name="file_additionals[]" value=""/>
		<?php echo form_error('file_additionals[]') ? '<div class="alert alert-danger">'.form_error('file_additionals[]').'</div>' : ''; ?>
	</div>
	<div id="div_opg_sg_additional" class="multiple" style="display:none;"></div>
	<a href="#" id="add_opg_sg_additional">Add more file</a><br />
	<i>Maximum file size is 20MB</i>
	
	<?php if (!empty($membersapp->file_additionals)): ?>
		<?php echo form_hidden('file_additionals', htmlspecialchars_decode($membersapp->file_additionals)); ?>
		<div class="form-group"><br />		
			<label>Current file(s)</label>
			<?php $upfiles_cert = explode(',', $membersapp->file_additionals); ?>
			<div class="table-responsive">
			<table class="table table-striped table-supplychain" style="border:1px solid #ddd;">
				<thead>
					<tr>
						<th style="width:10%;">Delete</th>
						<th>Filename</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach($upfiles_cert as $f): ?>
					<?php if ($f): ?>
					<tr>
						<td style="padding-left:28px; padding-top:0px; padding-bottom:0px;">
							<input type="checkbox" name="remove_uploaded_additionals[]" value="<?php echo $f; ?>" style="margin-top:6px;"/>
						</td>
						<td style="vertical-align:middle; padding-top:0px; padding-bottom:0px;"><a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($f))) ?>" target="_blank"><?php echo $f; ?></a></td>
					</tr>
					<?php endif; ?>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
			<p><i>Check the delete box and click save to delete your uploaded document(s)</i></p>
		</div>
		<div class="clearfix"></div>
	<?php else: ?>
		<div class="clearfix"><br /></div>
	<?php endif; ?>
	<!-- end additional -->
<script type="text/javascript">
$('a#add_opg_sg_additional').click(function(e){
	e.preventDefault();
	//var h = $('#div_opg_sg_additional').html();
	var h = '<input type="file" name="file_additionals[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), "all")"  class="required">'+
		'<input data-validation-engine="validate[required]" type="hidden" name="file_additionals[]" value=""/>';

	$('#div_opg_sg_additional').append(h);
	$('#div_opg_sg_additional input[type=file]').filestyle({
		iconName : '',
		buttonText : 'Browse',
	});
	var a = '<a href="#" class="btn btn-orange btn-lg remove_file" style="float:left;height:43px;">x</a>';
	$('#div_opg_sg_additional').find('.bootstrap-filestyle:last').prepend(a);
	$('#div_opg_sg_additional').fadeIn();
});
</script>