<style>
	.btn {
		border-radius: 0px;
		padding: 11.4px 12px;
		border: 1px solid #D5CEC8;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
</style>
<section class="first-section">
	<div class="container text-center">
		<div class="row">
			<h2 class="section-heading">MEMBERSHIP APPLICATION</h2>
		</div>
		
		<div class="row tml-contact id-organisation">
			<div class="col-md-3 text-left">
				Applying as
				<h5>Affiliate Members</h5>
				<h5>Organisation</h5>
			</div>
			<div class="col-md-6">
				<div class="col-md-3">
					<div class="bullets-orange"></div>
					<label class="orange">1. Organisation Details</label>
				</div>
				<div class="col-md-3">
					<div class="bullets-zero"></div>
					<label>2. Contact Details</label>
				</div>
				<div class="col-md-3">
					<div class="bullets-zero"></div>
					<label>3. Questions</label>
				</div>
				<div class="col-md-3">
					<div class="bullets-zero"></div>
					<label>4. Supporting Details</label>
				</div>
			</div>
		</div>
	</div>
</section>

<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading">1. ORGANISATION DETAIL</h3>	
	</div>
	<div class="container">
		<div class="row">
		<form action="#" method="post">
		<div class="col-md-offset-3 col-md-6 col-sm-12 col-xs-12">
			<div class="box-contact-form organisation">
				<div class="form-group">
					<label>Organisation's Name</label>
					<input type="text" class="form-control" name="name">
				</div>
				
				<div class="row ">
					<div class="col-md-1 col-xs-1" style="padding-right:0px; width:35px;">
						<input type="radio" name="ok" style="margin-top:-12px">
					</div>
					<div class="col-md-5 col-xs-5" style="padding-left:0px;">
						Parent Company
					</div>
					<div class="col-md-1 col-xs-1" style="padding-right:0px; width:35px;">
						<input type="radio" name="ok" style="margin-top:-12px">
					</div>
					<div class="col-md-5 col-xs-5" style="padding-left:0px;">
						Subsidiary Company
					</div>
				</div>
				
				<div class="form-group">
					<label>Address</label>
					<input type="text" class="form-control" name="name">
				</div>
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>ZIP/Post code</label>
							<input type="text" class="form-control" name="zip">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>City</label>
							<input type="text" class="form-control" name="city">
						</div>
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>State/Province</label>
							<input type="text" class="form-control" name="province">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Country</label><br/>
								<select class="selectpicker form-control" style="height:45px;">
									<option>country</option>
									<option>country 1</option>
                                    <option>country 2</option>
                                    <option>country 3</option>
                                    <option>country 4</option>
                                    <option>country 5</option>
                                    <option>country 6</option>
                                    <option>country 7</option>
                                    <option>country 8</option>
                                    <option>country 9</option>
								</select>
						</div>
					</div>
				</div>
				
				<div class="form-group">
					<label>Telephone</label>
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" name="code-telp">
						</div>
					    <input class="form-control" type="text">
					</div>
				</div>
				
				<div class="form-group">
					<label>Fax (Optional)</label>
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" name="code-telp">
						</div>
					    <input class="form-control" type="text">
					</div>
				</div>
				
				<div class="form-group">
					<label>Email</label>
					<input type="text" class="form-control" name="fullname">
				</div>
				
				<div class="form-group">
					<label>Website</label>
					<input type="text" class="form-control" name="web">
				</div>
				
				<div class="form-group">
					<label>Registration Number</label>
					<input type="text" class="form-control" name="reg-number">
				</div>
				
				<div class="form-group">
					<label>Organisation's Logo</label>
					<input type="file" id="logo" name="logo">
				</div>
				
				<div class="form-group">
					<label class="mb-0">Description</label>
					<textarea class="form-control" rows="5" name="reg-number2" placeholder="Please provide some background information on your organisation in less than 250 words" style="height:200px;"></textarea>
				</div>
				<div class="form-group text-right" style="margin-bottom:0px;">
					<input type="submit" value="SAVE" class="btn btn-lg btn-orange" style="border-radius:3px;">
					<input type="submit" value="NEXT" class="btn btn-lg btn-orange" style="border-radius:3px;">
				</div>
			</div>
		</div>
	</form>
	</div>
	</div>
</section>
<!--

<script type="text/javascript">
	$('#logo').filestyle({
		iconName : 'glyphicon-plus',
		buttonText : 'Browse',
	});
</script>
-->