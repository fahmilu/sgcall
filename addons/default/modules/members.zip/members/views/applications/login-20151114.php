<style>
	.btn {
		border-radius: 0px;
		padding: 11.4px 12px;
	}
	.box-contact-form label {
		color: #333;
		font-size: 14px;
		margin-bottom: 6px;
	}
</style>
<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
		<h3 class="subsection-heading">LOGIN</h3>	
	</div>
	<div class="container">
		<div class="row">
		<div class="col-lg-3 col-md-3 col-sm-3"></div>
		<?php echo form_open('members/login', 'id="activate-user"') ?>
		<div class="col-lg-6 col-md-6 col-sm-6">

<?php if(!empty($error_string)): ?>
<div class="alert alert-danger">
	<?php echo $error_string ?>
</div>
<?php endif;?>

			<div class="box-contact-form organisation">
				<div class="form-group" style="display: block;">
					<label>Email</label>
					<input type="text" class="form-control" name="email" placeholder="Your email" />
				</div>
				
				<div class="form-group"  style="display: block;">
					<label>Password</label>
					<input type="password" class="form-control" name="password" placeholder="Password" />
				</div>

				<div class="form-group text-right" style="margin-bottom:0px; display: block;">
					<input type="hidden" name="redirect_to" value="members/application" />
					<input type="submit" value="LOG IN" class="btn btn-lg btn-orange" style="border-radius:3px; margin-right:10px;">
					<a href="<?php echo site_url('members/forget'); ?>">Forgot your password?</a>
				</div>

			</div>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-3"></div>
		</form>
	</div>
</section>

