<div id="docs_sector_SCA" style="display:block;">
	<!-- required -->
	<ul style="padding-left:15px;">
		<li>
			Please attach proof of business registration (e.g. certificate of incorporation, certificate of good standing, article of incorporation or other similar documents).
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="sca_business_registration" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->sca_business_registration)): ?>
					<?php echo form_hidden('sca_business_registration', $membersapp->sca_business_registration); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->sca_business_registration))) ?>" target="_blank"><?php echo $membersapp->sca_business_registration; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('sca_business_registration') ? '<div class="alert alert-danger">'.form_error('sca_business_registration').'</div>' : ''; ?>
			</div>
		</li>
		<li>	
			Please attach a signed copy of the Supply Chain Associates Agreement – Click <a href="{{ url:site }}files/download/7e2a8028de2c885">here</a> to download.
			<i style="margin-top: 8px;display: block;">Maximum file size is 20MB</i>
			<div class="form-group">
				<input type="file" class="filestyle" name="sca_agreement" onchange="copyfname(this.value, $(this), 'all')">
				<input type="hidden" />
				<?php if (!empty($membersapp->sca_agreement)): ?>
					<?php echo form_hidden('sca_agreement', $membersapp->sca_agreement); ?>
					<div class="clear"></div>
					<label class="inline">Filename: </label> <a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($membersapp->sca_agreement))) ?>" target="_blank"><?php echo $membersapp->sca_agreement; ?></a>
				<?php endif; ?>
							
				<?php echo form_error('sca_agreement') ? '<div class="alert alert-danger">'.form_error('sca_agreement').'</div>' : ''; ?>
			</div>
		</li>
	</ul>
	<!-- end required -->
	
	<!-- SCA additional -->
	<ul style="padding-left:15px;">
		<li>Latest Annual Report or Shareholder documents (required document for subsidiary inclusion in Group Membership). </li>
	</ul>
	<div id="more_file_additionals">
		<input type="file" name="file_additionals[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), 'all')"  class="required filestyle">	
		<input data-validation-engine="validate[required]" type="hidden" name="file_additionals[]" value=""/>
		<?php echo form_error('div_sca_additional[]') ? '<div class="alert alert-danger">'.form_error('div_sca_additional[]').'</div>' : ''; ?>
	</div>
	<div id="div_sca_additional" class="multiple" style="display:none;"></div>
	<a href="#" id="add_sca_additional">Add more file</a><br />
	<i>Maximum file size is 20MB</i>
	
	<?php if (!empty($membersapp->file_additionals)): ?>
		<?php echo form_hidden('file_additionals', htmlspecialchars_decode($membersapp->file_additionals)); ?>
		<div class="form-group"><br />		
			<label>Current file(s)</label>
			<?php $upfiles_cert = explode(',', $membersapp->file_additionals); ?>
			<div class="table-responsive">
			<table class="table table-striped table-supplychain" style="border:1px solid #ddd;">
				<thead>
					<tr>
						<th style="width:10%;">Delete</th>
						<th>Filename</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach($upfiles_cert as $f): ?>
					<?php if ($f): ?>
					<tr>
						<td style="padding-left:28px; padding-top:0px; padding-bottom:0px;">
							<input type="checkbox" name="remove_uploaded_additionals[]" value="<?php echo $f; ?>" style="margin-top:6px;"/>
						</td>
						<td style="vertical-align:middle; padding-top:0px; padding-bottom:0px;"><a href="<?php echo site_url('members/preview-docs/'.urlencode(base64_encode($f))) ?>" target="_blank"><?php echo $f; ?></a></td>
					</tr>
					<?php endif; ?>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
			<p><i>Check the delete box and click save to delete your uploaded document(s)</i></p>
		</div>
		<div class="clearfix"></div>
	<?php else: ?>
		<div class="clearfix"><br /></div>
	<?php endif; ?>
	<!-- end additional -->
</div>

<script type="text/javascript">
$('a#add_sca_additional').click(function(e){
	e.preventDefault();
	//var h = $('#div_sca_additional').html();
	var h = '<input type="file" name="file_additionals[]" data-validation-engine="validate[funcCall[checkFile]]" onchange="copyfname(this.value, $(this), "all")"  class="required">'+
		'<input data-validation-engine="validate[required]" type="hidden" name="file_additionals[]" value=""/>';

	$('#div_sca_additional').append(h);
	$('#div_sca_additional input[type=file]').filestyle({
		iconName : '',
		buttonText : 'Browse',
	});
	var a = '<a href="#" class="btn btn-orange btn-lg remove_file" style="float:left;height:43px;">x</a>';
	$('#div_sca_additional').find('.bootstrap-filestyle:last').prepend(a);
	$('#div_sca_additional').fadeIn();
});
</script>