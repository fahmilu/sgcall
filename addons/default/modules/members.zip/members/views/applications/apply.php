<div class="container text-center margin-bottom-15" id="header-white">
	<h1>Membership Application</h1>
</div>
<div class="container-1080 member-map" style="overflow: unset;">
	<div class="row">
		<div class="col-lg-7 col-md-7 col-sm-12 none-padding">
			<div class="bordered-top">
				<label class="map-rev margin-top-26">Review the Requirements</label>
				<h2>Ordinary and Affiliate Membership</h2>
				<p>For applicants directly involved in the palm oil supply chain; representing a NGO; representing an organisation that is not directly involved in the palm oil supply chain; and individuals.</p>
			</div>
			<div class="bordered-all pad-20">
				<div class="panel-group" id="accordion">
				  <div class="panel panel-default">
				    <div class="panel-heading">
				      <h4 class="panel-title">
				        <a class="accordion-toggle">Membership Fees</a>
				      </h4>
				    </div>
				    <div id="collapse1" class="panel-collapse collapse in">
			      	<div class="clearfix"></div>
				      <div class="panel-body">
								<br/>
				      	<h2>Ordinary Member</h2>
								<ul>
									<li class="section">Oil Palm Growers
						      	<ul class="mainlist">
											<li>
												Growers (≥ 500 hectares) <span>&euro; 2,000 per year</span>
											</li>
						      		<li>Smallholder Group Manager
						      			<ul class="subonly">
													<li>> 1,900 hectares <span>&euro; 2,000 per year </span></li>
													<li>1,000 - 1,900 hectares <span>&euro; 1,000 per year </span></li>
													<li>< 1,000 hectares <span>&euro; 250 per year </span></li>
													<!--
													<li>&euro; 2,000 per year (More than 1,999 ha)</li>
						      				<li>&euro; 1,000 per year (1,000 to 1,999 ha)</li>
						      				<li>&euro; 250 per year (Less than 1,000 ha)</li>
													-->
						      			</ul>
						      		</li>
											<li>Small Growers (< 500 hectares) <span>&euro; 500 per year </span></li>
											<!--
											<li>Outgrower
						      			<ul class="sublist2">
						      				<li>&euro; 500 per year (500 ha and below)</li>
						      			</ul>
						      		</li>
											-->
						      	</ul>
									</li>
									<li class="section">Other sectors <span>&euro; 2,000 per year </span></li>
								</ul>
								<br/>
				      	<ul class="listnone">
				      		<li class="list-aff"><strong style="font-family:'Montserrat';color:#252525;">Affiliate</strong>
				      				<span>&euro; 250 per year</span>
				      		</li>
				      	</ul>
				      </div>
				    </div>
				    <div class="clearfix"></div>
				  </div>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-lg-5 no-pad-left no-pad-right pdf-download-area1">
				<a href="//www.rspo.org/files/download/c5483f5338f306b">
					<div class="bordered-all2 downloadable">
					<i class="pdf-download"></i><label class="pdf-title">RSPO Statutes</label></div>
				</a>
			</div>
			<div class="col-lg-7 no-pad-left no-pad-right pdf-download-area">
				<a href="//www.rspo.org/files/download/8a111694d249905">
					<div class="bordered-all2 downloadable-216"><i class="pdf-download"></i><label class="pdf-title">Code of Conduct</label></div>
				</a>
			</div>
			<div class="clearfix"></div>
			<br/>
			<div>
				<h2>Supply Chain Associates Membership</h2>
				<p>For applicants working with an organisation that has business activities along the palm oil supply chain but limited to purchasing, using, or trading no more than 500 metric tonnes of palm oil and palm oil products annually.</p>
			</div>
			<div class="bordered-all">
				<div class="panel-group" id="accordion">
				  <div class="panel panel-default">
				    <div class="panel-heading">
				      <h4 class="panel-title">
				        <a class="accordion-toggle">Membership Fees</a>
				      </h4>
				    </div>
				    <div id="collapse2" class="panel-collapse collapse in">
				      <div class="panel-body">
								<br/>
				      	<ul class="listnone">
				      		<li class="list-aff"><label><strong>Supply Chain Associates</strong></label>
				      			<span>&euro; 100 per year</span>
				      		</li>
				      	</ul>
				      </div>
				    </div>
				    <div class="clearfix"></div>
				  </div>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-lg-5 no-pad-left no-pad-right pdf-download-area1">
				<a href="//www.rspo.org/files/download/c5483f5338f306b">
					<div class="bordered-all2 downloadable">
					<i class="pdf-download"></i><label class="pdf-title">RSPO Statutes</label></div>
				</a>
			</div>
			<div class="col-lg-7 no-pad-left no-pad-right pdf-download-area">
				<a href="//www.rspo.org/files/download/c7536a5fd1d6739">
					<div class="bordered-all2 downloadable-280"><i class="pdf-download"></i><label class="pdf-title">Code of Conduct for SCA</label></div>
				</a>
			</div>
			<div class="clearfix"></div>
			<div class="pad-24-30 margin-top-30">
			</div>
<!--
			<div class="bg-light-gray pad-24-30 margin-top-30 margin-bottom-50">
				<h2 class="no-padding no-margin">What happens after submission</h2>
				<p class="margin-top-17 color-63">All membership applications go through a process whereby background research is
				undertaken. Submitted documents are reviewed; input is received from various
				stakeholders followed by a final approval from the RSPO Secretary General upon
				endorsement from the Board of Governors. Any appeals to applications declined will be
				handed by an Arbitration Board.</p>

				<p class="color-63">Membership of the RSPO includes a 2-year commitment consecutively with membership
				fees payable annually. Membership is renewable annually thereafter.</p>
			</div>
-->
		</div>
		<div class="col-lg-5 col-md-5 col-sm-12 no-pad-right margin-bottom-30 form-map">
			<div class="bg-yellow">
				<p>RSPO membership applicants need to register in the form below.
				If you have already registered, kindly <a href="/members/myrspo-login">login</a> to resume.
				</p>
				<img src="<?php echo base_url(); ?>addons/default/themes/r3p1_revamp/img/icon-info.png"/>
			</div>
			<div class="bordered-top-bot no-padding margin-top-30 margin-bottom-50">
				<div style="display:none;" id="regAlert"></div>
				<form id="memRegister" name="memRegister" method="post" action="{{url:site}}members/register" accept-charset="utf-8">
					<input autocomplete="off" type="text" name="email" placeholder="Enter your email" class="form-control map-input-text" id="reg_email" />
					<input autocomplete="off" type="text" class="form-control map-input-text" name="full_name" id="full_name" placeholder="Enter your name" />
					<input type="password" class="form-control map-input-text" name="password" id="password1" placeholder="Password" />
					<input type="password" class="form-control map-input-text" name="password2" id="password2" placeholder="Confirm Password" />

					<?php echo form_input('d0ntf1llth1s1n', ' ', 'class="default-form" style="display:none"') ?>

					<div class="clearfix"></div>
					<div class="col-lg-7 col-md-7 col-sm-9 col-xs-6 no-padding captcha1">
						<input name="captcha" value="" id="captcha" maxlength="5" type="text" class="form-control map-input-text-2" placeholder="Enter the letters you see">
					</div>
					<div class="col-lg-5 col-md-5 col-sm-3 col-xs-6 no-padding captcha2">
						<?php echo $captcha; ?>
                        <a href="#" id="new_captcha" data-num="<?php echo $captcha_time ?>"><i class="material-icons">refresh</i></a>
					</div>
					<div class="clearfix"></div>
					<div class="bordered-left-right-bot pad-left-30 pad-right-30 pad-bottom-30">
						<button id="btnSubmit" type="button" name="btnSubmit" onClick="read_applyNewMembers();" class="btn map-btn btn-black">SUBMIT</button>
						<div class="clearfix"></div>
					</div>
				</form>
			</div>
		</div>
		<!--
		<div class="questionMembers">
			<a class="maximize">
				<h2>Question?</h2>
			</a>
			<p>if you encountered issues,<br/>please send your question here</p>
			<a href="https://askrspo.force.com/memberships/s/contactsupport" class="btn btn-black" target="_blank">Send your question</a>
			<a class="minimize"></a>
		</div>
		-->
	</div>
</div>

<!-- popup RSPO Membership Rule, Code of conduct, Privacy policy -->
<div style="display:none;">
	<div id="applyNewMembers">
		<div class="contentapplyNewMembers">
			<ul>
				<li id="tNMmembershipRule" class="active">Membership Rule</li>
				<li id="tNMcodeofConduct" class="">Code of Conduct</li>
				<li id="tNMprivacyPolicy" class="">Privacy Policy</li>
			</ul>
			<div class="contentRight">
				<div id="NMmembershipRule" class="contentAgree mCustomScrollbar active">
					<div class="cNMmembershipRule">
						<div class="fileTodownload">
							<a href="//www.rspo.org/publications/download/638ae27c7f6b004">
								<label>English</label>
								<i>Save as PDF</i>
							</a>
						</div>
						<h2>Please read and accept the membership rules to understand your obligations, duties and responsibilities and accept future modifications.</h2>
						<h3>RSPO Membership Rules</h3>
						<p>All members must comply with the requirements as described in this document. Endorsed by the Board of Governors on 6 March 2017, in Kuala Lumpur, Malaysia </p>

						<?php $this->load->view('/applications/pdf-membership-rule.php'); ?>
					</div>
				</div>
				<div id="NMcodeofConduct" class="contentAgree mCustomScrollbar">
					<div class="cNMcodeofConduct">
						<div class="fileTodownload">
							<a href="//www.rspo.org/publications/download/cbb1628a5688f20">
								<label>English</label>
								<i>Save as PDF</i>
							</a>
						</div>
						<h2>Code of Conduct for Supply Chain Associates of The Roundtable on Sustainable Palm Oil</h2>
						<h3>It is fundamental to the integrity, credibility and continued  progress of the RSPO that every member supports, promotes and works towards the production, procurement and use of Sustainable Palm Oil.</h3>
						<p>All Supply Chain Associates must act in good faith towards this objective and commit to adhering to the principles set out in this Code.</p>
						<p>This Code applies to all Supply Chain Associates of the RSPO with respect to their activities in the palm oil sector and its derivatives.</p>

						<?php $this->load->view('/applications/pdf-code-of-conduct.php'); ?>
					</div>
				</div>
				<div id="NMprivacyPolicy" class="contentAgree mCustomScrollbar">
					<div class="cNMprivacyPolicy">
						<div class="fileTodownload">
							<a href="//www.rspo.org/uploads/default/files/ea2fe53574e48e9f986557b9c749f5bd.pdf">
								<label>English</label>
								<i>Save as PDF</i>
							</a>
						</div>
						<h2>PRIVACY POLICY</h2>

						<?php $this->load->view('/applications/pdf-privacy-policy.php'); ?>
					</div>
				</div>
			</div>
		</div>
		<div class="contentButtonAction">
			<div class="left">
				<a class="btn btn-f0f0f0" onclick="$.colorbox.close();return false;">CANCEL</a>
			</div>
			<div class="right">
				<a class="btn btn-f0f0f0 mar-r-15 goBack back_MembershipRule" style="display:none;">GO BACK</a>
				<a href="//rspo.catalyze.id/members/selecttype" class="agreeAndContinue btn btn-black goTo_CodeofConduct">AGREE &amp; CONTINUE</a>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
/* show or hide container question box */
$(function () {
	var $win = $(window);
	var $footerHeight = $('footer').height();

	$win.scroll(function () {
		var $pageHeight = $(document).height();
		var $positionScroll = $win.height() + $win.scrollTop();
		var $showQuestion = ($pageHeight - $footerHeight) + 100;

		var $showQuestion = ($pageHeight - $footerHeight) + 100;
		if ($positionScroll >= $showQuestion){
			$('.questionMembers').addClass('show');
		} else{
			$('.questionMembers').removeClass('show');

			/* reset css attr */
			$('.questionMembers').css({'height':'',});
			$('.questionMembers h2').css({'margin-top':'',});
			$('.questionMembers a.minimize').css({'display':'block',});
		}
	});
});
$(window).resize(function(){
	$(function () {
		var $win = $(window);
		var $footerHeight = $('footer').height();

		$win.scroll(function () {
			var $pageHeight = $(document).height();
			var $positionScroll = $win.height() + $win.scrollTop();

			var $showQuestion = ($pageHeight - $footerHeight) + 100;
			if ($positionScroll >= $showQuestion){
				$('.questionMembers').addClass('show');
			} else{
				$('.questionMembers').removeClass('show');

				/* reset css attr */
				$('.questionMembers').css({'height':'',});
				$('.questionMembers h2').css({'margin-top':'',});
				$('.questionMembers a.minimize').css({'display':'block',});
			}
		});
	});
});
$(document).on('click','.maximize',function(){
	$('.questionMembers').css({'height':'200px',});
	$('.questionMembers h2').css({'margin-top':'24px',});
	$('.questionMembers a.minimize').css({'display':'block',});
});
$(document).on('click','.minimize',function(){
	$('.questionMembers').css({'height':'52px',});
	$('.questionMembers h2').css({'margin-top':'13px',});
	$('.questionMembers a.minimize').css({'display':'none',});
});
/* end show or hide container question box */

/* popup RSPO Membership Rule, Code of conduct, Privacy policy */
var cboxOptions_applyNewMembers = {
	inline: true,
	href: '#applyNewMembers',
	fixed: true,
	width: "100%",
	height: "100%",
	maxWidth: "810px",
	maxHeight: "620px",
	close: false,
	onOpen: function(){
		$("#cboxClose").css("opacity", 0);
		$('#cboxOverlay').css({"background":"#000"});
	},
	onComplete: function(){
		$("#cboxClose").css({"opacity": 1});
		$('#cboxOverlay').css({"background":"#000"});
	},
	onClosed:function(){
		$("#cboxClose").css({"opacity": 0});
		$('#cboxOverlay').css({"background":"#000"});
	}
}

function ValidateEmail(mail)   {
	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))  {
		return (true);
	}
    alert("You have entered an invalid email address!")
    return false;
}
function read_applyNewMembers(){
	if (!$('#reg_email').val()){
		alert('Please enter your email address');
		$('#reg_email').focus();
		return false;
	}

	var $emailVal = $('#reg_email').val();
	var reMailCheck = /[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}/igm;
	if (!reMailCheck.test($emailVal)){
		alert('Please enter a valid email address.');
		return false;
	}

    var data_email = {email : $emailVal, captcha : $('#captcha').val()};
	var ajx_data = '';

    $.ajax({
        url: '/members/register_validation',
        data: data_email,
        dataType: 'json',
        method: 'post',
        async: false,
        success: function (data) {
            ajx_data = data;
        }
    });

    console.log(ajx_data);

    if(ajx_data.status == 'warning') {
        alert(ajx_data.message);
        $('#reg_email').focus();
    }

    if (ajx_data.status == 'error') {
        alert(ajx_data.message);
        $('#reg_email').focus();
        return false;
    }

	if (!$('#full_name').val())	{
		alert('Please enter your full name');
		$('#full_name').focus();
		return false;
	}

	if (!$('#password1').val()){
		alert('Please create a new password');
		$('#password1').focus();
		return false;
	}

	if (!$('#password2').val()){
		alert('Please reconfirm your new password');
		$('#password2').focus();
		return false;
	}

	if ($('#password2').val() != $('#password1').val()){
		alert('The password you entered do not match');
		$('#password1').focus();
		return false;
	}

	// recaptcha
	if ($('#captcha').val() == ''){
		alert('Please enter the characters you see in the Captcha image.');
		$('#captcha').focus();
		return false;
	}

	$.colorbox(cboxOptions_applyNewMembers);
}
$(window).resize(function(){
	$.colorbox.resize({
		width: window.innerWidth > parseInt(cboxOptions_applyNewMembers.maxWidth) ? cboxOptions_applyNewMembers.maxWidth : cboxOptions_applyNewMembers.width,
		height: window.innerHeight > parseInt(cboxOptions_applyNewMembers.maxHeight) ? cboxOptions_applyNewMembers.maxHeight : cboxOptions_applyNewMembers.height
	});
});
/* control next and prev the popup step */
// past, active
$(document).on('click','.goTo_CodeofConduct',function(e){
	e.preventDefault();
	$('.goBack').show();

	$('#tNMmembershipRule').removeClass('active').addClass('past');
	$('#NMmembershipRule').removeClass('active');

	$('#tNMcodeofConduct').addClass('active');
	$('#NMcodeofConduct').addClass('active');

	$('.agreeAndContinue').addClass('goTo_PrivacyPolicy');
	$('.agreeAndContinue').removeClass('goTo_CodeofConduct');
});
$(document).on('click','.back_MembershipRule',function(e){
	e.preventDefault();
	$('.goBack').hide();

	$('#tNMmembershipRule').removeClass('past').addClass('active');
	$('#NMmembershipRule').addClass('active');

	$('#tNMcodeofConduct').removeClass('active');
	$('#NMcodeofConduct').removeClass('active');

	$('.agreeAndContinue').removeClass('goTo_PrivacyPolicy');
	$('.agreeAndContinue').addClass('goTo_CodeofConduct');
});
$(document).on('click','.goTo_PrivacyPolicy',function(e){
	e.preventDefault();
	$('.goBack').show();

	$('#tNMcodeofConduct').removeClass('active').addClass('past');
	$('#NMcodeofConduct').removeClass('active');

	$('.goBack').addClass('back_CodeofConduct');
	$('.goBack').removeClass('back_MembershipRule');

	$('#tNMprivacyPolicy').addClass('active');
	$('#NMprivacyPolicy').addClass('active');

	$('.agreeAndContinue').addClass('submitMAP');
	$('.agreeAndContinue').removeClass('goTo_PrivacyPolicy');
});
$(document).on('click','.back_CodeofConduct',function(e){
	e.preventDefault();
	$('.goBack').show();

	$('#tNMcodeofConduct').removeClass('past').addClass('active');
	$('#NMcodeofConduct').addClass('active');

	$('.goBack').removeClass('back_CodeofConduct');
	$('.goBack').addClass('back_MembershipRule');

	$('#tNMprivacyPolicy').removeClass('active');
	$('#NMprivacyPolicy').removeClass('active');

	$('.agreeAndContinue').removeClass('submitMAP');
	$('.agreeAndContinue').addClass('goTo_PrivacyPolicy');
});
</script>
<script>
$(function(){
    $('#new_captcha').button({
        text: false,
        icons: {
            primary: 'ui-icon-refresh'
        }
    }).click(function(event){
        event.preventDefault();

        var post_data = {num: $(this).attr('data-num')};
        $.ajax({
            url: "<?php echo site_url('members/refresh_captcha'); ?>",
            method: "POST",
            data: post_data,
            type: "json",
            success: function(obj){
                var data = JSON.parse(obj);
                $('.map-captcha').attr('src', '<?php echo site_url() ?>'+data.image);
                $('#new_captcha').attr('data-num', data.num);
            }
        });
    });
});

/* function submit on popup */
$(document).on('click','.submitMAP',function(e){
	// if(document.memRegister.onsubmit()){
		e.preventDefault();
		var data = $('form#memRegister').serialize();

		console.log(data);

		$.ajax({
			beforeSend: function(){
				// $('#btnSubmit').text('Please wait...');
				// $('#btnSubmit').attr('disabled', true);
				$('.submitMAP').text('Please wait...');
			},
			url: '/members/register',
			data: data,
			dataType: 'json',
			method: 'post'
		}).error(function(){
			// $('#btnSubmit').text('Submit');
			// $('#btnSubmit').attr('disabled', false);
			$('.submitMAP').text('AGREE & CONTINUE');
		}).done(function(html){

			// $('#btnSubmit').text('Submit...');
			// $('#btnSubmit').attr('disabled', false);
			$('.submitMAP').text('AGREE & CONTINUE');

			if (html.status=='error'){
				$.colorbox.close(); //close popup

				$('#regAlert').html('<div class="alert alert-danger alert-dimissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
				$('html, body').animate({
					scrollTop: ($("#regAlert").offset().top * 1) - 50
				}, 300, function(){
					$('#regAlert').fadeIn();
				});
			} else if (html.status=='ok'){
				//Recaptcha.reload();
				$('#regAlert').html('<div class="alert alert-success alert-dimissible" role="alert"  style="margin-top:30px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
				$('html, body').animate({
					scrollTop: ($("#regAlert").offset().top * 1) - 50
				}, 300, function(){
					$('#regAlert').fadeIn(function(){
						$('form#memRegister')[0].reset();
						// $('#btnSubmit').attr('disabled', true);
						gaProcess('members/apply', 'Register', 'User Registrations');
					});
				});

				$.colorbox.close(); //close popup
			}
		});
	// }
});
</script>
