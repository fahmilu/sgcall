<!-- Full Page Image Background Carousel Header -->
    <div class="row">
        <div class="container text-center" id="header-white">
            <h1>MEMBERSHIP APPLICATION</h1>
        </div>    
    </div>
	
	<style>
		.btn {
			display: inline-block;
			padding: 6px 12px;
			margin-bottom: 0px;
			font-size: 14px;
			font-weight: 400;
			line-height: 1.42857;
			text-align: center;
			white-space: nowrap;
			vertical-align: middle;
			cursor: pointer;
			-moz-user-select: none;
			background-image: none;
			border-radius: 3px;
		}
	</style>
	<!-- dual image Section -->
    <section id="registration-step" style="padding-top:0px;">
        <div class="container text-center">
            <div class="row">
			<div style="max-width:800px; width:800px; margin:0 auto;">
				<h2 class="title-on-top" style="font-size:16px; padding-bottom:30px; line-height:1.75;">Thank you for applying for RSPO membership. First, please select your membership type below before you click on APPLY to proceed to the next step. If you have any questions, please <a href="mailto:membership@rspo.org">email us</a>.</h2>
			</div>
			<div style="width:1000px; max-width:1000px; margin:0 auto;">
                <div class="col-lg-4 area-step text-left " >
                    <div class="row">
                    <div class="container-step" style="padding-top:20px; margin-top:0px; margin-bottom:0px; margin-right:0px; margin-left:0px; background-color:#f5f5f5; border: 4px solid #f5f5f5; min-height:300px;">
						
						<div style="height:290px; min-height:290px;">
							<div style="height:108px; min-height:108px;">
								<h3 class="title-on-top" style="text-align:center; font-size:46px; letter-spacing:1px;">ORDINARY</h3>
								<h5 class="title-on-top" style="text-align:center; color:gray; letter-spacing: 2px;">MEMBERSHIP</h5>
							</div>	
								<p style="">My organisation is directly involved within the palm oil supply chain, or is an associated NGO.</p>
						</div>
						
						<br/>
						
						<div class="form-group">
							<select class="selectpicker form-control" style="height:45px;">
								<option>Choose your category</option>
								<option value="Bank and Investors"> Bank and Investors</option>
							</select>
						</div>
						
						<br/>
						
						<div class="form-group">
                            <button type="submit" class="btn btn-primary" style="width:100%; font-size:16px; font-weight:600; letter-spacing:1px;">APPLY</button>
						</div>
						
					</div>
					</div>
                </div>
                
                <div class="col-lg-4  area-step text-left ">
                    <div class="row">
                    <div class="container-step " style="padding-top:20px; margin-top:0px; margin-bottom:0px;  margin-right:1px;  margin-left:1px;background-color:#f5f5f5; border: 4px solid #f5f5f5; min-height:300px;">
						<div style="height:290px; min-height:290px;">
							<div style="height:108px; min-height:108px;">
								<h3 class="title-on-top" style="text-align:center; font-size:46px; letter-spacing:1px;">AFFILIATE</h3>
								<h5 class="title-on-top" style="text-align:center; color:gray; letter-spacing: 2px;">MEMBERSHIP</h5>
							</div>
								<p>I work with an organisation (or I am an individual) that is not directly involved in the palm oil supply chain in any of the 7 categories in the Ordinary Membership above.</p>
						</div>
						
						<br/>
						
						<div class="form-group">
							<select class="selectpicker form-control" style="height:45px;">
								<option>Choose your category</option>
								<option value="Organisation"> Organisation</option>
								<option value="Individual"> Individual</option>
							</select>
						</div>
						
						<br/>
						
						<div class="form-group">
                            <button type="submit" class="btn btn-primary" style="width:100%; font-size:16px; font-weight:600; letter-spacing:1px;">APPLY</button>
						</div>
						
					</div>
					</div>
                </div> 
				
				<div class="col-lg-4 area-step text-left ">
                    <div class="row">
                    <div class="container-step" style="padding-top:20px; margin-top:0px; margin-bottom:0px; background-color:#f5f5f5; border: 4px solid #f5f5f5; margin-right:0px; margin-left:0px; min-height:300px;">
						<div style="height:290px; min-height:290px;">
							<div style="height:108px; min-height:108px;">
								<h3 class="title-on-top" style="text-align:center; font-size:23; letter-spacing:2px; font-weight:600;">SUPPLY CHAIN ASSOCIATE</h3>
								<h5 class="title-on-top" style="text-align:center; color:gray; letter-spacing: 2px;">MEMBERSHIP</h5>
							</div>
								<p>I work with an organisation that has business activities along the palm oil supply chain but limited to purchasing, using, or trading not more than 500 metric tonnes of palm oil and palm oil products annually.</p>
						</div>
						
						<br/>
						
						<div class="form-group">
							<select class="selectpicker form-control" style="height:45px;">
								<option>Choose your category</option>
								<option value="Organisation"> Organisation</option>
								<option value="Supply Chain Group Manager"> Supply Chain Group Manager</option>
							</select>
						</div>
						
						<br/>
						
						<div class="form-group">
                            <button type="submit" class="btn btn-primary" style="width:100%; font-size:16px; font-weight:600; letter-spacing:1px;">APPLY</button>
						</div>
						
					</div>
					</div>
                </div>
            </div>
            </div>
        </div>
    </section>