    <div class="row">
        <div class="container text-center" id="header-white" style="padding-bottom:13px;">
            <h1>MEMBERSHIP APPLICATION</h1>
        </div>    
    </div>
	<style>
	.btn {
		display: inline-block;
		margin-bottom: 0px;
		font-size: 14px;
		padding:10px 20px;
		font-weight: 600;
		line-height: 1.42857;
		text-align: center;
		white-space: nowrap;
		vertical-align: middle;
		cursor: pointer;
		-moz-user-select: none;
		background: #ED7B1C;
		border: 1px solid transparent;
		border-radius: 0px;
		color:#FFF;
		text-transform: none;
	}
	#inside form .dropdown-menu{ max-height: 300px !important; }
	#inside .dropdown-menu, 
	#front .dropdown-menu {
		margin-top: none;
	}
	.dropdown-menu {
		position: absolute;
		top: 100%;
		left: 0px;
		z-index: 1000;
		display: none;
		float: left;
		min-width: 160px;
		/* padding: 0px; */
		margin: 2px 0px 0px;
		font-size: 14px;
		text-align: left;
		list-style: none outside none;
		background-color: #FFF;
		background-clip: padding-box;
		border: 1px solid rgba(0, 0, 0, 0.15);
		border-radius: 0px;
		box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.176);
	}
	.dropdown-menu > li > a {
		display: block;
		padding: 10px 20px;
		clear: both;
		font-weight: 400;
		line-height: 1.42857;
		font-weight: 600;
		color: #333;
		white-space: nowrap;
	}
	.bootstrap-select.btn-group .dropdown-menu {
		min-width: 100%;
		z-index: 1035;
		box-sizing: border-box;
		border:none;
		margin-top: 8px;
	}
	.btn-group.open .dropdown-toggle {
		box-shadow: none;
	}
	.btn-default:hover, 
	.btn-default:focus, 
	.btn-default:active, 
	.btn-default.active, 
	.open > .dropdown-toggle.btn-default {
		color: #fff;
		border-color: transparent;
	}
	.bootstrap-select.btn-group .dropdown-menu.inner {
		position: static;
		border: none;
		padding: 0px;
		margin: 0px;
		border-radius: 0px;
		box-shadow: none;
	}
	.form-group {
		margin-bottom: 0px;
	}
	#colorbox{ // background:#fff; }
	#colorbox p,
	#colorbox ol{
		text-align:left;
	}
	.memSelect .bootstrap-select.btn-group .dropdown-menu{
		min-width: 300px;
	}
	</style>
	<!-- dual image Section -->
    <section id="registration-step" class="no-pad-top">
        <div class="container text-center">
            <div class="row">
			<div class="contain800">
				<h2 class="title-on-top" style="font-size:16px; padding-bottom:22px; line-height:1.75; margin-bottom:0px;">Thank you for applying for RSPO membership. First, please select your membership category below before you click on APPLY to proceed to the next step. If you have any questions, please <a href="mailto:membership@rspo.org">email us</a>.</h2>
			</div>
			<div class="contain900">
                <div class="col-lg-4 area-step text-left " >
                    <div class="row">
                    <div class="container-step contain-MAP-1">
						<div class="contain-MAP-inner-1">
							<div class="contain-MAP-inner2-1">
								<h3 class="title-on-top" style="text-align:center; font-size:36px; letter-spacing:1px;font-weight:500;">ORDINARY</h3>
								<h5 class="title-on-top" style="text-align:center; color:gray; letter-spacing: 2px;font-size:12px">MEMBERSHIP</h5>
							</div>	
							<p style="">My organisation is <b>directly involved within the palm oil supply chain</b>, or is an associated NGO.</p>
						</div>
						
						<br/>

						<form method="post" name="memOrdinary" action="<?php echo site_url('members/application'); ?>" id="memOrdinary" class="memSelect">
							<div class="form-group">
								{{dropdowns:categories category="ordinary_member" title="Sector" class="selectpicker form-control"}}
							</div>
							
							<br/>
							
							<div class="form-group">
								<input type="hidden" name="type" value="Ordinary" />
								<button type="submit" name="btnOrdinary" class="btn btn-primary" style="width:100%; font-size:16px; font-weight:600; letter-spacing:1px; border-radius: 3px;">APPLY</button>
							</div>
						</form>
					</div>
					</div>
                </div>
                
                <div class="col-lg-4 area-step text-left ">
                    <div class="row">
                    <div class="container-step contain-MAP-2">
						<div class="contain-MAP-inner-2">
							<div class="contain-MAP-inner2-2">
								<h3 class="title-on-top" style="text-align:center; font-size:36px; letter-spacing:1px;font-weight:500;">AFFILIATE</h3>
								<h5 class="title-on-top" style="text-align:center; color:gray; letter-spacing: 2px;font-size:12px">MEMBERSHIP</h5>
							</div>
							<p>I work with an organisation (or I am an individual) <b>that is <span style="font-size:16px;">NOT</span> directly involved in the palm oil supply chain</b>.</p>
						</div>
						
						<br/>
						
						<form method="post" name="memAffiliate" action="<?php echo site_url('members/application'); ?>" id="memAffiliate" class="memSelect">
							<div class="form-group">
								{{dropdowns:categories category="affiliate" title="Sector" class="selectpicker form-control"}}
							</div>
							
							<br/>
							
							<div class="form-group">
								<input type="hidden" name="type" value="Affiliate" />
								<button type="submit" name="btnAffiliate" class="btn btn-primary" style="width:100%; font-size:16px; font-weight:600; letter-spacing:1px; border-radius: 3px;">APPLY</button>
							</div>
						</form>
					</div>
					</div>
                </div> 
				
				<div class="col-lg-4 area-step text-left ">
                    <div class="row">
                    <div class="container-step contain-MAP-3">
						<div class="contain-MAP-inner-3">
							<div class="contain-MAP-inner2-3">
								<h3 class="title-on-top" style="text-align:center; font-size:36px; letter-spacing:1px;font-weight:500;">ASSOCIATE</h3>
								<h5 class="title-on-top" style="text-align:center; color:gray; letter-spacing: 2px;font-size:12px">MEMBERSHIP</h5>
							</div>
							<p>I work with an organisation that has business activities along the palm oil supply chain but limited to <b>purchasing, using, or trading not more than 500 metric tonnes of palm oil and palm oil products annually</b>.</p>
						</div>
						
						<br/>

						<form method="post" name="memSCA" action="<?php echo site_url('members/application'); ?>" id="memSCA" class="memSelect">
							<div class="form-group">
								{{dropdowns:categories category="supply_chain" title="Sector" class="selectpicker form-control"}}
							</div>
							
							<br/>
							
							<div class="form-group">
								<input type="hidden" name="type" value="Associate" />
								<button type="submit" name="btnSCA" class="btn btn-primary" style="width:100%; font-size:16px; font-weight:600; letter-spacing:1px; border-radius: 3px;">APPLY</button>
							</div>
						</form>
					</div>
					</div>
                </div>
            </div>
            </div>
        </div>
    </section>

<!-- popup RSPO Membership Rule -->
<div style="display:none;">
	<div id="mapp-announcement">
		<h2>RSPO Membership Rule</h2>
		<p></p>
		<p>I have read and understood my obligations, duties and responsibilities under the RSPO’s <a href="//www.rspo.org/publications/download/638ae27c7f6b004">Membership Rule</a> and will accept future modifications of the rule by RSPO without any informed notifications.</p>

		<p>&nbsp;</p>
		<a class="btn btn-lg btn-orange fullWidth" onclick="$.colorbox.close();return false;">OK</a>
	</div>
</div>
	
<script type="text/javascript">
$(document).ready(function(){
	$('form.memSelect').on('submit', function(e){
		//e.preventDefault();
		var i = $(this).attr('id');
		var u = $(this).attr('action');
		var v = $('select', this).val();
		if (!v)
		{
			alert('Please select the category first.');
			return false;
		}
		return true;
		//$(this).submit()
	});

	var cboxOptions_selecttype = {
		inline: true,
		href: '#mapp-announcement',
		fixed: true,
		width: "100%",
		height: "100%",
		maxWidth: "520px",
		maxHeight: "300px",
		close: false,
		onOpen: function(){
			$("#cboxClose").css("opacity", 0);
			$('#cboxOverlay').css({"background":"#000"});
		},
		onComplete: function(){
			$("#cboxClose").css({"opacity": 1});
			$('#cboxOverlay').css({"background":"#000"});
		},
		onClosed:function(){
			$("#cboxClose").css({"opacity": 0});
			$('#cboxOverlay').css({"background":"#000"});
		}
	}	
	$.colorbox(cboxOptions_selecttype);
	/* when resize */
	$(window).resize(function(){
		$.colorbox.resize({
			width: window.innerWidth > parseInt(cboxOptions_selecttype.maxWidth) ? cboxOptions_selecttype.maxWidth : cboxOptions_selecttype.width,
			height: window.innerHeight > parseInt(cboxOptions_selecttype.maxHeight) ? cboxOptions_selecttype.maxHeight : cboxOptions_selecttype.height
		});
	});
});
</script>
<script type="text/javascript">
	function desc_sectors() {
		$('span.text').each(function(){
			var cek_sector = $(this).text(); //cek value sector
			cek_sector = cek_sector.replace(/ /g, "");
				
			if(cek_sector == 'BanksandInvestors'){
				$(this).after('<span class="desc_sector"><?php echo $BI;?></span>');
			}
					
			if(cek_sector == 'ConsumerGoodsManufacturers'){
				$(this).after('<span class="desc_sector"><?php echo $CGM;?></span>');
			}
					
			if(cek_sector == 'EnvironmentalorNatureConservationOrganisations(NonGovernmentalOrganisation)'){
				$(this).after('<span class="desc_sector"><?php echo $ENGO;?></span>');
			}
					
			if(cek_sector == 'OilPalmGrowers'){
				$(this).after('<span class="desc_sector"><?php echo $OPG;?></span>');
			}
					
			if(cek_sector == 'Growers'){
				$(this).after('<span class="desc_sector"><?php echo $OPG;?></span>');
			}
					
			if(cek_sector == 'PalmOilProcessorsand/orTraders'){
				$(this).after('<span class="desc_sector"><?php echo $PNT;?></span>');
			}
				
			if(cek_sector == 'Processorand/orTrader'){
				$(this).after('<span class="desc_sector"><?php echo $PNT;?></span>');
			}
					
			if(cek_sector == 'Retailers'){
				$(this).after('<span class="desc_sector"><?php echo $Retailers;?></span>');
			}
					
			if(cek_sector == 'SocialorDevelopmentOrganisations(NonGovernmentalOrganisation)'){
				$(this).after('<span class="desc_sector"><?php echo $SNGO;?></span>');
			}
					
			if(cek_sector == 'Associations'){
				$(this).after('<span class="desc_sector"><?php echo $Associations;?></span>');
			}
					
			if(cek_sector == 'Individuals'){
				$(this).after('<span class="desc_sector"><?php echo $Individuals;?></span>');
			}
					
			if(cek_sector == 'Organisations'){
				$(this).after('<span class="desc_sector"><?php echo $Organisations;?></span>');
			}
					
			if(cek_sector == 'SupplyChainAssociate'){
				$(this).after('<span class="desc_sector"><?php echo $SCA;?></span>');
			}
					
			if(cek_sector == 'SupplyChainGroupManager'){
				$(this).after('<span class="desc_sector"><?php echo $SCGM;?></span>');
			}
		}); 
	} 

$(document).ready(function(){
	desc_sectors();
});
</script>