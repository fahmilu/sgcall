<!-- Full Page Image Background Carousel Header -->
<div class="container">
	<div class="container text-center" id="header-white">
		<h1>MEMBERSHIP APPLICATION</h1>
	</div>
</div>

<!--
<section id="related">
<div class="container">
<div class="row text-center" style="height:300px;">
<p>Sorry, the online membership application is currently being upgraded. <br/><br/>Please <a href="mailto:membership@rspo.org">email us</a> or check back again soon.</p>
</div>
</div>
</section>
-->

<!-- <div hidden=""> -->
<style>
	.requirement-list li a{
		font-size:14px;
	}
	.requirement-list li{
		font-size:14px;
	}
	.alert-success {
		color: #3C763D;
		border-radius: 3px;
		font-size: 14px;
		width: 300px;
		text-align: center;
		margin: 0px auto 23px;
		border: 1px solid transparent;
	}
	.alert-warning{
		border-color: tranparent;
		border-radius: 3px;
		font-size: 14px;
		width: 300px;
		text-align:center;
		margin: 0 auto;
	}
	.alert-danger{
		color: red;
		width: 300px;
		border-color: tranparent;
		border-radius: 0px 0px 3px 3px;
		font-size: 14px;
		margin: 0 auto;
	}
</style>
<!-- dual image Section -->
<section id="registration-step" class="bg-light-gray">
	<div class="container text-center">
		<div class="row">
			<!-- <h2 class="title-on-top" style="font-size:20px;">To become a RSPO member please follow these steps</h2> -->
			<div class="col-lg-4 area-step text-left" >
				<div class="row">
					<div class="absolute-title" id="title-a">
						<span class="alpha">A</span><span>WHY APPLY</span>
					</div>
					<div class="container-step" style="min-height:610px;">
						<p style="padding-bottom:5px;">As a RSPO member, you can contribute constructively towards promoting the growth and use of sustainable palm oil to protect people, planet and profit. <a href="#" id="showwhyapply" style="font-size:14px;">Continue reading...</a></p>
						<div class="whyapply" style="display:none;">
							<ul class="requirement-list">
								<li>First step to show commitment towards embracing sustainable palm oil</li>
								<li>RSPO is recognized globally as a certification standard for sustainable palm oil</li>
								<li>For growers, certification of mills and supply base according to the RSPO Principles & Criteria demonstrates to customers that you are a responsible producer</li>
								<li>Active participation along the palm oil supply chain of RSPO's membership categories</li>
								<li>International market access</li>
								<li>Create and influence RSPO policies and key decisions</li>
								<li>Access to agricultural; environmental and social best practices</li>
								<li>Increased efficiency, productivity and profitability with sustainable palm oil practices</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 area-step text-left">
				<div class="row">
					<div class="absolute-title" id="title-b">
						<span class="alpha">B</span><span>REVIEW THE REQUIREMENTS</span>
					</div>
					<div class="container-step" style="min-height:610px;">
						<strong>Ordinary and Affiliate membership</strong><br/>
						<p style="line-height:1.5; font-size:14px; padding-bottom:5px;">My organisation is directly involved within the palm oil supply chain, or is an associated NGO, or I work with an organisation (or I am an individual) that is not directly involved in the palm oil supply chain.</p>
						<ul class="requirement-list">
							<li><a href="{{ url:site }}publications/download/c9713097c32580a">RSPO By-laws</a></li>
							<li>
								<a href="{{ url:site }}publications/download/27ab1cc4d14bef3">RSPO Code of Conduct: English<a/> | 
								<a href="{{ url:site }}publications/download/e04803ea0e25e35">Dutch</a> | 
								<a href="{{ url:site }}publications/download/71d6c0bd0e9caa3">French</a> | 
								<a href="{{ url:site }}publications/download/09d3de0492ada14">Spanish</a>
							</li>
							<li><a href="#" id="show_ordinary_affiliate_membership">Membership fees </a></li>
						</ul>
						<div class="ordinary_affiliate_membership" style="display:none; padding-left:15px;">
							<ul class="requirement-list">
								<li>&euro; 2,000 per year</li>
							</ul>
							<strong>Smallholder Group Manager</strong>
							<ul class="requirement-list">
								<li>&euro; 2,000 per year (More than 1,999 ha)</li>
								<li>&euro; 1,000 per year (1,000 to 1,999 ha)</li>
								<li>&euro; 250 per year (Less than 1,000 ha)</li>
							</ul>
							<strong>Outgrower</strong>
							<ul class="requirement-list">
								<li>&euro; 500 per year (500 ha and below)</li>
							</ul>
							<strong>Affiliate member</strong>
							<ul class="requirement-list">
								<li>&euro; 250 per year</li>
							</ul>
						</div>
						<hr style="margin-top:20px;">
						<strong>Supply Chain Associates membership</strong><br/>
						<p style="line-height:1.5; font-size:14px; padding-bottom:5px;">I work with an organisation that has business activities along the palm oil supply chain but limited to purchasing, using, or trading not more than 500 metric tonnes of palm oil and palm oil products annually.</p>
						<ul class="requirement-list">
							<li><a href="{{ url:site }}publications/download/c9713097c32580a">RSPO By-laws</a></li>
							<li><a href="{{ url:site }}publications/download/cbb1628a5688f20">RSPO Code of Conduct</a></li>
							<li><a href="#" id="show_suppy_chain_associate_membership">Membership fees</a></li>
						</ul>
						<div class="suppy_chain_associate_membership" style="display:none; padding-left:15px;">
							<ul class="requirement-list" style="">
								<li>&euro; 100 per year</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4  area-step text-left">
				<div class="row">
					<div class="absolute-title" id="title-a">
						<span class="alpha">C</span><span>REGISTER NOW</span>
					</div>
					<div class="container-step" style="min-height:610px;">
						<div style="display:none;" id="regAlert"></div>
						<div class="row step0 login-area" id="uregister">
							<form method="post" name="memRegister" id="memRegister" action="{{url:site}}members/register" accept-charset="utf-8">
								<div class="col-sm-12">
									<label>Email</label>
									<input type="text" name="email" placeholder="email@domain.com" class="form-control input-sm height43" id="reg_email" />
								</div>
								<br/>
								<div class="col-sm-12">
									<label>Name</label>
									<input type="text" placeholder="Full Name" class="form-control input-sm height43" name="full_name" id="full_name" />
								</div>
								<br/>
								<div class="col-sm-12">
									<label>Password</label>
									<input type="password" placeholder="Enter new password" class="form-control input-sm height43" name="password" id="password1" />
								</div>
								<br/>
								<div class="col-sm-12">
									<label>Reconfirm password</label>
									<input type="password" placeholder="Reconfirm password" class="form-control input-sm height43" name="password2" id="password2" />
								</div>
								<div class="col-sm-12">
									<div class="form-group">
										<div class="row">
											<div class="col-md-12" style="top:0">
												<label class="inline" style="font-size:13px; font-weight:normal;"><input type="checkbox" name="agree_cod" class="shouldcheck" id="agree_cod" value="1">
												I have read and understood my obligations, duties and responsibilities under the RSPO's  <a href="{{url:site}}publications/download/cbb1628a5688f20">Code of Conduct</a> and will accept future modifications.</label>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-12" style="top:0">
												<label class="inline" style="font-size:13px; font-weight:normal;"><input type="checkbox" name="agree_pp" class="shouldcheck" id="agree_pp" value="2"> I agree with the RSPO's <a href="{{ url:site }}files/download/49e1013ec4b2002">Privacy Policy</a></label>
											</div>
										</div>
									</div>
								</div>
								<div class="col-sm-12">
									<?php echo form_input('d0ntf1llth1s1n', ' ', 'class="default-form" style="display:none"') ?>
									<button type="submit" disabled="disabled" class="btn btn-primary" id="btnSubmit" name="btnSubmit">SUBMIT</button>
								</div>
							</form>
							<div class="col-sm-12" >
								<div style="font-size:13px; border-top:1px solid #ededed; margin-top:15px; padding-top:15px;">
									Already started your application? Log in to resume.<br/><br/>
									<button type="botton" class="btn btn-primary registershow2" rel="ulogin">LOG IN</button>
									<span style="text-align: right;"><a href="#" class="registershow3" rel="uforget">Forgot your password?</a></span>
								</div>
							</div>
						</div>
						<div class="row step0 registerarea" style="display: none;" id="ulogin">
							<div class="col-sm-12">
								<strong>LOGIN HERE TO RESUME</strong>
							</div>
							<div style="display:none;" id="loginAlert"></div>
							<br/><br/>
							<form method="post" name="memLogin" id="memLogin" action="{{url:site}}members/login" accept-charset="utf-8">
								<div class="col-sm-12">
									<label>Email</label>
									<input type="text" placeholder="Email address" onclick="return false;" name="email" id="loginEmail" class="form-control input-sm height43"/>
								</div>
								<br/>
								<div class="col-sm-12">
									<label>Password</label>
									<input type="password" placeholder="Password" class="form-control input-sm height43" name="password" id="loginPass" />
								</div>
								<div class="col-sm-12">
									<button type="submit" class="btn btn-primary" id="btnLogin">LOG IN</button>
									<span style="text-align: right;"><a href="#" class="registershow3" rel="uforget">Forgot your password?</a></span>
									<br/>
									<br/>
									<a href="#" class="registershow" style="color:#999999" rel="uregister">&laquo; back</a>
								</div>
							</form>
						</div>
						<div class="row step0 forgetarea" style="display: none;" id="uforget">
							<div class="col-sm-12">
								<p><strong>FORGET YOUR PASSWORD?</strong><br />
								Having issues to access your membership application? No problem -- you'll just have to create a new password. Please enter the email address you used to start your application, and we will send you a verification email</p>
								<div class="clearfix"></div>
							</div>
							<br/><br/>
							<div style="display:none;" id="forgetAlert"></div>
							<form method="post" name="memForget" id="memForget" action="{{url:site}}members/forget" accept-charset="utf-8">
								<div class="col-sm-12">
									<label>Email</label>
									<input type="text" placeholder="Email address" name="email" id="emailForget" class="form-control input-sm height43"/>
								</div>
								<div class="col-sm-12">
									<button type="submit" class="btn btn-primary" id="btnForget">SUBMIT</button>
									<br/>
									<br/>
									<a href="#" class="registershow" style="color:#999999" rel="uregister">&laquo; back</a>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container text-center">
		<div class="row" style="max-width:800px; width:800px; margin:0 auto;">
			<h2 class="section-heading">WHAT HAPPENS AFTER SUBMISSION</h2>
			<p class="whoweareabout" style="line-height:1.75">All membership applications go through a process whereby background research is undertaken. Submitted documents are reviewed; input is received from various stakeholders followed by a final approval from the RSPO Secretary General upon endorsement from the Board of Governors. Any appeals to applications declined will be handed by an Arbitration Board.</p>
			<p>Membership of the RSPO includes a 2-year commitment consecutively with membership fees payable annually. Membership is renewable annually thereafter.</p>
		</div>
	</div>
</section>
<script>
	$(document).ready(function(){
			  
		$('#showwhyapply').click(function(e){
			e.preventDefault();
			$('.whyapply').slideToggle();
		});
	
		$('#show_what_happen_after_submission').click(function(e){
			e.preventDefault();
			$('.what_happen_after_submission').slideToggle();
		});
	
		$('#show_ordinary_affiliate_membership').click(function(e){
			e.preventDefault();
			$('.ordinary_affiliate_membership').slideToggle();
		});
						
		$('#show_suppy_chain_associate_membership').click(function(e){
			e.preventDefault();
			$('.suppy_chain_associate_membership').slideToggle();
		});
	
		$('.registershow,.registershow2,.registershow3').click(function(e){
			e.preventDefault();
			var d = $(this).attr('rel');
			$('.step0').slideUp(function(){
			});
				$('#'+d).fadeIn();
		});
	
		$('#agree_cod, #agree_pp').on('click', function(){
			if ($('#agree_pp').is(':checked') && $('#agree_cod').is(':checked'))
			{
				$('#btnSubmit').attr('disabled', false);
			}
			else
			{
				$('#btnSubmit').attr('disabled', true);
			}
		});
	
	
		$('form#memRegister').on('submit', function(e){
			e.preventDefault();
	
			if (!$('#reg_email').val())
			{
				alert('Please enter your email address');
				$('#reg_email').focus();
				return false;
			}
	
			if (!$('#full_name').val())
			{
				alert('Please enter your full name');
				$('#full_name').focus();
				return false;
			}
	
			if (!$('#password1').val())
			{
				alert('Please create a new password');
				$('#password1').focus();
				return false;
			}
	
			if (!$('#password2').val())
			{
				alert('Please reconfirm your new password');
				$('#password2').focus();
				return false;
			}
	
			if ($('#password2').val() != $('#password1').val())
			{
				alert('The password you entered do not match');
				$('#password1').focus();
				return false;
			}
	
			if (!$('#agree_cod').is(':checked'))
			{
				alert("Please check to confirm that you agree to RSPO's Code of Conduct.");
				$('#agree_cod').focus();
				return false;
			}
	
			if (!$('#agree_pp').is(':checked'))
			{
				alert("Please check to confirm that you agree to RSPO's Privacy Policy.");
				$('#agree_pp').focus();
				return false;
			}
	
			var data = $('form#memRegister').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btnSubmit').text('Please wait...');
					$('#btnSubmit').attr('disabled', true);
				},
				url: '/members/register',
				data: data,
				dataType: 'json',
				method: 'post'
	
			}).error(function(){
				$('#btnSubmit').text('Submit');
				$('#btnSubmit').attr('disabled', false);
			}).done(function(html){
	
				$('#btnSubmit').text('Submit...');
				$('#btnSubmit').attr('disabled', false);
	
				if (html.status=='error')
				{
					$('#regAlert').html('<div class="alert alert-danger alert-dimissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#regAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#regAlert').fadeIn();
					});
				}
				else if (html.status=='ok')
				{
					$('#regAlert').html('<div class="alert alert-success alert-dimissible" role="alert" ><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#regAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#regAlert').fadeIn(function(){
							$('form#memRegister')[0].reset();
							$('#btnSubmit').attr('disabled', true);
						});
					});
				}
	
			});
	
		});
	
	
		$('form#memForget').on('submit', function(e){
			e.preventDefault();
	
			if (!$('#emailForget').val())
			{
				alert('Please enter your email address');
				$('#emailForget').focus();
				return false;
			}
	
			var data = $('form#memForget').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btnForget').text('Please wait...');
					$('#btnForget').attr('disabled', true);
				},
				url: '/members/forget',
				data: data,
				dataType: 'json',
				method: 'post'
	
			}).error(function(){
				$('#btnForget').text('SUBMIT');
				$('#btnForget').attr('disabled', false);
			}).done(function(html){
	
				$('#btnForget').text('SUBMIT');
				$('#btnForget').attr('disabled', false);
	
				if (html.status)
				{
					$('#forgetAlert').html('<div class="clearfix"></div><div class="alert alert-success alert-dimissible" role="alert" ><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#forgetAlert').fadeIn(function(){
							$('form#memForget')[0].reset();
							//window.location = '<?php echo site_url('members/application'); ?>';
						});
					});
				}
				else
				{
					$('#forgetAlert').html('<div class="clearfix"></div><div class="alert alert-danger alert-dimissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#forgetAlert').fadeIn();
					});
				}
	
			});
	
		});

		$('form#memLogin').on('submit', function(e){
			e.preventDefault();
	
			if (!$('#loginEmail').val())
			{
				alert('Please enter your email address');
				$('#reg_email').focus();
				return false;
			}
	
			if (!$('#loginPass').val())
			{
				alert('Please create a new password');
				$('#password1').focus();
				return false;
			}
	
			var data = $('form#memLogin').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btnLogin').text('Please wait...');
					$('#btnLogin').attr('disabled', true);
				},
				url: '/members/login',
				data: data,
				dataType: 'json',
				method: 'post'
	
			}).error(function(){
				$('#btnLogin').text('LOGIN');
				$('#btnLogin').attr('disabled', false);
			}).done(function(html){
	
				$('#btnLogin').text('LOGIN');
				$('#btnLogin').attr('disabled', false);
				//return false;
				if (html.status)
				{
					$('#loginAlert').html('<div class="alert alert-success alert-dimissible" role="alert" ><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#loginAlert').fadeIn(function(){
							$('form#memLogin')[0].reset();
							if (html.redirect_to)
							{
								window.location = html.redirect_to;
							}
							else
							{
								window.location = '<?php echo site_url('members/selecttype'); ?>';
							}
						});
					});
				}
				else
				{
					$('#loginAlert').html('<div class="alert alert-danger alert-dimissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#loginAlert').fadeIn();
					});
				}
	
			});
	
		});

	});
</script>
<!-- </div> -->