<!-- Full Page Image Background Carousel Header -->
    <div class="row">
        <div class="container text-center" id="header-white" style="padding-bottom:13px;">
            <h1>MEMBERSHIP APPLICATION</h1>
        </div>    
    </div>
							<style>
								.btn {
									display: inline-block;
									margin-bottom: 0px;
									font-size: 14px;
									padding:10px 20px;
									font-weight: 600;
									line-height: 1.42857;
									text-align: center;
									white-space: nowrap;
									vertical-align: middle;
									cursor: pointer;
									-moz-user-select: none;
									background: #ED7B1C;
									border: 1px solid transparent;
									border-radius: 0px;
									color:#FFF;
									text-transform: none;
								}
								.dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus {
									color: #262626;
									text-decoration: none;
									background-color: #ED7B1C;
								}
								#inside .dropdown-menu, #front .dropdown-menu {
									margin-top: none;
								}
								.dropdown-menu {
									position: absolute;
									top: 100%;
									left: 0px;
									z-index: 1000;
									display: none;
									float: left;
									min-width: 160px;
									padding: 0px;
									margin: 2px 0px 0px;
									font-size: 14px;
									text-align: left;
									list-style: none outside none;
									background-color: #FFF;
									background-clip: padding-box;
									border: 1px solid rgba(0, 0, 0, 0.15);
									border-radius: 0px;
									box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.176);
								}
								.dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus {
									color: #FFF;
									text-decoration: none;
									background-color: #ED7B1C;
									font-weight: 600;
								}
								.dropdown-menu > li > a {
									display: block;
									padding: 10px 20px;
									clear: both;
									font-weight: 400;
									line-height: 1.42857;
									font-weight: 600;
									color: #333;
									white-space: nowrap;
								}
								.bootstrap-select.btn-group .dropdown-menu {
									min-width: 100%;
									z-index: 1035;
									box-sizing: border-box;
									border:none;
									margin-top: 8px;
								}
								.btn-group.open .dropdown-toggle {
									box-shadow: none;
								}
								.btn-default:hover, .btn-default:focus, .btn-default:active, .btn-default.active, .open > .dropdown-toggle.btn-default {
									color: #fff;
									border-color: transparent;
								}
								.bootstrap-select.btn-group .dropdown-menu.inner {
									position: static;
									border: none;
									padding: 0px;
									margin: 0px;
									border-radius: 0px;
									box-shadow: none;
								}
								.form-group {
									margin-bottom: 0px;
								}
							</style>
	<!-- dual image Section -->
    <section id="registration-step" style="padding-top:0px; padding-bottom:0px;">
        <div class="container text-center">
            <div class="row">
			<div style="max-width:800px; width:800px; margin:0 auto;">
				<h2 class="title-on-top" style="font-size:16px; padding-bottom:22px; line-height:1.75; margin-bottom:0px;">Thank you for applying for RSPO membership. First, please select your membership type below before you click on APPLY to proceed to the next step. If you have any questions, please <a href="mailto:membership@rspo.org">email us</a>.</h2>
			</div>
			<div style="width:1000px; max-width:1000px; margin:0 auto;">
                <div class="col-lg-4 area-step text-left " >
                    <div class="row">
                    <div class="container-step" style="padding-top:16px; margin-top:0px; margin-bottom:0px; margin-right:0px; margin-left:0px; background-color:#f5f5f5; border: 4px solid #f5f5f5; min-height:285px;">
						
						<div style="height:250px; min-height:250px;">
							<div style="height:97px; min-height:97px;">
								<h3 class="title-on-top" style="text-align:center; font-size:46px; letter-spacing:1px;">ORDINARY</h3>
								<h5 class="title-on-top" style="text-align:center; color:gray; letter-spacing: 2px;">MEMBERSHIP</h5>
							</div>	
								<p style="">My organisation is directly involved within the palm oil supply chain, or is an associated NGO.</p>
						</div>
						
						<br/>

						<form method="post" name="memOrdinary" action="<?php echo site_url('members/application'); ?>" id="memOrdinary" class="memSelect">
						<div class="form-group">
							{{dropdowns:categories category="ordinary" class="selectpicker form-control"}}
						</div>
						
						<br/>
						
						<div class="form-group">
							<input type="hidden" name="type" value="Ordinary Members" />
                            <button type="submit" name="btnOrdinary" class="btn btn-primary" style="width:100%; font-size:16px; font-weight:600; letter-spacing:1px; border-radius: 3px;">APPLY</button>
						</div>
						</form>

					</div>
					</div>
                </div>
                
                <div class="col-lg-4  area-step text-left ">
                    <div class="row">
                    <div class="container-step " style="padding-top:16px; margin-top:0px; margin-bottom:0px;  margin-right:1px;  margin-left:1px;background-color:#f5f5f5; border: 4px solid #f5f5f5; min-height:285px;">
						<div style="height:250px; min-height:250px;">
							<div style="height:97px; min-height:97px;">
								<h3 class="title-on-top" style="text-align:center; font-size:46px; letter-spacing:1px;">AFFILIATE</h3>
								<h5 class="title-on-top" style="text-align:center; color:gray; letter-spacing: 2px;">MEMBERSHIP</h5>
							</div>
								<p>I work with an organisation (or I am an individual) that is not directly involved in the palm oil supply chain in any of the 7 Ordinary Membership categories to the left.</p>
						</div>
						
						<br/>
						
						<form method="post" name="memAffiliate" action="<?php echo site_url('members/application'); ?>" id="memAffiliate" class="memSelect">
						<div class="form-group">
							{{dropdowns:categories category="affiliate" class="selectpicker form-control"}}
						</div>
						
						<br/>
						
						<div class="form-group">
							<input type="hidden" name="type" value="Affiliate Members" />
                            <button type="submit" name="btnAffiliate" class="btn btn-primary" style="width:100%; font-size:16px; font-weight:600; letter-spacing:1px; border-radius: 3px;">APPLY</button>
						</div>
						</form>
						
					</div>
					</div>
                </div> 
				
				<div class="col-lg-4 area-step text-left ">
                    <div class="row">
                    <div class="container-step" style="padding-top:16px; margin-top:0px; margin-bottom:0px; background-color:#f5f5f5; border: 4px solid #f5f5f5; margin-right:0px; margin-left:0px; min-height:285px;">
						<div style="height:250px; min-height:250px;">
							<div style="height:97px; min-height:97px;">
								<h3 class="title-on-top" style="text-align:center; font-size:23; letter-spacing:2px; font-weight:600;">SUPPLY CHAIN ASSOCIATE</h3>
								<h5 class="title-on-top" style="text-align:center; color:gray; letter-spacing: 2px;">MEMBERSHIP</h5>
							</div>
								<p>I work with an organisation that has business activities along the palm oil supply chain but limited to purchasing, using, or trading not more than 500 metric tonnes of palm oil and palm oil products annually.</p>
						</div>
						
						<br/>

						<form method="post" name="memSCA" action="<?php echo site_url('members/application'); ?>" id="memSCA" class="memSelect">
						<div class="form-group">
							{{dropdowns:categories category="supply_chain" class="selectpicker form-control"}}
						</div>
						
						<br/>
						
						<div class="form-group">
							<input type="hidden" name="type" value="Supply Chain Associate" />
                            <button type="submit" name="btnSCA" class="btn btn-primary" style="width:100%; font-size:16px; font-weight:600; letter-spacing:1px; border-radius: 3px;">APPLY</button>
						</div>
						</form>

					</div>
					</div>
                </div>
            </div>
            </div>
        </div>
    </section>

<div style="display:none;">
<div id="mapp-announcement">

	<h3>Are you a parent company?</h3>
	<p></p>
	<p>If applicable, please declare your parent company / subsidiaries in the application for our recording purposes. Kindly be informed that RSPO encourages parent companies to apply for RSPO Membership as they will benefit from the following:</p>

	<ol>
		<li>The membership by the parent company will include all the subsidiaries i.e. only one application needs to be submitted and only one membership fee to be paid</li>
		<li>Only one submission of the Annual Communications of Progress (ACOP)</li>
		<li>More convenient and simpler certification application</li>
	</ol>

	<p>&nbsp;</p>
	<div class="none">
		<a href="#" class="btn btn-block btn-primary" onclick="$.colorbox.close();return false;">OK</a>
	</div>

</div>
</div>


<script>
$(document).ready(function(){

	$('form.memSelect').on('submit', function(e){
		//e.preventDefault();
		var i = $(this).attr('id');
		var u = $(this).attr('action');
		var v = $('select', this).val();
		if (!v)
		{
			alert('Please select the category first.');
			return false;
		}
		return true;
		//$(this).submit()
	});

	$.colorbox({
		inline: true,
		href: '#mapp-announcement',
		fixed: true,
		width: "500px",
		height: "500px",
		close: false
	})

});
</script>