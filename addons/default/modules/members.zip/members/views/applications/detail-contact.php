<section class="first-section">
	<div class="container text-center">
		<div class="row">
			<h2 class="section-heading">MEMBERSHIP APPLICATION</h2>
		</div>
		
		<div class="row tml-contact id-contact">
			<div class="col-md-3 text-left">
				Applying as
				<h5>Affiliate Members</h5>
				<h5>Organisation</h5>
			</div>
			<div class="col-md-6">
				<div class="col-md-3">
					<div class="bullets-orange"></div>
					<label class="orange">1. Organisation Details</label>
				</div>
				<div class="col-md-3">
					<div class="bullets-orange"></div>
					<label class="orange">2. Contact Details</label>
				</div>
				<div class="col-md-3">
					<div class="bullets-zero"></div>
					<label>3. Questions</label>
				</div>
				<div class="col-md-3">
					<div class="bullets-zero"></div>
					<label>4. Supporting Details</label>
				</div>
			</div>
		</div>
	</div>
</section>

<section id="contact_detail" class="border-top-gray">
	<div class="container text-center">
	<div class="form-group">
		<label class="stage-supporting">2. CONTACT DETAIL</label>&nbsp;&nbsp;&nbsp;
		<img src="{{ theme:image_path file='oval-information.png' }}" id="pop-info" data-html="true" data-placement="right" data-toggle="popover" 
			data-content="<p>
			The membership application should be endorsed and signed off
			by a senior member of the organisation who will also be accountable in
			ensuring the organisation conforms to the <a href='{{url:site}}publications/download/c9713097c32580a'>RSPO Statuses, by-laws,</a>
			and <a href='{{url:site}}publications/download/cbb1628a5688f20'>Code of Conduct</a>.</p>
			<p>Mussum ipsum aradis. Paisis, filhis, espiritis santis. Me faiz elementum girarzis, 
			nisi eros vermeuem e amistosis quis leo. Manduma pindureta quium dia nois paga. </p>">	
		</div>		
	</div>
	
	<div class="container">
	<form action="#" method="post">
		<div class="row">
			<div class="col-md-6 col-sm-6"> 
				<div class="box-contact-form contact">
					<h3 class="subsection-heading">PRIMARY NOMINATION</h3>
					<H5>OF REPRESENTATIVE</h5>
					
					<div class="form-group">
						<label>Full Name</label>
						<input type="text" class="form-control" name="fullname">
					</div>
					<div class="form-group">
						<label>Position</label>
						<input type="text" class="form-control" name="position">
					</div>
					<div class="form-group">
						<label>Telephone</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input class="mobile-number tlp-code" type="tel" name="code-telp">
							</div>
						  <input class="form-control" type="text">
						</div>
					</div>
					<div class="form-group">
						<label>Fax</label> (Optional)
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input class="mobile-number tlp-code" type="tel" name="code-telp">
							</div>
						  <input class="form-control" type="text">
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="text" class="form-control" name="fullname">
					</div>
					
					<br/>
					<h3 class="subsection-heading">SECONDARY NOMINATION</h3>
					<H5>OF REPRESENTATIVE</h5>
					
					<div class="form-group">
						<label>Full Name</label>
						<input type="text" class="form-control" name="fullname">
					</div>
					<div class="form-group">
						<label>Position</label>
						<input type="text" class="form-control" name="position">
					</div>
					<div class="form-group">
						<label>Telephone</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input class="mobile-number tlp-code" type="tel" name="code-telp">
							</div>
						  <input class="form-control" type="text">
						</div>
					</div>
					<div class="form-group">
						<label>Fax</label> (Optional)
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input class="mobile-number tlp-code" type="tel" name="code-telp">
							</div>
						  <input class="form-control" type="text">
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="text" class="form-control" name="fullname">
					</div>
			</div>
		</div>
		
		<div class="col-md-6 col-sm-6"> 
			<div class="box-contact-form contact">
				<h3 class="subsection-heading">CONTACT PERSON</h3>
				<h5 style="opacity:0" >OF REPRESENTATIVE</h5>
				
				<div class="form-group">
					<label>Full Name</label>
					<input type="text" class="form-control" name="fullname">
				</div>
				<div class="form-group">
					<label>Position</label>
					<input type="text" class="form-control" name="position">
				</div>
				<div class="form-group">
					<label>Telephone</label>
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" name="code-telp">
						</div>
					    <input class="form-control" type="text">
					</div>
				</div>
				<div class="form-group">
					<label>Fax (Optional)</label> 
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" name="code-telp">
						</div>
					    <input class="form-control" type="text">
					</div>
				</div>
				<div class="form-group">
					<label>Email</label>
					<input type="text" class="form-control" name="fullname">
				</div>
				
				<br/>
				<h3 class="subsection-heading">FINANCE CONTACT</h3>
				<H5>FOR MEMBERSHIP FEE</h5>
				
				<div class="form-group">
					<label>Full Name</label>
					<input type="text" class="form-control" name="fullname">
				</div>
				<div class="form-group">
					<label>Position</label>
					<input type="text" class="form-control" name="position">
				</div>
				<div class="form-group">
					<label>Telephone</label>
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" name="code-telp">
						</div>
					    <input class="form-control" type="text">
					</div>
				</div>
				<div class="form-group">
					<label>Fax</label> (Optional)
					<div class="input-group no-margin">
						<div class="input-group-addon no-padding">
							<input class="mobile-number tlp-code" type="tel" name="code-telp">
						</div>
					    <input class="form-control" type="text">
					</div>
				</div>
				<div class="form-group">
					<label>Email</label>
					<input type="text" class="form-control" name="fullname">
				</div>
				<input type="submit" value="NEXT" class="btn btn-lg btn-orange pull-right">
			</div>
			</div>
		</div>
	</div>
	</form>
	
</section>