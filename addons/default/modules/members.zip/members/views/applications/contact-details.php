<section id="contact_detail" class="border-top-gray">
	<div class="container-820">
		<div>
			<h3 class="text-center">2. CONTACT DETAIL <a href="#" tabindex="0" id ="pop-info" data-html="true" data-toggle="popover" data-trigger="focus" data-content="<p>
			The membership application should be endorsed and signed off
			by a senior member of the organisation who will also be accountable in
			ensuring the organisation conforms to the <a href='//www.rspo.org/files/download/c5483f5338f306b'>RSPO Statutes,</a>
			and <a href='//www.rspo.org/files/download/8a111694d249905'>Code of Conduct</a>.</p>"><img style="margin-top:-5px;" src="{{ theme:image_path file='oval-information.png' }}"></a></h3>
		</div>
	</div>
	
	<div class="container-820 s_contact_details" style="margin-bottom:55px;">
		
		<!-- left menu -->
		<div id="list_CD_left" class="detectScroolspyActive">
			<div id="navCD" class="nav left_m_contact_details mCustomScrollbar affix-top" data-spy="affix" data-offset-top="412">
				<ul class="CD_right">
					<li>
						<a href="#prymaryRepresentative">Primary representative</a>
					</li>
					<li>
						<a href="#secondaryRepresentative">Secondary representative</a>
					</li>
					<li>
						<a href="#financeContact">Finance contact</a>
					</li>
					<li>
						<a href="#contactPerson">Contact person</a>
					</li>
				</ul>
			</div>
		</div>
		
		<!-- right content -->
		<div class="list_CD_right">
			<div class="c_form list_of_CD">
				<div id="prymaryRepresentative" class="bg-f5f5f5 c_form_list">
					<h3 class="subsection-heading">PRIMARY REPRESENTATIVE</h3>
					<div class="form-group">
						<label>First Name</label>
						<?php echo form_input('name_p', htmlspecialchars_decode($membersapp->name_p), 'class="form-control  checkuse" rel="name_s"') ?>
						<?php echo form_error('name_p') ? '<div class="alert alert-danger">'.form_error('name_p').'</div>': ''; ?>
					</div>
					<div class="form-group">
						<label>Last Name</label>
						<?php echo form_input('name_last_p', htmlspecialchars_decode($membersapp->name_last_p), 'class="form-control  checkuse" rel="name_s"') ?>
						<?php echo form_error('name_last_p') ? '<div class="alert alert-danger">'.form_error('name_last_p').'</div>': ''; ?>
					</div>
					<div class="form-group">
						<label>Position</label>
						<?php echo form_input('designation_p', htmlspecialchars_decode($membersapp->designation_p), 'class="form-control required" rel="designation_s"') ?>
						<?php echo form_error('designation_p') ? '<div class="alert alert-danger">'.form_error('designation_p').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Telephone</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->telephone_p?>" class="mobile-number tlp-code tlpCodeContactDetails" type="tel" name="telephone_p">
							</div>
							<?php //echo form_input('telephone_p', $membersapp->telephone_p, 'class="form-control required required2"') ?>
						</div>
						<?php echo form_error('telephone_p') ? '<div class="alert alert-danger">'.form_error('telephone_p').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Fax</label> <i>(Optional)</i>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->fax_p?>" class="mobile-number tlp-code tlpCodeContactDetails" type="tel" name="fax_p">
							</div>
						<?php //echo form_input('fax_p', $membersapp->fax_p, 'class="form-control"') ?>
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<?php echo form_input('email_p', $membersapp->email_p, 'class="form-control checkuse" rel="email_s"') ?>
						<div class="alert alert-danger" style="display:<?php echo form_error('email_p') ? 'block' : 'none'; ?>;">
							<?php echo form_error('email_p') ? form_error('email_p') : ''; ?>
						</div>
						<?php //echo form_error('email_p') ? '<div class="alert alert-danger">'.form_error('email_p').'</div>' : ''; ?>
					</div>
				</div>
				<div id="secondaryRepresentative" class="bg-f5f5f5 c_form_list">
					<h3 class="subsection-heading">SECONDARY REPRESENTATIVE</h3>
					<div class="form-group">
						<label>First Name</label>
						<?php echo form_input('name_s', htmlspecialchars_decode($membersapp->name_s), 'class="form-control checkuse" rel="name_p"') ?>
						<?php echo form_error('name_s') ? '<div class="alert alert-danger">'.form_error('name_s').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>last Name</label>
						<?php echo form_input('name_last_s', htmlspecialchars_decode($membersapp->name_last_s), 'class="form-control checkuse" rel="name_p"') ?>
						<?php echo form_error('name_last_s') ? '<div class="alert alert-danger">'.form_error('name_last_s').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Position</label>
						<?php echo form_input('designation_s', htmlspecialchars_decode($membersapp->designation_s), 'class="form-control required" rel="designation_p"') ?>
						<div class="alert alert-danger" style="display:none;"></div>
						<?php echo form_error('designation_s') ? '<div class="alert alert-danger">'.form_error('designation_s').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Telephone</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->telephone_s?>" class="mobile-number tlp-code tlpCodeContactDetails" type="tel" name="telephone_s">
							</div>
							<?php //echo form_input('telephone_s', $membersapp->telephone_s, 'class="form-control required required2"') ?>
						</div>
						<?php echo form_error('telephone_s') ? '<div class="alert alert-danger">'.form_error('telephone_s').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Fax</label> <i>(Optional)</i>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->fax_s?>" class="mobile-number tlp-code tlpCodeContactDetails" type="tel" name="fax_s">
							</div>
							<?php //echo form_input('fax_s', $membersapp->fax_s, 'class="form-control"') ?>
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<?php echo form_input('email_s', $membersapp->email_s, 'class="form-control checkuse" rel="email_p"') ?>
						<div class="alert alert-danger" style="display:<?php echo form_error('email_s') ? 'block' : 'none'; ?>;">
							<?php echo form_error('email_s') ? form_error('email_s') : ''; ?>
						</div>
						<?php //echo form_error('email_s') ? '<div class="alert alert-danger">'.form_error('email_s').'</div>' : ''; ?>
					</div>
				</div>
				<div id="financeContact" class="bg-f5f5f5 c_form_list">
					<h3 class="subsection-heading">FINANCE CONTACT</h3>
					<H5>FOR MEMBERSHIP FEE</h5>
					<div class="form-group">
						<label>First Name</label>
							<?php echo form_input('name_f', htmlspecialchars_decode($membersapp->name_f), 'class="form-control required"') ?>
							<?php echo form_error('name_f') ? '<div class="alert alert-danger">'.form_error('name_f').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Last Name</label>
							<?php echo form_input('name_last_f', htmlspecialchars_decode($membersapp->name_last_f), 'class="form-control required"') ?>
							<?php echo form_error('name_last_f') ? '<div class="alert alert-danger">'.form_error('name_last_f').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Position</label>
							<?php echo form_input('designation_f', htmlspecialchars_decode($membersapp->designation_f), 'class="form-control required"') ?>
							<?php echo form_error('designation_f') ? '<div class="alert alert-danger">'.form_error('designation_f').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Telephone</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->telephone_f?>" class="mobile-number tlp-code tlpCodeContactDetails" type="tel" name="telephone_f">
							</div>
							<?php //echo form_input('telephone_f', $membersapp->telephone_f, 'class="form-control required required2"') ?>
						</div>
						<?php echo form_error('telephone_f') ? '<div class="alert alert-danger">'.form_error('telephone_f').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Fax</label> <i>(Optional)</i> 
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->fax_f?>" class="mobile-number tlp-code tlpCodeContactDetails" type="tel" name="fax_f">
							</div>
							<?php //echo form_input('fax_f', $membersapp->fax_f, 'class="form-control"') ?>
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<?php echo form_input('email_f', $membersapp->email_f, 'class="form-control required"') ?>
						<?php echo form_error('email_f') ? '<div class="alert alert-danger">'.form_error('email_f').'</div>' : ''; ?>
					</div>
				</div>
				<div id="contactPerson" class="bg-f5f5f5 c_form_list">
					<h3 class="subsection-heading">CONTACT PERSON</h3>
					<div class="form-group">
						<label>First Name</label>
							<?php echo form_input('contact_person', htmlspecialchars_decode($membersapp->contact_person), 'class="form-control required"') ?>
							<?php echo form_error('contact_person') ? '<div class="alert alert-danger">'.form_error('contact_person').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Last Name</label>
							<?php echo form_input('contact_lname', htmlspecialchars_decode($membersapp->contact_lname), 'class="form-control required"') ?>
							<?php echo form_error('contact_lname') ? '<div class="alert alert-danger">'.form_error('contact_lname').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Position</label>
							<?php echo form_input('designation', htmlspecialchars_decode($membersapp->designation), 'class="form-control required"') ?>
							<?php echo form_error('designation') ? '<div class="alert alert-danger">'.form_error('designation').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Telephone</label>
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->contact_tel?>" class="mobile-number tlp-code tlpCodeContactDetails" type="tel" name="contact_tel">
							</div>
							<?php //echo form_input('contact_tel', $membersapp->contact_tel, 'class="form-control required required2"') ?>
						</div>
						<?php echo form_error('contact_tel') ? '<div class="alert alert-danger">'.form_error('contact_tel').'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<label>Fax</label> <i>(Optional)</i> 
						<div class="input-group no-margin">
							<div class="input-group-addon no-padding">
								<input value="<?php echo $membersapp->contact_fax?>" class="mobile-number tlp-code tlpCodeContactDetails" type="tel" name="contact_fax">
							</div>
							<?php //echo form_input('contact_fax', $membersapp->contact_fax, 'class="form-control"') ?>
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<?php echo form_input('contact_email', $membersapp->contact_email, 'class="form-control required"') ?>
						<?php echo form_error('contact_email') ? '<div class="alert alert-danger">'.form_error('contact_email').'</div>' : ''; ?>
					</div>
				</div>
			</div>
			
			<div class="form-group text-right" style="margin-bottom:0px; float:right; width:100%;">
				<input type="submit" value="PREV" id="prev_1" class="btn btn-black btn-prev" style="border: 1px solid #ED7B1C;">
				
				<button name="btnSave" type="button" class="btn btn-black btn-save btnSave" value="2">SAVE</button>
				<!-- <button name="btnSave" type="submit" class="btn btn-black btn-save" value="2">SAVE</button> -->
				<!-- <input type="submit" value="SAVE" name="btnSave" class="btn btn-black btn-save" style="border: 1px solid #ED7B1C;"> -->
						
				<!-- check go to step3 or step4 -->
				<input type="submit" value="NEXT" id="next_2" class="btn btn-black btn-next c_next2" style="border: 1px solid #ED7B1C;">
				<input type="submit" value="NEXT" id="next_3_1" class="btn btn-black btn-next c_next3" style="border: 1px solid #ED7B1C;">
			</div>
		</div>
	</div>
</section>