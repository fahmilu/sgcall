<div class="container text-center margin-bottom-15" id="header-white">
	<h1>Membership Application</h1>
</div>
<div class="container member-map">
	<div class="row">
		<div class="col-lg-7 col-md-7 col-sm-12 none-padding">
			<div class="bordered-top">
				<label class="map-rev margin-top-26">Review the Requirements</label> 
				<h2>Ordinary and Affiliate Membership</h2>
				<p>For applicants directly involved in the palm oil supply chain; representing a NGO; representing an organisation that is not directly involved in the palm oil supply chain; and individuals.</p>
			</div>
			<div class="bordered-all pad-20">
				<div class="panel-group" id="accordion">
				  <div class="panel panel-default">
				    <div class="panel-heading">
				      <h4 class="panel-title">
				        <a class="accordion-toggle">Membership Fees</a>
				      </h4>
				    </div>
				    <div id="collapse1" class="panel-collapse collapse in">
			      	<div class="clearfix"></div>
				      <div class="panel-body">
				      	<h2>Ordinary Member</h2>
				      	<ul>
				      		<li>Smallholder Group Manager
				      			<ul class="sublist">
				      				<li>&euro; 2,000 per year (More than 1,999 ha)</li>
				      				<li>&euro; 1,000 per year (1,000 to 1,999 ha)</li>
				      				<li>&euro; 250 per year (Less than 1,000 ha)</li>
				      			</ul>
				      		</li>
				      		<li>Outgrower
				      			<ul class="sublist2">
				      				<li>&euro; 500 per year (500 ha and below)</li>
				      			</ul>
				      		</li>
				      	</ul>
				      	<ul class="listnone">
				      		<li class="list-aff"><label>Affiliate</label>
				      			<ul class="sublist3">
				      				<li>&euro; 250 per year</li>
				      			</ul>
				      		</li>
				      	</ul>
				      </div>
				    </div>
				    <div class="clearfix"></div>
				  </div>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-lg-5 no-pad-left no-pad-right pdf-download-area1">
				<a href="http://www.rspo.org/files/download/c5483f5338f306b">
					<div class="bordered-all2 downloadable">
					<i class="pdf-download"></i><label class="pdf-title">RSPO Statutes</label></div>
				</a>
			</div>
			<div class="col-lg-7 no-pad-left no-pad-right pdf-download-area">
				<a href="http://www.rspo.org/files/download/8a111694d249905">
					<div class="bordered-all2 downloadable-216"><i class="pdf-download"></i><label class="pdf-title">Code of Conduct</label></div>
				</a>
			</div>
			<div class="clearfix"></div>
			<br/>
			<div>
				<h2>Supply Chain Associates Membership</h2>
				<p>For applicants working with an organisation that has business activities along the palm oil supply chain but limited to purchasing, using, or trading no more than 500 metric tonnes of palm oil and palm oil products annually.</p>
			</div>
			<div class="bordered-all">
				<div class="panel-group" id="accordion">
				  <div class="panel panel-default">
				    <div class="panel-heading">
				      <h4 class="panel-title">
				        <a class="accordion-toggle">Membership Fees</a>
				      </h4>
				    </div>
				    <div id="collapse2" class="panel-collapse collapse in">
				      <div class="panel-body">
				      	<ul class="listnone">
				      		<li class="list-aff"><label>Supply Chain Associates</label>
				      			<ul class="sublist4">
				      				<li>&euro; 100 per year</li>
				      			</ul>
				      		</li>
				      	</ul>
				      </div>
				    </div>
				    <div class="clearfix"></div>
				  </div>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-lg-5 no-pad-left no-pad-right pdf-download-area1">
				<a href="http://www.rspo.org/files/download/c5483f5338f306b">
					<div class="bordered-all2 downloadable">
					<i class="pdf-download"></i><label class="pdf-title">RSPO Statutes</label></div>
				</a>
			</div>
			<div class="col-lg-7 no-pad-left no-pad-right pdf-download-area">
				<a href="http://www.rspo.org/files/download/c7536a5fd1d6739">
					<div class="bordered-all2 downloadable-278"><i class="pdf-download"></i><label class="pdf-title">Code of Conduct for SCA</label></div>
				</a>
			</div>
			<div class="clearfix"></div>
			<div class="pad-24-30 margin-top-30">
			</div>
<!--
			<div class="bg-light-gray pad-24-30 margin-top-30 margin-bottom-50">
				<h2 class="no-padding no-margin">What happens after submission</h2>
				<p class="margin-top-17 color-63">All membership applications go through a process whereby background research is 
				undertaken. Submitted documents are reviewed; input is received from various 
				stakeholders followed by a final approval from the RSPO Secretary General upon 
				endorsement from the Board of Governors. Any appeals to applications declined will be 
				handed by an Arbitration Board.</p> 

				<p class="color-63">Membership of the RSPO includes a 2-year commitment consecutively with membership 
				fees payable annually. Membership is renewable annually thereafter.</p> 
			</div>
-->
		</div> 
		<div class="col-lg-5 col-md-5 col-sm-12 no-pad-right margin-bottom-30 form-map">
			<div class="bg-yellow">
				<p>RSPO membership applicants need to register in the form below. 
				If you have already registered, kindly <a href="/members/myrspo-login">login</a> to resume.
				</p>
				<img src="<?php echo base_url(); ?>addons/default/themes/r3p1_revamp/img/icon-info.png"/>
			</div>
			<div class="bordered-top-bot no-padding margin-top-30 margin-bottom-50">

				<div style="display:none;" id="regAlert"></div>

				<form method="post" name="memRegister" id="memRegister" action="{{url:site}}members/register" accept-charset="utf-8">

					<input autocomplete="off" type="text" name="email" placeholder="Enter your email" class="form-control map-input-text" id="reg_email" />
					<input autocomplete="off" type="text" class="form-control map-input-text" name="full_name" id="full_name" placeholder="Enter your name" />
					<input type="password" class="form-control map-input-text" name="password" id="password1" placeholder="Password" />
					<input type="password" class="form-control map-input-text" name="password2" id="password2" placeholder="Confirm Password" />

					<?php echo form_input('d0ntf1llth1s1n', ' ', 'class="default-form" style="display:none"') ?>

					<div class="clearfix"></div>
					<div class="col-lg-7 col-md-7 col-sm-9 col-xs-6 no-padding captcha1">
						<input name="captcha" value="" id="captcha" maxlength="5" type="text" class="form-control map-input-text-2" placeholder="Enter the letters you see">
					</div>
					<div class="col-lg-5 col-md-5 col-sm-3 col-xs-6 no-padding captcha2">
						<?php echo $captcha; ?>
					</div> 
					<div class="clearfix"></div>
					<div class="bordered-left-right-bot pad-left-30 pad-right-30 pad-bottom-30">
						<ul class="listnone pad-bottom-20">
							<li>
								<div class="checkbox checkbox-warning">
									<input type="checkbox" name="agree_mr" class="shouldcheck" id="agree_mr" value="1">
			                        <label for="agree_mr" class="map-agree">
										I have read and understood my obligations, duties and responsibilities under the RSPO’s <a href="http://www.rspo.org/publications/download/638ae27c7f6b004">Membership Rule</a> and will accept future modifications.
			                        </label>
			                    </div>
							</li>
							<li>
								<div class="checkbox checkbox-warning">
									<input type="checkbox" name="agree_cod" class="shouldcheck" id="agree_cod" value="1">
			                        <label for="agree_cod" class="map-agree">
										I have read and understood my obligations, duties and responsibilities under the RSPO's  <a href="{{url:site}}publications/download/cbb1628a5688f20">Code of Conduct</a> and will accept future modifications.
			                        </label>
			                    </div>
							</li>
							<li>
								<div class="checkbox checkbox-warning">
									<input type="checkbox" name="agree_pp" id="agree_pp" class="shouldcheck" value="2">
			                        <label for="agree_pp" class="map-agree">
										I agree with the RSPO's <a href="{{ url:site }}uploads/default/files/ea2fe53574e48e9f986557b9c749f5bd.pdf">Privacy Policy</a>
			                        </label>
			                    </div>
							</li>
						</ul>

						<button type="submit" disabled="disabled" class="btn btn-primary btn-sm map-btn btn-black" id="btnSubmit" name="btnSubmit">SUBMIT</button>
						<div class="clearfix"></div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function(){
			  
		$('#showwhyapply').click(function(e){
			e.preventDefault();
			$('.whyapply').slideToggle();
		});
	
		$('#show_what_happen_after_submission').click(function(e){
			e.preventDefault();
			$('.what_happen_after_submission').slideToggle();
		});
	
		$('#show_ordinary_affiliate_membership').click(function(e){
			e.preventDefault();
			$('.ordinary_affiliate_membership').slideToggle();
		});
						
		$('#show_suppy_chain_associate_membership').click(function(e){
			e.preventDefault();
			$('.suppy_chain_associate_membership').slideToggle();
		});
	
		$('.registershow,.registershow3').click(function(e){
			e.preventDefault();
			var d = $(this).attr('rel');
			$('.step0').slideUp(function(){
			});
				$('#'+d).fadeIn();
		});

		$('.registershow2').click(function(e){
			e.preventDefault();
			var d = $(this).attr('rel');
			$('.step0').slideUp(function(){
			});
				$('#'+d).fadeIn('fast', function(){
					$('html, body').animate({
						scrollTop: ($("#uregister").offset().top * 1) - 100
					}, 100);
				});

		});
	
		$('#agree_cod, #agree_pp, #agree_mr').on('click', function(){
			if ($('#agree_pp').is(':checked') && $('#agree_cod').is(':checked') && $('#agree_mr').is(':checked'))
			{
				$('#btnSubmit').attr('disabled', false);
			}
			else
			{
				$('#btnSubmit').attr('disabled', true);
			}
		});
	
	
		$('form#memRegister').on('submit', function(e){
			e.preventDefault();
	
			if (!$('#reg_email').val())
			{
				alert('Please enter your email address');
				$('#reg_email').focus();
				return false;
			}
	
			if (!$('#full_name').val())
			{
				alert('Please enter your full name');
				$('#full_name').focus();
				return false;
			}
	
			if (!$('#password1').val())
			{
				alert('Please create a new password');
				$('#password1').focus();
				return false;
			}
	
			if (!$('#password2').val())
			{
				alert('Please reconfirm your new password');
				$('#password2').focus();
				return false;
			}
	
			if ($('#password2').val() != $('#password1').val())
			{
				alert('The password you entered do not match');
				$('#password1').focus();
				return false;
			}

			// recaptcha
			if ($('#captcha').val() == '')
			{
				alert('Please enter the characters you see in the Captcha image.');
				$('#captcha').focus();
				return false;
			}

			if (!$('#agree_cod').is(':checked'))
			{
				alert("Please check to confirm that you agree to RSPO's Code of Conduct.");
				$('#agree_cod').focus();
				return false;
			}
	
			if (!$('#agree_pp').is(':checked'))
			{
				alert("Please check to confirm that you agree to RSPO's Privacy Policy.");
				$('#agree_pp').focus();
				return false;
			}
	
			if (!$('#agree_mr').is(':checked'))
			{
				alert("Please check to confirm that you agree to RSPO's Privacy Policy.");
				$('#agree_mr').focus();
				return false;
			}
	
			var data = $('form#memRegister').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btnSubmit').text('Please wait...');
					$('#btnSubmit').attr('disabled', true);
				},
				url: '/members/register',
				data: data,
				dataType: 'json',
				method: 'post'
	
			}).error(function(){
				$('#btnSubmit').text('Submit');
				$('#btnSubmit').attr('disabled', false);
			}).done(function(html){
	
				$('#btnSubmit').text('Submit...');
				$('#btnSubmit').attr('disabled', false);
	
				if (html.status=='error')
				{
					$('#regAlert').html('<div class="alert alert-danger alert-dimissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#regAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#regAlert').fadeIn();
					});
					//Recaptcha.reload();
/*
					if (html.recaptcha != undefined)
					{
						$('#captcha_container').fadeTo('fast', 0, function(){
							$(this).html(html.recaptcha).fadeTo('fast', 1);
						});
					}
*/
				}
				else if (html.status=='ok')
				{
					//Recaptcha.reload();
					$('#regAlert').html('<div class="alert alert-success alert-dimissible" role="alert"  style="margin-top:30px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#regAlert").offset().top * 1) - 50
					}, 300, function(){
						$('#regAlert').fadeIn(function(){
							$('form#memRegister')[0].reset();
							$('#btnSubmit').attr('disabled', true);
							gaProcess('members/apply', 'Register', 'User Registrations');
						});
					});
				}
	
			});
	
		});
	
	
		$('form#memForget').on('submit', function(e){
			e.preventDefault();
	
			if (!$('#emailForget').val())
			{
				alert('Please enter your email address');
				$('#emailForget').focus();
				return false;
			}
	
			var data = $('form#memForget').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btnForget').text('Please wait...');
					$('#btnForget').attr('disabled', true);
				},
				url: '/members/forget',
				data: data,
				dataType: 'json',
				method: 'post'
	
			}).error(function(){
				$('#btnForget').text('SUBMIT');
				$('#btnForget').attr('disabled', false);
			}).done(function(html){
	
				$('#btnForget').text('SUBMIT');
				$('#btnForget').attr('disabled', false);
	
				if (html.status)
				{
					$('#forgetAlert').html('<div class="clearfix"></div><div class="alert alert-success alert-dimissible" role="alert" style="margin-top:30px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert2").offset().top * 1) - 50
					}, 300, function(){
						$('#forgetAlert').fadeIn(function(){
							$('form#memForget')[0].reset();
							//window.location = '<?php echo site_url('members/application'); ?>';
						});
					});
				}
				else
				{
					$('#forgetAlert').html('<div class="clearfix"></div><div class="alert alert-danger alert-dimissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert2").offset().top * 1) - 50
					}, 300, function(){
						$('#forgetAlert').fadeIn();
					});
				}
	
			});
	
		});

		$('form#memLogin2').on('submit', function(e){
			e.preventDefault();
	
			if (!$('#loginEmail2').val())
			{
				alert('Please enter your email address');
				$('#loginEmail2').focus();
				return false;
			}
	
			if (!$('#loginPass2').val())
			{
				alert('Please enter your password');
				$('#loginPass2').focus();
				return false;
			}
	
			var data = $('form#memLogin2').serialize();
			$.ajax({
				beforeSend: function(){
					$('#btnLogin').text('Please wait...');
					$('#btnLogin').attr('disabled', true);
				},
				url: '/members/login',
				data: data,
				dataType: 'json',
				method: 'post'
	
			}).error(function(){
				$('#btnLogin').text('LOGIN');
				$('#btnLogin').attr('disabled', false);
			}).done(function(html){
	
				$('#btnLogin').text('LOGIN');
				$('#btnLogin').attr('disabled', false);
				//return false;
				if (html.status=='login')
				{
					$('#loginAlert2').html('<div class="alert alert-success alert-dimissible" role="alert" style="margin-top:5px;margin-bottom:5px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					if (html.redirect_to)
					{
						window.location = html.redirect_to;
					}
					return false;
				}
				else if (html.status)
				{
						document.getElementById("hiam").innerHTML = html.message;
						$('.steps-members-status').hide('fast');
						$('#message_login_status').modal('show');
						return false;
				}
				else
				{
					$('#loginAlert2').html('<div class="alert alert-danger alert-dimissible" role="alert" style="margin-top:10px;"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div style="margin-right:15px;">'+html.message+'</div></div>');
					$('html, body').animate({
						scrollTop: ($("#loginAlert2").offset().top * 1) - 50
					}, 300, function(){
						$('#loginAlert2').fadeIn();
					});
				}
	
			});
	
		});

	});
</script>
