					<ol>
						<li class="bold">Promotion and Commitment
							<ol>
								<li>Member organisations will acknowledge their responsibility as a Supply Chain Associate of the RSPO, its objectives, statutes and by-laws, the Supply Chain Certification Systems requirements and agreements, the Principle and Criteria (P&C),  and its respective national interpretations and implementation process through informed and explicit endorsement.</li>
								<li>Associates will promote and communicate this commitment throughout its own organisation and to its customers, suppliers, sub-contractors and wider value chains where necessary.</li>
								<li>Associates of the RSPO must be endorsed by a senior representative of the member organisation.</li>
							</ol>
						</li>
						<li class="bold">Transparency, reporting and claims
							<ol>
								<li>Associates will not make any misleading or unsubstantiated claims about the production, procurement or use of sustainable palm oil. 2.2 Associates will commit to open and transparent engagement with interested parties, and actively seek resolution of conf lict.</li>
							</ol>
						</li>
						<li class="bold">Implementation
							<ol>
								<li>Associates to whom the P&C apply will work towards implementation and certification of the P&C.</li>
								<li>Associates to whom the P&C do not apply directly will implement parallel standards relevant  to their own organisation, which cannot be lower than those set out in the P&C.</li>
								<li>Associates are responsible for ensuring that their commitment to the objectives of the RSPO is underpinned by adequate resources within its organisation.</li>
								<li>Relevant personnel within member organisations will be provided appropriate information that will enable them to work towards the objectives of the RSPO in their work.</li>
								<li>Associates will share with other Associates experience in the design and implementation of activities to support sustainable palm oil.</li>
								<li>Associates to whom the P&C do not directly apply will actively seek to promote sustainable palm oil and will give support to those Associates engaged in implementing the RSPO P&C. </li>
							</ol>
						</li>
						<li class="bold">Pricing and incentives
							<ol>
								<li>Associates procuring palm oil will integrate implementation and independent verif ication of the P&C as a positive performance measure when assessing supplier performance.</li>
								<li>Associates will adhere strictly to the RSPO anti-trust guidelines, and refrain from any behaviour which can be construed as anti-competitive practice.</li>
							</ol>
						</li>
						<li class="bold">Breaches of this Code
							<ol>
								<li>Associates will seek to resolve grievances directly with other member organisations in a timely fashion, and will not make unsubstantiated allegations of breaches against other Associates.</li>
								<li>Breaches of this Code, or the by-laws and statutes of the RSPO may lead to exclusion from the organisation.</li>
								<li> Prior to taking public action in cases of unresolved allegations of breaches of this Code, Associates will report breaches to the Executive Board, which will deal with the alleged breaches in accordance with the RSPO Grievance Procedure.</li>
								<li>Executive Board Associates who are found, after due inquiry, to have breached the Code, will be replaced.</li>
							</ol>
						</li>
					</ol>