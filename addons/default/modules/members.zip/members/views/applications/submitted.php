<section id="contact_detail thankyou_map_applications">
	<div class="container-1080 text-center">
		<h3 class="subsection-heading">THANK YOU FOR APPLYING</h3>	
	</div>
	<div class="container-1080">
		<div class="row">
			<?php echo form_open('members/login/members/apply', 'id="activate-user"') ?>
				<div class="margin-top-17">
					<div class="container-640" style="background:#F5F5F5; padding:30px;">
						<p>We will process your membership application and notify you as soon as it is approved. During this time, please note that you cannot log in to your account.</p>
						<center><a href="{{url:site}}"><button class="btn btn-lg" style="border-radius:3px; margin-top:14px;">CLOSE</button></a></center>
					</div>
				</div>
			</form>
		</div>
	</div>
</section>