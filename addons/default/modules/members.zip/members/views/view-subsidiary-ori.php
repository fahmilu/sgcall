<!-- member Section -->
<section id="members-prof" class="first-section">
	<div class="container text-center">

		<div class="col-md-4 col-sm-4 col-xs-12 text-left" style="width:225px;">
		<div class="back-linkmembers">
			<span><a href="<?php echo site_url('members/all') ?>"><i class="fa fa-caret-left"></i>ALL MEMBERS</a></span>			
		</div>
			<div class="logo-members text-center" alt="">
				<?php
					if ( $member->logo && $member->logo <> 'ma/logo/')
					{
						if (strstr($member->logo, '/sites/default/files/'))
							echo '<img class="img-responsive" src="http://www.rspo.org'.$member->logo.'" />'.PHP_EOL;
						else
							echo '<img class="img-responsive" src="http://www.rspo.org/'.$member->logo.'" />'.PHP_EOL;
					}
					else
					{?>
						{{theme:image file="generic-member.jpg"}}
					<? }
						//echo '<img class="img-responsive" src="http://www.rspo.org/tpl/default/images/members/generic-member.jpg" />'.PHP_EOL;
				?>
			</div>
			<div class="descr-profile">
				<span>Membership No.</span> 
				<p class="member_profile"><?php echo $member->member_num; ?></p>
				<span>Type</span> 
				<p class="member_profile"><?php echo $member->type; ?></p>
				<span>Region</span> 
				<p member_profile><?php echo $member->primary_market_ops ? $member->primary_market_ops : 'N/A'; ?></p>
				<span>Country</span> 
				<p class="member_profile"><?php echo $member->country; ?></p>
				<span>Member since</span> 
				<p class="member_profile"><?php echo date("j F Y", $member->approved_date); ?></p>
				<?php if(!empty($member->website)):?>
				<span>Web</span><br/>
				<?php if (substr($member->website, 0, 7) <> 'http://') $member->website = 'http://'.$member->website; ?>
				<?php echo $member->website ? '<a target="_blank" href="'.$member->website.'">'.str_ireplace(array('http://', 'www.'), '', trim($member->website, '/')).'</a>' : 'N/A'; ?>
				<?php endif;?>
			</div>
			<style>
				.logo-traders a.btn-brown {
					text-align: center;
					font-size: 12px;
					font-weight: 400;
					text-transform: uppercase;
					line-height: 11.5px;
					background: none repeat scroll 0% 0% #735636;
					color: #F2F2F2;
					width: 152px;
					border-radius: 3px !important;
					margin-top: -3px;
				}
				/* .logo-traders a.btn-brown:hover { 
					text-align: center;
					font-size: 12px;
					font-weight: 400;
					text-transform: uppercase;
					line-height: 11.5px;
					background: none repeat scroll 0% 0% #FF6500;
					color: #fff;
					width: 152px;
					border-radius: 3px !important;
					margin-top: -3px;
				}*/
				.btn {
					border: none;
				}
			</style>
			<div class="brand-trade text-center">
				<div class="logo-traders text-center">
					<img class="img-responsive traders-img" src="{{ theme:image_path file='trade-logo.png' alt='Pursuit for Betterment Towards 100% CSPO'}}">
					<h3>Pursuit For Betterment<br />Towards 100% CSPO</h3> 
					<a class="btn btn-large btn-brown" href="#" style="font-size:13px; line-height:1.3; border-radius:3px; font-weight:600; padding:6px 20px 8px 20px; cursor:default;">pledge towards<br /> 100% cspo</a>
				</div>
			</div>
		</div>
		
		<!-- right -->
		<div class="col-md-8 col-sm-8 col-xs-12 text-left" style="width:800px; max-width:915px">
			<h3><?php echo stripslashes($member->name); ?></h3>
            <div class="col-lg-12 col-md-12 primary-member" style="width:800px; max-width:915px">

            <?php if (!empty($member->parent_member)): ?>
				<a href="<?php echo site_url('members/'.$member->parent_member->intID.'/'.url_title($member->parent_member->name)); ?>" class="btn btn-orange-member" style="margin-bottom:22px;">A Subsidiary Of <?php echo $member->parent_member->name ?></a>
			<?php endif; ?>
				<div class="desc-primary-members">
					<div class="row">
						<h4 class="subsection-heading">Profile</h4>
						<div class="text-desc-members" style="padding-top:4px;">
							<font style="color:#43372c; line-height:1.75"><?php echo nl2br(strip_tags(stripslashes($member->profile))) ?></font>
						</div>
					</div>
				</div>
			</div>
			<!--
			<div class="col-md-12 report-content" style="width:800px; max-width:915px">
				<div class="member-report">
					<div class="hidden">
					<h4 class="subsection-heading">Reports</h2>							 
					<div class="list-reports">
						<li><a href="#">ACOP 2013 Progress Report (50KB)</a></li>
						<li><a href="#">Annual Report - Wilmar International Ltd 2011-2012 (50KB)</a></li>
						<li><a href="#">Annual Report - Wilmar International Ltd 2010-2011 (117KB)</a></li>
					</div>
					</div>
				</div>						   
			</div>-->
			<?php if (!empty($sccs)): ?>
			<div class="col-md-12 suply-chain" style="width:799px; padding-right:0px; max-width:915px; padding-bottom:30px; border-bottom: 1px solid #dedede; padding-top:24px;">
				<h4 class="subsection-heading">Supply Chain Certification</h4>
				<div class="table-responsive" style="padding-top:16px;">
					<?php $this->load->view('partials/scc'); ?>
				</div>	 
			</div>	
			<?php endif; ?>
			
			<div class="col-md-8 col-sm-8 col-xs-12 text-left" style="width:800px; max-width:915px; padding-left:0px;">
				<?php if ( $member->q1 OR $member->q2 OR $member->q3 OR $member->q4 ): ?>
					<style>
						.m_question, .m_answer {
							padding: 0 0 10px 30px;
							position: relative;
						}
						.m_question {
							color: #999999;
						}
						.m_answer {
							display: none;
							padding-bottom: 20px;
						}
						.m_question i.fa, .m_answer i.fa {
							position: absolute;
							left: 0;
							top: 5px;
						}
					</style>
					<script>
					$(document).ready(function(){
					  
					$('a#show_all').click(function(e){
						e.preventDefault();
						$('.m_answer').slideToggle('fast', function(){
							if ($('.m_answer').css('display')=='none')
							{
								$('html, body').animate({
									scrollTop: ($("#member_question").offset().top * 1) - 100
								}, 200);
							}
						});
					});
					  
					});
					</script>
					<div class="member-report" id="member_question" style="padding-bottom:30px;">
						<h4 class="subsection-heading">Organisation's Commitments Toward Sustainability</h4> 
						<div class="list-reports">

						<?php if ($member->q1): ?>
						<li>
							<div class="m_question"><i class="fa fa-lg fa-question-circle"></i>How will your organisation promote the RSPO internally and to other stakeholders?</div>
							<div class="m_answer">
								<!-- <i class="fa fa-lg fa-pencil-square"></i> -->
								<?php echo nl2br(str_ireplace('\\', '', $member->q1)); ?>
							</div>
						</li>
						<?php endif; ?>

						<?php if ($member->q2): ?>
						<li>
							<div class="m_question"><i class="fa fa-lg fa-question-circle"></i>Where relevant, what processes is the organisation establishing to engage with interested parties, for example to resolve conflict or to use sustainably produced palm oil?</div>
							<div class="m_answer">
								<!-- <i class="fa fa-lg fa-pencil-square"></i> -->
								<?php echo nl2br(str_ireplace('\\', '', $member->q2)); ?>
							</div>
						</li>
						<?php endif; ?>

						<?php if ($member->q3): ?>
						<li>
							<div class="m_question"><i class="fa fa-lg fa-question-circle"></i>Where relevant, how will your organisation work towards implementing the RSPO Principles and Criteria or assessing supplier performance against these criteria?</div>
							<div class="m_answer">
								<!-- <i class="fa fa-lg fa-pencil-square"></i> -->
								<?php echo nl2br(str_ireplace('\\', '', $member->q3)); ?>
							</div>
						</li>
						<?php endif; ?>

						<?php if ($member->q4): ?>
						<li>
						<div class="m_question"><i class="fa fa-lg fa-question-circle"></i>Any other information that would support the application such as what your organisation hopes to gain from joining RSPO and how it would support RSPO?</div>
						<div class="m_answer">
						<!-- <i class="fa fa-lg fa-pencil-square"></i> -->
						<?php echo nl2br(str_ireplace('\\', '', $member->q3)); ?>
						</div>
						</li>
						<?php endif; ?>
						</div>
						<a href="#" id="show_all" class="btn btn-sm btn-primary">View all responses</a>
					</div>
					<?php endif; ?>
			</div>
			
			<div class="col-lg-12 col-md-12 tabbed-of-member bg-light-gray" style="width:799px; max-width:915px; padding:13px 20px;">
				<h4 class="subsection-heading" style="line-height:1.75">DISCLAIMER</h2>	
				<p class="member_profile" style="color:#43372c; margin-bottom:0px; line-height:1.75;">This material and accompanying data is based on submissions from RSPO members which has not been independently verified and is provided by the RSPO and authors without warranty of any kind, either expressed or implied. By making use of this material you do so at your own risk and you accept that the author shall not be liable for any claims, liabilities, losses, damages, costs or expenses of any kind arising.</p>
            </div>
		</div>			  
	</div></div>
</section>

<section id="related" class="first-section">
	<div class="container text-center">	
	</div>
</section>