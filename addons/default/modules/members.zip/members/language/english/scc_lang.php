<?php

$lang['scc:nav_scc']				= 'Supply Chain Certificate';

$lang['scc:create_title']			= 'Add SCC';
$lang['scc:edit_title']				= 'Edit SCC - %s';

$lang['scc:status_label']			= 'Status';
$lang['scc:facility_label']			= 'Certified unit/facility';
$lang['scc:member_label']			= "Member's name";
$lang['scc:supply_option_label']	= 'Supply options';
$lang['scc:application_date_label']	= 'Application date';
$lang['scc:approval_date_label']	= 'Approval date';
$lang['scc:expiry_date_label']		= 'Expiry date';
$lang['scc:files_label']			= 'Attach files';

$lang['scc:keywords_label']			= 'Search';

$lang['scc:edit_success']			= 'Supply Chain Certification for "%s" was saved successfully.';
$lang['scc:edit_error']				= 'Error saving Supply Chain Certification for "%s".';
$lang['scc:add_error']				= 'Error saving Supply Chain Certification. Please try again.';

$lang['scc:delete_success']			= 'SCC "%s" has been deleted.';
$lang['scc:mass_delete_success']	= 'SCCs "%s" have been deleted.';
$lang['scc:delete_error']           = 'No SCCs were deleted.';


$lang['scc:scc_not_exist_error']	= 'The Supply Chain Certificate you like to see is not available.';
