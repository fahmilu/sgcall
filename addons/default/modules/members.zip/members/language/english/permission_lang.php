<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['members:role_approve_member']	= 'Approve member';
$lang['members:role_edit_member']		= 'Edit member data';
$lang['members:role_delete_member'] 	= 'Delete member';
$lang['members:role_add_member'] 		= 'Add member';
$lang['members:role_view_member'] 		= 'View draft member';

$lang['members:role_add_scc'] 			= 'Add member\'s SCC';
$lang['members:role_edit_scc'] 			= 'Edit member\'s SCC';
$lang['members:role_delete_scc'] 		= 'Delete member\'s SCC';

$lang['members:role_add_pnc'] 			= 'Add member\'s P&C';
$lang['members:role_edit_pnc'] 			= 'Edit member\'s P&C';
$lang['members:role_delete_pnc'] 		= 'Delete member\'s P&C';

$lang['members:role_add_pnc_type'] 			= 'Add P&C type';
$lang['members:role_edit_pnc_type'] 			= 'Edit P&C type';
$lang['members:role_delete_pnc_type'] 		= 'Delete P&C type';

$lang['members:role_add_complaints']			=	'Add Complaints';
$lang['members:role_edit_complaints']			=	'Edit Complaints';
$lang['members:role_delete_complaints']		=	'Delete Complaints';

$lang['members:role_add_cb']			=	'Add Certification bodies';
$lang['members:role_edit_cb']			=	'Edit Certification bodies';
$lang['members:role_delete_cb']		=	'Delete Certification bodies';