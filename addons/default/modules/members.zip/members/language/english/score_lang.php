<?php

$lang['score:nav_score']				= 'ACOP Score Card';

$lang['score:create_title']			= 'Upload Score Card';
$lang['score:edit_title']			= 'Edit Score Card - %s';

$lang['score:status_label']			= 'Status';
$lang['score:facility_label']			= 'Certified unit/facility';
$lang['score:member_label']			= "Member's name";
$lang['score:supply_option_label']	= 'Supply options';
$lang['score:application_date_label']	= 'Application date';
$lang['score:approval_date_label']	= 'Approval date';
$lang['score:expiry_date_label']		= 'Expiry date';
$lang['score:files_label']			= 'Upload Score Card file';

$lang['score:keywords_label']			= 'Search';

$lang['score:edit_success']			= 'Score Card for "%s" was updated successfully.';
$lang['score:create_success']			= 'Score Card for "%s" was saved successfully.';
$lang['score:edit_error']				= 'Error updating Score Card for "%s".';
$lang['score:create_error']				= 'Error saving Score Card. Please try again.';

$lang['score:delete_success']			= 'Score Card for "%s" has been deleted.';
$lang['score:mass_delete_success']	= 'Score Card for "%s" have been deleted.';
$lang['score:delete_error']           = 'No scores were deleted.';


$lang['score:score_not_exist_error']	= 'The Score Card you like to see is not available.';
