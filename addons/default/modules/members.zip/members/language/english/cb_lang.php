<?php

// admin menus
$lang['cb:cb_title']				= 'Certification Bodies';
$lang['cb:create_title']			= 'Add Certification Body';
$lang['cb:edit_title']				= 'Edit Certification Body "%s"';


$lang['cb:status_label']			= 'Status';
$lang['cb:certification_label']		= 'RSPO certification provided';
$lang['cb:accreditation_label']		= 'Accreditation';
$lang['cb:cb_number_label']			= 'CB Number';
$lang['cb:name_label']				= 'Certification Body';
$lang['cb:slug_label']				= 'Slug';	
$lang['cb:pic_and_position_label']	= 'Contact person & position';	
$lang['cb:phone_label']				= 'Office phone number (with area code)';
$lang['cb:mobile_label']			= 'Mobile phone number (with area code)';
$lang['cb:fax_label']				= 'Fax number (with area code)';
$lang['cb:email_label']				= 'Email';
$lang['cb:website_label']			= 'Website';
$lang['cb:address_label']			= 'Complete Address';
$lang['cb:country_label']			= 'Country';
$lang['cb:geographical_label']		= 'Geographical Area';
$lang['cb:red_auditor_label']		= 'RSPO-RED Editor';
$lang['cb:website_label']			= 'Website';

$lang['cb:add_success']				= 'Certification Body "%s" was added successfully.';
$lang['cb:add_error']				= 'Sorry, error saving the Certification Body.';

$lang['cb:edit_success']			= 'Certification Body "%s" was saved successfully.';
$lang['cb:edit_error']				= 'Sorry, error saving "%s".';

$lang['cb:already_exist_error']		= 'Sorry, Certification Body "%s" already exists.';


$lang['cb:empty_cbs_msg']			= 'Certification Body database is still empty.';
$lang['cb:cb_does_not_exist']		= 'Sorry, the Certification Body does not exist.';

$lang['cb:delete_success']			= 'Certification "%s" has been deleted.';
$lang['cb:mass_delete_success']	= 'Certification "%s" have been deleted.';
$lang['cb:delete_error']           = 'No Certification were deleted.';
