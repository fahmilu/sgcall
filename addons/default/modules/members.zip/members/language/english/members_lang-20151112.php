<?php

// admin menus
$lang['members:nav_membership']			=	'Membership';
$lang['members:nav_membership_submenu']	=	'Membership Application';
$lang['members:nav_call_for_comments']	=	'Call for Comments';
$lang['members:nav_pnc_assessment']		=	'P&amp;C Assessment';
$lang['members:nav_pnc_assessment_type']=	'P&amp;C Assessment Type';
$lang['members:nav_scc']				=	'Supply Chain Certification';
$lang['members:nav_cb']					=	'Certification Bodies';
$lang['members:nav_trademark']			=	'Trademark Application';
$lang['members:nav_complaints']			=	'Membership Complaints';
$lang['members:nav_pcc']				=	'NI/NPP Comments';
(SITE_REF=='bcn'? $lang['members:nav_sh_certification_inquiries']	=	'Smallholders Inquiries' : $lang['members:nav_sh_certification_inquiries']	=	'SH & Certification Inquiries');

$lang['members:pnc_add_label']			=	'Add Assessment';
$lang['members:pnctype_add_label']		=	'Add Type';
$lang['members:scc_add_label']			=	'Add SCC';
$lang['members:cb_add_label']			=	'Add CB';


// tabs
$lang['members:tab_status']				= 'Membership Status';
$lang['members:tab_about']				= 'About the Organisation';
$lang['members:tab_contact']			= 'Contact Details';
$lang['members:tab_questions']			= 'Questions';
$lang['members:tab_documents']			= 'Supporting Documents';

$lang['members:members_title']			=	'Membership';
$lang['members:create_title']			=	'Create';
$lang['members:edit_title']				=	'Edit - %s';


$lang['members:members_label']			=	'Members';
$lang['members:members_add_label']		=	'Add Member';

$lang['members:status_label']			=	'Status';
$lang['members:approved_date_label']	=	'Approved Date';
$lang['members:type_label']				=	'Membership Type';
$lang['members:category_label']			=	'Membership Category';


$lang['members:approved_label']			=	'Approved';
$lang['members:expired_label']			=	'Expired';

// messages
$lang['members:empty_membership_msg']		=	'Sorry, membership database is still empty';
$lang['members:member_not_exist_error']		=	'Sorry, that member does not exist';

$lang['members:member_save_success']		=	'Member "%s" was updated successfully.';
$lang['members:member_save_error']			=	'Sorry, error saving member "%s"';

$lang['members:delete_error']				=	'Failed deleting member.';
$lang['members:delete_success']				=	'Member "%s" was marked as deleted.';
$lang['members:mass_delete_success']		=	'Members "%s" were marked as deleted.';

