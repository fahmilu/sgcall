<?php

// admin menus
$lang['pnc:nav_membership']			= 'Membership';
$lang['pnc:nav_call_for_comments']	= 'Call for Comment';
$lang['pnc:nav_pnc_assessment']		= 'P&amp;C Assessment';
$lang['pnc:nav_scc']				= 'Supply Chain Certificate';

$lang['pnc:create_title']			= 'Add P&amp;C Certification';
$lang['pnc:edit_title']				= 'Edit P&amp;C Certification - %s';

$lang['pnc:status_label']			= 'Status';
$lang['pnc:mill_label']				= 'Mill';
$lang['pnc:member_label']			= 'Member';
$lang['pnc:cb_label']				= 'Certification Body';
$lang['pnc:assessment_type_label']	= 'Assessment Type';
$lang['pnc:assessment_status_label']	= 'Assessment Status';
$lang['pnc:date_notification_label']	= 'Notification Date';
$lang['pnc:date_assessment_label']		= 'Assessment Date';
$lang['pnc:sub_remarks_label']			= 'Sub Remarks';
$lang['pnc:file_certificate_label']		= 'Certificate';
$lang['pnc:file_notification_label']	= 'Notification';
$lang['pnc:file_public_summary_report_label'] = 'Public summary report';
$lang['pnc:date_final_report_label']	= 'Final Report Date';
$lang['pnc:remarks_label']			= 'Remarks';
$lang['pnc:date_report_accepted']	= 'Report Accepted Date';

$lang['pnc:keywords_label']			= 'Search';

$lang['pnc:edit_success']			= 'P&amp;C Assessment for "%s" was saved successfully.';
$lang['pnc:edit_error']				= 'Error saving P&amp;C Assessment for "%s".';
$lang['pnc:add_error']				= 'Error saving P&amp;C Assessment. Please try again.';

// p&c types & form labels
$lang['pnc:assessment_type_label']	= 'Assessment Type';
$lang['pnc:stage_label']			= 'Stage';
$lang['pnc:description_label']		= 'Description';
$lang['pnc:position_label']			= 'Position';

$lang['pnc:type_create_title']		= 'Create Type';
$lang['pnc:type_edit_title']		= 'Edit Type "%s"';

$lang['pnc:type_add_error']			= 'Error saving P&amp;C Assessment Type';
$lang['pnc:type_add_edit_success']	= 'P&amp;C Assessment Type "%s" was saved successfully';
$lang['pnc:type_edit_error']		= 'Error editing P&amp;C Assessment Type';

$lang['pnc:delete_success']			= 'Certification "%s" has been deleted.';
$lang['pnc:mass_delete_success']	= 'Certification "%s" have been deleted.';
$lang['pnc:delete_error']           = 'No Certification were deleted.';