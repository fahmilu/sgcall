<?php

// admin menus
$lang['members:nav_membership']			=	'Membership';
$lang['members:nav_membership_submenu']	=	'Membership Application';
$lang['members:nav_call_for_comments']	=	'Call for Comments';
$lang['members:nav_pnc_assessment']		=	'Certified Companies';//'P&amp;C Assessment';
$lang['members:nav_pnc_assessment_type']=	'P&amp;C Assessment Type';
$lang['members:nav_scc']				=	'Supply Chain Certification';
$lang['members:nav_cb']					=	'Certification Bodies';
$lang['members:nav_gm']					=	'Group Memberships';
$lang['members:nav_score']				=	'ACOP Score Card';
$lang['members:nav_trademark']			=	'Trademark Application';
$lang['members:nav_complaints']			=	'Membership Complaints';
$lang['members:nav_survey']				=	'GM Statistics';
$lang['members:nav_pcc']				=	'NI/NPP Comments';
(SITE_REF=='bcn'? $lang['members:nav_sh_certification_inquiries']	=	'Smallholders Inquiries' : $lang['members:nav_sh_certification_inquiries']	=	'SH & Certification Inquiries');

$lang['members:pnc_add_label']			=	'Add Assessment';
$lang['members:pnctype_add_label']		=	'Add Type';
$lang['members:scc_add_label']			=	'Add SCC';
$lang['members:score_add_label']		=	'Add Score Card';
$lang['members:cb_add_label']			=	'Add CB';
$lang['members:gm_add_label']			=	'Add GM';


// tabs
$lang['members:tab_status']				= 'Membership Status';
$lang['members:tab_about']				= 'About the Organisation';
$lang['members:tab_contact']			= 'Contact Details';
$lang['members:tab_questions']			= 'Questions';
$lang['members:tab_documents']			= 'Supporting Documents';

$lang['members:members_title']			=	'Membership';
$lang['members:create_title']			=	'Create';
$lang['members:edit_title']				=	'Edit - %s';


$lang['members:members_label']			=	'Members';
$lang['members:members_add_label']		=	'Add Member';

$lang['members:status_label']			=	'Status';
$lang['members:approved_date_label']	=	'Approved Date';
$lang['members:type_label']				=	'Membership Type';
$lang['members:category_label']			=	'Membership Category';


$lang['members:approved_label']			=	'Approved';
$lang['members:expired_label']			=	'Expired';

// messages
$lang['members:empty_member_data']			=	'Sorry, membership database is still empty';
$lang['members:empty_membership_msg']		=	'Sorry, membership database is still empty';
$lang['members:member_not_exist_error']		=	'Sorry, that member does not exist';

$lang['members:member_save_success']		=	'Member "%s" was updated successfully.';
$lang['members:member_save_error']			=	'Sorry, error saving member "%s"';

$lang['members:delete_error']				=	'Failed deleting member.';
$lang['members:delete_success']				=	'Member "%s" was marked as deleted.';
$lang['members:mass_delete_success']		=	'Members "%s" were marked as deleted.';

$lang['members:reg_email_already_used']		=	'The email address you entered is already registered in our system. Please enter a different one.';
$lang['members:reg_email_activation_msg']	=	'Thank you for registering to RSPO website. For verification purpose, we sent an email to you with a link and instructions how to activate your account. Please check your mailbox, and if necessary check your junk mail box in case your email system mistakenly identifies it as spam.';
$lang['reg_email_activation_error_msg']		= 'Sorry, the activation email could not be sent.';
