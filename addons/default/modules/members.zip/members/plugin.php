<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * CFC Plugin
 *
 * Create lists of comments
 * 
 */
class Plugin_Members extends Plugin
{
	public $version = '2.25';
	public $name = array(
		'en' => 'Membership',
	);
	public $description = array(
		'en' => 'Membership related plugin',
	);

	public $countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Honduras", "Hong Kong S.A.R", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macao S.A.R", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan Region", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vatican City", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");

	function __construct()
	{
		$this->db->set_dbprefix('default_');
		$this->load->model(array('members_m', 'pnc_m'));
	}

	function __destruct()
	{
		$this->db->set_dbprefix(SITE_REF.'_');
	}

	public function cfc()
	{
		$limit		= $this->attribute('limit', 5);
		$charlimit 	= (int)$this->attribute('char-limit', 100);
		$order_by 	= $this->attribute('order-by', 'expiry_date');
		$order_dir 	= 'desc';
		
		$members = $this->pyrocache->model('members_m', 'get_many_by', array( array(
			'status'		=> 'Call for Comment',
			'limit'			=> array($limit, 0),
			'expired'		=> true,
			'order_by'		=> $order_by,
			'order_dir'		=> $order_dir,
		) ) );

		foreach($members as $m)
		{
			$m->url = 'members/call-for-comments/comment/'.$m->intID.'/'.url_title($m->title);
			$m->title = strtok(wordwrap($m->title, 30, "...\n"), "\n");
		}

		return $members;
	}

	public function pnc()
	{
		$limit		= $this->attribute('limit', 5);
		$charlimit 	= (int)$this->attribute('char-limit', 100);
		$order_by 	= $this->attribute('order-by', 'notification_end');
		$order_dir 	= 'desc';

        $thirtydays = 31*60*60*24;
		
/*
		$members = $this->pyrocache->model('pnc_m', 'get_many_by', array( array(
			'limit'			=> array($limit, 0),
			'order_by'		=> $order_by,
			'order_dir'		=> $order_dir,
		) ) );
*/

		$members = $this->pnc_m->get_many_by( array(
				'limit'			=> array($limit, 0),
				'order_by'		=> $order_by,
				'order_dir'		=> $order_dir,
			)
		);

		
		foreach($members as $m)
		{
			$m->member_name = strtok(wordwrap($m->member_name, 25, "...\n"), "\n");
			$m->url = site_url('members/'.$m->mid.'/'.url_title($m->member_name));
			//$m->assesment_date_extended = $m->assessment_date ? $m->assessment_date + $thirtydays: '--';
			$m->notification_end_date_extended = $m->notification_end ? $m->notification_end : '--';

			$counter = 0;
			foreach($m->mill as $i=>$mill){
				//echo 'counter: '.$counter.' - ';
				if($counter == 0) {
					$firstMill = str_replace("'", "'", $mill->mill);
				}
				$counter++;
			}
			
			$m->urlFilter = site_url('certification/public-announcement?keywords='.urlencode(addslashes($firstMill)));
		}
		
		return $members;
	}

	/**
	 * Get random members
	 *
	 *
	**/
	public function get_random_logo()
	{
		$limit		= $this->attribute('limit', 6);
		$ret = $this->members_m->get_random_logo(array('limit'=>$limit));
		foreach($ret as $r)
		{
			$ids[] = $r->intID;
		}

		if (!empty($ret))
		{
			foreach($ret as $i=>$r)
			{
				// --> aslinya$logo = 'http://rspo.org'. ( substr($r->logo, 0, 8) <> 'ma/logo/' ? '' : '/') . $r->logo ;
				$logo = ( substr($r->logo, 0, 8) <> 'ma/logo/' ? '' : '/') . $r->logo ;

				$imageexists = $this->_logo_exists($logo);
				if (!$imageexists)
				{
//echo "(before) \$r->logo: ".$r->logo. "; logo: $logo<br />";
//echo "(before) first \$imageexists: $imageexists<br /><br />";
					$x = 1;
					while(!$imageexists)
					{
						$ret[$i] = $this->_get_another_logo($ids);
						// --> aslinya $logo = 'http://rspo.org'. ( substr($ret[$i]->logo, 0, 8) <> 'ma/logo/' ? '' : '/') . $ret[$i]->logo ;
						$logo = ( substr($ret[$i]->logo, 0, 8) <> 'ma/logo/' ? '' : '/') . $ret[$i]->logo ;
						$imageexists = $this->_logo_exists( $logo);
//echo "(after) \$r->logo: ".$ret[$i]->logo. "; logo: $logo<br />";
//echo "(after) first \$imageexists: $imageexists<br />";

//echo "- x: $x<br />";
//echo "- logo: $logo<br />";
//echo "- \$imageexists: $imageexists<br />";

						$x++;
						if ($x==10) break;
					}
					$ret[$i]->logo = $logo;
					if(SITE_REF=='bcn'){
						$ret[$i]->link_url = 'http://rspo.org/members/'.$ret[$i]->intID.'/'.url_title($ret[$i]->title);
					}else{
						$ret[$i]->link_url = site_url('members/'.$ret[$i]->intID.'/'.url_title($ret[$i]->title));
					}
					//$ret[$i]->link_url = site_url('members/'.$ret[$i]->intID.'/'.url_title($ret[$i]->title));
				}
				else
				{
					$r->logo = $logo;
					if(SITE_REF=='bcn'){
						$r->link_url = 'http://rspo.org/members/'.$r->intID.'/'.url_title($r->title);
					}else{
						$r->link_url = site_url('members/'.$r->intID.'/'.url_title($r->title));
					}
					//$r->link_url = site_url('members/'.$r->intID.'/'.url_title($r->title));
				}
				//$r->link_url = $r->website ? (substr($r->website, 0, 7) <> 'http://' ? 'http://'.$r->website : $r->website) : NULL;
			}
		}

		return $ret;
	}

	private function _logo_exists($url)
	{
		$homedir = 'public_html';
		$root_dir = $_SERVER['DOCUMENT_ROOT'];
//echo "\$root_dir: $root_dir$url<br />";
//exit;
		$ret = @file_exists($root_dir.$url) AND @is_file($root_dir.$url) AND @filesize($root_dir.$url);
/*
echo "<!-- \n";
echo " - \$root_dir.\$url: $root_dir.$url<br />";
echo " - \$ret: $ret<br />\n";
echo "\n -->\n";
*/
		if ($ret)
			return true;
		else
			return false;
/*
		if (!empty($logo))
		{
			return true;
		}
		return false;
*/
	}

	private function _get_another_logo($ids)
	{
		$ret = $this->members_m->get_random_logo(array('limit'=>1, 'not-id'=>$ids));
		return $ret[0];
	}

	public function scc_search_bar()
	{
		$countries = array(""=>"All countries/regions");
		if ($this->countries)
		{
			foreach($this->countries as $c)
			{
				$countries[$c] = $c;
			}

			$this->template
				->set('countries', $countries);
		}
		else
		{
			echo "Countries/Regions config not detected<br />\n";
		}

$ret = '
<style>
		.dropdown-menu {
			margin-top: 0px;
			border-radius: 0px;
		}
		.bootstrap-select > .btn {
			width: 100%;
			padding-right: 25px;
		}
		.form-control {
			display: block;
			/* width: 100%;
			height: 34px; */
			padding: 6px 12px;
			font-size: 14px;
			line-height: 1.42857;
			color: #555;
			background-color: #FFF;
			background-image: none;
			border: 1px solid #CCC;
			border-radius: 0px;
			box-shadow: none;
			transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
		}
		.bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
			width: 100%;
		}
		.btn {
			padding: 9.4px 20px;
			font-size:13px;
			font-weight:600;
			border: 1px solid #ddd;
			border-radius: 0px;
		}
		
		.btn:hover, .btn:focus {
			color: #FFF;
			text-decoration: none;
			background: none repeat scroll 0% 0% #FF6500;
			border: 1px solid #FF6500;
		}
		.search-form input, .search-form div, .search-form button {
			border-radius: 0px;
			margin: 0px -2px 0px 0px;
			font-size: 13px;
			min-height: 40px;
			border-color: #ddd;
		}
	</style>
            <div class="row" style="padding-top:30px;">
				<div class="text-center" id="container-cari">
				<form target="'.(SITE_REF=='bcn' ? '_blank' : '') .'"  action="'. (SITE_REF=='bcn' ? 'http://www.rspo.org/certification/supply-chain-certificate-holders' : site_url('certification/supply-chain-certificate-holders')).'" method="get" style="width:none;" name="latinonlycn" onsubmit="return chinacheckchar()">	
						<div>
							<div class="col-lg-12 col-md-12 col-sm-12" style="padding-bottom:10px; padding-left:0px; padding-right:0px;">
								<div class="col-lg-7 col-md-7 col-sm-7" style="padding-left:0px; padding-right:1px;">
									<input type="text" class="form-control input-member-keyword" id="input-keyword-certification" placeholder="'.(SITE_REF=='bcn' ? '请输入英文' : 'Type keywords here').'" value="" name="keywords" style="width:100%;">
								</div>
								<div class="col-lg-3 col-md-3 col-sm-3" style="padding-left:0px; padding-right:1px;">
								';

							$ret .= form_dropdown('country', $countries, '', 'class="selectpicker" title="Country/Region"');

							$ret .='
								</div>
								<div class="col-lg-2 col-md-2 col-sm-2" style="padding-left:0px; padding-right:1px;">
									<button type="submit" class="btn btn-primary btn-orange pull-left '.(SITE_REF=='bcn' ? 'go-to-scc' : '').'" style="border-radius:0px 3px 3px 0px; border-color:transparent; width:100%;">'.(SITE_REF=='bcn' ? '搜索' : 'Search').'</button>
								</div>
							</div>
						';

						$ret .= '
						<div class="col-lg-12 col-md-12 col-sm-12" style="padding-left:0px; padding-right:0px;">
								<div class="col-lg-3 col-md-3 col-sm-3" style="padding-left:0px; padding-right:1px; text-align:left;">
									<label style="font-weight:normal;"><input type="checkbox" name="supply_options[]" value="Identity Preserved"><span style="padding-left:10px;">'.(SITE_REF=='bcn' ? '身份保留' : 'Identity Preserved').'</span></label>
								</div>
								<div class="col-lg-3 col-md-3 col-sm-3" style="padding-left:0px; padding-right:1px; text-align:left;">
									<label style="font-weight:normal;"><input type="checkbox" name="supply_options[]" value="Segregated"><span style="padding-left:10px;">'.(SITE_REF=='bcn' ? '隔离' : 'Segregated').'</span></label>
								</div>
								<div class="col-lg-3 col-md-3 col-sm-3" style="padding-left:0px; padding-right:1px; text-align:left;">
									<label style="font-weight:normal;"><input type="checkbox" name="supply_options[]" value="Mass Balance"><span style="padding-left:10px;">'.(SITE_REF=='bcn' ? '质量平衡' : 'Mass Balance').'</span></label>
								</div>
							</div>
						</div>
				</form>
                </div>
			</div>
			';

		return $ret;
	}
	
	public function pandc_search_bar()
	{
		$this->load->model(array('pnc_m', 'members_m'));

		$assessments = $this->pnc_m->get_assessment_type();
		$ass_type[] = "Assessment type";
		foreach($assessments as $a)
		{
			$ass_type[$a->id] = $a->stage;
		}
		
		$sts = $this->pnc_m->get_assessment_status();
		$pnc_statuses[] = "Status";
		foreach($sts as $s)
		{
			$idx = strtolower($s->status);
			$pnc_statuses[$idx] = $s->status;
		}

		$this->template
			->set('year_approved', array_combine($year_approved = range(2008, date('Y')), $year_approved))
			->set('notification_date', array_combine($notification_date = range(2013, date('Y')), $notification_date))
			->set('ass_type', $ass_type)
			->set('pnc_statuses', $pnc_statuses);
	
		$countries = array(""=>"All countries/regions");
		if ($this->countries)
		{
			foreach($this->countries as $c)
			{
				$countries[$c] = $c;
			}

			$this->template
				->set('countries', $countries);
		}
		else
		{
			echo "Countries/Regions config not detected<br />\n";
		}

$ret = '
<style>
		.dropdown-menu {
			margin-top: 0px;
			border-radius: 0px;
		}
		.bootstrap-select > .btn {
			width: 100%;
			padding-right: 25px;
		}
		.form-control {
			display: block;
			/* width: 100%;
			height: 34px; */
			padding: 6px 12px;
			font-size: 14px;
			line-height: 1.42857;
			color: #555;
			background-color: #FFF;
			background-image: none;
			border: 1px solid #CCC;
			border-radius: 0px;
			box-shadow: none;
			transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
		}
		.bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
			width: 100%;
		}
		.btn {
			padding: 9.4px 20px;
			font-size:13px;
			font-weight:600;
			border: 1px solid #ddd;
			border-radius: 0px;
		}
		
		.btn:hover, .btn:focus {
			color: #FFF;
			text-decoration: none;
			background: none repeat scroll 0% 0% #FF6500;
			border: 1px solid #FF6500;
		}
		.search-form input, .search-form div, .search-form button {
			border-radius: 0px;
			margin: 0px -2px 0px 0px;
			font-size: 13px;
			min-height: 40px;
			border-color: #ddd;
		}
	</style>
            <div class="row" style="padding-top:30px;">
			<?php if (!empty($pncs)): ?>
                <div class="text-center" id="container-cari">
					<form target="'.(SITE_REF=='bcn' ? '_blank' : '').'"  action="'. (SITE_REF=='bcn' ? 'http://www.rspo.org/certification/principles-and-criteria-assessment-progress' : site_url('certification/principles-and-criteria-assessment-progress')).'" method="get" style="width:none;" name="latinonlycn_pnc" onsubmit="return chinacheckchar_pnc()">
                        <div class="row">
						<div class="cotainer-full">
                            <div>
								<div class="col-lg-12 col-md-12 col-sm-12" style="padding-bottom:10px; padding-left:0px; padding-right:0px;">
									<div class="col-lg-10 col-md-10 col-sm-10" style="padding-left:0px; padding-right:1px;">
										<input type="text" name="keywords" class="form-control input-member-keyword" id="input-keyword" placeholder="'.(SITE_REF=='bcn' ? '请输入英文' : 'Type keywords here').'" style="width:100%;">
									</div>
									<div class="col-lg-2 col-md-2 col-sm-2" style="padding-left:0px; padding-right:1px;">
										<button type="submit" class="btn btn-primary btn-orange pull-left '.(SITE_REF=='bcn' ? 'go-to-pnc' : '').'" style="border-radius:0px 3px 3px 0px; border-color:transparent; width:100%;">'.(SITE_REF=='bcn' ? '搜索' : 'Search').'</button>
									</div>
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12" style="padding-left:0px; padding-right:0px;">
									<div class="col-lg-2 col-md-2 col-sm-2" style="padding-left:0px; padding-right:1px; width:20%;">
';

$ret .= form_dropdown('country', $countries, '', 'class="selectpicker" title="Country/Region"');

$ret .= '
						</div>
									<div class="col-lg-2 col-md-2 col-sm-2" style="padding-left:0px; padding-right:1px; width:13%;">';
$ret .= form_dropdown('pnc_status', $pnc_statuses, !empty($base_where['pnc_status']) ? $base_where['pnc_status'] : '', 'class="selectpicker form-control" style="height:45px; width:100%"');

$ret .= '							</div>
									<div class="col-lg-2 col-md-2 col-sm-2" style="padding-left:0px; padding-right:1px; width:22%;">';
$ret .= form_dropdown('assessment_type', $ass_type, !empty($base_where['assessment_type']) ? $base_where['assessment_type'] : '', 'class="selectpicker form-control" style="height:45px; width:100%"');

$ret .= '									</div>
									<div class="col-lg-2 col-md-2 col-sm-2" style="padding-left:0px; padding-right:1px; width:21%">';
$ret .= form_dropdown('year_approved', array(""=>"Year approved")+$year_approved, !empty($base_where['year_approved']) ? $base_where['year_approved'] : '', 'class="selectpicker form-control" style="height:45px; width:100%"');
$ret .= '									</div>
									<div class="col-lg-2 col-md-2 col-sm-2" style="padding-left:0px; padding-right:1px; width:24%;">';
$ret .= form_dropdown('notification_date', array(""=>"Notification date")+$notification_date, !empty($base_where['notification_date']) ? $base_where['notification_date'] : '', 'class="selectpicker form-control" style="height:45px; width:100%"');
$ret .= '									</div>
								</div>  
									
								<div class="radio-options pull-left  text-right">
										<!--
                                        <input type="checkbox" name="" value="">&nbsp;Identity Preserved&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="checkbox" name="" value="">&nbsp;Segregated&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="checkbox" name="" value="">&nbsp;Mass Balance&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="checkbox" name="" value="">&nbsp;Show expired Supply Chain Sertification
										-->
								</div>                                                           
                            </div>                        
                        </div>                        
                        </div>                        
                    </form>
                </div>
            </div>
';

		return $ret;

	}

	/**
	 * List
	 *
	 * Creates a list of members
	 *
	 * Usage:
	 * {{ members:posts order-by="title" limit="5" }}
	 *		<h2>{{ title }}</h2>
	 *		<p> {{ body }} </p>
	 * {{ /members:posts }}
	 *
	 * @param	array
	 * @return	array
	 */
	public function posts()
	{
		$wordlimit	= (int)$this->attribute('word-limit');
		$charlimit 	= (int)$this->attribute('char-limit'); 
		$limit		= $this->attribute('limit', 10);
		$category	= $this->attribute('category');
		$notcategory= $this->attribute('notcategory');
		$order_by 	= $this->attribute('order-by', 'created_on');
		$order_dir	= $this->attribute('order-dir', 'DESC');
		$offset		= $this->attribute('offset');
		$break		= $this->attribute('break');
		$socmed		= $this->attribute('share', 0);
		$first_image= $this->attribute('first-image', 0);
		$nointro	= $this->attribute('no-intro', 0);
		//$headline	= $this->attribute('headline', 1);

		$mostread	= $this->attribute('mostread', NULL);

		$where = $yr = '';

		$this->load->helper('filename');


		$categories = NULL;
		if ($category)
		{
			$array_cats = array();
			$categories = explode('|', $category);
			foreach($categories as $cat)
			{
				$array_cats[] = array('category'=>$cat);
			}
		}

/*
		if ($notcategory)
		{
			$notcategories = explode('|', $notcategory);
			$notcategory = array_shift($notcategories);

			$this->db->where('news_categories.' . (is_numeric($category) ? 'id' : 'slug') . ' !=', $notcategory);

			foreach($notcategories as $ncategory)
			{
				$this->db->where('news_categories.' . (is_numeric($ncategory) ? 'id' : 'slug') . ' != ', $ncategory);
			}
		}
*/

		$posts = $this->pyrocache->model('articles_m', 'get_many_by', array( array(
			'status'		=> 'live',
			'limit'			=> array($limit, $offset ? $offset : 0),
			'category'		=> $categories,
			'mostread'		=> $mostread,
			'order_by'		=> $order_by,
			'order_dir'		=> $order_dir,
			'where'			=> $where
		) ) );


/*
		$posts = $this->db
			->select('news.*')
			->select('news_categories.title as category_title, news_categories.slug as category_slug')
			->select('p.display_name as author_name')
			->where('status', 'live')
			->where('created_on <=', now())
			->join('news_categories', 'news.category_id = news_categories.id', 'left')
			->join('profiles p', 'news.author_id = p.user_id', 'left')
			->order_by('news.' . $order_by, $order_dir)
			->limit($limit, $offset ? $offset : 0)
			->get('news')
			->result();
*/

		if ($first_image)
		{
			$index = 1;
		}

		foreach ($posts as &$post)
		{
			$intro = '';
			$post->url = site_url('news/'.date('Y', $post->created_on).'/'.date('m', $post->created_on).'/'.$post->slug);
			if ($post->lead) $post->intro = $post->lead;
			$post->intro = strip_tags($post->intro);
			$post->short_intro = word_limiter($post->intro, 35);
			if ($nointro)
			{
				$post->intro = $post->short_intro = NULL;
			}
			if ($charlimit)
			{
				$post->intro = character_limiter($post->intro, $charlimit);
/*
echo "<pre>\n";
echo "intro: " . $post->intro . "\n";
echo "char: " . strlen($post->intro) . "\n";
echo "\n --------------------------------- \n";
echo "</pre>\n";
*/
			}
			else
			{
				if ($wordlimit === -1)
					$post->intro = $post->intro;
				elseif ($wordlimit > 0)
					$post->intro = word_limiter($post->intro, $wordlimit);
				else
					$post->intro = word_limiter($post->intro, 35);
			}
//			$post->intro = $wordlimit === 0 ? $post->intro : $wordlimit > 0 ? word_limiter($post->intro, $wordlimit) : word_limiter($post->intro, 40);
			$post->date = date('d/m/Y H:i', $post->created_on);
			$post->date_only = date('d F Y', $post->created_on);
			$post->hours = date('H:i', $post->created_on);

				$post->class = "active";
				$post->thumbnail = $post->attachment ? UPLOAD_PATH . 'articles/'. thumbnail($post->attachment) : '';
				$post->first_class = $this->attribute('first-class', '');

/*
echo "<pre>\n";
print_r($post);
echo "</pre>\n";
*/
/*
			if ($first_image)
			{
				if (!empty($index) && $index <> 1)
					$post->thumbnail = NULL;
				else
				{
					if(!empty($index) && $index == 1)
						$post->thumbnail = $post->attachment ? UPLOAD_PATH . 'news/'. ($post->attachment) : '';
					else
						$post->thumbnail = $post->attachment ? UPLOAD_PATH . 'news/'. thumbnail($post->attachment) : '';
				}
				$index++;
			}
			else
			{
				$post->thumbnail = $post->attachment ? UPLOAD_PATH . 'news/'. ($post->attachment) : '';
			}
*/
			$post->socmed = $socmed;
		}

		return $posts;
	}

	public function popular()
	{
		$wordlimit	= (int)$this->attribute('word-limit');
		$charlimit 	= (int)$this->attribute('char-limit'); 
		$limit		= $this->attribute('limit', 10);
		$break		= $this->attribute('break');
		$socmed		= $this->attribute('share', 0);
		$first_image= $this->attribute('first-image', 0);
		$nointro	= $this->attribute('no-intro', 0);
		$offset		= $this->attribute('offset');
		$category	= $this->attribute('category', 0);
		$notcategory= $this->attribute('notcategory', 0);

		$mostread	= 1;

		$where = $yr = '';

//		if ($mostread)
//		{
			$order_by = 'viewed';
			$order_dir = 'desc';
			$yr = date('Y');
//			$this->db->where("FROM_UNIXTIME(created_on, '%Y') = $yr");
			//$this->db->where('( viewed > 50 AND viewed < 200 )');
//		}

		$this->load->helper('filename');

		$posts = $this->pyrocache->model('news_m', 'get_many_by', array( array(
			'status'		=> 'live',
			'limit'			=> array($limit, $offset ? $offset : 0),
			'mostread'		=> $mostread,
			'order_by'		=> $order_by,
			'order_dir'		=> $order_dir,
			'where'			=> $where,
			'year'			=> $yr
		) ) );

		if ($first_image)
		{
			$index = 1;
		}

		foreach ($posts as &$post)
		{
			$intro = '';
			$post->url = site_url('news/'.date('Y', $post->created_on).'/'.date('m', $post->created_on).'/'.$post->slug);
			if ($post->lead) $post->intro = $post->lead;
			$post->intro = strip_tags($post->intro);
			$post->short_intro = word_limiter($post->intro, 35);
			if ($nointro)
			{
				$post->intro = $post->short_intro = NULL;
			}
			if ($charlimit)
			{
				$post->intro = character_limiter($post->intro, $charlimit);
			}
			else
			{
				if ($wordlimit === -1)
					$post->intro = $post->intro;
				elseif ($wordlimit > 0)
					$post->intro = word_limiter($post->intro, $wordlimit);
				else
					$post->intro = word_limiter($post->intro, 35);
			}

			$post->date = date('d/m/Y H:i', $post->created_on);
			$post->date_only = date('d/m/Y', $post->created_on);
			$post->hours = date('H:i', $post->created_on);

			if (!empty($index) && $index == 1)
			{
				$post->thumbnail = $post->attachment ? UPLOAD_PATH . 'news/'. ($post->attachment) : '';
				$post->first_class = $this->attribute('first-class', '');
				$index++;
			}
			else
			{
				$post->thumbnail = $post->first_class =  $post->intro = NULL;
			}

			$post->socmed = $socmed;
		}

		return $posts;
	}

	public function headlines()
	{


		$wordlimit	= (int)$this->attribute('word-limit');
		$charlimit 	= (int)$this->attribute('char-limit'); 
		$limit		= $this->attribute('limit', 10);
		$category	= $this->attribute('category');
		$notcategory= $this->attribute('notcategory');
		$order_by 	= $this->attribute('order-by', 'created_on');
		$order_dir	= $this->attribute('order-dir', 'DESC');
		$offset		= $this->attribute('offset');
		$break		= $this->attribute('break');
		$headline	= $this->attribute('headlines', 1);

		$mostread	= $this->attribute('mostread', NULL);

		$where = '';

		if ($mostread)
		{
			$order_by = 'viewed';
			$order_dir = 'desc';
		}

		$this->load->helper('filename');

		if ($category)
		{
			$array_where = array();
			$categories = explode('|', $category);
			foreach($categories as $category)
			{
				$array_where[] = $this->db->dbprefix('news_categories') . '.' . (is_numeric($category) ? 'id' : 'slug') . ' = \'' . $category . '\'';
			}

			$where = ' ( ' . implode(' OR ', $array_where) . ' ) ';
		}

		if ($notcategory)
		{
			$notcategories = explode('|', $notcategory);
			$notcategory = array_shift($notcategories);

			$this->db->where('news_categories.' . (is_numeric($category) ? 'id' : 'slug') . ' !=', $notcategory);

			foreach($notcategories as $ncategory)
			{
				$this->db->or_where('news_categories.' . (is_numeric($ncategory) ? 'id' : 'slug') . ' != ', $ncategory);
			}
		}

		$posts = $this->pyrocache->model('news_m', 'get_many_by', array( array(
			'status'		=> 'live',
			'limit'			=> array($limit, $offset ? $offset : 0),
			'headline'		=> 1,
			'where'			=> $where
		) ) );

		$index = 1;
		foreach ($posts as &$post)
		{
			if ($index === 1)
			{
				$post->active = 'active';
				$index = 2;
			}
			else
				$post->active = '';
			$post->url = site_url('news/'.date('Y', $post->created_on).'/'.date('m', $post->created_on).'/'.$post->slug);
			if ($post->lead) $post->intro = $post->lead;
			$post->short_intro = word_limiter($post->intro, 35);
			if ($charlimit)
			{
				$post->intro = character_limiter($post->intro, $charlimit);
			}
			else
			{
				if ($wordlimit === -1)
					$post->intro = $post->intro;
				elseif ($wordlimit > 0)
					$post->intro = word_limiter($post->intro, $wordlimit);
				else
					$post->intro = word_limiter($post->intro, 35);
			}
			$post->date = date('d/m/Y H:i', $post->created_on);
			$post->thumbnail = $post->attachment ? UPLOAD_PATH . 'news/'. thumbnail($post->attachment) : '';
			$post->image = $post->attachment ? UPLOAD_PATH . 'news/'. ($post->attachment) : '';
		}
		
		return $posts;
	}

	public function homeslider()
	{
		$wordlimit	= (int)$this->attribute('word-limit');
		$charlimit 	= (int)$this->attribute('char-limit'); 
		$limit		= $this->attribute('limit', 10);
		$category	= $this->attribute('category');
		$order_by 	= $this->attribute('order-by', 'created_on');
		$order_dir	= $this->attribute('order-dir', 'DESC');
		$offset		= $this->attribute('offset');
		$break		= $this->attribute('break');
		$column		= $this->attribute('column');
		$mostread	= $this->attribute('mostread', NULL);
		$notcategory= $this->attribute('notcategory');
		$class		= ' class="'.$this->attribute('li-class').'" ';
		$dateclass 	= $this->attribute('dateclass', 'icon-calendar-empty');

		if ($mostread)
		{
			$order_by = 'viewed';
			$order_dir = 'desc';
		}

		if ($notcategory)
		{
			$array_notcats = array();
			$notcategories = explode('|', $notcategory);
			foreach($notcategories as $cat)
			{
				$array_notcats[] = $cat;
			}
		}


		$this->load->helper('filename');

		$result = array();

		$posts = $this->pyrocache->model('news_m', 'get_many_by', array( array(
			'status'		=> 'live',
			'notcategory'	=> $array_notcats,
			'limit'			=> array($limit, $offset ? $offset : 0),
		) ) );

		$retdiv = '';

		if (!empty($posts))
		{
			$idx = 1;
			foreach($posts as $r)
			{
				if ($r->lead) $r->intro = $r->lead;
				if ($idx == 1)
				{
					$retdiv .= '
							<li '.$class.'>
								<!-- <div class="li-items"> -->
					';
				}
				if ($idx <> ($break+1))
				{
					$retdiv .= '
									<div class="li-items">';
					$r->url = site_url('news/'.date('Y', $r->created_on).'/'.date('m', $r->created_on).'/'.$r->slug);
					$retdiv .= '<h5><small><i class="'.$dateclass.'"></i> '.date('d/m/Y', $r->created_on) . ' <i class="fa fa-clock-o"></i> '.date('H:i', $r->created_on).'</small><br /><a href="'.$r->url.'">'.$r->title.'</a></h5>'.PHP_EOL;
					$retdiv .= '
									</div>
					';
					$idx++;
				}
				if ($idx == ($break+1))
				{
					$retdiv .= '
								<!-- </div> -->
							</li>
					';
					$idx = 1;
				}
			} // endforeach

			if ($idx <> 1)
			{
					$retdiv .= '
								<!-- </div> -->
							</li>
					';
			}
			return $retdiv;
		}

	}

	/**
	 * Categories
	 *
	 * Creates a list of news categories
	 *
	 * Usage:
	 * {{ news:categories order-by="title" limit="5" }}
	 *		<a href="{{ url }}" class="{{ slug }}">{{ title }}</a>
	 * {{ /news:categories }}
	 *
	 * @param	array
	 * @return	array
	 */
	public function categories()
	{
		$limit		= $this->attribute('limit');
		$order_by 	= $this->attribute('order-by', 'title');
		$order_dir	= $this->attribute('order-dir', 'ASC');

		if ($limit) $this->db->limit($limit);

		$categories = $this->db
			->select('title, slug')
			->order_by($order_by, $order_dir)
			->get('news_categories')
			->result();

		foreach ($categories as &$category)
		{
			$category->url = site_url('news/category/'.$category->slug);
		}
		
		return $categories;
	}

	/**
	 * Count Posts By Column
	 *
	 * Usage:
	 * {{ news:count_posts author_id="1" }}
	 *
	 * The attribute name is the database column and 
	 * the attribute value is the where value
	 */
	public function count_posts()
	{
		$wheres = $this->attributes();
		unset($wheres['parse_params']);

		// make sure they provided a where clause
		if (count($wheres) == 0) return FALSE;

		$category	= $this->attribute('category');
		$array_where[] = array();

/*
		if ($category)
		{
			$categories = explode('|', $category);
			$category = array_shift($categories);

			$this->db->where('news_categories.' . (is_numeric($category) ? 'id' : 'slug'), $category);

			foreach($categories as $category)
			{
				$this->db->or_where('news_categories.' . (is_numeric($category) ? 'id' : 'slug'), $category);
			}
			unset($wheres['category']);
		}
*/

		if ($category)
		{
			$array_where = array();
			$categories = explode('|', $category);
			foreach($categories as $category)
			{
				$array_where[] = $this->db->dbprefix('news_categories') . '.' . (is_numeric($category) ? 'id' : 'slug') . ' = \'' . $category . '\'';
			}
		}

		foreach ($wheres AS $column => $value)
		{
			$array_where[] = "$column = '$value'";
			//$this->db->where($column, $value);
		}

		$where = '';
		if (!empty($array_where))
			$where = ' ( ' . implode(' OR ', $array_where) . ' ) ';

		return $this->pyrocache->model('news_m', 'count_by', array( array(
			'status'		=> 'live',
			'where'			=> $where
		) ) );


/*
		return $this->db
			->select('news.*')
			->select('news_categories.title as category_title, news_categories.slug as category_slug')
			->where('status', 'live')
			->where('created_on <=', now())
			->join('news_categories', 'news.category_id = news_categories.id', 'left')
			->count_all_results('news');
*/
	}

	function detail()
	{
		$detail = $this->attribute('detail', 'name');
		if (!empty($this->current_user->id))
		{
			$mid = $this->current_user->id;
			$ret = $this->db->where('MemberID_2', $mid)->get('membership')->row();
			if ($detail == 'name')
			{
				if (!$ret->name) $name = $ret->title;
				else $name = $ret->name;
				echo $name;
			}
			return !empty($ret->{$detail}) ? $ret->{$detail} : '';
		}
	}

}

/* End of file plugin.php */