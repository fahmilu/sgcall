<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Certification_bodies extends Public_Controller
{

	protected $country_arrays = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Honduras", "Hong Kong S.A.R", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macao S.A.R", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan Region", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vatican City", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");

	protected $section = 'cb';

	public function __construct()
	{
		parent::__construct();
		
		//db prefix default to join db
		$this->db->set_dbprefix('default_');
		
		$this->load->model(array('cb_m', 'members_m'));
		$this->load->config('config');

		$cb_certifications = array(
				'scc'=>'Supply Chain Certificate',
				'pnc'=>'Principles and Criteria',
		);

		foreach($this->country_arrays as $c)
		{
			$countries[$c] = $c;
		}

		$this->template
			->set('countries', $countries)
			->set('cb_certifications', $cb_certifications);
	}
	
	function __destruct()
	{
		$this->db->set_dbprefix(SITE_REF.'_');
	}
	
	public function index()
	{
		$slug = NULL;
		if ($slug)
		{
			$this->_view($slug);
		}	
		else
		{
			//set the base/default where clause
			$base_where = array('status' => 'live');
			
			//add get values to base_where if f_module is posted
			if ($this->input->get('country'))
				$base_where['country'] = $this->input->get('country');
			
			if ($this->input->get('keywords'))
				$base_where['keywords'] = $this->input->get('keywords');
				
			if ($this->input->get('certification'))
				$base_where['certification'] = $this->input->get('certification');
			
			if ($this->input->get('red'))
				$base_where['red'] = $this->input->get('red');
			
			// Create pagination links
			$total_rows = $this->pyrocache->model('cb_m', 'count_by', array( $base_where ) );
			$pagination = create_pagination('certification/bodies/page/', $total_rows, NULL, 4);

			//$base_where['limit'] = array($pagination['limit'], $pagination['offset']);

			// Using this data, get the relevant results
			$cbs = $this->pyrocache->model('cb_m', 'get_many_by', array( array('limit'=>array($pagination['limit'], $pagination['offset']))+$base_where ) );

			//do we need to unset the layout because the request is ajax?
			$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

			if(SITE_REF == "bcn"){
				$this->template
				->title('RSPO批准认证机构名录')
				//->append_js('admin/filter.js')
				->set_breadcrumb('RSPO认证', 'certification')
				->set_breadcrumb('RSPO批准认证机构名录')
				->set('base_where', $base_where)
				->set('pagination', $pagination)
				->set('cbs', $cbs)
				->build('cb/index-cn');
				
				$this->db->set_dbprefix('default_');
			}else{
				$this->template
				->title('Certification Bodies')
				//->append_js('admin/filter.js')
				->set_breadcrumb('Certification', 'certification')
				->set_breadcrumb('Certification Bodies')
				->set('base_where', $base_where)
				->set('pagination', $pagination)
				->set('cbs', $cbs)
				->build('cb/index');
			}
		}

	}

	private function _view($slug)
	{
		$slug or redirect('members');

		$member = $this->members_m->get_by(array('intID'=>$slug, 'status'=>'Approved', 'isDeleted'=>'0'));
		if (!empty($member))
		{
			$this->template
				->title($member->name)
				//->append_js('admin/filter.js')
				->set('member', $member);
	
			$this->input->is_ajax_request() ? $this->template->build('ajax/view') : $this->template->build('view');
		}
		else
		{
			$this->session->set_flashdata('error', lang('members:member_not_exist_error'));
			redirect('members');
		}

	}

}