<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Admin_survey extends Admin_Controller
{
	protected $section = 'survey';

	protected $categories;
	protected $member_categories;

	public function __construct()
	{
		parent::__construct();

		$this->db->set_dbprefix('default_');

		$this->load->model('members_m');
		$this->lang->load('members');

		$this->categories = array(
			'om' => array(
				'Banks and Investors',
				'Consumer Goods Manufacturers',
				'Environmental or Nature Conservation Organisations (Non Governmental Organisations)',
				'Oil Palm Growers',
				'Palm Oil Processors and/or Traders',
				'Retailers',
				'Social or Development Organisations (Non Governmental Organisations)',
			),
			'am' => array(
				'Associations',
				'Individuals',
				'Organisations'
			),
			'asc'=> array(
				//'Organisations',
				'Supply Chain Associate',
				'Supply Chain Group Manager'
			)
		);
		$this->member_categories = array(
				'Banks and Investors'=>'Banks and Investors',
				'Consumer Goods Manufacturers'=>'Consumer Goods Manufacturers',
				'Environmental or Nature Conservation Organisations (Non Governmental Organisations)'=>'Environmental or Nature Conservation Organisations (Non Governmental Organisations)',
				'Oil Palm Growers'=>'Oil Palm Growers',
				'Palm Oil Processors and/or Traders'=>'Palm Oil Processors and/or Traders',
				'Retailers'=>'Retailers',
				'Social or Development Organisations (Non Governmental Organisations)'=>'Social or Development Organisations (Non Governmental Organisations)',
				'Individuals'=>'Individuals',
				'Organisations'=>'Organisations',
				'Supply Chain Associate'=>'Supply Chain Associate',
				'Supply Chain Group Manager'=>'Supply Chain Group Manager',
		);

		$this->subcategories = array(
			'Oil Palm Growers' => array(
				'SmallGrower',
				'Smallholder Group Manager'
			),
			'Consumer Goods Manufacturers' => array(
				'Refinery, Edible oils and Food ingredients processors',
				'Only Trading, Logistics and Distributions',
				'Power, Energy and Bio-fuel',
				'Chemicals, Surfactants, and Non-Food ingredients processors',
				'Across the POSC (Plantation, Mill Refining, Trading, Manufacturing & Retailing)',
				'Others'
			),
			'Palm Oil Processors and/or Traders' => array(
				'Refinery, Edible oils and Food ingredients processors',
				'Only Trading, Logistics and Distributions',
				'Power, Energy and Bio-fuel',
				'Chemicals, Surfactants, and Non-Food ingredients processors',
				'Across the POSC (Plantation, Mill Refining, Trading, Manufacturing & Retailing)',
				'Others'
			),
			'Environmental or Nature Conservation Organisations (Non Governmental Organisations)' => array(
				"NGO's"
			),
			'Social or Development Organisations (Non Governmental Organisations)' => array(
				"NGO's"
			),
			'Individuals' => array(
				"Refinery, Edible oils and Food ingeredients processors",
				"Only Trading, Logistics and Distributions",
				"Power, Energy and Bio-fuel",
				"Chemicals, Surfactants, and Non-Food ingredients processors",
				"Across the POSC (Plantation, Mill Refining, Trading, Manufacturing & Retailing)",
				"Others"
			),
			'Supply Chain Associate' => array(
				"Refinery, Edible oils and Food ingeredients processors",
				"Only Trading, Logistics and Distributions",
				"Power, Energy and Bio-fuel",
				"Chemicals, Surfactants, and Non-Food ingredients processors",
				"Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)",
				"Others"
			),
			'Organisations' => array(
				"Refinery, Edible oils and Food ingeredients processors",
				"Only Trading, Logistics and Distributions",
				"Power, Energy and Bio-fuel",
				"Chemicals, Surfactants, and Non-Food ingredients processors",
				"Across the POSC (Plantation, Mill Refining, Trading, Manufacturing & Retailing)",
				"Others"
			),
		);

/*
	    $this->types_reversed = array(
	      ''=>'Select type',
	      'Ordinary Members'=>'om',
	      'Affiliate Members'=>'am',
	      'Associate'=>'asc',
	    );

	    $this->types = array(
	      ''=>'Select type',
	      'om'=>'Ordinary Members',
	      'am'=>'Affiliate Members',
	      'asc'=>'Associate',
	    );

	    $this->types_sf = array(
	      ''=>'Select type',
	      'Ordinary'=>'Ordinary Members',
	      'Affiliate'=>'Affiliate Members',
	      'Supply Chain'=>'Supply Chain Associate',
	    );

	    $this->member_types = array(
	      ''=>'Select type',
	      'Ordinary Members'=>'Ordinary Members',
	      'Affiliate Members'=>'Affiliate Members',
	      'Supply Chain Associate'=>'Supply Chain Associate',
	    );
*/
	    $this->types_reversed = array(
	      ''=>'Select type',
	      'Ordinary'=>'om',
	      'Affiliate'=>'am',
	      'Associate'=>'asc',
	    );

	    $this->types = array(
	      ''=>'Select type',
	      'om'=>'Ordinary',
	      'am'=>'Affiliate',
	      'asc'=>'Associate',
	    );

	    $this->types_sf = array(
	      ''=>'Select type',
	      'Ordinary'=>'Ordinary',
	      'Affiliate'=>'Affiliate',
	      'Associate'=>'Associate',
	    );

	    $this->member_types = array(
	      ''=>'Select type',
	      'Ordinary'=>'Ordinary',
	      'Affiliate'=>'Affiliate',
	      'Associate'=>'Associate',
	    );


		$this->subcat_growers = array(
			'Smallholder Group Manager', 
			'SmallGrower'
		);

		$this->subcat_others = array(
			''=>'Select subcategory',
			'Refinery, Edible oils and Food ingredients processors',
			'Only Trading, Logistics and Distributions',
			'Power, Energy and Bio-fuel',
			'Chemicals, Surfactants, and Non-Food ingredients processors',
			'Across the POSC (Plantation, Mill Refining, Trading, Manufacturing & Retailing)'
		);
		
		$this->subcat_popt = array(
			''=>'Select subcategory',
			'Refinery, Edible oils and Food ingredients processors',
			'Only Trading, Logistics and Distributions',
			'Power, Energy and Bio-fuel',
			'Chemicals, Surfactants, and Non-Food ingredients processors',
			'Across the POSC (Plantation, Mill Refining, Trading, Manufacturing & Retailing)',
			'Others'
		);

		$this->membership_status = array(
			''=>'Select status',
			'Applied'	=> 'Applied',
			'Call for Comment'	=> 'Call for Comment',
			'Due Diligence'		=> 'Due Diligence',
			'Invoicing'		=> 'Invoicing',
			'Pending'	=> 'Pending',
			'Inactive'	=> 'Inactive',
			'Cancelled'	=> 'Cancelled',
			'Accepted'	=> 'Accepted',
			'Active'	=> 'Active',
			'Suspended'	=> 'Suspended',
			'Terminated'=> 'Terminated',
			'Withdrawn' => 'Withdrawn',
			'Resigned'	=> 'Resigned',
			'Deleted'	=> 'Deleted',
			// these two are used only by CMS
			'Approved'	=> 'Approved',
			'Draft'		=> 'Draft',
		);

		$count = $this->members_m->count_all();

/*
		foreach($this->country_arrays as $c)
		{
			$countries[$c] = $c;
		}
*/

		$this->config_upload = array(
			'upload_path' 	=> UPLOAD_PATH . 'memberlogos',
			'allowed_types' => 'gif|jpg|png|pdf',
			'max_size' 		=> '20000',
			'remove_spaces'		=> TRUE,
			'overwrite'			=> FALSE,
			'encrypt_name'		=> FALSE,
		);
		

/*
		$this->template
			->set('country_arrays', $countries)
			->set('count', $count)
			->set('member_categories', $this->member_categories)
			->set('categories', $this->categories)
			->set('member_types', $this->member_types)
			->set('types_sf', $this->types_sf)
			->set('types', $this->types)
			->set('types_reversed', $this->types_reversed)
			->set('member_subcategories', $this->subcategories)
			->set('membership_status', $this->membership_status)
			->set('subcat_growers', $this->subcat_growers)
			->set('subcat_others', $this->subcat_others)
			->set('subcat_popt', $this->subcat_popt);
*/
	}

	function __destruct()
	{
		$this->db->set_dbprefix(SITE_REF.'_');
	}

	public function index()
	{
		$acop_start = mktime(23,59,59,3,16,2017);
		// total registration
		// - by category
		// - by country
		// - by sector

		// by category starts
		$sql = "
			SELECT type as thekey, COUNT(*) as total_members
			FROM default_users
			INNER JOIN default_membership ON default_users.id = default_membership.MemberID_2
			WHERE created_on > $acop_start AND (default_membership.status = 'Approved' OR default_membership.status = 'Suspended') AND (title not like '%catalyze%' and title not like '%penyaringan%')
			GROUP BY type
		";

		$total = 0;
		//echo "<h2>Total registration by Category:</h2>";
		$query = $this->db->query($sql);
		if ($query)
		{
			$members = $query->result();
			$this->template->set('tr_category', $members);

/*
			foreach($members as $m)
			{
				//echo $m->type . ': '.$m->total_members.'<br />'.PHP_EOL;
				$total += $m->total_members;
			}
*/
			//echo "--------------------------------------------------------------<br />\n";
			//echo "<b>Total: $total</b><br />";
		}
		else
		{
			print_r($this->db->error());
		}
		// by category ends
		//echo "<hr />\n";


		// by sector starts
		$sql = "
			SELECT category as thekey, COUNT(*) as total_members
			FROM default_users
			INNER JOIN default_membership ON default_users.id = default_membership.MemberID_2
			WHERE created_on > $acop_start AND (default_membership.status = 'Approved' OR default_membership.status = 'Suspended') AND (title not like '%catalyze%' and title not like '%penyaringan%')
			GROUP BY category
		";

		$total = 0;
		//echo "<h2>Total registration by Sector:</h2>";
		$query = $this->db->query($sql);
		if ($query)
		{
			$members = $query->result();
			$this->template->set('tr_sector', $members);

/*
			foreach($members as $m)
			{
				echo $m->category . ': '.$m->total_members.'<br />'.PHP_EOL;
				$total += $m->total_members;
			}
			echo "--------------------------------------------------------------<br />\n";
			echo "<b>Total: $total</b><br />";
*/
		}
		else
		{
			print_r($this->db->error());
		}
		// by category ends
		//echo "<hr />\n";


		// by country starts
		$sql = "
			SELECT country as thekey, COUNT(*) as total_members
			FROM default_users
			INNER JOIN default_membership ON default_users.id = default_membership.MemberID_2
			WHERE created_on > $acop_start AND (default_membership.status = 'Approved' OR default_membership.status = 'Suspended') AND (title not like '%catalyze%' and title not like '%penyaringan%')
			GROUP BY country
		";

		$total = 0;
		//echo "<h2>Total registration by Country:</h2>";
		$query = $this->db->query($sql);
		if ($query)
		{
			$members = $query->result();
			$this->template->set('tr_country', $members);

/*
			foreach($members as $m)
			{
				echo $m->country . ': '.$m->total_members.'<br />'.PHP_EOL;
				$total += $m->total_members;
			}
			echo "--------------------------------------------------------------<br />\n";
			echo "<b>Total: $total</b><br />";
*/
		}
		else
		{
			print_r($this->db->error());
		}

		// survey completed by category starts
		$sql = "
			SELECT type as thekey, COUNT(*) as total_members
			FROM default_membership
			WHERE survey = '1' AND (default_membership.status = 'Approved' OR default_membership.status = 'Suspended') AND (title not like '%catalyze%' and title not like '%penyaringan%')
			GROUP BY type
		";

		$total = 0;
		//echo "<h2>Survey completed by Category:</h2>";
		$query = $this->db->query($sql);
		if ($query)
		{
			$members = $query->result();
			$this->template->set('sc_category', $members);

/*
			foreach($members as $m)
			{
				echo $m->type . ': '.$m->total_members.'<br />'.PHP_EOL;
				$total += $m->total_members;
			}
			echo "--------------------------------------------------------------<br />\n";
			echo "<b>Total: $total</b><br />";
*/
		}
		else
		{
			print_r($this->db->error());
		}
		// by category ends
		//echo "<hr />\n";

		// survey completed by category starts
		$sql = "
			SELECT category as thekey, COUNT(*) as total_members
			FROM default_membership
			WHERE survey = '1' AND (default_membership.status = 'Approved' OR default_membership.status = 'Suspended') AND (title not like '%catalyze%' and title not like '%penyaringan%')
			GROUP BY category
		";

		$total = 0;
		//echo "<h2>Survey completed by Sector:</h2>";
		$query = $this->db->query($sql);
		if ($query)
		{
			$members = $query->result();
			$this->template->set('sc_sector', $members);

/*
			foreach($members as $m)
			{
				echo $m->category . ': '.$m->total_members.'<br />'.PHP_EOL;
				$total += $m->total_members;
			}
			echo "--------------------------------------------------------------<br />\n";
			echo "<b>Total: $total</b><br />";
*/
		}
		else
		{
			print_r($this->db->error());
		}
		// survey completed by category ends
		//echo "<hr />\n";


		// survey completed by category starts
		$sql = "
			SELECT country as thekey, COUNT(*) as total_members
			FROM default_membership
			WHERE survey = '1' AND (default_membership.status = 'Approved' OR default_membership.status = 'Suspended') AND (title not like '%catalyze%' and title not like '%penyaringan%')
			GROUP BY country
		";

		$total = 0;
		//echo "<h2>Survey completed by Sector:</h2>";
		$query = $this->db->query($sql);
		if ($query)
		{
			$members = $query->result();
			$this->template->set('sc_country', $members);

/*
			foreach($members as $m)
			{
				echo $m->category . ': '.$m->total_members.'<br />'.PHP_EOL;
				$total += $m->total_members;
			}
			echo "--------------------------------------------------------------<br />\n";
			echo "<b>Total: $total</b><br />";
*/
		}
		else
		{
			print_r($this->db->error());
		}
		// survey completed by category ends
		//echo "<hr />\n";


		// survey as parent by category starts
		$sql = "
			SELECT type as thekey, COUNT(*) as total_members
			FROM default_membership
			WHERE survey = '1' AND parent_company != '' AND (default_membership.status = 'Approved' OR default_membership.status = 'Suspended') AND (title not like '%catalyze%' and title not like '%penyaringan%')
			GROUP BY type
		";
		$total = 0;
		//echo "<h2>Survey completed as parent by Category:</h2>";
		$query = $this->db->query($sql);
		if ($query)
		{
			$members = $query->result();
			$this->template->set('sc_parent_category', $members);

/*
			foreach($members as $m)
			{
				echo $m->type . ': '.$m->total_members.'<br />'.PHP_EOL;
				$total += $m->total_members;
			}
			echo "--------------------------------------------------------------<br />\n";
			echo "<b>Total: $total</b><br />";
*/
		}
		else
		{
			print_r($this->db->error());
		}
		// survey as parent by category ends
		//echo "<hr />\n";


		// survey as parent by sector starts
		$sql = "
			SELECT category as thekey, COUNT(*) as total_members
			FROM default_membership
			WHERE survey = '1' AND parent_company != '' AND (default_membership.status = 'Approved' OR default_membership.status = 'Suspended') AND (title not like '%catalyze%' and title not like '%penyaringan%')
			GROUP BY category
		";
		$total = 0;
		//echo "<h2>Survey completed as parent by Sector:</h2>";
		$query = $this->db->query($sql);
		if ($query)
		{
			$members = $query->result();
			$this->template->set('sc_parent_sector', $members);

/*
			foreach($members as $m)
			{
				echo $m->category . ': '.$m->total_members.'<br />'.PHP_EOL;
				$total += $m->total_members;
			}
			echo "--------------------------------------------------------------<br />\n";
			echo "<b>Total: $total</b><br />";
*/
		}
		else
		{
			print_r($this->db->error());
		}
		// survey as parent by sector ends
		//echo "<hr />\n";


		// survey as parent by country starts
		$sql = "
			SELECT country as thekey, COUNT(*) as total_members
			FROM default_membership
			WHERE survey = '1' AND parent_company != '' AND (default_membership.status = 'Approved' OR default_membership.status = 'Suspended') AND (title not like '%catalyze%' and title not like '%penyaringan%')
			GROUP BY country
		";
		$total = 0;
		//echo "<h2>Survey completed as parent by Sector:</h2>";
		$query = $this->db->query($sql);
		if ($query)
		{
			$members = $query->result();
			$this->template->set('sc_parent_country', $members);

/*
			foreach($members as $m)
			{
				echo $m->category . ': '.$m->total_members.'<br />'.PHP_EOL;
				$total += $m->total_members;
			}
			echo "--------------------------------------------------------------<br />\n";
			echo "<b>Total: $total</b><br />";
*/
		}
		else
		{
			print_r($this->db->error());
		}
		// survey as parent by country ends
		//echo "<hr />\n";


		// total survey in draft by category starts
		$sql = "
			SELECT default_membership.type as thekey, COUNT(*) as total_members
			FROM default_membership
			INNER JOIN default_membership_temp ON default_membership_temp.intID = default_membership.intID
			WHERE default_membership.survey != 1 AND (default_membership.status = 'Approved' OR default_membership.status = 'Suspended') AND (default_membership.title not like '%catalyze%' and default_membership.title not like '%penyaringan%')
			GROUP BY default_membership.type
		";

		$total = 0;
		//echo "<h2>Total draft survey by Category:</h2>";
		$query = $this->db->query($sql);
		if ($query)
		{
			$members = $query->result();
			$this->template->set('draft_category', $members);

/*
			foreach($members as $m)
			{
				echo $m->type . ': '.$m->total_members.'<br />'.PHP_EOL;
				$total += $m->total_members;
			}
			echo "--------------------------------------------------------------<br />\n";
			echo "<b>Total: $total</b><br />";
*/
		}
		else
		{
			print_r($this->db->error());
		}
		// total survey in draft by category ends

		// total survey in draft by sector starts
		$sql = "
			SELECT default_membership.category as thekey, COUNT(*) as total_members
			FROM default_membership
			INNER JOIN default_membership_temp ON default_membership_temp.intID = default_membership.intID
			WHERE default_membership.survey != 1 AND (default_membership.status = 'Approved' OR default_membership.status = 'Suspended') AND (default_membership.title not like '%catalyze%' and default_membership.title not like '%penyaringan%')
			GROUP BY default_membership.category
		";

		$total = 0;
		//echo "<h2>Total draft survey by Sector:</h2>";
		$query = $this->db->query($sql);
		if ($query)
		{
			$members = $query->result();
			$this->template->set('draft_sector', $members);

/*
			foreach($members as $m)
			{
				echo $m->category . ': '.$m->total_members.'<br />'.PHP_EOL;
				$total += $m->total_members;
			}
			echo "--------------------------------------------------------------<br />\n";
			echo "<b>Total: $total</b><br />";
*/
		}
		else
		{
			$this->template->set('draft_sector_error', $this->db->error());
		}
		// total survey in draft by sector ends


		// total survey in draft by sector starts
		$sql = "
			SELECT default_membership.country as thekey, COUNT(*) as total_members
			FROM default_membership
			INNER JOIN default_membership_temp ON default_membership_temp.intID = default_membership.intID
			WHERE default_membership.survey != 1 AND (default_membership.status = 'Approved' OR default_membership.status = 'Suspended') AND (default_membership.title not like '%catalyze%' and default_membership.title not like '%penyaringan%')
			GROUP BY default_membership.country
		";

		$total = 0;
		//echo "<h2>Total draft survey by Sector:</h2>";
		$query = $this->db->query($sql);
		if ($query)
		{
			$members = $query->result();
			$this->template->set('draft_country', $members);

/*
			foreach($members as $m)
			{
				echo $m->category . ': '.$m->total_members.'<br />'.PHP_EOL;
				$total += $m->total_members;
			}
			echo "--------------------------------------------------------------<br />\n";
			echo "<b>Total: $total</b><br />";
*/
		}
		else
		{
			$this->template->set('draft_sector_error', $this->db->error());
		}
		// total survey in draft by sector ends

		$this->template->build('admin/survey');

	}

	public function pick($id=0)
	{
		$q = $this->input->get('term');
		$res = $this->members_m->get_many_by_name($q);
		foreach($res as $m)
		{
			$members[] = array('value'=>$m->title, 'id'=>$m->intID);
		}

		echo json_encode($members);
	}




}