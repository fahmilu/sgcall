<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Admin_gm extends Admin_Controller
{
	protected $section = 'gm';



	public function __construct()
	{
		parent::__construct();

		// Load all the required classes
		$this->load->model('subsidiaries_m');
		$this->load->model('subsidiaries_log_m');
		$this->load->library('form_validation');
		$this->load->library('pagination');
		$this->load->library('zip');
		$this->load->helper("file");
		$this->load->helper('user');

		// Set the validation rules
		$this->item_validation_rules = array(
			array(
				'field' => 'id',
				'label' => 'id',
				'rules' => ''
			),
			array(
				'field' => 'gm_sf_id',
				'label' => 'gm_sf_id',
				'rules' => 'required'
			),
			array(
				'field' => 'account_sf_id',
				'label' => 'account_sf_id',
				'rules' => 'required'
			),
		);

		$this->upload_cfg = array(
				'allowed_types'		=> 'csv', //implode('|', $allowed_extensions),
				'upload_path'       => UPLOAD_PATH . 'members/',
				'max_size'			=> '10000',
				'remove_spaces'		=> TRUE,
				'overwrite'			=> FALSE,
				'encrypt_name'		=> TRUE,
			);

			$this->check_dir($this->upload_cfg['upload_path']);

		// We'll set the partials and metadata here since they're used everywhere
		$this->template
		->append_js('module::datatables.min.js')
		->append_css('module::bootstrap.css')
		->append_css('module::font-awesome.min.css')
		->append_css('module::datatables.min.css');
	}

	function check_dir($dir) {
			// check directory
			$fileOK = array();
			$fdir = explode('/', $dir);
			$ddir = '';
			for($i=0; $i<count($fdir); $i++)
			{
				$ddir .= $fdir[$i] . '/';
				if (!is_dir($ddir))
				{
					if (!@mkdir($ddir, 0777)) {
						$fileOK[] = 'not_ok';
					}
					else
					{
						$fileOK[] = 'ok';
					}
				}
				else
				{
					$fileOK[] = 'ok';
				}
			}
			return $fileOK;

	}
	public function unlinkfile($filename) {
			$thumbfile = thumbnail($filename);

			$stat = array();
					// delete the files
					if (file_exists($this->upload_cfg['upload_path'] . '/' . $thumbfile))
					{
						if (!@unlink($this->upload_cfg['upload_path'] . '/' . $thumbfile))
						{
							$stat[] = 'error';
							$msg[] = sprintf(lang('articles_delete_img_error'), $thumbfile);
						}
					}

					if (file_exists($this->upload_cfg['upload_path'] . '/' . $filename))
					{
						if (!@unlink($this->upload_cfg['upload_path'] . '/' . $filename))
						{
							$stat[] = 'error';
							$msg[] = sprintf(lang('articles_delete_img_error'), $filename);
						}
					}

					if (in_array('error', $stat))
					{
						$status = 'error';
						$message = implode('<br />', $msg);
					}
					else
					{
						$status = 'success';
						$message = sprintf(lang('articles_delete_img_success'), $filename);
					}

		return (array($status, $message));
	}

  public function index($page = '')
 	{
 		$section = 'items';

 		$items = $this->subsidiaries_m->order_by('id','asc')->get_all();

		$group_user = $this->current_user->group_id;
 		$this->input->is_ajax_request() and $this->template->set_layout(false);

 		$this->template
 			->title($this->module_details['name'])
 			->set('section', $section)
 			->set('items', $items)
			->set('group_user',$group_user)
 			->build('admin/gm/index');
 	}
	public function log()
 	{
 		$section = 'items';

 		$items = $this->subsidiaries_log_m->order_by('id','asc')->get_all();
 		$this->template
 			->title($this->module_details['name'])
 			->set('section', $section)
 			->set('items', $items)
 			->build('admin/gm/log');
 	}
	public function import()
	 {
		 //error_reporting(0);
		 if($this->current_user->group_id == 5) $status = 0; else $status = 1;
	if (!empty($_FILES['csv']['name']) && !empty($_FILES['csv']['tmp_name'])) {
 				// Setup upload config
 				$this->load->library('upload', $this->upload_cfg);
 				// check directory exists
 				$this->check_dir($this->upload_cfg['upload_path']);

 				if ( ! $this->upload->do_upload('csv')) {

 				} else {
 					$file = $this->upload->data('');

					// import csv
					$import = $_FILES['csv']['tmp_name'];
					$handle = fopen($import,"r");
					if (($handle) !== FALSE) {
					$this->db->query("TRUNCATE TABLE default_membership_subsidiaries_log");
					$no = 1;
					while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {

						if($no > 2) :

							$query = $this->db->query("UPDATE default_membership_subsidiaries SET

								gm_sf_id = '".addslashes($data[1])."',
								account_sf_id = '".addslashes($data[2])."'

								WHERE id = '".addslashes($data[0])."'

					        ");

							if($query) {
								$text = "Updating GM CMS ID ".addslashes($data[0])."
								with Account SF ID: ".addslashes($data[2])." and GM SF ID: ".addslashes($data[1])." was successful";
								$this->db->query(" INSERT INTO default_membership_subsidiaries_log (`condition`,`description`) VALUES ('1','$text') ");
							} else {
								$text = "Updating GM CMS ID ".addslashes($data[0])."
								with Account SF ID: ".addslashes($data[2])." and GM SF ID: ".addslashes($data[1])." failed";
								$this->db->query(" INSERT INTO default_membership_subsidiaries_log (`condition`,`description`) VALUES ('0','$text') ");
							}

						endif;

					    $no++;}
					}
					fclose($handle);
					// end import


 				}
 			}

 		$this->session->set_flashdata('success', lang('alert-imported'));
 		redirect('admin/members/gm');
	 }

	public function delete($id = 0) {
			$this->subsidiaries_m->delete($id);
			$this->session->set_flashdata('error', lang('alert-delete'));
			redirect('admin/members/gm');

	}
}
