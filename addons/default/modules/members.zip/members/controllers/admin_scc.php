<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Admin_scc extends Admin_Controller
{
	protected $section = 'scc';

	protected $validation_rules = array(
		array(
			'field' => 'facility',
			'label' => 'lang:scc:facility_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'mid',
			'label' => 'lang:scc:mill_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'member_name',
			'label' => 'lang:scc:member_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'supply_options[]',
			'label' => 'lang:scc:supply_option_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'application_date',
			'label' => 'lang:scc:application_date_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'approval_date',
			'label' => 'lang:scc:approval_date_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'certification_expiry_date',
			'label' => 'lang:scc:expiry_date_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'file',
			'label' => 'lang:scc:files_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'file_2',
			'label' => 'lang:scc:files_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'file_3',
			'label' => 'lang:scc:files_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'file_text_1[]',
			'label' => 'lang:scc:files_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'file_text_2',
			'label' => 'lang:scc:files_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'file_text_3',
			'label' => 'lang:scc:files_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'online_status',
			'label' => 'lang:scc:status_label',
			'rules' => 'trim|required'
		),
	);

	protected $upload_cfg = array(
		'allowed_types'		=> 'jpg|gif|png|jpeg|pdf',
		'max_size'			=> '100000',
		'remove_spaces'		=> TRUE,
		'overwrite'			=> FALSE,
		'encrypt_name'		=> FALSE,
	);

	protected $supply_options = array(
		'B&C'		=> 'Book &amp; Claim',
		'MB'		=> 'Mass Balance',
		'SG'		=> 'Segregated',
		'IP'		=> 'Identity Preserved',
	);

	public function __construct()
	{
		parent::__construct();
		$this->load->model(array('members_m', 'scc_m'));
		$this->load->helper('filesize');
		$this->lang->load(array('members', 'scc'));

		$this->upload_cfg['upload_path'] = UPLOAD_PATH . 'scc';
	}

	public function index()
	{
		//$this->output->enable_profiler(true);
		//set the base/default where clause
		$base_where = array('status' => 'all');//, 'order'=>'created_on', 'sort'=>'desc');
		if ($this->input->post('f_status'))
		{
			$fs = $this->input->post('f_status');
			if ($fs=='draft')
				$s = 0;
			elseif ($fs=='live')
				$s = 1;
			else
				$s = 'all';
			$base_where['status'] = $s;
		}
		$base_where['status'] = $this->input->post('f_status') ? $this->input->post('f_status') : NULL;
		$base_where['keywords'] = $this->input->post('f_keywords') ? stripslashes(urldecode($this->input->post('f_keywords'))) : NULL;
		$base_where['supply_options'] = $this->input->post('f_supplyoption') ? stripslashes(urldecode($this->input->post('f_supplyoption'))) : NULL;
		
		// Create pagination links
		$total_rows = $this->scc_m->count_by($base_where);
		$pagination = create_pagination('admin/members/scc/index', $total_rows, NULL, 5);

		$base_where['limit'] = array($pagination['limit'], $pagination['offset']);

		// Using this data, get the relevant results
		//$sccs = $this->scc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
		$sccs = $this->scc_m->get_many_by($base_where);

		//do we need to unset the layout because the request is ajax?
		$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';
		
		$assessment_status = array(
			'notification'	=>'Notification',
			'assessment'	=>'Assessment',
		);
		
		//$this->output->enable_profiler(true);
		
		$this->template
			->title($this->module_details['name'])
			->append_js('admin/filter.js')
			->set('supply_options', $this->supply_options)
			->set('count', $total_rows)
			->set('pagination', $pagination)
			->set('sccs', $sccs);

		$this->input->is_ajax_request() ? $this->template->build('admin/scc/tables/scc') : $this->template->build('admin/scc/index');
	}

	public function create($mid=0)
	{
		role_or_die('members', 'add_scc');

		$scc = new stdClass();

		if ($mid)
		{
			$member = $this->members_m->get_by('intID', $mid);
			if (!empty($member))
			{
				$this->template
					->set('member_name', $member->title)
					->set('member_id', $member->intID);
			}
		}

		$this->form_validation->set_rules($this->validation_rules);


		if ($this->input->post('application_date'))
		{
			$application_date = strtotime(sprintf('%s %s:%s', $this->input->post('application_date'), 0, 0));
		}
		else
		{
			$application_date = 0;
		}

		if ($this->input->post('approval_date'))
		{
			$approval_date = strtotime(sprintf('%s %s:%s', $this->input->post('approval_date'), 0, 0));
		}
		else
		{
			$approval_date = 0;
		}

		if ($this->input->post('certification_expiry_date'))
		{
			$certification_expiry_date = strtotime(sprintf('%s %s:%s', $this->input->post('certification_expiry_date'), 0, 0));
		}
		else
		{
			$certification_expiry_date = 0;
		}

		$isUp = $this->input->post('online_status') == 'live' ? '1' : '0';

		// check directory exists
		$this->check_dir($this->upload_cfg['upload_path']);
		$this->load->library('upload', $this->upload_cfg);
		
		if (!empty($_FILES['file']['name']) )
		{
			if($this->upload->do_upload("file"))
			{
				$uploaded = $this->upload->data();
				$file = $uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$file = $this->input->post('file_text_1');
		}
		

		if (!empty($_FILES['file_2']['name']) )
		{
			if($this->upload->do_upload("file_2"))
			{
				$uploaded = $this->upload->data();
				$file_2 = $uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$file_2 = $this->input->post('file_text_2');
		}

		if (!empty($_FILES['file_3']['name']) )
		{
			if($this->upload->do_upload("file_3"))
			{
				$uploaded = $this->upload->data();
				$file_3 = $uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$file_3 = $this->input->post('file_text_3');
		}
		
		if ($this->input->post('remove_file'))
		{
			$remove = $this->input->post('remove_file');
			if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$remove) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$remove))
			{
				$file_2 = NULL;
			}
			else
			{
				$this->session->set_flashdata('info', 'Error deleting file '.$remove);
			}
		}

		if ($this->input->post('remove_file_2'))
		{
			$remove = $this->input->post('remove_file_2');
			if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$remove) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$remove))
			{
				$file_2 = NULL;
			}
			else
			{
				$this->session->set_flashdata('info', 'Error deleting file '.$remove);
			}
		}

		if ($this->input->post('remove_file_3'))
		{
			$remove = $this->input->post('remove_file_3');
			if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$remove) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$remove))
			{
				$file_3 = NULL;
			}
			else
			{
				$this->session->set_flashdata('info', 'Error deleting file '.$remove);
			}
		}

		if ($this->form_validation->run())
		{
			$input = array(
				'strAddDate'		=> date('Y-m-d', now()),
				'strAddPerson'		=> $this->current_user->id,
				'mid'				=> (int)$this->input->post('member_id'),
				'facility'			=> $this->input->post('facility'),
				'isUp'				=> $isUp,
				'supply_option'		=> $this->input->post('supply_options') ? implode(",", $this->input->post('supply_options')) : NULL,
				'application_date'	=> $application_date,
				'approval_date'		=> $approval_date,
				'certification_expiry_date'	=> $certification_expiry_date,
				'file'				=> $file,
				'file_2'			=> $file_2,
				'file_3'			=> $file_3,
				'date'				=> now(),
			);

			if ($id = $this->scc_m->insert($input))
			{
				$this->pyrocache->delete_all('scc_m');
				$this->session->set_flashdata(array('success' => sprintf(lang('scc:create_success'), $this->input->post('member_name'))));
				($this->input->post('btnAction') == 'save_exit') ? redirect('admin/members/scc') : redirect('admin/members/scc/edit/'.$id);
			}
			else
			{
				//$this->session->set_flashdata(array('error' => sprintf(lang('scc:create_error'), $this->input->post('member_name'))));
				$this->template->set('error', sprintf(lang('scc:create_error'), $this->input->post('member_name')) );
			}

			// Redirect back to the form or main page
		}

		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $key => $field)
		{
			if ($field['field'] != 'file' AND $field['field'] != 'file_2' AND $field['field'] != 'file_3')
				$scc->$field['field'] = set_value($field['field']);
		}

		$scc->application_date 			= $application_date;
		$scc->approval_date 			= $approval_date;
		$scc->certification_expiry_date = $certification_expiry_date;
		$scc->mid 						= $this->input->post('member_id');
		$scc->file 						= $file;
		$scc->file_2 					= $file_2;
		$scc->file_3 					= $file_3;
		$scc->file_text_1 				= $file;
		$scc->file_text_2 				= $file_2;
		$scc->file_text_3 				= $file_3;
		$scc->supply_option 			= $this->input->post('supply_options') ? implode("\r\n", $this->input->post('supply_options')) : NULL;

		$scc->isUp = $isUp;

		$this->template
			//->append_metadata($this->load->view('fragments/wysiwyg', array(), TRUE))
			->set('supply_options', $this->supply_options)
			->set('scc', $scc)
			->build('admin/scc/form');
	}
	
	public function view($id=0)
	{
		$scc = $this->scc_m->get($id);
		
		//do we need to unset the layout because the request is ajax?
		$this->input->is_ajax_request() and $this->template->set_layout(false);
		//$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

		$this->template
			->title($this->module_details['name'])
			->set('scc', $scc);

		$this->template->build('members/admin/scc/view');
	}
	
	public function edit($id=0)
	{
		role_or_die('members', 'edit_scc');

		$id OR redirect('members/admin/scc');

		$scc = $this->scc_m->get($id);

		$this->form_validation->set_rules($this->validation_rules);


		if ($this->input->post('application_date'))
		{
			$application_date = strtotime(sprintf('%s %s:%s', $this->input->post('application_date'), 0, 0));
		}
		else
		{
			$application_date = $scc->application_date;
		}

		if ($this->input->post('approval_date'))
		{
			$approval_date = strtotime(sprintf('%s %s:%s', $this->input->post('approval_date'), 0, 0));
		}
		else
		{
			$approval_date = $scc->approval_date;
		}

		if ($this->input->post('certification_expiry_date'))
		{
			$certification_expiry_date = strtotime(sprintf('%s %s:%s', $this->input->post('certification_expiry_date'), 0, 0));
		}
		else
		{
			$certification_expiry_date = $scc->certification_expiry_date;;
		}

		if ($this->input->post('online_status')){
			$isUp = $this->input->post('online_status') == 'live' ? '1' : '0';
		}
		else{
			$isUp = $this->input->post('online_status') == 'live' ? '1' : $scc->isUp;
		}
		
		// check directory exists
		$this->check_dir($this->upload_cfg['upload_path']);
		$this->load->library('upload', $this->upload_cfg);

		if (!empty($_FILES['file']['name']) )
		{
			if($this->upload->do_upload("file"))
			{
				$uploaded = $this->upload->data();
				$file = $uploaded['file_name'];
				$this->remove_file($this->input->post('file_text_1'));
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$file = $scc->file;
		}
		
		if ($this->input->post('remove_file'))
		{
			$remove = $this->input->post('remove_file');
			if ( $this->remove_file($remove) )
			{
				$file_2 = NULL;
			}
			else
			{
				$this->session->set_flashdata('info', 'Error deleting file '.$remove);
			}
		}


		if (!empty($_FILES['file_2']['name']) )
		{
			if($this->upload->do_upload("file_2"))
			{
				$uploaded = $this->upload->data();
				$file_2 = $uploaded['file_name'];
				$this->remove_file($this->input->post('file_text_2'));
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$file_2 = $scc->file_2;
		}

		if (!empty($_FILES['file_3']['name']) )
		{
			if($this->upload->do_upload("file_3"))
			{
				$uploaded = $this->upload->data();
				$file_3 = $uploaded['file_name'];
				$this->remove_file($this->input->post('file_text_3'));
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$file_3 = $scc->file_3;
		}

/*
echo "\$file: $file; \$file_2: $file_2; \$file_3: $file_3; <br />\n";
exit;
*/

		if ($this->input->post('remove_file_2'))
		{
			$remove = $this->input->post('remove_file_2');
			if ( $this->remove_file($remove) )
			{
				$file_2 = NULL;
			}
			else
			{
				$this->session->set_flashdata('info', 'Error deleting file '.$remove);
			}
		}

		if ($this->input->post('remove_file_3'))
		{
			$remove = $this->input->post('remove_file_3');
			if ( $this->remove_file($remove) )
			{
				$file_3 = NULL;
			}
			else
			{
				$this->session->set_flashdata('info', 'Error deleting file '.$remove);
			}
		}

		if ($this->form_validation->run())
		{
			$input = array(
				'strModifyDate'		=> date('Y-m-d'),
				'strModifyPerson'	=> $this->current_user->id,
				'mid'				=> (int)$this->input->post('member_id'),
				'facility'			=> $this->input->post('facility'),
				'isUp'				=> $isUp,
				'supply_option'		=> $this->input->post('supply_options') ? implode(",", $this->input->post('supply_options')) : NULL,
				'application_date'	=> $application_date,
				'approval_date'		=> $approval_date,
				'certification_expiry_date'	=> $certification_expiry_date,
				'file'				=> $file,
				'file_2'			=> $file_2,
				'file_3'			=> $file_3,
				'date'				=> now(),
			);

/*
echo "<pre>";
echo "\$input:\n";
print_r($input);
echo "\n------------------\n";
echo "</pre>";
exit;
*/

			if ($this->scc_m->update($id, $input))
			{
				$this->pyrocache->delete_all('scc_m');
				$this->session->set_flashdata(array('success' => sprintf(lang('scc:edit_success'), $this->input->post('member_name'))));
				($this->input->post('btnAction') == 'save_exit') ? redirect('admin/members/scc') : redirect('admin/members/scc/edit/'.$id);
			}
			else
			{
				//$this->session->set_flashdata(array('error' => sprintf(lang('scc:create_error'), $this->input->post('member_name'))));
				$this->template->set('error', sprintf(lang('scc:create_error'), $this->input->post('member_name')) );
			}

			// Redirect back to the form or main page
		}

		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $key => $field)
		{
			if (isset($_POST[$field['field']]))
			{
				if ($field['field'] != 'file' AND $field['field'] != 'file_2' AND $field['field'] != 'file_3')
					$scc->$field['field'] = set_value($field['field']);
			}
		}

		$scc->application_date 			= $application_date;
		$scc->approval_date 			= $approval_date;
		$scc->certification_expiry_date = $certification_expiry_date;
		//$scc->mid 						= $this->input->post('member_id');
		$scc->file 						= $file;
		$scc->file_2 					= $file_2;
		$scc->file_3 					= $file_3;
		$scc->file_text_1 				= $file;
		$scc->file_text_2 				= $file_2;
		$scc->file_text_3 				= $file_3;
		$scc->supply_option 			= $this->input->post('supply_options') ? implode("\r\n", $this->input->post('supply_options')) : $scc->supply_option;
	
		$scc->online_status    = $isUp ? 'live' : 'draft';
		$scc->isUp = $isUp;

		$this->template
			//->append_metadata($this->load->view('fragments/wysiwyg', array(), TRUE))
			->set('supply_options', $this->supply_options)
			->set('scc', $scc)
			->build('admin/scc/form');
	}
	
	public function editOLD($id=0)
	{
		$scc = $this->scc_m->get($id);

		$this->form_validation->set_rules($this->validation_rules);

		if ($this->input->post('notification_date'))
		{
			$date = $this->input->post('notification_date'); //strtotime(sprintf('%s %s:%s', $this->input->post('notification_date'), 0, 0));
		}
		else
		{
			$date = $scc->date;
		}

		if ($this->input->post('assessment_date'))
		{
			$assessment_date = strtotime(sprintf('%s %s:%s', $this->input->post('assessment_date'), 0, 0));
		}
		else
		{
			$assessment_date = $scc->assessment_date;
		}

		if ($this->input->post('final_report_date'))
		{
			$final_report_date = strtotime(sprintf('%s %s:%s', $this->input->post('final_report_date'), 0, 0));
		}
		else
		{
			$final_report_date = $scc->final_report_date;
		}

		if ($this->input->post('report_accepted_date'))
		{
			$report_accepted_date = strtotime(sprintf('%s %s:%s', $this->input->post('report_accepted_date'), 0, 0));
		}
		else
		{
			$report_accepted_date = $scc->report_accepted_date;
		}

		// check directory exists
		$this->check_dir($this->upload_cfg['upload_path']);
		$this->load->library('upload', $this->upload_cfg);

		if (!empty($_FILES['certificate']))
		{
			if($this->upload->do_upload("certificate"))
			{
				$file_certificate = $this->upload->data();
				$scc->certificate = $file_certificate['file_name'];
			}
		}

		if (!empty($_FILES['uploaded']['name'][0]))
		{
			if($this->upload->do_multi_upload("uploaded"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();
				foreach($file_uploaded as $file)
				{
					$uploaded[] = $file['file_name'];
				}
				$scc->uploaded = implode(',', $uploaded);
				$uploaded += explode(',', $this->input->post('uploaded_files'));
			}
		}
		else
		{
			$uploaded = explode(',', $scc->uploaded);
		}

		if (!empty($_FILES['notification_1']['name']) )
		{
			if($this->upload->do_upload("notification_1"))
			{
				$notification_uploaded = $this->upload->data();
				$notification = $notification_uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$notification = $this->input->post('notification_file_1');
		}

		if (!empty($_FILES['notification_2']['name']) )
		{
			if($this->upload->do_upload("notification_2"))
			{
				$notification_uploaded = $this->upload->data();
				$notification_2 = $notification_uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$notification_2 = $this->input->post('notification_file_2');
		}

		if (!empty($_FILES['notification_3']['name']) )
		{
			if($this->upload->do_upload("notification_3"))
			{
				$notification_uploaded = $this->upload->data();
				$notification_3 = $notification_uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$notification_3 = $this->input->post('notification_file_3');
		}


		if ($this->input->post('remove_notification'))
		{
			$rn = $this->input->post('remove_notification');
			foreach($rn as $r)
			{
				if (($key = array_search($r, $notifications)) !== false) {
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$r))
					{
						unset($notifications[$key]);
					}
					else
					{
						unset($notifications[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$scc->notification = implode(',', $notifications);
		}

		if ($this->input->post('remove_uploaded'))
		{
			$remove_uploaded = $this->input->post('remove_uploaded');
			foreach($remove_uploaded as $r)
			{
				if (($key = array_search($r, $uploaded)) !== false) {
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$r))
					{
						unset($uploaded[$key]);
					}
					else
					{
						unset($uploaded[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$scc->uploaded = implode(',', $uploaded);
		}

		if ($this->form_validation->run())
		{
			$certificate_file = !empty($scc->certificate) ? $scc->certificate : $this->input->post('certificate_file');
			$uploaded_files = $this->input->post('uploaded_files') . (!empty($uploaded)?','.implode(',', $uploaded):'');
			$cb_id = (int)$this->input->post('cb_id');

			$input = array(
				'updated_on'		=> now(),
				'updated_by'		=> $this->current_user->id,
				'mill'				=> $this->input->post('mill'),
				'isUp'				=> $this->input->post('online_status') == 'live' ? '1' : '0',
				'date'				=> $date,
				'mid'				=> $this->input->post('member_id'),
				'certification_body'=> $cb_id ? '' : $this->input->post('certification_body'),
				'cb_id'				=> $cb_id,
				'assessment_type'	=> $this->input->post('assessment_type'),
				'status'			=> $this->input->post('status'),
				//'notification_date'	=> $date,
				'assessment_date'	=> $assessment_date,
				'subremarks'		=> $this->input->post('subremarks'),
				'certificate_file'	=> $certificate_file,
				'notification'		=> $notification,
				'notification_2'	=> $notification_2,
				'notification_3'	=> $notification_3,
				'uploaded'			=> implode(',', $uploaded),
				'final_report_date'	=> $final_report_date,
				'remarks'			=> $this->input->post('remarks'),
				'report_accepted_date'=> $report_accepted_date,
			);

			if ($this->scc_m->update($id, $input))
			{
				$this->pyrocache->delete_all('scc_m');
				$this->session->set_flashdata(array('success' => sprintf(lang('scc:edit_success'), $this->input->post('member_name'))));
				($this->input->post('btnAction') == 'save_exit') ? redirect('admin/members/scc') : redirect('admin/members/scc/edit/'.$id);
			}
			else
			{
				$this->session->set_flashdata(array('error' => sprintf(lang('scc:edit_error'), $this->input->post('member_name'))));
				$this->template->set('error', sprintf(lang('scc:edit_error'), $this->input->post('member_name')) );
			}

			// Redirect back to the form or main page
		}

		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $key => $field)
		{
			if (isset($_POST[$field['field']]))
			{
				$scc->$field['field'] = set_value($field['field']);
			}
		}

		$scc->date = $date;
		$scc->assessment_date = $assessment_date;
		$scc->final_report_date = $final_report_date;
		$scc->report_accepted_date = $report_accepted_date;

		$this->template
			//->append_metadata($this->load->view('fragments/wysiwyg', array(), TRUE))
			->set('scc', $scc)
			->build('admin/scc/form');
	}

	public function action()
	{
		switch ($this->input->post('btnAction'))
		{
			case 'delete':
				$this->delete();
				break;

			default:
				redirect('admin/members/scc');
				break;
		}
	}

	public function delete($id=0)
	{
		role_or_die('members', 'delete_scc');

		// Delete one
		$ids = ($id) ? array($id) : $this->input->post('action_to');

		// Go through the array of slugs to delete
		if ( ! empty($ids))
		{
			$post_titles = array();
			$deleted_ids = array();
			foreach ($ids as $id)
			{
				// Get the current page so we can grab the id too
				if ($scc = $this->scc_m->get($id))
				{
					if ($this->scc_m->delete($id))
					{
						// delete the files
						$flatfiles = $scc->file . ', ' . $scc->file_2 . ', '.$scc->file_3;
						$files = explode(',', $flatfiles);
						if (!empty($files))
						{
							foreach($files as $file)
							{
								$this->remove_file($file);
							}
						}
						// Wipe cache for this model, the content has changed
						$this->pyrocache->delete_all('scc_m');
						$post_titles[] = $scc->member_name;
						$deleted_ids[] = $id;
					}
				}
			}
		}

		// Some pages have been deleted
		if ( ! empty($post_titles))
		{
			// Only deleting one page
			if (count($post_titles) == 1)
			{
				$this->session->set_flashdata('success', sprintf($this->lang->line('scc:delete_success'), $post_titles[0]));
			}
			// Deleting multiple pages
			else
			{
				$this->session->set_flashdata('success', sprintf($this->lang->line('scc:mass_delete_success'), implode('", "', $post_titles)));
			}
		}
		// For some reason, none of them were deleted
		else
		{
			$this->session->set_flashdata('notice', lang('scc:delete_error'));
		}

		redirect('admin/members/scc');
	}


	/**
	 * method to fetch filtered results for content list
	 * @access public
	 * @return void
	 */
	public function ajax_filter()
	{
		$area = $this->input->post('f_area');
		$status = $this->input->post('f_status');
		$type = $this->input->post('f_type');

		$post_data = array();

		if ($status == 'live' OR $status == 'draft')
		{
			$post_data['status'] = $status;
		}

		if ($type)
		{
			$post_data['type'] = $type;
		}

		if ($area != 0)
		{
			$post_data['area_id'] = $area;
		}

		$results = $this->members_m->search($post_data);

		//set the layout to false and load the view
		$this->template
			->set_layout(FALSE)
			->set('members', $results)
			->build('admin/tables/members');
	}

	public function remove_file($file)
	{
		$full = $_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$file;
		if (file_exists($full))
		{
			if (is_file($full))
			{
				if (unlink($full))
					return TRUE;
				else
					return FALSE;
			}
			return TRUE;
		}
		else
		{
			// file dissapear, maybe has been deleted?
			return TRUE;
		}
	}

	/**
	 * Check attachment dir, and create accordingly
	 *
	 * @param string Directory to check
	 * @return array
	 */
	function check_dir($dir)
	{
		// check directory
		$fileOK = array();
		$fdir = explode('/', $dir);
		$ddir = '';
		for($i=0; $i<count($fdir); $i++)
		{
			$ddir .= $fdir[$i] . '/';
			if (!is_dir($ddir))
			{
				if (!@mkdir($ddir, 0777)) {
					$fileOK[] = 'not_ok';
				}
				else
				{
					$fileOK[] = 'ok';
				}
			}
			else
			{
				$fileOK[] = 'ok';
			}
		}
		return $fileOK;

	}

	function fixmember()
	{
		$q = "SELECT dm.intID,dm.title,dm.name,dm.mid,dm.status FROM default_membership dm ";
		$q .= " where dm.mid is null or dm.mid = '' order by dm.intID";
		$r = $this->db->query($q);

		$this->_print_header();

		$results = $r->result();
		$count = count($results);
		echo "Counts: " . $count . " data<br />\n";

		if ($count)
		{
			echo "<ul>\n";
			foreach($results as $i=>$m)
			{
				$m_name = ($m->title ? $m->title : $m->name);
	
				echo "<li style=\"padding-bottom: 20px;\">\n";
				echo "Member: " . $m_name . ", intID: " . $m->intID . ", status: ".$m->status."<br />\n";
	
				/* */
				$last_mid = $this->members_m->get_last_mid();
				if ($last_mid)
				{
					$input['mid'] = $last_mid + 1;
				}
				else
				{
					$input['mid'] = $m->intID;
				}
	
				/* */
				$res = $this->members_m->update($m->intID, $input);
				/* */
				$res = true;
				if ($res)
				{
					echo "Member 'mid' is updated to $last_mid";
				}
				else
				{
					echo "<div style=\"color:red;\">Member $m_name is <b>NOT</b> updated...</div>";
					echo "Error: " . $this->db->_error_message();
				}
				/* */
				echo "</li>\n";
			}
			echo "</ul>\n";
		}
		else
		{
			echo "No members with empty 'mid' found...";
		}

		$this->_print_footer();
	}

	function fixmid()
	{
		$q = "SELECT dm.intID,dm.title,dm.name,dm.mid,dm.status, cmc.MotherID,cmc.name as cmc_name,cmc.mid as cmc_mid,cmc.status as cmc_status FROM default_membership dm ";
		$q .= "LEFT JOIN js_custom_membership_content cmc ON cmc.MotherID = dm.intID and cmc.LangID = 1";
		//$q .= "LEFT JOIN js_custom_membership_content cmc ON cmc.mid = dm.mid and cmc.LangID = 1";
		$q .= " where (dm.mid is null or dm.mid = '') and (dm.status is not null or dm.status = 'Approved' or dm.status = 'Call for Comment')";
		$r = $this->db->query($q);

		$this->_print_header();

		$results = $r->result();
		echo "Counts: " . (count($results)) . " data<br />\n";

		echo "<ul>\n";
		foreach($results as $i=>$m)
		{
			$m_name = ($m->title ? $m->title : $m->name);
			if ($m->cmc_name == $m_name) continue;
			echo "<li style=\"padding-bottom: 20px;\">\n";
			echo "Member: " . $m_name . ", intID: " . $m->intID . ", mid: " . $m->mid . ", status: ".$m->status."<br />\n";
			echo "cmc: " . ($m->cmc_name) . ", cmc_mid: " . $m->cmc_mid. ", status: ".$m->cmc_status."<br />\n";
			if ($m->cmc_name <> $m_name)
			{
				echo "<b style=\"color:red;\">NOT THE SAME!</b>\n";
			}
			/* *
			$last_mid = $this->members_m->get_last_mid();
			if ($last_mid)
			{
				$input['mid'] = $last_mid + 1;
			}
			else
			{
				$input['mid'] = $m->intID;
			}
			$res = $this->db->members_m->update($m->intID, $input);
			if ($res)
			{
				echo "Member " . ($m->title ? $m->title : $m->name) . " is updated...";
			}
			else
			{
				echo "<div style=\"color:red;\">Member " . ($m->title ? $m->title : $m->name) . " is <b>NOT</b> updated...</div>";
				echo "Error: " . $this->db->_error_message();
			}
			/* */
			unset($results[$i]);
			echo "</li>\n";
		}
		echo "</ul>\n";

		$results = array_filter($results);
		echo "Counts: " . (count($results)) . " data<br />\n";

		$this->_print_footer();
	}

	function showscc($num=0)
	{
		$this->_print_header();

		$num_data = 50; //Settings::get('records_per_page');
		if ($num)
		{
			$offset = $num * 25;
			$limit = " LIMIT $offset,$num_data";
		}
		else
		{
			$offset = 0;
			$limit = " LIMIT $num_data";
		}

		$total_rows = $this->db
			->where('certification_expiry_date >=', now())
			//->where('default_member_scc.mid', 'default_membership.mid')
			->join('default_membership', 'default_membership.intID = default_member_scc.mid', 'left')
			->count_all_results('member_scc');

		$sq = "SELECT COUNT(*) as numrows FROM default_member_scc WHERE certification_expiry_date >= " . now();
		$re = $this->db->query($sq);
		if ($re)
		{
			$row = $re->row();
			$numrows = $row->numrows;
			echo "\$numrows: $numrows<br />\n";
		}

		$pagination = create_pagination('admin/members/scc/fixscc', $numrows, 50, 5);

		if ($pagination['offset'])
		{
			$offset = $num * 25;
			$limit = " LIMIT $offset,$num_data";
		}
		else
		{
			$offset = 0;
			$limit = " LIMIT $num_data";
		}

		$q = "SELECT default_member_scc.id, default_member_scc.mid, default_member_scc.facility, default_member_scc.certification_expiry_date, default_membership.intID, default_membership.mid as m_mid, default_membership.title as m_title, default_membership.name as m_name FROM `default_member_scc` ";
		$q .= "LEFT JOIN default_membership ON default_membership.intID = default_member_scc.mid ";
		$q .= "WHERE certification_expiry_date >= " . now();
		//$q .= " AND default_member_scc.mid !=  default_membership.mid ";
		// LIMIT 10 OFFSET 15
		//$q .= " LIMIT " . $pagination['limit'] . " OFFSET " . $pagination['offset'];
		$q .= " ORDER BY default_member_scc.id DESC ";
		//$q .= $limit;
		
		$r = $this->db->query($q);

/*
echo "<pre>\n";
print_r($pagination);
echo "</pre>\n";
*/

		if ($r)
		{
?>
			<h2>Total: <?php echo $total_rows; ?></h2>
			<table cellpadding="4" cellspacing="1" border="1">
				<tr>
					<th width="25">No.</th>
					<th>SCC ID</th>
					<th>SCC mid</th>
					<th>Member mid</th>
					<th>Expiry Date</th>
					<th width="30%">SCC Facility</th>
					<th>Member ID</th>
					<th width="30%">Member name</th>
				</tr>
<?php
			$idx = $pagination['offset'] + 1;
			foreach($r->result() as $m)
			{
/*
echo "<pre>";
print_r($m);
echo "</pre>";
*/
				echo "<tr>\n";
					echo "<td>$idx</td>\n";
					$idx++;
					echo "<td><a href=\"/admin/members/scc/edit/".$m->id."\" target=\"_scc\">" . $m->id . "</a></td>\n";
					echo "<td>" . $m->mid . "</td>\n";
					echo "<td>" . $m->m_mid . "</td>\n";
					echo "<td>" . date('d M Y', $m->certification_expiry_date) . "</td>\n";
					echo "<td><a href=\"http://rspo.org/certification/supply-chain-certificate-holders?keywords=".urlencode($m->facility)."\" target=\"_scc_front\">" . word_limiter(strip_tags($m->facility), 20) . "</a></td>\n";
					echo "<td>" . $m->intID . "</td>\n";
					echo "<td><a href=\"/members/".$m->intID."\" target=\"_memb\">" . ($m->m_title?$m->m_title:$m->m_name) . "</a></td>\n";
				echo "</tr>\n\n";
			}
?>
			</table>
<?php
			echo $pagination['links'].PHP_EOL;
		}
		else
		{
			echo "SQL: <code>$q</code><br />";
			echo "Error: " . mysql_error();
		}

		$this->_print_footer();
	}

	function fixscc($num=0)
	{
		$this->_print_header();

		$q = "SELECT default_member_scc.id, default_member_scc.mid, default_member_scc.facility, default_member_scc.certification_expiry_date, default_membership.intID, default_membership.mid as m_mid, default_membership.title as m_title, default_membership.name as m_name FROM `default_member_scc` ";
		$q .= "LEFT JOIN default_membership ON default_membership.mid = default_member_scc.mid ";
		$q .= "WHERE certification_expiry_date >= " . now();
		$q .= " ORDER BY default_member_scc.id DESC ";
		
		$r = $this->db->query($q);

/*
echo "<pre>\n";
print_r($pagination);
echo "</pre>\n";
*/

		if ($r)
		{
?>
			<h2>Total: <?php echo $total_rows; ?></h2>
			<table cellpadding="4" cellspacing="1" border="1">
				<tr>
					<th width="25">No.</th>
					<th>SCC ID</th>
					<th>SCC mid</th>
					<th>Member mid</th>
					<th>Expiry Date</th>
					<th width="30%">SCC Facility</th>
					<th>Member ID</th>
					<th width="30%">Member name</th>
				</tr>
<?php
			foreach($r->result() as $idx=>$m)
			{
/*
echo "<pre>";
print_r($m);
echo "</pre>";
*/
				// update scc table - change value of mid to the value of intID
				$upd = "UPDATE default_member_scc SET mid = '".$m->intID."' WHERE default_member_scc.id = '".$m->id."' LIMIT 1";
				$res = $this->db->query($upd);
				echo "<tr>\n";
					echo "<td>".($idx+1)."</td>\n";
					$idx++;
					echo "<td><a href=\"/admin/members/scc/edit/".$m->id."\" target=\"_scc\">" . $m->id . "</a></td>\n";
					echo "<td>" . $m->mid . "</td>\n";
					echo "<td>" . $m->m_mid . "</td>\n";
					echo "<td>" . date('d M Y', $m->certification_expiry_date) . "</td>\n";
					echo "<td><a href=\"/certification/supply-chain-certificate-holders?keywords=".urlencode($m->facility)."\" target=\"_scc_front\">" . word_limiter(strip_tags($m->facility), 20) . "</a><hr /><code>$upd</code> <b>Status: $res</b></td>\n";
					echo "<td>" . $m->intID . "</td>\n";
					echo "<td><a href=\"/members/".$m->intID."\" target=\"_memb\">" . ($m->m_title?$m->m_title:$m->m_name) . "</a></td>\n";
				echo "</tr>\n\n";
			}
?>
			</table>
<?php
			echo $pagination['links'].PHP_EOL;
		}
		else
		{
			echo "SQL: <code>$q</code><br />";
			echo "Error: " . mysql_error();
		}

		$this->_print_footer();
	}

	function fixit()
	{
		$q = "SELECT intID,title,name,mid FROM `default_membership` where mid is null or mid = ''";
		$r = $this->db->query($q);

		foreach($r->result() as $m)
		{
echo "ID: " . $m->intID . "<br />";
			$members[$m->intID]['title'] = $m->title ? $m->title : $m->name;
			$members[$m->intID]['id'] = $m->intID;
		}

		$query = "SELECT MotherID,name,mid FROM `js_custom_membership_content` where MotherID IN (SELECT intID FROM `default_membership` where mid is null or mid = '') and LangID = '1'";
		$result = $this->db->query($query);
		if ($result)
		{
			echo "<ul>\n";
			foreach($result->result() as $res)
			{
				echo "<li style=\"padding-bottom: 20px;\">\n";
				echo "<fieldset style=\"width: 30%;float:left;margin-right:10px;\"><legend>custom_membership_content</legend>\n";
				echo "Member: $res->name<br />\n";
				echo "intID: $res->MotherID<br />";
				echo "mid: $res->mid";
				echo "</fieldset>\n";
				echo "<fieldset style=\"width: 30%;\"><legend>default_membership</legend>\n";
				echo "Member: ".$members[$res->MotherID]['title'] . "<br />\n";
				echo "intID: ".$members[$res->MotherID]['id'] . "<br />\n";
				//echo "Updating mid..<br />";
				//$this->db->members_m->update()
				echo "</fieldset>\n";
				echo "<div style=\"clear:both;\"></div>\n";
				echo "</li>\n";
			}
			echo "</ul>\n";
		}
		else
		{
			echo "Error: " . mysql_error();
		}
	}

	function _print_header()
	{
		echo '<!doctype html>
	<head>
		<title>SCC Consistency Check</title>
		<meta charset="utf-8">
		<style>
			* {
				font-family: "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
				font-size: 14px;
			}
			tr.muted td {color: #888;}
			tr.normal td {color: #000;}
			a {color: #FF9539;text-decoration:none;}
			a:hover {text-decoration:underline;}
			.pagination {
				display: block;
				margin: 5px 0 15px;
				border-bottom: 1px solid #ccc;
			}
			.pagination ul li {
				width: 20px;
				height: 16px;
				text-align:center;
				display:block;
				float:left;
				margin-bottom: 5px;
			}
			.pagination ul li a {
				width: 100%;
			}
		</style>
	</head>
	<body>

		';
	}

	function _print_footer()
	{
		echo "
	</body>
</html>

		";
	}

	// consistency check
	function consistency()
	{
		$select = "
			member_scc.id,member_scc.mid,member_scc.facility,member_scc.strAddDate as scc_date,
			membership_content.MotherID as mc_MotherID,membership_content.mid as member_mid2, membership_content.name as name2,
			membership.intID,membership.mid as member_mid, membership.name,membership.title
		";

		$scc = $this->db
			->select($select)
			->join('membership', 'membership.mid=member_scc.mid', 'left')
			->join('membership_content', 'membership_content.mid=member_scc.mid', 'left')
			->order_by('member_scc.id', 'desc')
			->get('member_scc')->result();

		$this->_print_header();

		echo "<h2>Total: " . count($scc) . "</h2>\n";

		echo "<table cellspacing=\"1\" cellpadding=\"5\" border=\"1\" width=\"100%\">\n";

		echo "<tr>\n";
				echo "<th rowspan=\"2\">No</th>";
		echo "<th rowspan=\"2\">SCC Date</th>";
		echo "<th rowspan=\"2\">SCC ID</th>";
		echo "<th rowspan=\"2\">SCC mid</th>";
		echo "<th rowspan=\"2\">Facility</th>";
		echo "<th colspan=\"3\">New membership DB";
		echo "<th colspan=\"3\">Old membership DB";
		//echo "<th rowspan=\"2\">Member</th>";
		echo "</tr>";

		echo "<tr>";
		echo "<th>mid</th>";
		echo "<th>intID</th>";
		echo "<th>Member</th>";
		echo "<th>mid</th>";
		echo "<th>intID</th>";
		echo "<th>Member</th>";
		echo "</tr>";

		$i=1;
		foreach($scc as $idx => $s)
		{
			if ($i==10)
			{
				echo "<tr>\n";
				echo "<th rowspan=\"2\">No</th>";
				echo "<th rowspan=\"2\">SCC Date</th>";
				echo "<th rowspan=\"2\">SCC ID</th>";
				echo "<th rowspan=\"2\">SCC mid</th>";
				echo "<th rowspan=\"2\">Facility</th>";
				echo "<th colspan=\"3\">New membership DB";
				echo "<th colspan=\"3\">Old membership DB";
				//echo "<th rowspan=\"2\">Member</th>";
				echo "</tr>";

				echo "<tr>";
				echo "<th>mid</th>";
				echo "<th>intID</th>";
				echo "<th>Member</th>";
				echo "<th>mid</th>";
				echo "<th>intID</th>";
				echo "<th>Member</th>";
				echo "</tr>";

				$i=1;
			}

				echo "<tr class=\"muted\">\n";
				echo "<td>".($idx+1)."</td>\n";
				echo "<td>".($s->scc_date?$s->scc_date:'&nbsp;')."</td>\n";
				echo "<td><a href=\"/admin/members/scc/edit/".$s->id."\" target=\"_scc_admin\">".$s->id."</a></td>\n";
				echo "<td><b style=\"color:red\">".$s->mid."</b></td>\n";
				echo "<td>".$s->facility."</td>\n";

				echo "<td><b style=\"color:red\">".$s->member_mid."</b></td>\n";
				echo "<td><b style=\"color:green\">".$s->intID."</b></td>\n";
				echo "<td><a target=\"_member\" href=\"".site_url('members/'.$s->intID)."\">".($s->name2?$s->name2:'&nbsp;')."</a></td>\n";

				echo "<td><b style=\"color:red\">".$s->member_mid2."</b></td>\n";
				echo "<td><b style=\"color:green\">".$s->mc_MotherID."</b></td>\n";
				echo "<td>".($s->name?$s->name:($s->title?$s->title:'&nbsp;'))."</td>\n";

				echo "</tr>\n";


/*
			if ($s->mc_MotherID == $s->intID)
			{
				//continue;
				echo "<tr class=\"normal\">\n";
				echo "<td>".($s->scc_date?$s->scc_date:'&nbsp;')."</td>\n";
				echo "<td>".$s->id."</td>\n";
				echo "<td><b style=\"color:red\">".$s->mid."</b></td>\n";

				echo "<td><b style=\"color:red\">".$s->member_mid2."</b></td>\n";
				echo "<td><b style=\"color:green\">".$s->mc_MotherID."</b></td>\n";

				echo "<td><b style=\"color:red\">".$s->member_mid."</b></td>\n";
				echo "<td><b style=\"color:green\">".$s->intID."</b></td>\n";

				echo "<td>".$s->facility."</td>\n";
				echo "<td>".($s->name?$s->name:$s->title)."</td>\n";
				echo "</tr>\n";
			}
			else
			{
				echo "<tr class=\"muted\">\n";
				echo "<td>".($s->scc_date?$s->scc_date:'&nbsp;')."</td>\n";
				echo "<td><a href=\"/admin/members/scc/edit/".$s->id."\" target=\"_blank\">".$s->id."</a></td>\n";
				echo "<td><b style=\"color:red\">".$s->mid."</b></td>\n";

				echo "<td><b style=\"color:red\">".$s->member_mid2."</b></td>\n";
				echo "<td><b style=\"color:green\">".$s->mc_MotherID."</b></td>\n";

				echo "<td><b style=\"color:red\">".$s->member_mid."</b></td>\n";
				echo "<td><b style=\"color:green\">".$s->intID."</b></td>\n";

				echo "<td>".$s->facility."</td>\n";
				echo "<td>".($s->name?$s->name:($s->title?$s->title:'&nbsp;'))."</td>\n";
				echo "</tr>\n";
			}
*/

			$i++;
		}
		echo "</table>\n";

		$this->_print_footer();

	}

}?>