<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Current_list_of_supply_chain_certification extends Public_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model(array('scc_m', 'members_m'));
		$this->lang->load(array('scc', 'members'));
		$this->load->helper('filesize');
		$this->config->load('config');
		if (config_item('country_arrays'))
		{
			$country_arrays = config_item('country_arrays');

			foreach($country_arrays as $c)
			{
				$countries[$c] = $c;
			}

			$this->template
				->set('countries', $countries);
		}

		$this->supply_options = array(
			'IP'=> 'Identity Preserved',
			'SG'=> 'Segregation',
			'MB'=> 'Mass Balance',
		);
	}

	public function index($slug='')
	{
		if ($slug && $slug <> 'page')
		{
			$this->_view($slug);
		}
		else
		{
			//set the base/default where clause
			$base_where = array('status' => 'live', 'expired'=>true );

			//add post values to base_where if f_module is posted
			//$base_where = $this->input->post('f_area') ? $base_where + array('area' => $this->input->post('f_area')) : $base_where;

			//$base_where['status'] = $this->input->post('f_status') ? $this->input->post('f_status') : $base_where['status'];

			$base_where['keywords'] = $this->input->get('keywords') ? stripslashes(urldecode($this->input->get('keywords'))) : NULL;
			$base_where['country'] = $this->input->get('country') ? $this->input->get('country') : NULL;

			if ($this->input->get('supply_options'))
			{
echo "supply_options:<br />\n";
$sscc = $this->input->get('supply_options');
print_r($sscc);
				$so = $this->input->get('supply_options');
print_r($so);
				foreach($so as $s)
				{
					$supply_options[] = $this->supply_options[$s];
				}
				$base_where['supply_options'] = $supply_options;
			}
echo "<pre>";
echo "\$base_where:\n";
print_r($base_where);
echo "</pre>\n";

			// Create pagination links
			$total_rows = $this->scc_m->count_by($base_where);

			$pagination = create_pagination('certification/supply-chain-certificate-holders/page/', $total_rows, NULL, 4);

			$base_where['limit'] = array($pagination['limit'], $pagination['offset']);

			// Using this data, get the relevant results
			//$sccs = $this->pyrocache->model('scc_m', 'get_many_by', array( $base_where ) );
			$sccs = $this->scc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);

			//do we need to unset the layout because the request is ajax?
			$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

			$this->template
				->title('SCC holders')
				->set('base_where', $base_where)
				->set_breadcrumb('Certification', 'certification')
				->set_breadcrumb('Supply Chain Certificate Holders')
				->set('pagination', $pagination)
				->set('sccs', $sccs);
	
			$this->template->build('scc/index');
		}

	}
	
	private function _view($slug)
	{
		$slug or redirect('members/supply-chain-certificate-holders');

		$scc = $this->scc_m->get($slug);
		if (!empty($scc))
		{
			$this->template
				->title($scc->member_name)
				//->append_js('admin/filter.js')
				->set('scc', $scc);
	
			if ($this->input->is_ajax_request())
				$this->template->set_layout(FALSE);
			$this->template->build('scc/view');
		}
		else
		{
			$this->session->set_flashdata('error', lang('scc:scc_not_exist_error'));
			redirect('members/supply-chain-certificate-holders');
		}

	}

}