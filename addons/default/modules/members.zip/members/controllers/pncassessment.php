<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Pncassessment extends Public_Controller
{

    protected $section = 'pnc';

	public function __construct()
	{
		parent::__construct();
		
		//db prefix default to join db
		$this->db->set_dbprefix('default_');
		
		$this->load->model(array('pnc_m', 'members_m'));

		$assessments = $this->pnc_m->get_assessment_type();
		// $ass_type[] = "Assessment type";
		foreach($assessments as $a)
		{
			$ass_type[$a->id] = $a->stage;
		}

		$sts = $this->pnc_m->get_assessment_status();
		$pnc_statuses[] = "Status";
		foreach($sts as $s)
		{
			$idx = strtolower($s->status);
			$pnc_statuses[$idx] = $s->status;
		}

		$this->template
			->set('year_approved', array_combine($year_approved = range(2008, date('Y')), $year_approved))
			->set('notification_date', array_combine($notification_date = range(2013, date('Y')), $notification_date))
			->set('assessment_type', $ass_type)
			->set('pnc_statuses', $pnc_statuses);
	}

	function __destruct()
	{
		$this->db->set_dbprefix(SITE_REF.'_');
	}
	
	public function index()
	{
			if(SITE_REF == "bcn"){
				$this->template
				->title('P&amp;C认证进度查询')
				->set_breadcrumb('RSPO认证', 'certification')
				->set_breadcrumb('P&C认证进度查询')
				//->set('base_where', $base_where)
				//->set('pagination', $pagination)
				//->set('pncs', $pncs)
				->build('pnc/iframe');
				
				$this->db->set_dbprefix('default_');
			}else{
				$this->template
				->title('Certified growers search')
				->set_breadcrumb('Certification', 'certification')
				->set_breadcrumb('Certified growers search')
				//->set('base_where', $base_where)
				//->set('pagination', $pagination)
				//->set('pncs', $pncs)
				->build('pnc/iframe');
			}
	}
	
	public function indexOLD()
	{
		$slug = NULL;
		if ($slug)
		{
			$this->_view($slug);
		}
		else
		{
//$this->output->enable_profiler(true);
			//set the base/default where clause
			$base_where = array('isUp' => '1');

			if ($this->input->get('country'))
				$base_where['country'] = $this->input->get('country');

			if ($this->input->get('pnc_status'))
				$base_where['pnc_status'] = $this->input->get('pnc_status');

			if ($this->input->get('assessment_type'))
				$base_where['assessment_type'] = $this->input->get('assessment_type');

			if ($this->input->get('year_approved'))
				$base_where['year_approved'] = $this->input->get('year_approved');

			if ($this->input->get('notification_date'))
				$base_where['notification_date'] = $this->input->get('notification_date');

			if ($this->input->get('keywords'))
				$base_where['keywords'] = $this->input->get('keywords');

			// Create pagination links
			//$total_rows = $this->pnc_m->count_by($base_where);
			$total_rows = $this->pyrocache->model('pnc_m', 'count_by', array( $base_where ) );
			
			
			//$posts = $this->pyrocache->model('content_m', 'get_articles', array( $params ) );

			$pagination = create_pagination('certification/principles-and-criteria-assessment-progress/page', $total_rows, NULL, 4);

			$base_where['limit'] = array($pagination['limit'], $pagination['offset']);

			// Using this data, get the relevant results
			$pncs = $this->pyrocache->model('pnc_m', 'get_many_by', array( array('limit'=>array($pagination['limit'], $pagination['offset']))+$base_where ) );

			//$pncs = $this->pnc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);

			//do we need to unset the layout because the request is ajax?
			$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

			if(SITE_REF == "bcn"){
				$this->template
				->title('P&C认证进度查询')
				->set_breadcrumb('RSPO认证', 'certification')
				->set_breadcrumb('P&C认证进度查询')
				->set('base_where', $base_where)
				->set('pagination', $pagination)
				->set('pncs', $pncs)
				->build('pnc/index-cn');
				
				$this->db->set_dbprefix('default_');
			}else{
				$this->template
				->title('P&C assessment progress')
				->set_breadcrumb('Certification', 'certification')
				->set_breadcrumb('P&C Certification Assessment Progress')
				->set('base_where', $base_where)
				->set('pagination', $pagination)
				->set('pncs', $pncs)
				->build('pnc/index');
			}
		}
	}
	
	public function publicannouncementXXX()
	{
			$base_where = array('isUp' => '1');

			if ($this->input->get('country'))
				$base_where['country'] = $this->input->get('country');

			if ($this->input->get('pnc_status'))
				$base_where['pnc_status'] = $this->input->get('pnc_status');

			if ($this->input->get('assessment_type'))
				$base_where['assessment_type'] = $this->input->get('assessment_type');

			if ($this->input->get('year_approved'))
				$base_where['year_approved'] = $this->input->get('year_approved');

			if ($this->input->get('notification_date'))
				$base_where['notification_date'] = $this->input->get('notification_date');

			if ($this->input->get('keywords'))
				$base_where['keywords'] = $this->input->get('keywords');

			// Create pagination links
			//$total_rows = $this->pnc_m->count_by($base_where);
			$total_rows = $this->pyrocache->model('pnc_m', 'count_by', array( $base_where ) );
			
			
			//$posts = $this->pyrocache->model('content_m', 'get_articles', array( $params ) );

			$pagination = create_pagination('certification/public-announcement/page', $total_rows, NULL, 4);
			//$pagination = create_pagination('certification/principles-and-criteria-assessment/public-announcement/page', $total_rows, NULL, 4);

			$base_where['limit'] = array($pagination['limit'], $pagination['offset']);

			// Using this data, get the relevant results
			$pncs = $this->pyrocache->model('pnc_m', 'get_many_by', array( array('limit'=>array($pagination['limit'], $pagination['offset']))+$base_where ) );

			//$pncs = $this->pnc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);

			//do we need to unset the layout because the request is ajax?
			$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

			if(SITE_REF == "bcn"){
				$this->template
				->title('P&C认证进度查询')
				->set_breadcrumb('RSPO认证', 'certification')
				->set_breadcrumb('P&C认证进度查询')
				->set('base_where', $base_where)
				->set('pagination', $pagination)
				->set('pncs', $pncs)
				->build('pnc/public-announcement-cn');
				
				$this->db->set_dbprefix('default_');
			}else{
				$this->template
				->title('P&C Assessment Public Announcement')
				->set_breadcrumb('Certification', 'certification')
				->set_breadcrumb('P&C Assessment Public Announcement')
				->set('base_where', $base_where)
				->set('pagination', $pagination)
				->set('pncs', $pncs)
				->build('pnc/public-announcement');
			}
	}
	
	public function publicannouncement()
	{
			$base_where = array('isUp' => '1', 'order' => 'assessment_date');

			if ($this->input->get('country'))
				$base_where['country'] = $this->input->get('country');

			if ($this->input->get('pnc_status'))
				$base_where['pnc_status'] = $this->input->get('pnc_status');

			if ($this->input->get('assessment_type'))
				$base_where['assessment_type'] = $this->input->get('assessment_type');

			if ($this->input->get('year_approved'))
				$base_where['year_approved'] = $this->input->get('year_approved');

			if ($this->input->get('notification_date'))
				$base_where['notification_date'] = $this->input->get('notification_date');

			if ($this->input->get('keywords'))
				$base_where['keywords'] = $this->input->get('keywords');

			// Create pagination links
			//$total_rows = $this->pnc_m->count_by($base_where);
			$total_rows = $this->pyrocache->model('pnc_m', 'count_by', array( $base_where ) );
			
			
			//$posts = $this->pyrocache->model('content_m', 'get_articles', array( $params ) );

			$pagination = create_pagination('certification/public-announcement/page', $total_rows, NULL, 4);
			//$pagination = create_pagination('certification/principles-and-criteria-assessment/public-announcement/page', $total_rows, NULL, 4);

			$base_where['limit'] = array($pagination['limit'], $pagination['offset']);

			// Using this data, get the relevant results
			$pncs = $this->pyrocache->model('pnc_m', 'get_many_by', array( array('limit'=>array($pagination['limit'], $pagination['offset']))+$base_where ) );

			//$pncs = $this->pnc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);

			//do we need to unset the layout because the request is ajax?
			$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

			if(SITE_REF == "bcn"){
				$this->template
				->title('P&C认证进度查询')
				->set_breadcrumb('RSPO认证', 'certification')
				->set_breadcrumb('P&C认证进度查询')
				->set('base_where', $base_where)
				->set('pagination', $pagination)
				->set('pncs', $pncs)
				->build('pnc/public-announcement-cn');
				
				$this->db->set_dbprefix('default_');
			}else{
				$this->template
				->title('P&C Assessment Public Announcement')
				->set_breadcrumb('Certification', 'certification')
				->set_breadcrumb('P&C Assessment Public Announcement')
				->set('base_where', $base_where)
				->set('pagination', $pagination)
				->set('pncs', $pncs)
				->build('pnc/public-announcement');
			}
	}
	
	private function _view($slug)
	{
		$slug or redirect('members');

		$member = $this->members_m->get_by(array('intID'=>$slug, 'status'=>'Approved', 'isDeleted'=>'0'));
		if (!empty($member))
		{
			$this->template
				->title($member->name)
				//->append_js('admin/filter.js')
				->set('member', $member);
	
			$this->input->is_ajax_request() ? $this->template->build('ajax/view') : $this->template->build('view');
		}
		else
		{
			$this->session->set_flashdata('error', lang('members:member_not_exist_error'));
			redirect('members');
		}
	}
}