<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Members extends Public_Controller
{
	
	protected $section = 'members';
	
	protected $country_arrays = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vatican City", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");
	
	protected $validation_rules = array(
			array(
				'field' => 'type',
				'label' => 'Membership type',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'category',
				'label' => "Organisation's category",
				'rules' => 'trim|required',
			),
			array(
				'field' => 'profession',
				'label' => "Organisation's sub-category",
				'rules' => 'trim',
			),
			array(
				'field' => 'name',
				'label' => "Organisation's name",
				'rules' => 'trim|required',
			),
			array(
				'field' => 'address',
				'label' => 'Street and number',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'address_city',
				'label' => 'City',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'address_state',
				'label' => 'State/Province',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'address_zip',
				'label' => 'Postal/Zip Code',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'country',
				'label' => 'Country',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'telephone',
				'label' => 'Telephone',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'fax',
				'label' => 'Fax',
				'rules' => 'trim',
			),
			array(
				'field' => 'email',
				'label' => 'Email',
				'rules' => 'trim|valid_email|required',
			),
			array(
				'field' => 'website',
				'label' => 'Website ',
				'rules' => 'trim',
			),
			array(
				'field' => 'registration_number',
				'label' => 'Organisation\'s registration',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'parent_company',
				'label' => 'Are you a parent company? ',
				'rules' => 'trim',
			),
			array(
				'field' => 'primary_market_ops',
				'label' => 'Primary market operations ',
				'rules' => 'trim',
			),
			array(
				'field' => 'other_market_ops',
				'label' => 'Other market operations ',
				'rules' => 'trim',
			),
			array(
				'field' => 'profile',
				'label' => 'Organisation\'s description ',
				'rules' => 'trim',
			),
			array(
				'field' => 'name_p',
				'label' => 'Primary Nomination Full name',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'designation_p',
				'label' => 'Primary Nomination Position',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'telephone_p',
				'label' => 'Primary Nomination Phone No.',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'fax_p',
				'label' => 'Primary Nomination Fax No.',
				'rules' => 'trim',
			),
			array(
				'field' => 'email_p',
				'label' => 'Primary Nomination Email',
				'rules' => 'trim|valid_email|required',
			),
			array(
				'field' => 'name_s',
				'label' => 'Secondary Nomination Full Name',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'designation_s',
				'label' => 'Secondary Nomination Position',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'telephone_s',
				'label' => 'Secondary Nomination Phone No.',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'fax_s',
				'label' => 'Secondary Nomination Fax No.',
				'rules' => 'trim',
			),
			array(
				'field' => 'email_s',
				'label' => 'Secondary Nomination Email',
				'rules' => 'trim|valid_email|required',
			),
			array(
				'field' => 'contact_person',
				'label' => 'Contact Person\'s Full Name',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'designation',
				'label' => 'Contact Person\'s Position',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'contact_tel',
				'label' => 'Contact Person\'s Phone No.',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'contact_fax',
				'label' => 'Contact Person\'s Fax No.',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_email',
				'label' => 'Contact Person\'s Email',
				'rules' => 'trim|valid_email|required',
			),
			array(
				'field' => 'name_f',
				'label' => 'Finance\'s Full Name',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'designation_f',
				'label' => 'Finance\'s Position',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'telephone_f',
				'label' => 'Finance\'s Phone No.',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'fax_f',
				'label' => 'Finance\'s Fax No.',
				'rules' => 'trim',
			),
			array(
				'field' => 'email_f',
				'label' => 'Finance\'s Email',
				'rules' => 'trim|valid_email|required',
			),
			array(
				'field' => 'q1',
				'label' => 'q1',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'q2',
				'label' => 'q2',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'q3',
				'label' => 'q3',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'q4',
				'label' => 'q4',
				'rules' => 'trim',
			),
			array(
				'field' => 'q_usage',
				'label' => 'q_usage',
				'rules' => 'trim',
			),
			array(
				'field' => 'name_a',
				'label' => 'Applicant\'s Full Name',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'designation_a',
				'label' => 'Applicant\'s Position',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'email_a',
				'label' => 'Applicant\'s Email',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'date_2',
				'label' => 'date_2',
				'rules' => 'trim',
			),
/*
			array(
				'field' => 'logo',
				'label' => 'Organisation\'s Logo',
				'rules' => 'trim',
			),
*/
			array(
				'field' => 'file',
				'label' => 'file',
				'rules' => 'trim',
			),
			array(
				'field' => 'grower_file',
				'label' => 'grower file',
				'rules' => 'trim',
			),
/*
			array(
				'field' => 'file_certificates',
				'label' => 'file certificates',
				'rules' => 'trim',
			),
*/
			array(
				'field' => 'uploaded_files_cert',
				'label'	=> 'uploaded_files_cert',
				'rules'	=> 'trim',
			),
			array(
				'field' => 'upload_logo',
				'label' => 'upload_logo',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'applied_date',
				'label' => 'Application Date',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'newsletter',
				'label' => 'Newsletter Subscription',
				'rules' => 'trim',
			),
			array(
				'field' => 'remarks',
				'label' => 'Other information to support member application',
				'rules' => 'trim',
			),
		);

	protected $subcat_growers = array('Smallholder Group Manager', 'Small growers');

	protected $subcat_others = array(
		'Refinery, Edible oils and Food ingredients processors',
		'Only Trading, Logistics and Distributions',
		'Power, Energy and Bio-fuel',
		'Chemicals, Surfactants, and Non-Food ingredients processors',
		'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)'
	);
	protected $subcat_popt = array(
		'Refinery, Edible oils and Food ingredients processors',
		'Only Trading, Logistics and Distributions',
		'Power, Energy and Bio-fuel',
		'Chemicals, Surfactants, and Non-Food ingredients processors',
		'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)',
		'Others'
	);

	protected $subcategories = array(
		'Oil Palm Growers' => array('Smallholder Group Manager', 'Small growers'),

		'Consumer Goods Manufacturers' => array(
			'Refinery, Edible oils and Food ingredients processors',
			'Only Trading, Logistics and Distributions',
			'Power, Energy and Bio-fuel',
			'Chemicals, Surfactants, and Non-Food ingredients processors',
			'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)'
		),
		'Palm Oil Processors and Traders' => array(
			'Refinery, Edible oils and Food ingredients processors',
			'Only Trading, Logistics and Distributions',
			'Power, Energy and Bio-fuel',
			'Chemicals, Surfactants, and Non-Food ingredients processors',
			'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)',
			'Others'
		),
	);

	protected $categories = array(
		'affiliate' => array('Organisation', 'Individual'),
		'sca' => array('Organisation', 'Supply Chain Group Manager'),
	);

	public function __construct()
	{
		parent::__construct();
		$this->load->model(array('members_m', 'pnc_m', 'scc_m'));
		$this->load->library('form_validation');
		$this->load->helper('filesize');

		$countries['All'] = 'All countries';
		foreach($this->country_arrays as $c)
		{
			$countries[$c] = $c;
		}

		$member_categories = array(
			'' => 'All sectors',
			'Banks and Investors'=>'Banks and Investors',
			'Consumer Goods Manufacturers'=>'Consumer Goods Manufacturers',
			'Environmental and Conservation NGOs'=>'Environmental and Conservation NGOs',
			'Oil Palm Growers'=>'Oil Palm Growers',
			'Palm Oil Processors and Traders'=>'Palm Oil Processors and Traders',
			'Retailers'=>'Retailers',
			'Social and Developmental NGOs'=>'Social and Developmental NGOs',
			'Individuals'=>'Individuals',
			'Organisations'=>'Organisations',
			'Supply Chain Group Manager'=>'Supply Chain Group Manager',
		);

	    $member_types = array(
			'' => 'All types',
			'Ordinary Members'=>'Ordinary Members',
			'Affiliate Members'=>'Affiliate Members',
			'Supply Chain Associate'=>'Supply Chain Associate',
	    );

		$this->config_upload = array(
			'upload_path' 	=> UPLOAD_PATH . 'memberlogos',
			'allowed_types' => 'gif|jpg|png|pdf',
			'max_size' 		=> '20000',
			'remove_spaces'		=> TRUE,
			'overwrite'			=> FALSE,
			'encrypt_name'		=> FALSE,
		);

		foreach($this->country_arrays as $c)
		{
			$member_countries[$c] = $c;
		}

		$this->template
			->set('member_categories', $member_categories)
			->set('member_subcategories', $this->subcategories)
			->set('member_types', $member_types)
			->set('member_countries', $countries)
			->set('country_arrays', $countries)
			->set('country_single_arrays', $countries);
	}

	public function index($slug='')
	{
		$search = $this->input->get('member_country');

		if ($slug && strtolower($slug) <> 'all' && strtolower($slug) <> 'page')
		{

			if (method_exists($this->module, $slug))
			{
				call_user_func(array($this->controller, $slug));
			}
			else
			{
				if (func_num_args() > 1)
				{
					$arg_list = func_get_args();
					$slug = implode('/', $arg_list);
				}
				$this->_view($slug);
			}

		}
		else
		{
			$query = new stdClass();
			$pagination_suffix = array();
			//set the base/default where clause
			$base_where = array();
			//$base_where = array('status' => array('Approved', 'Call for Comments') );
			$base_where = array( 'status' => 'Approved' );

			//add post values to base_where if f_module is posted
			//$base_where = $this->input->post('f_area') ? $base_where + array('area' => $this->input->post('f_area')) : $base_where;

			if ($this->input->get('show_only'))
			{
				if ($this->input->get('show_only') <> 'members')
					$base_where['show_only'] = $this->input->get('show_only');
			}

			if ($this->input->get('keywords'))
			{
				$base_where['keywords'] = $this->input->get('keywords');
				$query->keywords = $base_where['keywords'];
				$pagination_suffix[] = 'keywords='.$base_where['keywords'];
			}
			else
			{
				$query->keywords = NULL;
			}

			if ($this->input->get('member_type'))
			{
				$base_where['type'] = $this->input->get('member_type');
				$query->member_type = $base_where['type'];
				$pagination_suffix[] = 'member_type='.$base_where['type'];
			}
			else
			{
				$query->member_type = NULL;
			}

			if ($this->input->get('member_category'))
			{
				$base_where['category'] = $this->input->get('member_category');
				$query->member_category = $base_where['category'];
				$pagination_suffix[] = 'member_category='.$base_where['category'];
			}
			else
			{
				$query->member_category = NULL;
			}

			$query_country = $this->input->get('member_country');
			if ($query_country &&  strtolower($query_country) <> 'all')
			{
				$base_where['country'] = $this->input->get('member_country');
				$query->member_country = $base_where['country'];
				$pagination_suffix[] = 'member_country='.$base_where['country'];
			}
			else
			{
				$query->member_country = NULL;
			}

			$query->show_only = NULL;
/*
echo "<pre>";
echo "\$base_where:\n";
print_r($base_where);
echo "<hr />\n";
echo "\$this->input->get('show_only'): ".$this->input->get('show_only')."\n";
echo "</pre>";
exit;
*/


			// Create pagination links
			if (!empty($base_where['show_only']))
			{
				switch($base_where['show_only'])
				{
					case 'scc_report':
						$total_rows = $this->scc_m->count_by($base_where);
						$pagination = create_pagination('members/page/', $total_rows, NULL, 3);
						$base_where['limit'] = array($pagination['limit'], $pagination['offset']);
						$members = $this->scc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
						$tobuild = 'scc/member-search';
						//$tobuild = 'scc/index';
						$this->template->set('sccs', $members);
						$query->show_only = 'scc_report';
						break;

					case 'pnc_report':
						$total_rows = $this->pnc_m->count_by($base_where);
						$pagination = create_pagination('members/page/', $total_rows, NULL, 3);
						$base_where['limit'] = array($pagination['limit'], $pagination['offset']);
						$members = $this->pnc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
						$assessments = $this->pnc_m->get_assessment_type();
						foreach($assessments as $a)
						{
							$ass_type[$a->id] = $a->stage;
						}
						$this->template->set('assessment_type', $ass_type);
						$tobuild = 'pnc/member-search';
						//$tobuild = 'pnc/index';
						$this->template->set('pncs', $members);
						$query->show_only = 'pnc_report';
						break;

					default:
						$total_rows = $this->members_m->count_by($base_where);
						$pagination = create_pagination('members/page/', $total_rows, NULL, 3);
						$base_where['limit'] = array($pagination['limit'], $pagination['offset']);
						$members = $this->members_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
						break;
				}
			}
			else
			{
				$total_rows = $this->members_m->count_by($base_where);
				$pagination = create_pagination('members/page/', $total_rows, NULL, 3);
				$base_where['limit'] = array($pagination['limit'], $pagination['offset']);
				$members = $this->members_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
			}

			// Using this data, get the relevant results
			//$members = $this->members_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);

			$this->template
				->title($this->module_details['name'])
				->set('query', $query)
				->set('pagination', $pagination)
				->set('members', $members);

			//do we need to unset the layout because the request is ajax?
			$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

			if (!empty($base_where['show_only']))
			{
				$this->template->build($tobuild);
			}
			else
			{
				if (empty($pagination_suffix) && strtolower($slug) <> 'all' && empty($search))
				{
					$this->template->build('index');
				}
				else
				{
					$this->input->is_ajax_request() ? $this->template->build('ajax/members') : $this->template->build('all');
				}
			}
		}

	}

	private function _view($slug)
	{
		$slug or redirect('members');

		$member = $this->members_m->get_by(array('intID'=>$slug, 'status'=>'Approved', 'isDeleted'=>'0'));
		if (!empty($member))
		{
			$this->load->model('scc_m');
			$member->scc = $this->scc_m->get_many_by(array('mid'=>$member->mid));
			$member->parent_member = $this->members_m->get_parent_member($member->intID);

			$this->template
				->title('Member', $member->name)
				->set('sccs', $member->scc)
				//->append_js('admin/filter.js')
				->set('member', $member);

			//$this->input->is_ajax_request() ? $this->template->build('ajax/view') : $this->template->build('view-primary');

			if ($member->parent_company == 'y')
			{
				$this->template->build('view-primary');
			}
			elseif (!empty($member->parent_member))
			{
				$this->template->build('view-subsidiary');
			}
			else
			{
				//$this->template->build('view');
				$this->template->build('view-subsidiary');
			}
		}
		else
		{
			// check if we have the page
			$this->load->model('pages/page_m');
			$page = $this->page_m->get_by_uri('members/'.$slug);
			if ($page)
			{
				$this->template
					->title('Members', $page->meta_title ? $page->meta_title : $page->title)
					->set('page', $page)
					->build('view-page');
			}
			else
			{
				$this->session->set_flashdata('error', lang('members:member_not_exist_error'));
				redirect('members/all');
			}

		}

	}

	public function pleasewait()
	{
		$this->template->build('applications/wait');
	}

	public function selecttype()
	{
		if (empty($this->current_user->id) )
		{
			$this->session->set_flashdata('error', 'You need to login to submit a member application. If you haven\'t registered, please do so by filling in the form below.');
			$this->session->set_flashdata('redirect_to', 'members/selecttype');
			redirect('members/apply');
			//exit;
		}
		else
		{
			if ($this->current_user->group <> 'user')
			{
				$this->session->set_flashdata('error', 'Sorry, you are not registered as an applying member. If you think you should be, please contact us <a href="mailto:membership@rspo.org?Subject=Unable to complete application due to wrong user access.">here</a>, or <a href="'.site_url('members/logout/members/apply').'">logout</a>.');
				redirect('members/all');
			}
			//exit;
		}

		$m = $this->members_m->get_by('MemberID_2', $this->current_user->id);
		if (!empty($m))
		{
			redirect('members/application');
		}

		$this->template->build('applications/select-type');
	}

	public function application()
	{
		if (empty($this->current_user->id) )
		{
			$this->session->set_flashdata('error', 'You need to login to submit a member application. If you haven\'t registered, please do so by filling in the form below.');
			redirect('members/apply');
			//exit;
		}
		else
		{
			if ($this->current_user->group <> 'user')
			{
				$this->session->set_flashdata('error', 'Sorry, you are not registered as an applying member. If you think you should be, please contact us <a href="mailto:membership@rspo.org?Subject=Unable to complete application due to wrong user access.">here</a>, or <a href="'.site_url('members/logout/members/apply').'">logout</a>.');
				redirect('members/all');
			}
			//exit;
		}

		$save = false;
		if ($this->input->post('btnSave'))
		{
			$save = true;
		}

		if ($this->input->post('category') == 'Oil Palm Growers')
		{
			$this->validation_rules['primary_market_ops'] = array(
				'field' => 'primary_market_ops',
				'label' => "Primary Market Operation",
				'rules' => 'trim|required',
			);
			$this->validation_rules['other_market_ops'] = array(
				'field' => 'other_market_ops',
				'label' => "Other Market Operation",
				'rules' => 'trim|required',
			);
		}

		$membershipapplication = new stdClass();
		$membersapp = new stdClass();

		if ($this->input->post('category'))
		{
			$membershipapplication->category = $this->input->post('category');
		}

		if ($this->input->post('type'))
		{
			$membershipapplication->type = $this->input->post('type');
		}
		
		// check if member has saved session
		$m = $this->members_m->get_by('MemberID_2', $this->current_user->id);
		if (!empty($m))
		{
			if ($m->status == 'Pending')
			{
				redirect('members/logout?u=members/pleasewait');
			}
			$membershipapplication = $m;
		}
		else
		{
			if (empty($membershipapplication->category))
				redirect('members/selecttype');
			$membershipapplication->intID = 0;
		}

		$subsidiaries = $this->input->post('sub_company');
		$sub_company = array();
		if (!empty($subsidiaries))
		{
			foreach($subsidiaries['name'] as $k=>$v)
			{
				if ($v)
				{
					$sub_company[$k]['name'] = $v;
					$sub_company[$k]['id'] = $subsidiaries['id'][$k];
				}
			}
			$subsidiary = serialize($sub_company);
		}
		else
		{
			$subsidiary = !empty($membershipapplication->sub_company) ? $membershipapplication->sub_company : serialize(NULL);
		}

		$this->check_dir($this->config_upload['upload_path']);
		$this->load->library('upload', $this->config_upload);
		
		if(!empty($_FILES['logo']['name'])){
		
			if(!$this->upload->do_upload('logo')){ 
				
			}
			else{
				$filelogo_array = $this->upload->data();
				$filelogo = $filelogo_array['file_name'];
			}
		}
		else{
			if ($_POST)
				$filelogo = $this->input->post('upload_logo');
			else
				$filelogo = isset($membershipapplication->logo) ? $membershipapplication->logo : '';
		}

		if (!empty($_FILES['file_certificates']['name'][0]))
		{
			if($this->upload->do_multi_upload("file_certificates"))
				{
					$file_certificates = array();
					$file_uploaded = $this->upload->get_multi_upload_data();
					if ($this->input->post('uploaded_files_cert'))
					{
						$file_certificates = explode(',', $this->input->post('uploaded_files_cert'));
					}

					foreach($file_uploaded as $files)
					{
						$file_certificates[] = $files['file_name'];
					}
					
					$cert_file_m = implode(',', $file_certificates);
				}
		}
		else{
			if ($_POST)
				$cert_file_m = $this->input->post('uploaded_files_cert');
			else
				$cert_file_m = isset($membershipapplication->file_certificates) ? $membershipapplication->file_certificates : '';
		}

/*
echo "<pre>";
print_r($_FILES);
echo "</pre>";
exit;
*/

//echo "\$cert_file_m: $cert_file_m<br />";
		if ($this->input->post('remove_uploaded_cert'))
		{
			$forremoveimg = explode(',',$cert_file_m);
			$remove_uploaded_cert = $this->input->post('remove_uploaded_cert');
			foreach($remove_uploaded_cert as $r)
			{

				if (($key = array_search($r, $forremoveimg)) !== false) {
//echo " -- removing file... <br />";
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg[$key]);
					}
					else
					{
						unset($forremoveimg[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$cert_file_m = implode(',', $forremoveimg);
		}

/*
echo "\$cert_file_m: $cert_file_m<br />";
exit;
*/
		if (!empty($_FILES['file']['name'][0]))
		{
			if($this->upload->do_multi_upload("file"))
				{
					$file = array();
					$file_uploaded = $this->upload->get_multi_upload_data();
					if ($this->input->post('grower_file'))
					{
						$file = explode(',', $this->input->post('grower_file'));
					}

					foreach($file_uploaded as $files)
					{
						$file[] = $files['file_name'];
					}
					
					$file_grower_m = implode(',', $file);
				}
		}
		else{
			if ($_POST)
				$file_grower_m = $this->input->post('grower_file');
			else
				$file_grower_m = isset($membershipapplication->file) ? $membershipapplication->file : '';
		}
		
		$forremoveimg_grower = explode(',',$file_grower_m);
		if ($this->input->post('remove_uploaded_grower'))
		{
			$remove_uploaded_grower = $this->input->post('remove_uploaded_grower');
			foreach($remove_uploaded_grower as $r)
			{
				
				if (($key = array_search($r, $forremoveimg_grower)) !== false) {
	
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg_grower[$key]);
					}
					else
					{
						unset($forremoveimg_grower[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$file = implode(',', $forremoveimg_grower);
		}

		$validated = false;
		if ($save && $this->input->post('btnSave'))
		{
			$validated = true; //$this->form_validation->run();
		}
		elseif ($this->input->post('btnSubmit'))
		{
			$this->form_validation->set_rules($this->validation_rules);
			$validated = $this->form_validation->run();
		}
		if ($this->input->post('applied_date'))
		{
			$a_date = explode('/', $this->input->post('applied_date'));
			$applied_year = $a_date[2];
			$applied_month = $a_date[1];
			$applied_day = $a_date[0];
			$applied_date = mktime(0, 0, 0, $applied_month, $applied_day, $applied_year);
		}
		else
		{
			$applied_date = isset($membershipapplication->applied_date) ? $membershipapplication->applied_date : 0;
		}
//		$applied_date = strtotime(sprintf('%s $s:$s', $this->input->post('applied_date'), date('H'), date('i')));

		if($validated)
		{
			$pcompany = $this->input->post('parent_company');
			if ($pcompany == 'none') $pcompany = null;
			$input = array(
				'title' 	=> $this->input->post('title'),
				'type' 		=> $this->input->post('type'),
				'category' 	=> $this->input->post('category'),
				'name' 		=> $this->input->post('name'),
				'address' 	=> $this->input->post('address'),
				'address_city' 	=> $this->input->post('address_city'),
				'address_state' => $this->input->post('address_state'),
				'address_zip' 	=> $this->input->post('address_zip'),
				'country' 		=> $this->input->post('country'),
				'telephone' 	=> $this->input->post('telephone'),
				'fax' 			=> $this->input->post('fax'),
				'email' 		=> $this->input->post('email'),
				'website'	 	=> $this->input->post('website'),
				'registration_number' 	=> $this->input->post('registration_number'),
				'parent_company' 		=> $pcompany,
				'sub_company'			=> ($pcompany == 'yes' OR $pcompany == 'sub') ? $subsidiary : null,
				'primary_market_ops' 	=> $this->input->post('primary_market_ops'),
				'other_market_ops' 	=> $this->input->post('other_market_ops'),
				'logo' 				=> $filelogo,
				'profile' 			=> $this->input->post('profile'),
				
				'name_p' 		=> $this->input->post('name_p'),
				'designation_p' => $this->input->post('designation_p'),
				'telephone_p' 	=> $this->input->post('telephone_p'),
				'fax_p' 		=> $this->input->post('fax_p'),
				'email_p' 		=> $this->input->post('email_p'),
				'name_s' 		=> $this->input->post('name_s'),
				'designation_s' => $this->input->post('designation_s'),
				'telephone_s' 	=> $this->input->post('telephone_s'),
				'fax_s' 		=> $this->input->post('fax_s'),
				'email_s' 		=> $this->input->post('email_s'),
				
				'contact_person' 	=> $this->input->post('contact_person'),
				'designation' 		=> $this->input->post('designation'),
				'contact_tel'	 	=> $this->input->post('contact_tel'),
				'contact_fax'	 	=> $this->input->post('contact_fax'),
				'contact_email' 	=> $this->input->post('contact_email'),
				
				'name_f' 		=> $this->input->post('name_f'),
				'designation_f' => $this->input->post('designation_f'),
				'telephone_f' 	=> $this->input->post('telephone_f'),
				'fax_f' 		=> $this->input->post('fax_f'),
				'email_f' 		=> $this->input->post('email_f'),
				
				'q1' => $this->input->post('q1'),
				'q2' => $this->input->post('q2'),
				'q3' => $this->input->post('q3'),
				'q4' => $this->input->post('q4'),
				'q_usage' => $this->input->post('q_usage'),
				
				'name_a' 		=> $this->input->post('name_a'),
				'designation_a' => $this->input->post('designation_a'),
				'email_a'		=> $this->input->post('email_a'),
				'date_2' 		=> $this->input->post('date_2'),
				'profession' 		=> $this->input->post('profession'),
				'file_certificates'	=> $cert_file_m,
				'file'				=> $file_grower_m,
				'applied_date' 		=> $applied_date,
				'remarks' 			=> $this->input->post('remarks'),
				'newsletter' 		=> $this->input->post('newsletter') ? $this->input->post('newsletter') : 'n',
			);

			$update = false;
			if ($save && $m && $this->input->post('draft_id'))
			{
				// update data
				$update = $this->members_m->update($this->input->post('draft_id'), $input);

/*
				$data = $input;
				$data['from'] = "membership@rspo.org";
				$data['from'] = "okky@catalyzecommunications.com";
				$data['to']		= $input['email_a'];
				$data['email']	= $input['email_a'];
				$data['slug']	= 'membership-application';
				Events::trigger('email', $data, 'array');

				$data_admin = $input;
				$data_admin['from']		= $input['email_a'];
				$data_admin['app_id']	= $this->input->post('draft_id');
				$data_admin['to']		= Settings::get('contact_email');
				$data_admin['email']	= $data_admin['to'];
				$data_admin['slug']		= 'membership-application-admin';
				Events::trigger('email', $data_admin, 'array');
*/
			}
			else
			{
				$input['MemberID_2'] = $this->current_user->id;
				if ($m && $this->input->post('draft_id'))
				{
					// update -> change status to Pending
					$input['status'] = 'Pending';
					$update = $this->members_m->update($this->input->post('draft_id'), $input);
					if ($update)
						$update = $this->input->post('draft_id');
				}
				else
				{
					// insert new one (member clicks submit without saving
					$update = $this->members_m->insert($input);
				}

				if (!$save)
				{
					// send notification to submitter first
					$data = $input;
					$data['from'] 			= "membership@rspo.org";
					$data['slug']			= 'membership-application';
					$data['to']				= $input['email_a'];
					$data['email']			= $input['email_a'];
					Events::trigger('email', $data, 'array');

					$data_admin = $input;
					$data_admin['app_id']	= $update;
					$data['from']			= $input['email_a'];
					$data_admin['to']		= Settings::get('contact_email');;
					$data_admin['email']	= $data_admin['to'];
					$data_admin['slug']		= 'membership-application-admin';
					Events::trigger('email', $data_admin, 'array');

					redirect('members/logout?u=members/submitted');
				}

				if ($update)
					$membershipapplication->intID = $update;
			}

			if($update)
			{
				if ($save)
					$this->session->set_flashdata('success', 'Your form was saved successfully.');
				else
					$this->session->set_flashdata('success', 'Your application has been submitted successfully to RSPO.');
				redirect('members/application');
			}
			else
			{
				$this->session->set_flashdata('error', 'Error Add');
				if ($save)
					$this->session->set_flashdata('error', 'We have difficulties saving your form. Please try again or report it to us.');
				else
					$this->session->set_flashdata('error', 'We have difficulties submitting your application. Please try again or report it to us.');
				redirect('members/application');
			}
		}
		
		// Go through all the known fields and get the post values
		if ($_POST)
		{
			foreach ($this->validation_rules as $rule)
			{
				$membershipapplication->{$rule['field']} = $this->input->post($rule['field']);
			}
		}

		$membershipapplication->logo = $filelogo;
		$membershipapplication->file = $file_grower_m;
		$membershipapplication->file_certificates = $cert_file_m;
		$membershipapplication->file = implode(',', $forremoveimg_grower);
		//$membershipapplication->file_certificates = implode(',', $forremoveimg);
		$membershipapplication->sub_company = $subsidiary;

		$membershipapplication->name_a = $this->input->post('name_a') ? $this->input->post('name_a') : $this->current_user->first_name . ( $this->current_user->last_name ? ' ' . $this->current_user->last_name : '' );
		$membershipapplication->email_a = $this->input->post('email_a') ? $this->input->post('email_a') : $this->current_user->email;

		$this->template
			->append_css('main.css')
			//->append_js('jquery.steps.min.js')
			->append_js('bootstrap-filestyle.js')
			->set('membersapp', $membershipapplication)
			->build('applications/application');
			//->build('applications/application');
	}

	public function submitted()
	{
		$this->template->build('applications/submitted');
	}

	/**
	 * Method to log the user out of the system
	 */
	public function logout($slug='')
	{
		$redirect_to = '';
		$u = $this->input->get('u');
		if ($u)
		{
			$redirect_to = $u;
			$this->session->set_userdata('redirect_to', $redirect_to);
		}

		// allow third party devs to do things right before the user leaves
		Events::trigger('pre_user_logout');

		$this->ion_auth->logout();

		if ($this->input->is_ajax_request())
		{
			exit(json_encode(array('status' => true, 'message' => lang('user:logged_out'))));
		}
		else
		{
			$this->session->set_flashdata('success', lang('user:logged_out'));
			$redirect_to ? redirect($redirect_to) : redirect('');
		}
	}

	/**
	 * Activated page.
	 *
	 * Shows an activated messages and a login form.
	 */
	public function activated()
	{
		//if they are logged in redirect them to the home page
		if ($this->current_user)
		{
			redirect(base_url());
		}

		$this->template->activated_email = ($email = $this->session->flashdata('activated_email')) ? $email : '';

		$this->template
			->title(lang('user:activated_account_title'))
			->build('member/activated');
	}

	public function activate($id=0, $code='')
	{
		// Get info from email
		if ($this->input->post('email'))
		{
			$this->template->activate_user = $this->ion_auth->get_user_by_email($this->input->post('email'));
			$id = $this->template->activate_user->id;
		}

		if (!$code)
			$code = ($this->input->post('activation_code')) ? $this->input->post('activation_code') : $code;

		// If user has supplied both bits of information
		if ($id and $code)
		{
			// Try to activate this user
			if ($this->ion_auth->activate($id, $code))
			{
				$this->session->set_flashdata('activated_email', $this->ion_auth->messages());

				// trigger an event for third party devs
				Events::trigger('post_user_activation', $id);
				$data['to'] = $this->input->post('email');
				$data['from'] = Settings::get('contact_email');
				$data['slug'] = 'activation-successful';
				Events::trigger('email', $data, 'array');
				redirect('members/activated');
			}
			else
			{
				$this->template->error_string = 'We were unable to activate your account, or it has been activated. Please login <a href="'.site_url('members/login').'">here</a>';//$this->ion_auth->errors();
			}
		}

		$this->template
			->title(lang('user:activate_account_title'))
			->set_breadcrumb(lang('user:activate_label'), 'member/activate')
			->build('member/activate');
	}

	public function login()
	{
		// Check post and session for the redirect place
		$redirect_to = ($this->input->post('redirect_to')) 
			? trim(urldecode($this->input->post('redirect_to')))
			: $this->session->userdata('redirect_to');

		// Any idea where we are heading after login?
		if ( ! $_POST and $args = func_get_args())
		{
			$this->session->set_userdata('redirect_to', $redirect_to = implode('/', $args));
		}

		// Get the user data
		$user = (object) array(
			'email' => $this->input->post('email'),
			'password' => $this->input->post('password')
		);

		$validation = array(
			array(
				'field' => 'email',
				'label' => lang('global:email'),
				'rules' => 'required|trim|callback__check_login'
			),
			array(
				'field' => 'password',
				'label' => lang('global:password'),
				'rules' => 'required|min_length['.$this->config->item('min_password_length', 'ion_auth').']|max_length['.$this->config->item('max_password_length', 'ion_auth').']'
			),
		);

		// Set the validation rules
		$this->form_validation->set_rules($validation);

		// If the validation worked, or the user is already logged in
		if ($this->form_validation->run() or $this->current_user)
		{
			// Kill the session
			$this->session->unset_userdata('redirect_to');

			$redirect_to = 'members/selecttype';

			$user = $this->ion_auth->get_user_by_email($user->email);

			// check if member has saved session
			if (!empty($user->id))
			{
				$m = $this->members_m->count_by( array('MemberID_2'=>$user->id, 'status'=>'Draft') );
				if ($m)
					$redirect_to = 'members/application';
			}

			// trigger a post login event for third party devs
			Events::trigger('post_user_login');

			if ($this->input->is_ajax_request())
			{
				$user->password = '';
				$user->salt = '';

				exit(json_encode(array('status' => true, 'message' => 'You have logged in successfully. If you are not being redirected, please <a href="'.site_url('members/application').'">click here</a>.', 'data' => $user, 'redirect_to'=>site_url($redirect_to))));
			}
			else
			{
				$this->session->set_flashdata('success', lang('user:logged_in'));
			}

			// Don't allow protocols or cheeky requests
			if (strpos($redirect_to, ':') !== false and strpos($redirect_to, site_url()) !== 0)
			{
				// Just login to the homepage
				redirect('');
			}

			// Passes muster, on your way
			else
			{
				redirect('members/application');
				//redirect($redirect_to ? $redirect_to : '');
			}
		}

		if ($_POST and $this->input->is_ajax_request())
		{
			exit(json_encode(array('status' => false, 'message' => validation_errors())));
		}

		$this->template
			->title('Members Login')
			->build('applications/login', array(
				'_user' => $user,
				'redirect_to' => $redirect_to,
			));
	}

	public function registerXX()
	{
		$this->load->model('users/user_m');
		$this->load->helper('users/user');
		$this->lang->load('users/user');

		$msg = 'nothing';

		if ($this->input->post('full_name'))
		{
			$name = $this->input->post('full_name');
			$first_name = strstr($name, ' ', true);
			$last_name =  trim(strstr($name, ' ')); //substr($name, strpos(' ', $name)); //
			$msg = "\$first_name: $first_name; \$last_name: $last_name ";
		}


		$message['status'] = 'ok';
		$message['message'] = $msg;

/*
		$message['status'] = 'ok';
		$message['message'] = 'Thank you for registering. Please check your email for verification link and further information.';
*/

		echo json_encode($message);
	}

	public function register()
	{
		if (!$this->input->is_ajax_request())
			redirect('members/apply');

		$checked = ($this->input->post('agree_cod') && $this->input->post('agree_pp'));
		if (!$checked)
		{
			$message = array(
				'status' => "error",
				'message'	=> "Please check both the Code of Conduct and Privacy Policy agreement checkboxes"
			);
			echo json_encode($message);
			exit;
		}

		$this->load->model('users/user_m');
		$this->load->helper('users/user');
		$this->lang->load('users/user');

		$msg = 'nothing';
/*
		if ($this->current_user)
		{
			$this->session->set_flashdata('notice', lang('user:already_logged_in'));
			redirect();
		}
*/

		/* show the disabled registration message */
/*
		if ( ! Settings::get('enable_registration'))
		{
			$this->template
				->title(lang('user:register_title'))
				->build('disabled');
			return;
		}
*/

		// Validation rules
		$validation = array(
			array(
				'field' => 'password',
				'label' => lang('global:password'),
				'rules' => 'required|min_length['.$this->config->item('min_password_length', 'ion_auth').']|max_length['.$this->config->item('max_password_length', 'ion_auth').']'
			),
			array(
				'field' => 'email',
				'label' => lang('global:email'),
				'rules' => 'required|max_length[60]|valid_email|callback__email_check',
			),
			array(
				'field' => 'full_name',
				'label' => 'Full name',
				'rules' => 'required|max_length[100]',
			),
			array(
				'field' => 'username',
				'label' => lang('user:username'),
				'rules' => Settings::get('auto_username') ? '' : 'required|alpha_dot_dash|min_length[3]|max_length[20]|callback__username_check',
			),
		);

		// --------------------------------
		// Merge streams and users validation
		// --------------------------------
		// Why are we doing this? We need
		// any fields that are required to
		// be filled out by the user when
		// registering.
		// --------------------------------

		$name = $this->input->post('full_name');
		if ($name)
		{

			$fn = explode(' ', $name, 2);
			$first_name = $fn[0];
			$last_name = isset($fn[1]) ? $fn[1] : '';

		}

		$_POST['first_name'] = $first_name;
		$_POST['last_name'] = $last_name;

		// Get the profile fields validation array from streams
		$this->load->driver('Streams');
		$profile_validation = $this->streams->streams->validation_array('profiles', 'users');

		// Remove display_name
		foreach ($profile_validation as $key => $values)
		{
			if ($values['field'] == 'display_name')
			{
				unset($profile_validation[$key]);
				break;
			}
		}

		// Set the validation rules
		//$this->form_validation->set_rules(array_merge($validation, $profile_validation));

		// Get user profile data. This will be passed to our
		// streams insert_entry data in the model.
		$assignments = $this->streams->streams->get_assignments('profiles', 'users');

		// This is the required profile data we have from
		// the register form
		$profile_data = array();

		// Get the profile data to pass to the register function.
		foreach ($assignments as $assign)
		{
			if ($assign->field_slug != 'display_name')
			{
				if (isset($_POST[$assign->field_slug]))
				{
					$profile_data[$assign->field_slug] = escape_tags($this->input->post($assign->field_slug));
				}
			}
		}

		// --------------------------------

		// Set the validation rules
		$this->form_validation->set_rules($validation);

		$user = new stdClass();

		// Set default values as empty or POST values
		foreach ($validation as $rule)
		{
			$user->{$rule['field']} = $this->input->post($rule['field']) ? escape_tags($this->input->post($rule['field'])) : null;
		}

		// Are they TRYing to submit?
		if ($_POST)
		{
			if ($this->form_validation->run())
			{
				// Check for a bot usin' the old fashioned
				// don't fill this input in trick.
				if (escape_tags($this->input->post('d0ntf1llth1s1n')) !== ' ')
				{
					$this->session->set_flashdata('error', lang('user:register_error'));
					redirect(current_url());
				}

				$email = escape_tags($this->input->post('email'));
				$password = escape_tags($this->input->post('password'));

				// --------------------------------
				// Auto-Username
				// --------------------------------
				// There are no guarantees that we 
				// will have a first/last name to
				// work with, so if we don't, use
				// an alternate method.
				// --------------------------------

				if (Settings::get('auto_username'))
				{
					if ($this->input->post('first_name') and $this->input->post('last_name'))
					{
						$this->load->helper('url');
						$username = url_title(escape_tags($this->input->post('first_name')).'.'.escape_tags($this->input->post('last_name')), '-', true);

						// do they have a long first name + last name combo?
						if (strlen($username) > 19)
						{
							// try only the last name
							$username = url_title(escape_tags($this->input->post('last_name')), '-', true);

							if (strlen($username) > 19)
							{
								// even their last name is over 20 characters, snip it!
								$username = substr($username, 0, 20);
							}
						}
					}
					else
					{
						// If there is no first name/last name combo specified, let's
						// user the identifier string from their email address
						$email_parts = explode('@', $email);
						$username = $email_parts[0];
					}

					// Usernames absolutely need to be unique, so let's keep
					// trying until we get a unique one
					$i = 1;

					$username_base = $username;

					while ($this->db->where('username', $username)
						->count_all_results('users') > 0)
					{
						// make sure that we don't go over our 20 char username even with a 2 digit integer added
						$username = substr($username_base, 0, 18).$i;

						++$i;
					}
				}
				else
				{
					// The user specified a username, so let's use that.
					$username = escape_tags($this->input->post('username'));
				}

				// --------------------------------

				// Do we have a display name? If so, let's use that.
				// Othwerise we can use the username.
				if ( ! isset($profile_data['display_name']) or ! $profile_data['display_name'])
				{
					$profile_data['display_name'] = $username;
				}

				// We are registering with a null group_id so we just
				// use the default user ID in the settings.
				$id = $this->ion_auth->register($username, $password, $email, null, $profile_data);

				// Try to create the user
				if ($id > 0)
				{
					$status = 'ok';

					// Convert the array to an object
					$user->username = $username;
					$user->display_name = $username;
					$user->email = $email;
					$user->password = $password;

					// trigger an event for third party devs
					Events::trigger('post_user_register', $id);

					/* send the internal registered email if applicable */
					if (Settings::get('registered_email'))
					{
						$this->load->library('user_agent');

						Events::trigger('email', array(
							'name' => $user->display_name,
							'sender_ip' => $this->input->ip_address(),
							'sender_agent' => $this->agent->browser().' '.$this->agent->version(),
							'sender_os' => $this->agent->platform(),
							'slug' => 'registered',
							'email' => Settings::get('contact_email'),
						), 'array');
					}

					// show the "you need to activate" page while they wait for their email
					if ((int)Settings::get('activation_email') === 1)
					{
						$msg = $this->ion_auth->messages();
						//$this->session->set_flashdata('notice', $this->ion_auth->messages());
						//redirect('users/activate');
					}
					// activate instantly
					elseif ((int)Settings::get('activation_email') === 2)
					{
						$this->ion_auth->activate($id, false);

						$this->ion_auth->login(escape_tags($this->input->post('email')), escape_tags($this->input->post('password')));
						redirect($this->config->item('register_redirect', 'ion_auth'));
					}
					else
					{
						$this->ion_auth->deactivate($id);

						/* show that admin needs to activate your account */
						$msg = lang('user:activation_by_admin_notice');
						//$this->session->set_flashdata('notice', lang('user:activation_by_admin_notice'));
						//redirect('users/register'); /* bump it to show the flash data */
					}
				}

				// Can't create the user, show why
				else
				{
					$status = 'error';
					$msg = $this->ion_auth->errors();
					//$this->template->error_string = $this->ion_auth->errors();
				}
			}
			else
			{
				// Return the validation error
				$status = 'error';
				$msg = $this->form_validation->error_string();
				//$this->template->error_string = $this->form_validation->error_string();
			}
			$message['status'] = $status;
			$message['message'] = $msg;
		}

		// Is there a user hash?
		else {

			if (($user_hash = $this->session->userdata('user_hash')))
			{
				// Convert the array to an object
				$user->email = ( ! empty($user_hash['email'])) ? $user_hash['email'] : '';
				$user->username = $user_hash['nickname'];
			}
		}

		echo json_encode($message);

		// --------------------------------
		// Create profile fields.
		// --------------------------------

		// Anything in the post?

/*
		$this->template->set('profile_fields', $this->streams->fields->get_stream_fields('profiles', 'users', $profile_data));

		// --------------------------------

		$this->template
			->title(lang('user:register_title'))
			->set('_user', $user)
			->build('register');
*/
	}

	public function apply()
	{
		if (!empty($this->current_user->id))
		{
			if ($this->current_user->group == 'user')
			{
				$m = $this->members_m->count_by( array('MemberID_2'=>$this->current_user->id, 'status'=>'Draft') );
				if ($m)
					redirect('members/application');
				else
					redirect('members/selecttype');
			}
			else
			{
				$this->session->set_flashdata('error', 'Sorry, you are not registered as an applying member. If you think you should be, please contact us <a href="mailto:membership@rspo.org?Subject=Unable to complete application due to wrong user access.">here</a>, or <a href="'.site_url('members/logout/members/apply').'">logout</a>.');
				redirect('members/all');
			}
		}

		$this->template
			//->append_js('module::bootstrap.min.js')
			//->append_js('module::responsive-tabs.js')
			//->set('membersapp', $membershipapplication)
			->build('applications/apply');
	}

	public function applyOLD()
	{
		if (!empty($this->current_user->id))
		{
			if ($this->current_user->group == 'user')
			{
				$m = $this->members_m->count_by( array('MemberID_2'=>$this->current_user->id, 'status'=>'Draft') );
				if ($m)
					redirect('members/application');
				else
					redirect('members/selecttype');
			}
			else
			{
				$this->session->set_flashdata('error', 'Sorry, you are not registered as an applying member. If you think you should be, please contact us <a href="mailto:membership@rspo.org?Subject=Unable to complete application due to wrong user access.">here</a>, or <a href="'.site_url('members/logout/members/apply').'">logout</a>.');
				redirect('members/all');
			}
		}
		$membershipapplication = new stdClass();
		$membersapp = new stdClass();
		
		
		$this->check_dir($this->config_upload['upload_path']);
		
		
		
		$this->form_validation->set_rules($this->validation_rules);
		if($this->form_validation->run()){
			
			$membershipapp_insert = array(
				'title' 	=> $this->input->post('title'),
				'type' 		=> $this->input->post('type'),
				'category' 	=> $this->input->post('category'),
				'name' 		=> $this->input->post('name'),
				'address' 	=> $this->input->post('address'),
				'address_city' 	=> $this->input->post('address_city'),
				'address_state' => $this->input->post('address_state'),
				'address_zip' 	=> $this->input->post('address_zip'),
				'country' 		=> $this->input->post('country'),
				'telephone' 	=> $this->input->post('telephone'),
				'fax' 			=> $this->input->post('fax'),
				'email' 		=> $this->input->post('email'),
				'website'	 	=> $this->input->post('website'),
				'registration_number' 	=> $this->input->post('registration_number'),
				'parent_company' 		=> $this->input->post('parent_company'),
				'primary_market_ops' 	=> $this->input->post('primary_market_ops'),
				'other_market_ops' 	=> $this->input->post('other_market_ops'),
				'logo' 				=> $filelogo,
				'profile' 			=> $this->input->post('profile'),
				
				'name_p' 		=> $this->input->post('name_p'),
				'designation_p' => $this->input->post('designation_p'),
				'telephone_p' 	=> $this->input->post('telephone_p'),
				'fax_p' 		=> $this->input->post('fax_p'),
				'email_p' 		=> $this->input->post('email_p'),
				'name_s' 		=> $this->input->post('name_s'),
				'designation_s' => $this->input->post('designation_s'),
				'telephone_s' 	=> $this->input->post('telephone_s'),
				'fax_s' 		=> $this->input->post('fax_s'),
				'email_s' 		=> $this->input->post('email_s'),
				
				'contact_person' 	=> $this->input->post('contact_person'),
				'designation' 		=> $this->input->post('designation'),
				'contact_tel'	 	=> $this->input->post('contact_tel'),
				'contact_fax'	 	=> $this->input->post('contact_fax'),
				'contact_email' 	=> $this->input->post('contact_email'),
				
				'name_f' 		=> $this->input->post('name_f'),
				'designation_f' => $this->input->post('designation_f'),
				'telephone_f' 	=> $this->input->post('telephone_f'),
				'fax_f' 		=> $this->input->post('fax_f'),
				'email_f' 		=> $this->input->post('email_f'),
				
				'q1' => $this->input->post('q1'),
				'q2' => $this->input->post('q2'),
				'q3' => $this->input->post('q3'),
				'q4' => $this->input->post('q4'),
				'q_usage' => $this->input->post('q_usage'),
				
				'name_a' 		=> $this->input->post('name_a'),
				'designation_a' => $this->input->post('designation_a'),
				'date_2' 		=> $this->input->post('date_2'),
				'profession' 		=> $this->input->post('org_subcategory'),
				'file_certificates'	=> $cert_file_m,
				'file'				=> $file_grower_m,
			);
			
			if($this->members_m->insert($membershipapp_insert))
				{
					$this->session->set_flashdata('success', 'Success Add');
					//redirect('members/membership_app');
				}
			else{
					$this->session->set_flashdata('error', 'Error Add');
					//redirect('members/membership_app');
				}
		}
		
/*
		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $rule)
		{
			$membershipapplication->{$rule['field']} = $this->input->post($rule['field']);
		}
		
		$membershipapplication->logo = $filelogo;
		$membershipapplication->file = $file_grower_m;
		$membershipapplication->file_certificates = $cert_file_m;
		$membershipapplication->file = implode(',', $forremoveimg_grower);
		$membershipapplication->file_certificates = implode(',', $forremoveimg);
*/

		$redirect_to = $this->session->flashdata('redirect_to');

		$this->template
			//->append_js('module::bootstrap.min.js')
			//->append_js('module::responsive-tabs.js')
			->set('membersapp', $membershipapplication)
			->build('applications/apply');
	}

	public function forget($code=null)
	{
		$this->template->title(lang('user:reset_password_title'));

		if (PYRO_DEMO)
		{
			show_error(lang('global:demo_restrictions'));
		}

		//if user is logged in they don't need to be here
		if ($this->current_user)
		{
			if ($this->input->is_ajax_request())
			{
				exit(json_encode(array('status' => false, 'message' => lang('user:already_logged_in') )));
			}
			else
			{
				$this->session->set_flashdata('error', lang('user:already_logged_in'));
				redirect('');
			}
		}

		if ($this->input->post('email'))
		{
			$uname = (string) $this->input->post('user_name');
			$email = (string) $this->input->post('email');

			if ( ! $uname and ! $email)
			{
				// they submitted with an empty form, abort
				$this->template->set('error_string', $this->ion_auth->errors())
					->build('reset_pass');
			}

			if ( ! ($user_meta = $this->ion_auth->get_user_by_email($email)))
			{
				$user_meta = $this->ion_auth->get_user_by_username($email);
			}

			// have we found a user?
			if ($user_meta)
			{
				$new_password = $this->ion_auth->forgotten_password($user_meta->email);

				if ($new_password)
				{
					//set success message

					if ($this->input->is_ajax_request())
					{
						exit(json_encode(array('status' => true, 'message' => lang('user:password_reset_message') )));
					}
					else
					{
						$this->template->success_string = lang('user:password_reset_message');
					}
				}
				else
				{
					// Set an error message explaining the reset failed
					if ($this->input->is_ajax_request())
					{
						exit(json_encode(array('status' => false, 'message' => $this->ion_auth->errors() )));
					}
					else
					{
						$this->template->error_string = $this->ion_auth->errors();
					}
				}
			}
			else
			{
				//wrong username / email combination
				if ($this->input->is_ajax_request())
				{
					exit(json_encode(array('status' => false, 'message' => lang('user:forgot_incorrect') )));
				}
				else
				{
					$this->template->error_string = lang('user:forgot_incorrect');
				}
			}
		}

		if (!$code) $code = $this->input->post('code');
		// code is supplied in url so lets try to reset the password
		if ($code)
		{
			// verify reset_code against code stored in db
			$reset = $this->ion_auth->forgotten_password_complete($code);

			// did the password reset?
			if ($reset)
			{
				if ($this->input->is_ajax_request())
				{
					exit(json_encode(array('status' => true, 'message' => lang('user:password_reset_message') )));
				}
				else
				{
					redirect('members/reset_complete');
				}
			}
			else
			{
				// nope, set error message
				if ($this->input->is_ajax_request())
				{
					exit(json_encode(array('status' => false, 'message' => $this->ion_auth->errors() )));
				}
				else
				{
					$this->template->error_string = $this->ion_auth->errors();
				}
			}
		}

		$this->template->build('member/reset_pass');
	}

	/**
	 * Password reset is finished
	 */
	public function reset_complete()
	{
		//if user is logged in they don't need to be here. and should use profile options
		if ($this->current_user)
		{
			$this->session->set_flashdata('error', lang('user:already_logged_in'));
			redirect('members');
		}

		$this->template
			->title(lang('user:password_reset_title'))
			->build('member/reset_pass_complete');
	}

	public function applyXX(){
		$this->template
			->build('form_applications_login_or_register');
	}
	
	public function apply_membership_typeOLD(){
		$this->template
			->build('form_applications_register');
	}
	
	public function apply_organisation_detail(){
		$this->template
			//->append_js('jquery.min.js')
			->append_js('bootstrap-filestyle.js')
			->build('form_applications_orgdetail');
			//->build('applications/detail-organisation');
	}
	
	public function apply_contact_detail(){
		$this->template
			->build('applications/detail-contact');
	}
	
	public function apply_supporting_detail(){
		$this->template
			//->append_js('jquery.min.js')
			->append_js('bootstrap-filestyle.js')
			->build('applications/detail-supporting');
	}
	
	function check_dir($dir)
	{
		// check directory
		$fileOK = array();
		$fdir = explode('/', $dir);
		$ddir = '';
		for($i=0; $i<count($fdir); $i++)
		{
			$ddir .= $fdir[$i] . '/';
			if (!is_dir($ddir))
			{
				if (!@mkdir($ddir, 0777)) {
					$fileOK[] = 'not_ok';
				}
				else
				{
					$fileOK[] = 'ok';
				}
			}
			else
			{
				$fileOK[] = 'ok';
			}
		}
		return $fileOK;
	}

	/**
	 * Username check
	 *
	 * @author Ben Edmunds
	 *
	 * @param string $username The username to check.
	 *
	 * @return bool
	 */
	public function _username_check($username)
	{
		if ($this->ion_auth->username_check($username))
		{
			$this->form_validation->set_message('_username_check', lang('user:error_username'));
			return false;
		}

		return true;
	}

	/**
	 * Email check
	 *
	 * @author Ben Edmunds
	 *
	 * @param string $email The email to check.
	 *
	 * @return bool
	 */
	public function _email_check($email)
	{
		if ($this->ion_auth->email_check($email))
		{
			$this->form_validation->set_message('_email_check', lang('user:error_email'));
			return false;
		}

		return true;
	}

	/**
	 * Callback method used during login
	 *
	 * @param str $email The Email address
	 *
	 * @return bool
	 */
	public function _check_login($email)
	{
		$remember = false;
		if ($this->input->post('remember') == 1)
		{
			$remember = true;
		}

		if ($this->ion_auth->login($email, $this->input->post('password'), $remember))
		{
			return true;
		}

		Events::trigger('login_failed', $email);
		error_log('Login failed for user '.$email);

		$this->form_validation->set_message('_check_login', $this->ion_auth->errors());
		return false;
	}

	// pick a member for auto-suggest
	public function pick($id=0)
	{
		$q = $this->input->get('term');
		$res = $this->members_m->get_many_by_name($q);
		foreach($res as $m)
		{
			$members[] = array('value'=>$m->title, 'id'=>$m->intID);
		}

		echo json_encode($members);
	}


}