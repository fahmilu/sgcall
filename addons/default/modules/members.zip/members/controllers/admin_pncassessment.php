<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Admin_pncassessment extends Admin_Controller
{
	protected $section = 'pnc';

	protected $validation_rules = array(

		array(
			'field' => 'mill[]',
			'label' => 'lang:pnc:mill_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'mill_country[]',
			'label' => 'Mill\'s Country',
			'rules' => 'trim'
		),
		array(
			'field' => 'mid',
			'label' => 'lang:pnc:mill_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'date',
			'label' => 'lang:pnc:mill_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'online_status',
			'label' => 'lang:pnc:status_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'member_name',
			'label' => 'lang:pnc:member_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'mid',
			'label' => 'lang:pnc:member_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'certification_body',
			'label' => 'lang:pnc:cb_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'cb_id',
			'label' => 'lang:pnc:cb_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'assessment_type',
			'label' => 'lang:pnc:assessment_type_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'status',
			'label' => 'lang:pnc:assessment_status_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'notification_date',
			'label' => 'lang:pnc:date_notification_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'notification_end',
			'label' => 'lang:pnc:date_notification_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'assessment_date',
			'label' => 'lang:pnc:date_assessment_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'assessment_end',
			'label' => 'lang:pnc:end_assessment_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'subremarks',
			'label' => 'lang:pnc:sub_remarks_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'certificate_file',
			'label' => 'lang:pnc:sub_remarks_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'notification',
			'label' => 'lang:pnc:sub_remarks_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'notification_2',
			'label' => 'lang:pnc:sub_remarks_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'notification_3',
			'label' => 'lang:pnc:sub_remarks_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'uploaded',
			'label' => 'lang:pnc:sub_remarks_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'uploaded_files',
			'label' => 'lang:pnc:sub_remarks_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'notification_file_1',
			'label' => 'lang:pnc:sub_remarks_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'notification_file_2',
			'label' => 'lang:pnc:sub_remarks_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'notification_file_3',
			'label' => 'lang:pnc:sub_remarks_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'final_report_date',
			'label' => 'lang:pnc:date_final_report_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'remarks',
			'label' => 'lang:pnc:remarks_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'report_accepted_date',
			'label' => 'lang:pnc:date_report_accepted',
			'rules' => 'trim'
		),
		array(
			'field' => 'isUp',
			'label' => 'lang:pnc:date_report_accepted',
			'rules' => 'trim'
		),
//		array(
//			'field' => 'certified_area',
//			'label' => 'Certified Area',
//			'rules' => 'trim|numeric'
//		),
//		array(
//			'field' => 'production_area',
//			'label' => 'Production Area',
//			'rules' => 'trim|numeric'
//		),
//		array(
//			'field' => 'cspo',
//			'label' => 'Certified Volume (CSPO)',
//			'rules' => 'trim|numeric'
//		),
//		array(
//			'field' => 'cspk',
//			'label' => 'Certified Volume (CSPK)',
//			'rules' => 'trim|numeric'
//		),
	);

	protected $upload_cfg = array(
		'allowed_types'		=> 'jpg|gif|png|jpeg|pdf',
		'max_size'			=> '20000',
		'remove_spaces'		=> TRUE,
		'overwrite'			=> FALSE,
		'encrypt_name'		=> FALSE,
	);

	public function __construct()
	{
		parent::__construct();
		$this->load->model(array('members_m', 'pnc_m', 'cb_m'));
		$this->lang->load(array('members', 'pnc'));
		$this->load->config('config');

		$this->upload_cfg['upload_path'] = UPLOAD_PATH . 'pnc';

		$categories = array(
			'om' => array(
				'Banks and Investors',
				'Consumer Goods Manufacturers',
				'Environmental and Conservation NGOs',
				'Oil Palm Growers',
				'Palm Oil Processors and Traders',
				'Retailers',
				'Social and Developmental NGOs',
			),
			'am' => array('Individuals', 'Organisations'),
			'sca'=> array('Organisation', 'Supply Chain Group Manager')
		);
		$member_categories = array(
				'Banks and Investors'=>'Banks and Investors',
				'Consumer Goods Manufacturers'=>'Consumer Goods Manufacturers',
				'Environmental and Conservation NGOs'=>'Environmental and Conservation NGOs',
				'Oil Palm Growers'=>'Oil Palm Growers',
				'Palm Oil Processors and Traders'=>'Palm Oil Processors and Traders',
				'Retailers'=>'Retailers',
				'Social and Developmental NGOs'=>'Social and Developmental NGOs',
				'Individuals'=>'Individuals',
				'Organisations'=>'Organisations',
				'Supply Chain Group Manager'=>'Supply Chain Group Manager',
		);

	    $types = array(
	      'om_subcat'=>'Ordinary Members',
	      'am_subcat'=>'Affiliate Members',
	      'sca_subcat'=>'Supply Chain Associate',
	    );

	    $member_types = array(
	      'Ordinary Members',
	      'Affiliate Members',
	      'Supply Chain Associate',
	    );

		$subcat_growers = array('Smallholder Group Manager', 'Small growers');

		$subcat_others = array(
			'Refinery, Edible oils and Food ingredients processors',
			'Only Trading, Logistics and Distributions',
			'Power, Energy and Bio-fuel',
			'Chemicals, Surfactants, and Non-Food ingredients processors',
			'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)'
		);
		$subcat_popt = array(
			'Refinery, Edible oils and Food ingredients processors',
			'Only Trading, Logistics and Distributions',
			'Power, Energy and Bio-fuel',
			'Chemicals, Surfactants, and Non-Food ingredients processors',
			'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)',
			'Others'
		);

		$count = $this->pnc_m->count_all();

		$assessments = $this->pnc_m->get_assessment_type();
		foreach($assessments as $a)
		{
			$ass_type[$a->id] = $a->stage;
		}

		$assessment_status = array(
			'notification'	=>'Notification',
			'assessment'	=>'Assessment',
			'both'			=>'Both Notification & Assessment',
			'terminated'	=>'Terminated',
			'suspended'		=>'Suspended',
		);

		// countries - from config.php
//		$_countries = config_item('country_arrays');
//		foreach($_countries as $country)
//		{
//			$countries[$country] = $country;
//		}

		// supply options
		$supply_options = array(
			'IP' => 'Identity Preserved',
			'SG' => 'Segregated',
			'MB' => 'Mass Balance',
		);

		// countries - from config.php
		$_countries = config_item('country_arrays');
		foreach($_countries as $country)
		{
			$countries[$country] = $country;
		}

		// supply options
		$supply_options = array(
			'IP' => 'Identity Preserved',
			'SG' => 'Segregated',
			'MB' => 'Mass Balance',
		);

		$this->template
			->append_css('module::members.css')
			->set('count', $count)
			->set('supply_options', $supply_options)
			->set('countries', $countries)
			->set('assessment_type', $ass_type)
			->set('assessment_status', $assessment_status)
			->set('member_categories', $member_categories)
			->set('categories', $categories)
			->set('member_types', $member_types)
			->set('types', $types)
			->set('subcat_growers', $subcat_growers)
			->set('subcat_others', $subcat_others)
			->set('subcat_popt', $subcat_popt);
	}

	public function index()
	{
		//set the base/default where clause
		//$base_where = array('status' => 'all');//, 'order'=>'created_on', 'sort'=>'desc');
		$base_where = array('status' => 'all', 'order' => 'assessment_date');//, 'order'=>'created_on', 'sort'=>'desc');
//		if ($this->input->post('f_status'))
//		{
//			$fs = $this->input->post('f_status');
//			if ($fs=='draft')
//				$s = 0;
//			elseif ($fs=='live')
//				$s = 1;
//			else
//				$s = 'all';
//
//			$base_where['status'] = $s;
//		}
		$base_where['status'] = $this->input->post('f_status') ? $this->input->post('f_status') : NULL;

		$base_where['assessment_status'] = $this->input->post('f_assessment_status') ? $this->input->post('f_assessment_status') : NULL;

		$base_where['assessment_type'] = $this->input->post('f_assessment_type') ? $this->input->post('f_assessment_type') : NULL;

		$base_where['keywords'] = $this->input->post('f_keywords') ? $this->input->post('f_keywords') : NULL;

		// Create pagination links
		$total_rows = $this->pnc_m->count_by($base_where);
//		print_r($base_where);
//		print_r($total_rows);
//		die;
		$pagination = create_pagination('admin/members/pncassessment/index', $total_rows, NULL, 5);

		$base_where['limit'] = array($pagination['limit'], $pagination['offset']);

		// Using this data, get the relevant results
		$pncs = $this->pnc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);

		//do we need to unset the layout because the request is ajax?
		$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

		$this->template
			->title($this->module_details['name'])
			->append_js('admin/filter.js')
			->set('count', $total_rows)
			->set('pagination', $pagination)
			->set('pncs', $pncs);

		$this->input->is_ajax_request() ? $this->template->build('admin/pnc/tables/pnc') : $this->template->build('admin/pnc/index');
	}

	public function create($mid=0)
	{
		role_or_die('members', 'add_pnc');

		$pnc = new stdClass();

		if ($mid)
		{
			$member = $this->members_m->get_by('intID', $mid);
			if (!empty($member))
			{
				$this->template
					->set('member_name', $member->title)
					->set('member_id', $member->intID);
			}
		}

		$this->form_validation->set_rules($this->validation_rules);

		if ($this->input->post('notification_date'))
		{
			// $date = $this->input->post('notification_date');//strtotime(sprintf('%s %s:%s', $this->input->post('notification_date'), 0, 0));
			// $date .= ' 00:00:00';
			$date = strtotime(sprintf('%s %s:%s', $this->input->post('notification_date'), 0, 0));
		}
		else
		{
			// $date = date('Y-m-d', now());
			$date = null;
		}

		if ($this->input->post('notification_end'))
		{
			// $date = $this->input->post('notification_date');//strtotime(sprintf('%s %s:%s', $this->input->post('notification_date'), 0, 0));
			// $date .= ' 00:00:00';
			$date_end = strtotime(sprintf('%s %s:%s', $this->input->post('notification_end'), 0, 0));
		}
		else
		{
			// $date = date('Y-m-d', now());
			if ($this->input->post('notification_date')) {
				$date_end = strtotime(date("Y-m-d", strtotime($this->input->post('notification_date'))) . " +1 month");
			} else {
				$date_end = null;
			}
			
		}

//		if ($this->input->post('scc_model'))
//		{
//			$_so = $this->input->post('scc_model');
//			$_so = array_values($_so);
//			$supply_options = implode(',', $_so);
//		}
//		else
//		{
//			$supply_options = '';
//		}

		if ($this->input->post('assessment_date'))
		{
			$assessment_date = strtotime(sprintf('%s %s:%s', $this->input->post('assessment_date'), 0, 0));
		}
		else
		{
			$assessment_date = null;
		}

		if ($this->input->post('assessment_end'))
		{
			$assessment_end = strtotime(sprintf('%s %s:%s', $this->input->post('assessment_end'), 0, 0));
		}
		else
		{
			if ($this->input->post('assessment_date')) {
				$assessment_end = strtotime(date("Y-m-d", strtotime($this->input->post('assessment_date'))) . " +1 month");
			} else {
				$assessment_end = null;
			}
		}

		if ($this->input->post('final_report_date'))
		{
			$final_report_date = strtotime(sprintf('%s %s:%s', $this->input->post('final_report_date'), 0, 0));
		}
		else
		{
			$final_report_date = 0;
		}

		if ($this->input->post('report_accepted_date'))
		{
			$report_accepted_date = strtotime(sprintf('%s %s:%s', $this->input->post('report_accepted_date'), 0, 0));
		}
		else
		{
			$report_accepted_date = 0;
		}

		$isUp = $this->input->post('online_status') == 'live' ? '1' : '0';

		$cb_id = (int)$this->input->post('cb_id');
		if ($cb_id)
		{
			$cb = $this->cb_m->get($cb_id);
			$pnc->cb_name = $cb->name;
		}

		// check directory exists
		$this->check_dir($this->upload_cfg['upload_path']);
		$this->load->library('upload', $this->upload_cfg);

        $certificate_file = $this->input->post('certificate_file');
		if (!empty($_FILES['certificate']['name']))
		{
			if($this->upload->do_upload("certificate"))
			{
				$file_certificate = $this->upload->data();
				$pnc->certificate = $file_certificate['file_name'];
				$certificate_file = $file_certificate['file_name'];
			}
		}


		// if (!empty($_FILES['uploaded_files']['name'][0]))
		// {
		// 	if($this->upload->do_multi_upload("uploaded_files"))
		// 	{
		// 		$uploaded = array();
		// 		$file_uploaded = $this->upload->get_multi_upload_data('uploaded_files');
		// 		if ($this->input->post('uploaded_files'))
		// 		{
		// 			$uploaded = explode(',', $this->input->post('uploaded_files'));
		// 		}
		// 		foreach($file_uploaded as $file)
		// 		{
		// 			$uploaded[] = $file['file_name'];
		// 		}
		// 		$pnc->uploaded = implode(',', $uploaded);
		// 		//$uploaded = $uploaded + explode(',', $this->input->post('uploaded_files'));
		// 	}
		// }
		// else
		// {
		// 	$uploaded = explode(',', $this->input->post('uploaded_files'));
		// }

		if (!empty($_FILES['uploaded_files']['name']))
		{
			if($this->upload->do_multi_upload("uploaded_files"))
			{
				$uploaded = array();
				$file_uploaded = $this->upload->get_multi_upload_data('uploaded_files');
				if ($this->input->post('uploaded_files'))
				{
					$uploaded = explode(',', $this->input->post('uploaded_files'));
				}
				foreach($file_uploaded as $file)
				{
					$uploaded[] = $file['file_name'];
				}
				$pnc->uploaded = implode(',', $uploaded);
				$uploaded_input = implode(',', $uploaded);
				//$uploaded = $uploaded + explode(',', $this->input->post('uploaded_files'));
			}
		}
		else
		{
			// $uploaded = explode(',', $this->input->post('uploaded_files'));
			$uploaded = null;
		}


        $notification = $this->input->post('notification');
		if (!empty($_FILES['notification_file']['name']) )
		{
			if($this->upload->do_upload("notification_file"))
			{
				$notification_uploaded = $this->upload->data();
				$notification = $notification_uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}

        $notification_2 = $this->input->post('notification_2');
		if (!empty($_FILES['notification_file_2']['name']) )
		{
			if($this->upload->do_upload("notification_file_2"))
			{
				$notification_uploaded = $this->upload->data();
				$notification_2 = $notification_uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}

        $notification_3 = $this->input->post('notification_3');
		if (!empty($_FILES['notification_file_3']['name']) )
		{
			if($this->upload->do_upload("notification_file_3"))
			{
				$notification_uploaded = $this->upload->data();
				$notification_3 = $notification_uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}


		if ($this->input->post('remove_notification'))
		{
			$rn = $this->input->post('remove_notification');
			foreach($rn as $r)
			{
				if (($key = array_search($r, $notifications)) !== false) {
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$r))
					{
						unset($notifications[$key]);
					}
					else
					{
						unset($notifications[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$pnc->notification = implode(',', $notifications);
		}

		if ($this->input->post('remove_uploaded'))
		{
			$remove_uploaded = $this->input->post('remove_uploaded');
			foreach($remove_uploaded as $r)
			{
				if (($key = array_search($r, $uploaded)) !== false) {
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$r))
					{
						unset($uploaded[$key]);
					}
					else
					{
						unset($uploaded[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$pnc->uploaded = implode(',', $uploaded);
		}

		$mills = array();
		$_mills = $this->input->post('mill')?$this->input->post('mill'):array();
		$_countries = $this->input->post('mill_country');
		foreach($_mills as $i=>$mill)
		{
			$mills[$i] = array(
				'mill'=> $mill,
				'mill_country' => !empty($_countries[$i])?$_countries[$i]:''
			);
		}

		$pnc->mill = $mills;

		if ($this->form_validation->run())
		{
			$cb_id = (int)$this->input->post('cb_id');

			$input = array(
				'created_on'		=> now(),
				'created_by'		=> $this->current_user->id,
				'mill_index'		=> implode('|', $this->input->post('mill')),
				'mill_country_index'=> implode('|', $this->input->post('mill_country')),
				'isUp'				=> $isUp,
				// 'date'				=> $date,
				'mid'				=> $this->input->post('mid'),
				'certification_body'=> $cb_id ? '' : $this->input->post('certification_body'),
				'cb_id'				=> $cb_id,
				'assessment_type'	=> $this->input->post('assessment_type'),
				'status'			=> $this->input->post('status'),
				'online_status'		=> $this->input->post('online_status'),
				'notification_date'	=> $date,
				'notification_end'	=> $date_end,
				'assessment_date'	=> $assessment_date,
				'assessment_end'	=> $assessment_end,
				'subremarks'		=> $this->input->post('subremarks'),
				'certificate_file'	=> $certificate_file,
				'notification'		=> $notification,
				'notification_2'	=> $notification_2,
				'notification_3'	=> $notification_3,
				'uploaded'			=> $uploaded_input,
				'final_report_date'	=> $final_report_date,
				'remarks'			=> $this->input->post('remarks'),
				'report_accepted_date'=> $report_accepted_date,
//				'scc_model'			=> $supply_options,
//				'certified_area'	=> $this->input->post('certified_area') ? $this->input->post('certified_area') : NULL,
//				'production_area'	=> $this->input->post('production_area') ? $this->input->post('production_area') : NULL,
//				'cspo'				=> $this->input->post('cspo') ? $this->input->post('cspo') : NULL,
//				'cspk'				=> $this->input->post('cspk') ? $this->input->post('cspk') : NULL,
			);

			// var_dump($input);
			// die();
			//if ($this->pnc_m->insert($input))
			//$res = TRUE;
			if ($id = $this->pnc_m->insert($input))
			{
				// insert data to table member_pnc_mills
				if (!empty($pnc->mill))
				{
					foreach($pnc->mill as $mill)
					{
						$mills_input[] = array(
							'pnc_id' => $id,
							'mill' => $mill['mill'],
							'mill_country' => $mill['mill_country'],
						);
					}
					$mill_result = $this->pnc_m->update_mills($mills_input);
				}

				if (!empty($notification))
				{
					// insert uploaded files
					$file_input[] = array(
						'pnc_id' => $id,
						'pnc_type' => $this->input->post('assessment_type'),
						'filename' => $notification,
						'filetype' => 'notification',
					);

					$uploaded_result = $this->pnc_m->update_files($file_input);
				}

				if (!empty($notification_2))
				{
					// insert uploaded files
					$file_input[] = array(
						'pnc_id' => $id,
						'pnc_type' => $this->input->post('assessment_type'),
						'filename' => $notification_2,
						'filetype' => 'notification_2',
					);

					$uploaded_result = $this->pnc_m->update_files($file_input);
				}

				if (!empty($notification_3))
				{
					// insert uploaded files
					$file_input[] = array(
						'pnc_id' => $id,
						'pnc_type' => $this->input->post('assessment_type'),
						'filename' => $notification_3,
						'filetype' => 'notification_3',
					);

					$uploaded_result = $this->pnc_m->update_files($file_input);
				}
				
				if (!empty($uploaded))
				{
					// insert uploaded files
					foreach($uploaded as $f)
					{
						$file_input[] = array(
							'pnc_id' => $id,
							'pnc_type' => $this->input->post('assessment_type'),
							'filename' => $f,
							'filetype' => 'uploaded',
						);
					}

					$uploaded_result = $this->pnc_m->update_files($file_input);
				}

				if (!empty($certificate_file))
				{
					// insert certificate
					$file_input[] = array(
						'pnc_id' => $id,
						'pnc_type' => $this->input->post('assessment_type'),
						'filename' => $certificate_file,
						'filetype' => 'certificate_file',
					);

					$uploaded_result = $this->pnc_m->update_files($file_input);
				}

				$this->pyrocache->delete_all('pnc_m');
				$this->session->set_flashdata(array('success' => sprintf(lang('pnc:create_success'), $this->input->post('member_name'))));
				($this->input->post('btnAction') == 'save_exit') ? redirect('admin/members/pncassessment') : redirect('admin/members/pncassessment/edit/'.$id);
			}
			else
			{
				//$this->template->set('messages', array( 'error' => sprintf(lang('pnc:create_error'), $this->input->post('member_name')) ) );
				$this->template->set('messages', array( 'error' => $this->db->error()['message'] ) );
			}

			// Redirect back to the form or main page
		}

		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $key => $field)
		{
			if ($field['field'] != 'uploaded')
				$pnc->$field['field'] = set_value($field['field']);
		}

//		$pnc->scc_model = $supply_options;
		$pnc->date = $date;
		$pnc->notification_date = $date;
		$pnc->notification_end = $date_end;
		$pnc->assessment_end = $assessment_end;
		$pnc->assessment_date = $assessment_date;
		$pnc->final_report_date = $final_report_date;
		$pnc->report_accepted_date = $report_accepted_date;
		$pnc->isUp = $isUp;

		//$pnc->mid = $pnc->member_id;

		$pnc->certificate_file = $certificate_file;
		$pnc->notification = $notification;
		$pnc->notification_2 = $notification_2;
		$pnc->notification_3 = $notification_3;
		
		if (!empty($uploaded)) {
			$pnc->uploaded = implode(',', $uploaded);
		} else {
			$pnc->uploaded = null;
		}

		$this->template
			->append_js('module::pnctype.js')
			->append_js('module::date.js')
			->set('pnc', $pnc)
			->build('admin/pnc/form');
	}
	
	public function edit($id=0)
	{
		role_or_die('members', 'edit_pnc');

		$pnc = $this->pnc_m->get($id);


		$this->form_validation->set_rules($this->validation_rules);

		//if ($this->input->post('notification_date'))
		if ($_POST)
		{
			//$date = $this->input->post('notification_date'); //strtotime(sprintf('%s %s:%s', $this->input->post('notification_date'), 0, 0));
			if ($this->input->post('notification_date'))
				$date = strtotime(sprintf('%s %s:%s', $this->input->post('notification_date'), 0, 0));
			else
				$date = NULL;
		}
		else
		{
			$date = $pnc->date;
		}

		//if ($this->input->post('notification_end'))
		// if ($_POST)
		// {
			//$date = $this->input->post('notification_date'); //strtotime(sprintf('%s %s:%s', $this->input->post('notification_date'), 0, 0));
			if ($this->input->post('notification_end')) {
				$date_end = strtotime(sprintf('%s %s:%s', $this->input->post('notification_end'), 0, 0));
			} else {
				if ($this->input->post('notification_date')) {
					$date_end = strtotime(date("Y-m-d", strtotime($this->input->post('notification_date'))) . " +1 month");
				} else {
					$date_end = NULL;
				}
			}
		// }
		// else
		// {
		// 	$date_end = $pnc->date_end;
		// }

		//if ($this->input->post('assessment_date'))
		if ($_POST)
		{
			if ($this->input->post('assessment_date'))
				$assessment_date = strtotime(sprintf('%s %s:%s', $this->input->post('assessment_date'), 0, 0));
			else
				$assessment_date = NULL;
		}
		else
		{
			$assessment_date = $pnc->assessment_date;
		}

		//if ($this->input->post('assessment_end'))
		// if ($_POST)
		// {
		if ($this->input->post('assessment_end')) {
				
			$assessment_end = strtotime(sprintf('%s %s:%s', $this->input->post('assessment_end'), 0, 0));
			
		} else {
				
			if ($this->input->post('assessment_date')) {
					
				$assessment_end = strtotime(date("Y-m-d", strtotime($this->input->post('assessment_date'))) . " +1 year");
			
			} else {
					
				$assessment_end = NULL;
			
			}
				
		}
			
		// }
		// else
		// {
		// 	$assessment_end = $pnc->assessment_end;
		// }

		//if ($this->input->post('final_report_date'))
		if ($_POST)
		{
			if ($this->input->post('final_report_date'))
				$final_report_date = strtotime(sprintf('%s %s:%s', $this->input->post('final_report_date'), 0, 0));
			else
				$final_report_date = NULL;
		}
		else
		{
			$final_report_date = $pnc->final_report_date;
		}

		//if ($this->input->post('report_accepted_date'))
		if ($_POST)
		{
			if ($this->input->post('report_accepted_date'))
				$report_accepted_date = strtotime(sprintf('%s %s:%s', $this->input->post('report_accepted_date'), 0, 0));
			else
				$report_accepted_date = NULL;
		}
		else
		{
			$report_accepted_date = $pnc->report_accepted_date;
		}

//		if ($this->input->post('scc_model'))
//		{
//			$_so = $this->input->post('scc_model');
//			$_so = array_values($_so);
//			$supply_options = implode(',', $_so);
//		}
//		else
//		{
//			$supply_options = $pnc->scc_model;
//		}

		// check directory exists
		$this->check_dir($this->upload_cfg['upload_path']);
		$this->load->library('upload', $this->upload_cfg);

		if (!empty($_FILES['certificate']))
		{
			if($this->upload->do_upload("certificate"))
			{
				$file_certificate = $this->upload->data();
				$pnc->certificate = $file_certificate['file_name'];
			}
		}
		else
		{
			if ($this->input->post('certificate_file'))
			{
				$file_certificate = $this->input->post('certificate_file');
				$pnc->certificate = $file_certificate;
			}
		}

		if (!empty($_FILES['uploaded_files']['name'][0]))
		{
			if($this->upload->do_multi_upload("uploaded_files"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data('uploaded_files');

				foreach($file_uploaded as $file)
				{
					$uploaded[] = $file['file_name'];
				}
				$old_uploaded = explode(',', $this->input->post('uploaded'));
				$old_uploaded = array_values($old_uploaded);
				if (!empty($old_uploaded))
				{
					$uploaded = array_merge($uploaded, $old_uploaded);
				}
				$pnc->uploaded = implode(',', $uploaded);
			}
			else
			{
				echo $this->upload->display_errors();
			}
		}
		else
		{
			if ($this->input->post('uploaded'))
			{
				$uploaded = explode(',', $this->input->post('uploaded'));
			}
			else
			{
				$uploaded = explode(',', $pnc->uploaded);
			}
		}
		$uploaded = array_filter($uploaded);

		if (!empty($this->input->post('remove_notification_1'))) {
			
			// delete existing file: notification
			$notification_old = '';
			if (!empty($this->input->post('notification'))) {
				$notification_old = $this->input->post('notification');
			}

			if ($notification_old && file_exists($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$notification_old))
			{
				// delete the file
				unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$notification_old);
			}

			$notification = null;
			$notification_old = null;

			if (!empty($_FILES['notification_file']['name']) )
			{
				if($this->upload->do_upload("notification_file"))
				{
					$notification_uploaded = $this->upload->data();
					$notification = $notification_uploaded['file_name'];
				}
				else
				{
					// something wrong
				}
			} 

		} else {
			$notification = null;
			$notification_old = null;
			if (!empty($_FILES['notification_file']['name']) )
			{
				$notification_old = null;

				if($this->upload->do_upload("notification_file"))
				{
					$notification_uploaded = $this->upload->data();
					$notification = $notification_uploaded['file_name'];
					if (!empty($this->input->post('notification'))) {
						$notification_old = $this->input->post('notification');
					}
				}
				else
				{
					// something wrong
				}

				// delete existing file: notification
				if (!empty($notification_old)) {
					unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$notification_old);
				}

			} else {
				$notification = $this->input->post('notification');
			}
		}



		if (!empty($this->input->post('remove_notification_2'))) {
			
			// delete existing file: notification_2
			$notification_2_old = '';
			if (!empty($this->input->post('notification_2'))) {
				$notification_2_old = $this->input->post('notification_2');
			}

			if ($notification_2_old && file_exists($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$notification_2_old))
			{
				// delete the file
				unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$notification_2_old);
			}

			$notification_2 = null;
			$notification_2_old = null;

			if (!empty($_FILES['notification_file_2']['name']) )
			{
				if($this->upload->do_upload("notification_file_2"))
				{
					$notification_2_uploaded = $this->upload->data();
					$notification_2 = $notification_2_uploaded['file_name'];
				}
				else
				{
					// something wrong
				}
			} 

		} else {
			$notification_2 = null;
			$notification_2_old = null;

			if (!empty($_FILES['notification_file_2']['name']) )
			{
				$notification_2_old = null;

				if($this->upload->do_upload("notification_file_2"))
				{
					$notification_2_uploaded = $this->upload->data();
					$notification_2 = $notification_2_uploaded['file_name'];
					if (!empty($this->input->post('notification_2'))) {
						$notification_2_old = $this->input->post('notification_2');
					}
				}
				else
				{
					// something wrong
				}

				// delete existing file: notification_2
				if (!empty($notification_2_old)) {
					unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$notification_2_old);
				}

			} else {
				$notification_2 = $this->input->post('notification_2');
			}
		}

		

		if (!empty($this->input->post('remove_notification_3'))) {
			
			// delete existing file: notification_3
			$notification_3_old = '';
			if (!empty($this->input->post('notification_3'))) {
				$notification_3_old = $this->input->post('notification_3');
			}

			if ($notification_3_old && file_exists($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$notification_3_old))
			{
				// delete the file
				unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$notification_3_old);
			}

			$notification_3 = null;
			$notification_3_old = null;

			if (!empty($_FILES['notification_file_3']['name']) )
			{
				if($this->upload->do_upload("notification_file_3"))
				{
					$notification_3_uploaded = $this->upload->data();
					$notification_3 = $notification_3_uploaded['file_name'];

				}
				else
				{
					// something wrong
				}
			} 

		} else {
			$notification_3 = null;
			$notification_3_old = null;
			if (!empty($_FILES['notification_file_3']['name']) )
			{
				$notification_3_old = null;

				if($this->upload->do_upload("notification_file_3"))
				{
					$notification_3_uploaded = $this->upload->data();
					$notification_3 = $notification_3_uploaded['file_name'];
					if (!empty($this->input->post('notification_3'))) {
						$notification_3_old = $this->input->post('notification_3');
					}
				}
				else
				{
					// something wrong
				}

				// delete existing file: notification_3
				if (!empty($notification_3_old)) {
					unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$notification_3_old);
				}

			} else {
				$notification_3 = $this->input->post('notification_3');
			}
		}

		// if (!empty($_FILES['notification_file']['name']) )
		// {
		// 	if($this->upload->do_upload("notification_file"))
		// 	{
		// 		$notification_uploaded = $this->upload->data();
		// 		$notification = $notification_uploaded['file_name'];
		// 	}
		// 	else
		// 	{
		// 		// something wrong
		// 	}
		// }
		// else
		// {

		// 	if ($this->input->post('notification'))
		// 	{
		// 		$notification = $this->input->post('notification');
		// 		$pnc->notification = $notification;
		// 	}			
		// }

		// if (!empty($_FILES['notification_file_2']['name']) )
		// {
		// 	if($this->upload->do_upload("notification_file_2"))
		// 	{
		// 		$notification_uploaded = $this->upload->data();
		// 		$notification_2 = $notification_uploaded['file_name'];
		// 	}
		// 	else
		// 	{
		// 		// something wrong
		// 	}
		// }
		// else
		// {
		// 	$notification_2 = $this->input->post('notification_2');
		// }

		// if (!empty($_FILES['notification_file_3']['name']) )
		// {
		// 	if($this->upload->do_upload("notification_file_3"))
		// 	{
		// 		$notification_uploaded = $this->upload->data();
		// 		$notification_3 = $notification_uploaded['file_name'];
		// 	}
		// 	else
		// 	{
		// 		// something wrong
		// 	}
		// }
		// else
		// {
		// 	$notification_3 = $this->input->post('notification_3');
		// }


		if ($this->input->post('remove_notification'))
		{
			$rn = $this->input->post('remove_notification');
			foreach($rn as $r)
			{
				if (($key = array_search($r, $notifications)) !== false) {
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$r))
					{
						unset($notifications[$key]);
					}
					else
					{
						unset($notifications[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$pnc->notification = implode(',', $notifications);
		}

		if ($this->input->post('remove_uploaded'))
		{
			$remove_uploaded = $this->input->post('remove_uploaded');
			foreach($remove_uploaded as $r)
			{
				if (($key = array_search($r, $uploaded)) !== false) {
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$r))
					{
						unset($uploaded[$key]);
					}
					else
					{
						unset($uploaded[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$pnc->uploaded = implode(',', $uploaded);
		}

		$mills = array(); //new stdClass();
		if ($_POST)
		{
			$_mills = $this->input->post('mill');
			$_countries = $this->input->post('mill_country');
			foreach($_mills as $i=>$mill)
			{
				$mills[$i] = array(
					'mill'=> $mill,
					'mill_country' => !empty($_countries[$i])?$_countries[$i]:''
				);
			}
		}
		else
		{
			$_mills = $this->pnc_m->get_mills($id);
			foreach($_mills as $i=>$mill)
			{
				$mills[$i] = array(
					'mill'=> $mill->mill,
					'mill_country' => $mill->mill_country
				);
			}
		}

		$pnc->mill = $mills;

		if ($this->form_validation->run())
		{
			$certificate_file = !empty($pnc->certificate) ? $pnc->certificate : $this->input->post('certificate_file');
			$uploaded_files = $this->input->post('uploaded_files') . (!empty($uploaded)?','.implode(',', $uploaded):'');
			$cb_id = (int)$this->input->post('cb_id');

			$input = array(
				'updated_on'		=> now(),
				'updated_by'		=> $this->current_user->id,
				'mill_index'		=> implode('|', $this->input->post('mill')),
				'mill_country_index'=> implode('|', $this->input->post('mill_country')),
				'isUp'				=> $this->input->post('online_status') == 'live' ? '1' : '0',
				// 'date'				=> $date,
				'mid'				=> $this->input->post('mid'),
				'certification_body'=> $cb_id ? '' : $this->input->post('certification_body'),
				'cb_id'				=> $cb_id,
				'assessment_type'	=> $this->input->post('assessment_type'),
				'status'			=> $this->input->post('status'),
				'online_status'		=> $this->input->post('online_status'),
				'notification_date'	=> $date,
				'notification_end'	=> $date_end,
				'assessment_date'	=> $assessment_date,
				'assessment_end'	=> $assessment_end,
				'subremarks'		=> $this->input->post('subremarks'),
				'certificate_file'	=> $certificate_file,
				'notification'		=> $notification,
				'notification_2'	=> $notification_2,
				'notification_3'	=> $notification_3,
				'uploaded'			=> implode(',', $uploaded),
				'final_report_date'	=> $final_report_date,
				'remarks'			=> $this->input->post('remarks'),
				'report_accepted_date'=> $report_accepted_date,
//				'scc_model'			=> $supply_options,
//				'certified_area'	=> $this->input->post('certified_area') ? $this->input->post('certified_area') : NULL,
//				'production_area'	=> $this->input->post('production_area') ? $this->input->post('production_area') : NULL,
//				'cspo'				=> $this->input->post('cspo') ? $this->input->post('cspo') : NULL,
//				'cspk'				=> $this->input->post('cspk') ? $this->input->post('cspk') : NULL,
			);


		
			if ($this->pnc_m->update($id, $input))
			{
				// insert data to table member_pnc_mills
				if (!empty($pnc->mill))
				{
					foreach($pnc->mill as $mill)
					{
						$mills_input[] = array(
							'pnc_id' => $id,
							'mill' => $mill['mill'],
							'mill_country' => $mill['mill_country'],
						);
					}
					$mill_result = $this->pnc_m->update_mills($mills_input);
				}

				if (empty($notification)) {
					unlink($this->upload_cfg['upload_path'].'/'.$this->input->post('notification'));
				}

				if (!empty($notification_old))
				{

					// insert uploaded files
					$file_input[] = array(
						'pnc_id' => $id,
						'pnc_type' => $this->input->post('assessment_type'),
						'filename' => $notification_old,
						'filetype' => 'notification',
					);

					$uploaded_result = $this->pnc_m->update_files($file_input);
				
				} else {
					// insert uploaded files
					if (!empty($this->input->post('notification_old'))) {
						$file_input[] = array(
							'pnc_id' => $id,
							'pnc_type' => $this->input->post('assessment_type'),
							'filename' => $this->input->post('notification_old'),
							'filetype' => 'notification',
						);

						$uploaded_result = $this->pnc_m->update_files($file_input);
					}
				}

				if (!empty($notification_2_old))
				{

					// insert uploaded files
					$file_input[] = array(
						'pnc_id' => $id,
						'pnc_type' => $this->input->post('assessment_type'),
						'filename' => $notification_2_old,
						'filetype' => 'notification_2',
					);

					$uploaded_result = $this->pnc_m->update_files($file_input);
				
				} else {
					// insert uploaded files
					if (!empty($this->input->post('notification_2_old'))) {
						$file_input[] = array(
							'pnc_id' => $id,
							'pnc_type' => $this->input->post('assessment_type'),
							'filename' => $this->input->post('notification_2_old'),
							'filetype' => 'notification_2',
						);

						$uploaded_result = $this->pnc_m->update_files($file_input);
					}
				}

				if (!empty($notification_3_old))
				{

					// insert uploaded files
					$file_input[] = array(
						'pnc_id' => $id,
						'pnc_type' => $this->input->post('assessment_type'),
						'filename' => $notification_3_old,
						'filetype' => 'notification_3',
					);

					$uploaded_result = $this->pnc_m->update_files($file_input);
				
				} else {
					// insert uploaded files
					if (!empty($this->input->post('notification_3_old'))) {
						$file_input[] = array(
							'pnc_id' => $id,
							'pnc_type' => $this->input->post('assessment_type'),
							'filename' => $this->input->post('notification_3_old'),
							'filetype' => 'notification_3',
						);

						$uploaded_result = $this->pnc_m->update_files($file_input);
					}
				}

				// if (!empty($notification_2))
				// {
				// 	// insert uploaded files
				// 	$file_input[] = array(
				// 		'pnc_id' => $id,
				// 		'pnc_type' => $this->input->post('assessment_type'),
				// 		'filename' => $notification_2,
				// 		'filetype' => 'notification_2',
				// 	);

				// 	$uploaded_result = $this->pnc_m->update_files($file_input);
				// }

				// if (!empty($notification_3))
				// {
				// 	// insert uploaded files
				// 	$file_input[] = array(
				// 		'pnc_id' => $id,
				// 		'pnc_type' => $this->input->post('assessment_type'),
				// 		'filename' => $notification_3,
				// 		'filetype' => 'notification_3',
				// 	);

				// 	$uploaded_result = $this->pnc_m->update_files($file_input);
				// }
				
				if (!empty($uploaded))
				{
					// insert uploaded files
					foreach($uploaded as $f)
					{
						if ($f)
						{
							$file_input[] = array(
								'pnc_id' => $id,
								'pnc_type' => $this->input->post('assessment_type'),
								'filename' => $f,
								'filetype' => 'uploaded',
							);
						}
					}

					if (!empty($file_input))
						$uploaded_result = $this->pnc_m->update_files($file_input);
				}

				if (!empty($certificate_file))
				{
					// insert certificate
					$file_input[] = array(
						'pnc_id' => $id,
						'pnc_type' => $this->input->post('assessment_type'),
						'filename' => $certificate_file,
						'filetype' => 'certificate_file',
					);

					$uploaded_result = $this->pnc_m->update_files($file_input);
				}

				$this->pyrocache->delete_all('pnc_m');
				$this->session->set_flashdata(array('success' => sprintf(lang('pnc:edit_success'), $this->input->post('member_name'))));
				($this->input->post('btnAction') == 'save_exit') ? redirect('admin/members/pncassessment') : redirect('admin/members/pncassessment/edit/'.$id);
			}
			else
			{
				$this->session->set_flashdata(array('error' => sprintf(lang('pnc:edit_error'), $this->input->post('member_name'))));
				$this->session->set_flashdata(array('notice' => $this->db->error()['message']));
				$this->template->set('error', sprintf(lang('pnc:edit_error'), $this->input->post('member_name')) );
				($this->input->post('btnAction') == 'save_exit') ? redirect('admin/members/pncassessment') : redirect('admin/members/pncassessment/edit/'.$id);
			}
			// Redirect back to the form or main page
		}

		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $key => $field)
		{
			//if (isset($_POST[$field['field']]))
			if ($_POST)
			{
				$pnc->$field['field'] = set_value($field['field']);
			}
		}

		$member = $this->members_m->get_by('intID', $pnc->mid);
		if (!empty($member))
		{
			$this->template
				->set('member_name', $member->title)
				->set('member_id', $member->intID);
		}

//		$pnc->scc_model = $supply_options;
		$pnc->date = $date;
		
		if (!empty($this->input->post('notification_end'))) {
			$pnc->notification_end = $this->input->post('notification_end');
		} 


		$pnc->assessment_date = $assessment_date;

		if (!empty($this->input->post('assessment_end'))) {
			$pnc->assessment_end = $this->input->post('assessment_end');
		} 
		
		$pnc->final_report_date = $final_report_date;
		$pnc->report_accepted_date = $report_accepted_date;

		$this->template
			->append_js('module::pnctype.js')
			->append_js('module::date.js')
			->set('pnc', $pnc)
			->build('admin/pnc/form');
	}

	/**
	 * method to fetch filtered results for content list
	 * @access public
	 * @return void
	 */
	public function ajax_filter()
	{
		$area = $this->input->post('f_area');
		$status = $this->input->post('f_status');
		$type = $this->input->post('f_type');

		$post_data = array();

		if ($status == 'live' OR $status == 'draft')
		{
			$post_data['status'] = $status;
		}

		if ($type)
		{
			$post_data['type'] = $type;
		}

		if ($area != 0)
		{
			$post_data['area_id'] = $area;
		}

		$results = $this->members_m->search($post_data);

		//set the layout to false and load the view
		$this->template
			->set_layout(FALSE)
			->set('members', $results)
			->build('admin/tables/members');
	}
	
	/**
	 * Check attachment dir, and create accordingly
	 *
	 * @param string Directory to check
	 * @return array
	 */
	function check_dir($dir)
	{
		// check directory
		$fileOK = array();
		$fdir = explode('/', $dir);
		$ddir = '';
		for($i=0; $i<count($fdir); $i++)
		{
			$ddir .= $fdir[$i] . '/';
			if (!is_dir($ddir))
			{
				if (!@mkdir($ddir, 0777)) {
					$fileOK[] = 'not_ok';
				}
				else
				{
					$fileOK[] = 'ok';
				}
			}
			else
			{
				$fileOK[] = 'ok';
			}
		}
		return $fileOK;
	}
	
	
	public function delete($id = 0)
	{
		role_or_die('members', 'delete_pnc');

		// Delete one
		$ids = ($id) ? array($id) : $this->input->post('action_to');

		// Go through the array of slugs to delete
		if ( ! empty($ids))
		{
			$post_titles = array();
			$deleted_ids = array();
			foreach ($ids as $id)
			{
				// Get the current page so we can grab the id too
				if ($pnc = $this->pnc_m->get($id))
				{
					if ($this->pnc_m->delete($id))
					{
						// delete the files
						$flatfiles = $pnc->notification . ', ' . $pnc->notification_2 . ', '.$pnc->notification_3;
						$files = explode(',', $flatfiles);
						if (!empty($files))
						{
							foreach($files as $file)
							{
								$this->remove_file($file);
							}
						}
						// Wipe cache for this model, the content has changed
						$this->pyrocache->delete_all('pnc_m');
						$post_titles[] = $pnc->mill;
						$deleted_ids[] = $id;
					}
				}
			}

			// Fire an event. We've deleted one or more pnc posts.
			//Events::trigger('post_deleted', $deleted_ids);
		}

		// Some pages have been deleted
		if ( ! empty($post_titles))
		{
			// Only deleting one page
			if (count($post_titles) == 1)
			{
				$this->session->set_flashdata('success', sprintf($this->lang->line('pnc:delete_success'), $post_titles[0]));
			}
			// Deleting multiple pages
			else
			{
				$this->session->set_flashdata('success', sprintf($this->lang->line('pnc:mass_delete_success'), implode('", "', $post_titles)));
			}
		}
		// For some reason, none of them were deleted
		else
		{
			$this->session->set_flashdata('notice', lang('pnc:delete_error'));
		}

		redirect('admin/members/pncassessment');
	}
	
	public function action()
	{
		switch ($this->input->post('btnAction'))
		{
			case 'delete':
				$this->delete();
				break;

			default:
				redirect('admin/members/pncassessment');
				break;
		}
	}
	
	public function view($id=0)
	{
		$pnc = $this->pnc_m->get($id);

		$mills=array();
		$_mills = $this->pnc_m->get_mills($id);
		foreach($_mills as $i=>$mill)
		{
			$mills[$i] = array(
				'mill'=> $mill->mill,
				'mill_country' => $mill->mill_country
			);
		}
		$pnc->mill = $mills;

		//do we need to unset the layout because the request is ajax?
		$this->input->is_ajax_request() and $this->template->set_layout(false);
		//$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

		$this->template
			->title($this->module_details['name'])
			->set('pnc', $pnc);

		$this->template->build('members/admin/pnc/view');
	}
	
	public function remove_file($file)
	{
		$full = $_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$file;
		if (file_exists($full))
		{
			if (is_file($full))
			{
				if (unlink($full))
					return TRUE;
				else
					return FALSE;
			}
			return TRUE;
		}
		else
		{
			// file dissapear, maybe has been deleted?
			return TRUE;
		}
	}

	public function pindah_mill()
	{
		$num = $this->pnc_m->count_all();
		$pncs = $this->db->get('member_pnc')->result();
		$res = 0;
		foreach($pncs as $pnc)
		{
			$input = array();
			$input[] = array(
				'pnc_id' 	=> $pnc->id,
				'mill'		=> $pnc->mill_index,
			);
			if ($this->pnc_m->update_mills($input))
				$res++;
		}
		echo "<b>$res of $num</b> data was moved";
	}

	public function combine_mills()
	{
		echo "<pre>\n";
		$mills = $this->db->get('member_pnc_mills')->result();
		foreach($mills as $mill)
		{
			$id = $mill->pnc_id;
			$pnc = $this->pnc_m->get($id);
			echo "  Combining PNC ID $id\n";
			echo "       Mill: ".$mill->mill."\n";
			echo "       Country: ".$mill->mill_country."\n";
			$mill_index = ($pnc->mill_index ? $pnc->mill_index . '|' : '').$mill->mill;
			$country = ($pnc->mill_country_index ? $pnc->mill_country_index . '|' : '').$mill->mill_country;
			$input = array(
				'mill_index'=>$mill_index,
				'mill_country_index'=>$country
			);
			echo "       Mill index: $mill_index\n";
			$res = 1;
			$res = $this->pnc_m->update($id, $input);
			echo "  Result: $res\n";
			echo "<hr />\n";
		}
		echo "<b>DONE</b>\n";
		echo "</pre>\n";
	}

}