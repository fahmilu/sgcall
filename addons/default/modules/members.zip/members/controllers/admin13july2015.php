<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends Admin_Controller
{
	protected $section = 'members';

	protected $validation_rules = array(
			array(
				'field' => 'type',
				'label' => 'Membership type',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'category',
				'label' => "What is your organisation's category? *",
				'rules' => 'trim',
			),
			array(
				'field' => 'profession',
				'label' => "Organisation's sub-category",
				'rules' => 'trim',
			),
			array(
				'field' => 'org_name',
				'label' => "Organisation's name",
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'address',
				'label' => 'Street name and number *',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'address_city',
				'label' => 'City',
				'rules' => 'trim|htmlspecialchars', //|required
			),
			array(
				'field' => 'address_state',
				'label' => 'State/Province',
				'rules' => 'trim|htmlspecialchars', //|required
			),
			array(
				'field' => 'address_zip',
				'label' => 'Postal/Zip Code',
				'rules' => 'trim|htmlspecialchars', //|required
			),
			array(
				'field' => 'country',
				'label' => 'Country',
				'rules' => 'trim', //|required
			),
			array(
				'field' => 'telephone',
				'label' => 'Telephone',
				'rules' => 'trim', //|required
			),
			array(
				'field' => 'fax',
				'label' => 'Fax',
				'rules' => 'trim',
			),
			array(
				'field' => 'email',
				'label' => 'Email *',
				'rules' => 'trim|valid_email', //|required',
			),
			array(
				'field' => 'website',
				'label' => 'Website ',
				'rules' => 'trim',
			),
			array(
				'field' => 'registration_number',
				'label' => 'What is your registration number? *',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'parent_company',
				'label' => 'Are you a parent company? ',
				'rules' => 'trim',
			),
			array(
				'field' => 'primary_market_ops',
				'label' => 'Primary market operations ',
				'rules' => 'trim',
			),
			array(
				'field' => 'other_market_ops',
				'label' => 'Other market operations ',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'profile',
				'label' => 'Tell us about your organisation ',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'name_p',
				'label' => 'Full name *',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'name_last_p',
				'label' => 'Primary last name',
				'rules' => 'trim|required|htmlspecialchars',
			),
			array(
				'field' => 'designation_p',
				'label' => 'designation_p',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'telephone_p',
				'label' => 'telephone_p',
				'rules' => 'trim',
			),
			array(
				'field' => 'fax_p',
				'label' => 'fax_p',
				'rules' => 'trim',
			),
			array(
				'field' => 'email_p',
				'label' => 'email_p',
				'rules' => 'trim|valid_email',
			),
			array(
				'field' => 'country_p',
				'label' => 'Country',
				'rules' => 'trim',
			),
			array(
				'field' => 'category_p',
				'label' => 'Category',
				'rules' => 'trim',
			),
			array(
				'field' => 'name_s',
				'label' => 'name_s',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'name_last_s',
				'label' => 'Secondary Contact last name',
				'rules' => 'trim|required|htmlspecialchars',
			),
			array(
				'field' => 'designation_s',
				'label' => 'designation_s',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'telephone_s',
				'label' => 'telephone_s',
				'rules' => 'trim',
			),
			array(
				'field' => 'fax_s',
				'label' => 'fax_s',
				'rules' => 'trim',
			),
			array(
				'field' => 'email_s',
				'label' => 'email_s',
				'rules' => 'trim|valid_email', //|required',
			),
			array(
				'field' => 'country_s',
				'label' => 'Country',
				'rules' => 'trim',
			),
			array(
				'field' => 'category_s',
				'label' => 'Category',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_person',
				'label' => 'Contact person first name',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'contact_lname',
				'label' => 'Contact person last name',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'designation',
				'label' => 'designation',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'contact_tel',
				'label' => 'contact_tel',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_fax',
				'label' => 'contact_fax',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_email',
				'label' => 'contact_email',
				'rules' => 'trim|valid_email',
			),
			array(
				'field' => 'country_c',
				'label' => 'Country',
				'rules' => 'trim',
			),
			array(
				'field' => 'category_c',
				'label' => 'Category',
				'rules' => 'trim',
			),
			array(
				'field' => 'name_f',
				'label' => 'name_f',
				'rules' => 'trim|htmlspecialchars', //|required
			),
			array(
				'field' => 'name_last_f',
				'label' => 'Finance Contact last name',
				'rules' => 'trim|htmlspecialchars|required', //|required
			),
			array(
				'field' => 'designation_f',
				'label' => 'designation_f',
				'rules' => 'trim|htmlspecialchars', //|required
			),
			array(
				'field' => 'telephone_f',
				'label' => 'telephone_f',
				'rules' => 'trim', //|required
			),
			array(
				'field' => 'fax_f',
				'label' => 'fax_f',
				'rules' => 'trim',
			),
			array(
				'field' => 'email_f',
				'label' => 'email_f',
				'rules' => 'trim|valid_email', //|required
			),
			array(
				'field' => 'country_f',
				'label' => 'Country',
				'rules' => 'trim',
			),
			array(
				'field' => 'category_f',
				'label' => 'Category',
				'rules' => 'trim',
			),
			array(
				'field' => 'q1',
				'label' => 'q1',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'q2',
				'label' => 'q2',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'q3',
				'label' => 'q3',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'q4',
				'label' => 'q4',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'q_usage',
				'label' => 'q_usage',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'name_a',
				'label' => 'name_a',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'email_a',
				'label' => 'Application Email',
				'rules' => 'trim',
				//'rules' => 'trim|valid_email|required',
			),

			array(
				'field' => 'designation_a',
				'label' => 'designation_a',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'date_2',
				'label' => 'date_2',
				'rules' => 'trim', //|required
			),
			array(
				'field' => 'file',
				'label' => 'file',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'grower_file',
				'label' => 'grower file',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'file_certificates',
				'label' => 'file certificates',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'uploaded_files_cert',
				'label'	=> 'uploaded_files_cert',
				'rules'	=> 'trim',
			),
			array(
				'field' => 'logo',
				'label' => 'logo',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'upload_logo',
				'label' => 'upload_logo',
				'rules' => 'trim|htmlspecialchars', //|required
			),
			array(
				'field' => 'org_subcategory',
				'label' => 'Organisation Subcategory',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_telephone',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_fax',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_contact_tel',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_contact_fax',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_tel_p',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_fax_p',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_tel_s',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_fax_s',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_tel_f',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_fax_f',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'expiry_date',
				'label' => 'Expiry Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'approved_date',
				'label' => 'Approved Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'status',
				'label' => 'Membership Status',
				'rules' => 'trim',
			),
			array(
				'field' => 'member_num',
				'label' => 'Membership Number',
				'rules' => 'trim',
			),
			array(
				'field' => 'remarks',
				'label' => 'Remarks',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'newsletter',
				'label' => 'Newsletter Subscription',
				'rules' => 'trim',
			),
			array(
				'field' => 'applied_date',
				'label' => 'Applied Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'public_comment_start',
				'label' => 'Public Comment Start Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'public_comment_start',
				'label' => 'Public Comment Start Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'admin_comment',
				'label' => 'Admin Comment',
				'rules' => 'trim',
			),
			array(
				'field' => 'sub_category_other',
				'label' => 'Other Sub-category',
				'rules' => 'trim',
			),
			array(
				'field' => 'formerly_known_as',
				'label' => 'Formerly Known As',
				'rules' => 'trim',
			),
			array(
				'field' => 'complete_document_received',
				'label' => 'Complete Document Received',
				'rules' => 'trim',
			),
			array(
				'field' => 'suspended_date',
				'label' => 'Suspended Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'terminated_resigned_on',
				'label' => 'Termination Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'rev_notification',
				'label' => 'REV Notification',
				'rules' => 'trim',
			),
			array(
				'field' => 'acknowledgement',
				'label' => 'Acknowledgement',
				'rules' => 'trim',
			),
			array(
				'field' => 'acknowledgement',
				'label' => 'Acknowledgement',
				'rules' => 'trim',
			),
			array(
				'field' => 'account_currency',
				'label' => 'Account Currency',
				'rules' => 'trim',
			),
			array(
				'field' => 'total_amount_due',
				'label' => 'Total Amount Due',
				'rules' => 'trim',
			),
			array(
				'field' => 'total_amount_due',
				'label' => 'Total Amount Due',
				'rules' => 'trim',
			),
			array(
				'field' => 'proforma_invoice_date',
				'label' => 'Proforma Invoice Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'payment_status',
				'label' => 'Payment Status',
				'rules' => 'trim',
			),
			array(
				'field' => 'payment_received_on',
				'label' => 'Payment Received Date',
				'rules' => 'trim',
			),
		);

	protected $country_arrays = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Honduras", "Hong Kong S.A.R", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macao S.A.R", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan Region", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vatican City", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");

	protected $config_upload = array();

	protected $type = array();
	protected $categories = array();
	protected $member_categories = array();
	protected $subcategories = array();
	protected $types_reversed = array();
	protected $member_types = array();
	protected $subcat_growers = array();
	protected $subcat_others = array();
	protected $subcat_popt = array();
	protected $membership_status = array();

	protected $thumb_width = 150;
	protected $thumb_height = 250;
	protected $logo_width = 600;
	protected $logo_height = 400;

	public function __construct()
	{
		parent::__construct();

		$this->db->set_dbprefix('default_');

		$this->load->model('members_m');
		$this->lang->load('members');
		$this->load->helper('filename');

		$this->categories = array(
			'om' => array(
				'Banks and Investors',
				'Consumer Goods Manufacturers',
				'Environmental and Conservation NGOs',
				'Oil Palm Growers',
				'Palm Oil Processors and Traders',
				'Retailers',
				'Social and Developmental NGOs',
			),
			'am' => array(
				//'Association',
				'Individuals',
				'Organisations'
			),
			'sca'=> array(
				'Organisations',
				'Supply Chain Group Manager'
			)
		);
		$this->member_categories = array(
				'Banks and Investors'=>'Banks and Investors',
				'Consumer Goods Manufacturers'=>'Consumer Goods Manufacturers',
				'Environmental and Conservation NGOs'=>'Environmental and Conservation NGOs',
				'Oil Palm Growers'=>'Oil Palm Growers',
				'Palm Oil Processors and Traders'=>'Palm Oil Processors and Traders',
				'Retailers'=>'Retailers',
				'Social and Developmental NGOs'=>'Social and Developmental NGOs',
				'Individuals'=>'Individuals',
				'Organisation'=>'Organisation',
				'Organisations'=>'Organisations',
				'Supply Chain Group Manager'=>'Supply Chain Group Manager',
		);

		$this->subcategories = array(
			'Oil Palm Growers' => array('Smallholder Group Manager', 'Small growers'),
	
			'Consumer Goods Manufacturers' => array(
				'Refinery, Edible oils and Food ingredients processors',
				'Only Trading, Logistics and Distributions',
				'Power, Energy and Bio-fuel',
				'Chemicals, Surfactants, and Non-Food ingredients processors',
				'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)',
				'Others'
			),
			'Palm Oil Processors and Traders' => array(
				'Refinery, Edible oils and Food ingredients processors',
				'Only Trading, Logistics and Distributions',
				'Power, Energy and Bio-fuel',
				'Chemicals, Surfactants, and Non-Food ingredients processors',
				'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)',
				'Others'
			),
		);

	    $this->types_reversed = array(
	      ''=>'Select type',
	      'Ordinary Members'=>'om',
	      'Affiliate Members'=>'am',
	      'Supply Chain Associate'=>'sca',
	    );

	    $this->types = array(
	      ''=>'Select type',
	      'om'=>'Ordinary Members',
	      'am'=>'Affiliate Members',
	      'sca'=>'Supply Chain Associate',
	    );

	    $this->types_sf = array(
	      ''=>'Select type',
	      'Ordinary'=>'Ordinary Members',
	      'Affiliate'=>'Affiliate Members',
	      'Supply Chain'=>'Supply Chain Associate',
	    );

	    $this->member_types = array(
	      ''=>'Select type',
	      'Ordinary Members'=>'Ordinary Members',
	      'Affiliate Members'=>'Affiliate Members',
	      'Supply Chain Associate'=>'Supply Chain Associate',
	    );

		$this->subcat_growers = array('Smallholder Group Manager', 'Small growers');

		$this->subcat_others = array(
			''=>'Select subcategory',
			'Refinery, Edible oils and Food ingredients processors',
			'Only Trading, Logistics and Distributions',
			'Power, Energy and Bio-fuel',
			'Chemicals, Surfactants, and Non-Food ingredients processors',
			'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)'
		);
		$this->subcat_popt = array(
			''=>'Select subcategory',
			'Refinery, Edible oils and Food ingredients processors',
			'Only Trading, Logistics and Distributions',
			'Power, Energy and Bio-fuel',
			'Chemicals, Surfactants, and Non-Food ingredients processors',
			'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)',
			'Others'
		);

		$this->membership_status = array(
			''=>'Select status',
			'Applied'	=> 'Applied',
			'Call for Comment'	=> 'Call for Comment',
			'Due Diligence'		=> 'Due Diligence',
			'Invoicing'		=> 'Invoicing',
			'Pending'	=> 'Pending',
			'Inactive'	=> 'Inactive',
			'Cancelled'	=> 'Cancelled',
			'Accepted'	=> 'Accepted',
			'Active'	=> 'Active',
			'Suspended'	=> 'Suspended',
			'Terminated'=> 'Terminated',
			'Withdrawn' => 'Withdrawn',
			'Resigned'	=> 'Resigned',
			'Deleted'	=> 'Deleted',
			// these two are used only by CMS
			'Approved'	=> 'Approved',
			'Draft'		=> 'Draft',
		);

		$count = $this->members_m->count_all();

		foreach($this->country_arrays as $c)
		{
			$countries[$c] = $c;
		}

		$this->config_upload = array(
			'upload_path' 	=> UPLOAD_PATH . 'memberlogos',
			'allowed_types' => 'gif|jpg|png|pdf',
			'max_size' 		=> '20000',
			'remove_spaces'		=> TRUE,
			'overwrite'			=> FALSE,
			'encrypt_name'		=> FALSE,
		);
		

		$this->template
			->set('country_arrays', $countries)
			->set('count', $count)
			->set('member_categories', $this->member_categories)
			->set('categories', $this->categories)
			->set('member_types', $this->member_types)
			->set('types_sf', $this->types_sf)
			->set('types', $this->types)
			->set('types_reversed', $this->types_reversed)
			->set('member_subcategories', $this->subcategories)
			->set('membership_status', $this->membership_status)
			->set('subcat_growers', $this->subcat_growers)
			->set('subcat_others', $this->subcat_others)
			->set('subcat_popt', $this->subcat_popt);
	}

	function __destruct()
	{
		$this->db->set_dbprefix(SITE_REF.'_');
	}

	public function index()
	{
//$this->output->enable_profiler(true);
		//set the base/default where clause
		$base_where = array('status' => 'all');

		//add post values to base_where if f_module is posted
		//$base_where = $this->input->post('f_area') ? $base_where + array('area' => $this->input->post('f_area')) : $base_where;

		$base_where['status'] = $this->input->post('f_status') ? $this->input->post('f_status') : $base_where['status'];

		$base_where['type'] = $this->input->post('f_type') ? $this->input->post('f_type') : NULL;
		$base_where['category'] = $this->input->post('f_category') ? $this->input->post('f_category') : NULL;
		//$base_where['keywords'] = $this->input->post('f_keywords') ? htmlspecialchars($this->input->post('f_keywords'), ENT_QUOTES, "UTF-8") : NULL;
		$base_where['keywords'] = $this->input->post('f_keywords') ? str_ireplace("'", "%", $this->input->post('f_keywords')) : NULL;

		// Create pagination links
		$total_rows = $this->members_m->count_by($base_where);
		$pagination = create_pagination('admin/members/index', $total_rows);

		$base_where['limit'] = array($pagination['limit'], $pagination['offset']);

		// Using this data, get the relevant results
		$members = $this->members_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);

		//do we need to unset the layout because the request is ajax?
		$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

		$this->template
			->title($this->module_details['name'])
			->append_js('admin/filter.js')
			->set('pagination', $pagination)
			->set('members', $members);

		$this->input->is_ajax_request() ? $this->template->build('admin/tables/members') : $this->template->build('admin/index');
	}

	public function editXY($id=0)
	{
echo "\$id: $id<br />\n";
		role_or_die('members', 'edit_member');

		//$membershipapplication = $this->members_m->get_by('intID', $id);
		$membershipapplication = $this->members_m->get($id);
		$membersapp = new stdClass();



		$save = false;
		if ($this->input->post('btnSave'))
		{
			$save = true;
		}

		if ($this->input->post('category') == 'Oil Palm Growers')
		{
			$this->validation_rules['primary_market_ops'] = array(
				'field' => 'primary_market_ops',
				'label' => "Primary Market Operation",
				'rules' => 'trim|required',
			);
			$this->validation_rules['other_market_ops'] = array(
				'field' => 'other_market_ops',
				'label' => "Other Market Operation",
				'rules' => 'trim|required',
			);

			$membershipapplication->category = $this->input->post('category');
		}

		if ($this->input->post('type'))
		{
			$membershipapplication->type = $this->input->post('type');
		}
		
		// check if member has saved session
		$m = $this->members_m->get_by('MemberID_2', $this->current_user->id);
		if (!empty($m))
		{
			if ($m->status == 'Pending')
			{
				redirect('members/logout?u=members/pleasewait');
			}
			$membershipapplication = $m;
		}
		else
		{
			if (empty($membershipapplication->category))
				redirect('members/selecttype');
			$membershipapplication->intID = 0;
		}

		$subsidiaries = $this->input->post('sub_company');
		$sub_company = array();
		if (!empty($subsidiaries))
		{
			foreach($subsidiaries['name'] as $k=>$v)
			{
				if ($v)
				{
					$sub_company[$k]['name'] = $v;
					$sub_company[$k]['id'] = $subsidiaries['id'][$k];
				}
			}
			$subsidiary = serialize($sub_company);
		}
		else
		{
			$subsidiary = !empty($membershipapplication->sub_company) ? $membershipapplication->sub_company : serialize(NULL);
		}

		$this->check_dir($this->config_upload['upload_path']);
		$this->load->library('upload', $this->config_upload);
		
		if(!empty($_FILES['logo']['name'])){
		
			if(!$this->upload->do_upload('logo')){ 
				
			}
			else{
				$filelogo_array = $this->upload->data();
				$filelogo = $filelogo_array['file_name'];
			}
		}
		else{
			if ($_POST)
				$filelogo = $this->input->post('upload_logo');
			else
				$filelogo = isset($membershipapplication->logo) ? $membershipapplication->logo : '';
		}

		if (!empty($_FILES['file_certificates']['name'][0]))
		{
			$file_certificates = array();
			if ($this->input->post('uploaded_files_cert'))
			{
				$file_certificates = explode(',', $this->input->post('uploaded_files_cert'));
			}
			if($this->upload->do_multi_upload("file_certificates"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();

				foreach($file_uploaded as $files)
				{
					$file_certificates[] = $files['file_name'];
				}
				
				$cert_file_m = implode(',', $file_certificates);
			}
		}
		else{
			if ($_POST)
				$cert_file_m = $this->input->post('uploaded_files_cert');
			else
				$cert_file_m = isset($membershipapplication->file_certificates) ? $membershipapplication->file_certificates : '';
		}

		// additional files
		if (!empty($_FILES['file_additionals']['name'][0]))
		{
			$addfiles = array();
			if ($this->input->post('uploaded_file_additionals'))
			{
				$addfiles = explode(',', $this->input->post('uploaded_file_additionals'));
			}
			if($this->upload->do_multi_upload("file_additionals"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();

				foreach($file_uploaded as $files)
				{
					$addfiles[] = $files['file_name'];
				}
				
				$file_additionals = implode(',', $addfiles);
			}
		}
		else{
			if ($_POST)
				$file_additionals = $this->input->post('uploaded_file_additionals');
			else
				$file_additionals = isset($membershipapplication->file_additionals) ? $membershipapplication->file_additionals : '';
		}

		// smallholder group manager files
		if (!empty($_FILES['file_sh_group_manager']['name'][0]))
		{
			$shfiles = array();
			if ($this->input->post('uploaded_file_sh_group_manager'))
			{
				$shfiles = explode(',', $this->input->post('uploaded_file_sh_group_manager'));
			}

			if($this->upload->do_multi_upload("file_sh_group_manager"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();
				foreach($file_uploaded as $files)
				{
					$shfiles[] = $files['file_name'];
				}
					
				$file_sh_group_manager = implode(',', $shfiles);
			}
		}
		else{
			if ($_POST)
				$file_sh_group_manager = $this->input->post('uploaded_file_sh_group_manager');
			else
				$file_sh_group_manager = isset($membershipapplication->file_sh_group_manager) ? $membershipapplication->file_sh_group_manager : '';
		}

//echo "\$cert_file_m: $cert_file_m<br />";
		if ($this->input->post('remove_uploaded_cert'))
		{
			$forremoveimg = explode(',',$cert_file_m);
			$remove_uploaded_cert = $this->input->post('remove_uploaded_cert');
			foreach($remove_uploaded_cert as $r)
			{

				if (($key = array_search($r, $forremoveimg)) !== false) {
//echo " -- removing file... <br />";
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg[$key]);
					}
					else
					{
						unset($forremoveimg[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$cert_file_m = implode(',', $forremoveimg);
		}

/*
echo "\$cert_file_m: $cert_file_m<br />";
exit;
*/
		if (!empty($_FILES['file']['name'][0]))
		{
			if($this->upload->do_multi_upload("file"))
				{
					$file = array();
					$file_uploaded = $this->upload->get_multi_upload_data();
					if ($this->input->post('grower_file'))
					{
						$file = explode(',', $this->input->post('grower_file'));
					}

					foreach($file_uploaded as $files)
					{
						$file[] = $files['file_name'];
					}
					
					$file_grower_m = implode(',', $file);
				}
		}
		else{
			if ($_POST)
				$file_grower_m = $this->input->post('grower_file');
			else
				$file_grower_m = isset($membershipapplication->file) ? $membershipapplication->file : '';
		}
		
		$forremoveimg_grower = explode(',',$file_grower_m);
		if ($this->input->post('remove_uploaded_grower'))
		{
			$remove_uploaded_grower = $this->input->post('remove_uploaded_grower');
			foreach($remove_uploaded_grower as $r)
			{
				
				if (($key = array_search($r, $forremoveimg_grower)) !== false) {
	
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg_grower[$key]);
					}
					else
					{
						unset($forremoveimg_grower[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$file = implode(',', $forremoveimg_grower);
		}

		$primary_name = $this->input->post('name_p');
		$primary_email = $this->input->post('email_p');
		$primary_designation = $this->input->post('designation_p');

		$secondary_name = $this->input->post('name_s');
		$secondary_email = $this->input->post('email_s');
		$secondary_designation = $this->input->post('designation_s');

		$this->validation_rules['primary_name'] = array(
			'field' => 'name_p',
			'label' => 'Primary Nomination Full name',
			'rules' => 'trim|required|callback__check_use['.$secondary_name.']',
		);
		$this->validation_rules['secondary_name'] = array(
			'field' => 'name_s',
			'label' => 'Secondary Nomination Full Name',
			'rules' => 'trim|required|callback__check_use['.$primary_name.']',
		);

		$this->validation_rules['primary_email'] = array(
			'field' => 'email_p',
			'label' => 'Primary Nomination Email',
			'rules' => 'trim|required|valid_email|callback__check_use['.$secondary_email.']',
		);

		$this->validation_rules['secondary_email'] = array(
			'field' => 'email_s',
			'label' => 'Secondary Nomination Email',
			'rules' => 'trim|required|valid_email|callback__check_use['.$primary_email.']',
		);
		
		$this->validation_rules['primary_designation'] = array(
			'field' => 'designation_p',
			'label' => 'Primary Nomination Position',
			'rules' => 'trim|required|callback__check_use['.$secondary_designation.']',
		);

		$this->validation_rules['secondary_designation'] = array(
			'field' => 'designation_s',
			'label' => 'Secondary Nomination Position',
			'rules' => 'trim|required|callback__check_use['.$primary_designation.']',
		);

		if ($membershipapplication->category == 'Consumer Goods Manufacturers' OR $membershipapplication->category == 'Palm Oil Processors and Traders')
		{
			$this->validation_rules['sub_category'] = array(
				'field' => 'profession',
				'label' => "Organisation's sub-category",
				'rules' => 'trim|required',
			);
		}

		$validated = false;
		if ($save && $this->input->post('btnSave'))
		{
			$validated = true; //$this->form_validation->run();
		}
		elseif ($this->input->post('btnSubmit'))
		{
			$this->form_validation->set_rules($this->validation_rules);
			$validated = $this->form_validation->run();
		}

		if ($this->input->post('applied_date'))
		{
			$a_date = explode('/', $this->input->post('applied_date'));
			$applied_year = $a_date[2];
			$applied_month = $a_date[1];
			$applied_day = $a_date[0];
			$applied_date = mktime(0, 0, 0, $applied_month, $applied_day, $applied_year);
		}
		else
		{
			$applied_date = isset($membershipapplication->applied_date) ? $membershipapplication->applied_date : 0;
		}
//		$applied_date = strtotime(sprintf('%s $s:$s', $this->input->post('applied_date'), date('H'), date('i')));

		if($validated)
		{
			$pcompany = $this->input->post('parent_company');
			$mtype = $this->input->post('type');
			if ($pcompany == 'none') $pcompany = null;
			$input = array(
				'title' 	=> $this->input->post('title'),
				'type' 		=> $mtype,
				'category' 	=> $this->input->post('category'),
				'name' 		=> $this->input->post('org_name'),
				'address' 	=> $this->input->post('address'),
				'address_city' 	=> $this->input->post('address_city'),
				'address_state' => $this->input->post('address_state'),
				'address_zip' 	=> $this->input->post('address_zip'),
				'country' 		=> $this->input->post('country'),
				'telephone' 	=> $this->input->post('telephone'),
				'fax' 			=> $this->input->post('fax'),
				'email' 		=> $this->input->post('email'),
				'website'	 	=> $this->input->post('website'),
				'registration_number' 	=> $this->input->post('registration_number'),
				'parent_company' 		=> $pcompany,
				'sub_company'			=> ($pcompany == 'yes' OR $pcompany == 'sub') ? $subsidiary : null,
				'primary_market_ops' 	=> $this->input->post('primary_market_ops'),
				'other_market_ops' 	=> $this->input->post('other_market_ops'),
				'logo' 				=> $filelogo,
				'profile' 			=> $this->input->post('profile'),
				
				'name_p' 		=> $this->input->post('name_p'),
				'designation_p' => $this->input->post('designation_p'),
				'telephone_p' 	=> $this->input->post('telephone_p'),
				'fax_p' 		=> $this->input->post('fax_p'),
				'email_p' 		=> $this->input->post('email_p'),
				'name_s' 		=> $this->input->post('name_s'),
				'designation_s' => $this->input->post('designation_s'),
				'telephone_s' 	=> $this->input->post('telephone_s'),
				'fax_s' 		=> $this->input->post('fax_s'),
				'email_s' 		=> $this->input->post('email_s'),
				
				'contact_person' 	=> $this->input->post('contact_person'),
				'designation' 		=> $this->input->post('designation'),
				'contact_tel'	 	=> $this->input->post('contact_tel'),
				'contact_fax'	 	=> $this->input->post('contact_fax'),
				'contact_email' 	=> $this->input->post('contact_email'),
				
				'name_f' 		=> $this->input->post('name_f'),
				'designation_f' => $this->input->post('designation_f'),
				'telephone_f' 	=> $this->input->post('telephone_f'),
				'fax_f' 		=> $this->input->post('fax_f'),
				'email_f' 		=> $this->input->post('email_f'),
				
				'q1' => $this->input->post('q1'),
				'q2' => $this->input->post('q2'),
				'q3' => $this->input->post('q3'),
				'q4' => $this->input->post('q4'),
				'q_usage' => $this->input->post('q_usage'),
				
				'name_a' 		=> $this->input->post('name_a'),
				'designation_a' => $this->input->post('designation_a'),
				'email_a'		=> $this->input->post('email_a'),
				'date_2' 		=> $this->input->post('date_2'),
				'profession' 		=> $this->input->post('profession'),
				'file_certificates'	=> $cert_file_m,
				'file_additionals'	=> $file_additionals,
				'file_sh_group_manager'	=> $file_sh_group_manager,
				'file'				=> $file_grower_m,
				'applied_date' 		=> now(),
				'remarks' 			=> $this->input->post('remarks'),
				'newsletter' 		=> $this->input->post('newsletter') ? $this->input->post('newsletter') : 'n',
			);

			$update = false;
			if ($save && $m && $this->input->post('draft_id'))
			{
				// update data
				$update = $this->members_m->update($this->input->post('draft_id'), $input);

/*
				$data = $input;
				$data['from'] = "membership@rspo.org";
				$data['from'] = "okky@catalyzecommunications.com";
				$data['to']		= $input['email_a'];
				$data['email']	= $input['email_a'];
				$data['slug']	= 'membership-application';
				Events::trigger('email', $data, 'array');

				$data_admin = $input;
				$data_admin['from']		= $input['email_a'];
				$data_admin['app_id']	= $this->input->post('draft_id');
				$data_admin['to']		= Settings::get('contact_email');
				$data_admin['email']	= $data_admin['to'];
				$data_admin['slug']		= 'membership-application-admin';
				Events::trigger('email', $data_admin, 'array');
*/
			}
			else
			{
				$input['MemberID_2'] = $this->current_user->id;
				if ($m && $this->input->post('draft_id'))
				{
					// update -> change status to Pending
					$input['status'] = 'Pending';
					$update = $this->members_m->update($this->input->post('draft_id'), $input);
					if ($update)
						$update = $this->input->post('draft_id');
				}
				else
				{
					// insert new one (member clicks submit without saving
					$update = $this->members_m->insert($input);
				}

				if (!$save)
				{
					// send notification to submitter first
					$data = $input;
					$data['from'] 			= "membership@rspo.org";
					$data['slug']			= 'membership-application';
					$data['to']				= $input['email_a'];
					$data['email']			= $input['email_a'];
					$data['name']			= 'RSPO Membership';
					Events::trigger('email', $data, 'array');

					$data_admin = $input;
					$data_admin['app_id']	= $update;
					$data['from']			= $input['email_a'];
					$data_admin['to']		= Settings::get('contact_email');;
					$data_admin['email']	= $data_admin['to'];
					$data_admin['slug']		= 'membership-application-admin';
					//here add
					$data_admin['org_name']	= $this->input->post('org_name');
					$data_admin['parent_company']	= $pcompany;
					$data_admin['sub_company']	= ($pcompany == 'yes' OR $pcompany == 'sub') ? $subsidiary : null;
					$data_admin['address']		= $this->input->post('address');
					$data_admin['address_city']	= $this->input->post('address_city');
					$data_admin['address_state']	= $this->input->post('address_state');
					$data_admin['address_zip']		= $this->input->post('address_zip');
					$data_admin['country']		= $this->input->post('country');
					$data_admin['telephone']	= $this->input->post('telephone');
					$data_admin['fax']			= $this->input->post('fax');
					$data_admin['email_form']	= $this->input->post('email');
					$data_admin['website']		= $this->input->post('website');
					// end add
					Events::trigger('email', $data_admin, 'array');

					redirect('members/logout?u=members/submitted');
				}

				if ($update)
					$membershipapplication->intID = $update;
			}

			if($update)
			{
				if ($save)
					$this->session->set_flashdata('success', 'Your form was saved successfully.');
				else
					$this->session->set_flashdata('success', 'Your application has been submitted successfully to RSPO.');
				redirect('members/application');
			}
			else
			{
				$this->session->set_flashdata('error', 'Error Add');
				if ($save)
					$this->session->set_flashdata('error', 'We have difficulties saving your form. Please try again or report it to us.');
				else
					$this->session->set_flashdata('error', 'We have difficulties submitting your application. Please try again or report it to us.');
				redirect('members/application');
			}
		}
		
		// Go through all the known fields and get the post values
		if ($_POST)
		{
			foreach ($this->validation_rules as $rule)
			{
				$membershipapplication->{$rule['field']} = $this->input->post($rule['field']);
			}
		}

		$membershipapplication->logo = $filelogo;
		$membershipapplication->file = $file_grower_m;
		$membershipapplication->file_certificates = $cert_file_m;
		$membershipapplication->file = implode(',', $forremoveimg_grower);
		//$membershipapplication->file_certificates = implode(',', $forremoveimg);
		$membershipapplication->sub_company = $subsidiary;
		//$membershipapplication->org_name = $membershipapplication->name;

		$membershipapplication->name_a = $this->input->post('name_a') ? $this->input->post('name_a') : $this->current_user->first_name . ( $this->current_user->last_name ? ' ' . $this->current_user->last_name : '' );
		$membershipapplication->email_a = $this->input->post('email_a') ? $this->input->post('email_a') : $this->current_user->email;

		$this->template
			->title('Member Application')
			->set_breadcrumb('Members', 'members')
			->set_breadcrumb('Application')
			//->append_css('main.css')
			//->append_js('jquery.steps.min.js')
			//->append_js('bootstrap-filestyle.js')
			->set('membersapp', $membershipapplication)
			->build('admin/form-member');
			//->build('applications/application');
	}

	public function create()
	{
		role_or_die('members', 'add_member');
	
		$membershipapplication = new stdClass(); //$this->members_m->get($id);

/*
		if (empty($membershipapplication))
		{
			$this->session->set_flashdata('error', 'The member you tried to edit does not exist.');
			redirect('admin/members');
		}

		$this->input->post('org_subcategory');
*/

		$subsidiaries = $this->input->post('sub_company');
		$sub_company = array();
		if (!empty($subsidiaries))
		{
			foreach($subsidiaries['name'] as $k=>$v)
			{
				if ($v)
				{
					$sub_company[$k]['name'] = $v;
					$sub_company[$k]['id'] = $subsidiaries['id'][$k];
				}
			}
			$subsidiary = serialize($sub_company);
		}
		else
		{
			$subsidiary = !empty($membershipapplication->sub_company) ? $membershipapplication->sub_company : serialize(NULL);
		}

		$this->check_dir($this->config_upload['upload_path']);
		$this->load->library('upload', $this->config_upload);
		
		if(!empty($_FILES['logo']['name'])){
		
			if(!$this->upload->do_upload('logo')){ 
				
			}
			else{
				$filelogo_array = $this->upload->data();
				$filelogo = $filelogo_array['file_name'];
			}
		}
		else{
			if ($_POST)
				$filelogo = $this->input->post('upload_logo');
			else
				$filelogo = isset($membershipapplication->logo) ? $membershipapplication->logo : '';
		}
		
		if (!empty($_FILES['file_certificates']['name'][0]))
		{
			$file_certificates = array();
			if ($this->input->post('uploaded_files_cert'))
			{
				$file_certificates = explode(',', $this->input->post('uploaded_files_cert'));
			}
			if($this->upload->do_multi_upload("file_certificates"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();

				foreach($file_uploaded as $files)
				{
					$file_certificates[] = $files['file_name'];
				}
				
				$cert_file_m = implode(',', $file_certificates);
			}
		}
		else{
			if ($_POST)
				$cert_file_m = $this->input->post('uploaded_files_cert');
			else
				$cert_file_m = isset($membershipapplication->file_certificates) ? $membershipapplication->file_certificates : '';
		}

		if (!empty($_FILES['file_additionals']['name'][0]))
		{
			$addfiles = array();
			if ($this->input->post('uploaded_file_additionals'))
			{
				$addfiles = explode(',', $this->input->post('uploaded_file_additionals'));
			}
			if($this->upload->do_multi_upload("file_additionals"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();

				foreach($file_uploaded as $files)
				{
					$addfiles[] = $files['file_name'];
				}
				
				$file_additionals = implode(',', $addfiles);
			}
		}
		else{
			if ($_POST)
				$file_additionals = $this->input->post('uploaded_file_additionals');
			else
				$file_additionals = isset($membershipapplication->file_additionals) ? $membershipapplication->file_additionals : '';
		}

		// smallholder group manager files
		if (!empty($_FILES['file_sh_group_manager']['name'][0]))
		{
			$shfiles = array();
			if ($this->input->post('uploaded_file_sh_group_manager'))
			{
				$shfiles = explode(',', $this->input->post('uploaded_file_sh_group_manager'));
			}

			if($this->upload->do_multi_upload("file_sh_group_manager"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();
				foreach($file_uploaded as $files)
				{
					$shfiles[] = $files['file_name'];
				}
					
				$file_sh_group_manager = implode(',', $shfiles);
			}
		}
		else{
			if ($_POST)
				$file_sh_group_manager = $this->input->post('uploaded_file_sh_group_manager');
			else
				$file_sh_group_manager = isset($membershipapplication->file_sh_group_manager) ? $membershipapplication->file_sh_group_manager : '';
		}

		if ($this->input->post('remove_uploaded_cert'))
		{
			$forremoveimg = explode(',',$cert_file_m);
			$remove_uploaded_cert = $this->input->post('remove_uploaded_cert');
			foreach($remove_uploaded_cert as $r)
			{

				if (($key = array_search($r, $forremoveimg)) !== false) {
//echo " -- removing file... <br />";
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg[$key]);
					}
					else
					{
						unset($forremoveimg[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$cert_file_m = implode(',', $forremoveimg);
		}

		if (!empty($_FILES['file']['name'][0]))
		{
			if($this->upload->do_multi_upload("file"))
				{
					$file = array();
					$file_uploaded = $this->upload->get_multi_upload_data();
					if ($this->input->post('grower_file'))
					{
						$file = explode(',', $this->input->post('grower_file'));
					}

					foreach($file_uploaded as $files)
					{
						$file[] = $files['file_name'];
					}
					
					$file_grower_m = implode(',', $file);
				}
		}
		else{
			if ($_POST)
				$file_grower_m = $this->input->post('grower_file');
			else
				$file_grower_m = isset($membershipapplication->file) ? $membershipapplication->file : '';
		}
		
		$forremoveimg_grower = explode(',',$file_grower_m);
		if ($this->input->post('remove_uploaded_grower'))
		{
			$remove_uploaded_grower = $this->input->post('remove_uploaded_grower');
			foreach($remove_uploaded_grower as $r)
			{
				
				if (($key = array_search($r, $forremoveimg_grower)) !== false) {
	
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg_grower[$key]);
					}
					else
					{
						unset($forremoveimg_grower[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$file = implode(',', $forremoveimg_grower);
		}

		// If we have a useful date, use it
		if ($this->input->post('expiry_date'))
		{
			$expiry_date = strtotime(sprintf('%s', $this->input->post('expiry_date')));
		}
		else
		{
			$expiry_date = NULL;
		}

		// If we have approved_date date, use it
		if ($this->input->post('approved_date') && $this->input->post('status')=='Approved')
		{
			$approved_date = strtotime(sprintf('%s', $this->input->post('approved_date')));
		}
		else
		{
			$approved_date = NULL;
		}

		$this->form_validation->set_rules($this->validation_rules);
		if($this->form_validation->run()){
			$pcompany = $this->input->post('parent_company');
			$mtype = $this->input->post('type');
			if ($pcompany == 'none') $pcompany = null;
			$membershipapp_insert = array(
				'title' 				=> $this->input->post('org_name'),
				'type' 					=> $this->types[$mtype],
				'category' 				=> $this->input->post('category'),
				'profession' 			=> $this->input->post('profession'),
				'name' 					=> $this->input->post('org_name'),
				'address' 				=> $this->input->post('address'),
				'address_city' 			=> $this->input->post('address_city'),
				'address_state' 		=> $this->input->post('address_state'),
				'address_zip' 			=> $this->input->post('address_zip'),
				'country' 				=> $this->input->post('country'),
				'code_telephone' 		=> $this->input->post('code_telephone'),
				'telephone' 			=> $this->input->post('telephone'),
				'code_fax' 				=> $this->input->post('code_fax'),
				'fax' 					=> $this->input->post('fax'),
				'email' 				=> $this->input->post('email'),
				'website'	 			=> $this->input->post('website'),
				'registration_number' 	=> $this->input->post('registration_number'),
				'parent_company' 		=> $pcompany,
				'sub_company'			=> ($pcompany == 'yes' OR $pcompany == 'sub') ? $subsidiary : null,
				'primary_market_ops' 	=> $this->input->post('primary_market_ops'),
				'other_market_ops' 		=> $this->input->post('other_market_ops'),
				'logo' 					=> $filelogo,
				'profile' 				=> $this->input->post('profile'),
				
				'name_p' 		=> $this->input->post('name_p'),
				'name_last_p' 	=> $this->input->post('name_last_p'),
				'designation_p' => $this->input->post('designation_p'),
				'code_tel_p' 	=> $this->input->post('code_tel_p'),
				'telephone_p' 	=> $this->input->post('telephone_p'),
				'code_fax_p' 	=> $this->input->post('code_fax_p'),
				'fax_p' 		=> $this->input->post('fax_p'),
				'email_p' 		=> $this->input->post('email_p'),
				'name_s' 		=> $this->input->post('name_s'),
				'name_last_s' 	=> $this->input->post('name_last_s'),
				'designation_s' => $this->input->post('designation_s'),
				'code_tel_s' 	=> $this->input->post('code_tel_s'),
				'telephone_s' 	=> $this->input->post('telephone_s'),
				'code_fax_s' 	=> $this->input->post('code_fax_s'),
				'fax_s' 		=> $this->input->post('fax_s'),
				'email_s' 		=> $this->input->post('email_s'),
				
				'contact_person' 	=> $this->input->post('contact_person'),
				'contact_lname' 	=> $this->input->post('contact_lname'),
				'designation' 		=> $this->input->post('designation'),
				'code_contact_tel' 		=> $this->input->post('code_contact_tel'),
				'contact_tel'	 	=> $this->input->post('contact_tel'),
				'code_contact_fax' 		=> $this->input->post('code_contact_fax'),
				'contact_fax'	 	=> $this->input->post('contact_fax'),
				'contact_email' 	=> $this->input->post('contact_email'),
				
				'name_f' 		=> $this->input->post('name_f'),
				'name_last_f' 	=> $this->input->post('name_last_f'),
				'designation_f' => $this->input->post('designation_f'),
				'code_tel_f' 	=> $this->input->post('code_tel_f'),
				'telephone_f' 	=> $this->input->post('telephone_f'),
				'code_fax_f' 	=> $this->input->post('code_fax_f'),
				'fax_f' 		=> $this->input->post('fax_f'),
				'email_f' 		=> $this->input->post('email_f'),
				
				'q1' 			=> $this->input->post('q1'),
				'q2' 			=> $this->input->post('q2'),
				'q3' 			=> $this->input->post('q3'),
				'q4' 			=> $this->input->post('q4'),
				'q_usage' 		=> $this->input->post('q_usage'),

				'status' 			=> $this->input->post('status'),
				'member_num' 		=> $this->input->post('status')=='Approved'?$this->input->post('member_num'):NULL,
				'expiry_date' 		=> $expiry_date,
				'approved_date' 	=> $approved_date,

				'name_a' 			=> $this->input->post('name_a'),
				'email_a' 			=> $this->input->post('email_a'),
				'designation_a' 	=> $this->input->post('designation_a'),
				'date_2' 			=> $this->input->post('date_2'),
				'profession' 		=> $this->input->post('profession'),
				'file_certificates'	=> $cert_file_m,
				'file_additionals'	=> $file_additionals,
				'file_sh_group_manager'	=> $file_sh_group_manager,
				'file'				=> $file_grower_m,
				'applied_date' 		=> now(),
				'remarks' 			=> $this->input->post('remarks'),
				'newsletter' 		=> $this->input->post('newsletter') ? $this->input->post('newsletter') : 'n',
			);

/*
echo "<pre>\n";
echo "\$membershipapp_insert\n";
print_r($membershipapp_insert);
echo "</pre>\n";

echo "<pre>\n";
echo "\$_POST\n";
print_r($_POST);
echo "</pre>\n";
exit;
*/

			$membership_update = array(
				'status' 				=> $this->input->post('status'),
				'email_a' 				=> $this->input->post('email_a'),
				'parent_company' 		=> $this->input->post('parent_company'),
				'sub_company' 			=> $subsidiary,
				'expiry_date' 			=> $expiry_date
			);

			$id = $this->members_m->insert($membershipapp_insert);
			if($id)
				{
					$this->pyrocache->delete_all('members_m');
					$this->session->set_flashdata('success', sprintf( lang('memberss:member_save_success'), $this->input->post('org_name')) );

					if ($this->input->post('btnAction') == 'sync')
					{
						$triggered_event = Events::trigger('member_updated', array('id'=>$id, 'input'=>$membershipapp_insert));
						$this->session->set_flashdata('notice', $triggered_event); // <--- comment on live system
					}

					$membershipapplication = $this->members_m->get($id);
					if ($this->input->post('btnAction') == 'send_files')
					{
						$files = array(
							'application_sf_id'=>$membershipapplication->application_sf_id,
							'logo'=>$membershipapplication->logo,
							'file'=>$membershipapplication->file,
							'file_certificates'=>$membershipapplication->file_certificates,
							'file_additionals'=>$membershipapplication->file_additionals,
							'file_sh_group_manager'=>$membershipapplication->file_sh_group_manager,
							'file_sc_group_manager'=>$membershipapplication->file_sc_group_manager,
						);
						$triggered_event = Events::trigger('files_updated', array('id'=>$id, 'member_name'=>$membershipapplication->title, 'input'=>$files));
						$this->session->set_flashdata('notice', $triggered_event); // <--- comment on live system
					}

					$this->input->post('btnAction') == 'save' ? redirect('admin/members/edit/'.$id) : redirect('admin/members');
				}
			else{
					$this->session->set_flashdata('error', sprintf( lang('memberss:member_save_error'), $this->input->post('org_name')) );
					//$this->session->set_flashdata('error', 'Error updating member');
					redirect('admin/members');
				}
		}

		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $rule)
		{
			//if ($this->input->post())
			//{
				$membershipapplication->{$rule['field']} = $this->input->post($rule['field']);
			//}
		}
		
		$membershipapplication->logo = $filelogo;
		$membershipapplication->file = $file_grower_m;
		$membershipapplication->file_certificates = $cert_file_m;
		$membershipapplication->file = implode(',', $forremoveimg_grower);
		if (!empty($forremoveimg))
			$membershipapplication->file_certificates = implode(',', $forremoveimg);
		$membershipapplication->sub_company = $subsidiary;
		$membershipapplication->name = $membershipapplication->org_name;

		$this->template
			->append_metadata($this->load->view('fragments/wysiwyg', array(), TRUE))
			->append_css('module::members.css')
			->append_css('module::intlTelInput.css')
			->append_js('module::intlTelInput.js')
			->set('membersapp', $membershipapplication)
			->build('admin/application');
			//->build('admin/form-member');
	}

	public function memberclone($id=0)
	{
		$rules = array(
			array(
				'field' => 'user',
				'label' => 'User Link',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'type',
				'label' => 'Category',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'category',
				'label' => 'Sector',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'name',
				'label' => 'Organisation/Company Name',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'contact_primary',
				'label' => 'Primary Contact',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_secondary',
				'label' => 'Secondary Contact',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_finance',
				'label' => 'Finance Contact',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_other',
				'label' => 'Contact Person',
				'rules' => 'trim',
			),
			array(
				'field' => 'all_answers',
				'label' => 'Include all answers',
				'rules' => 'trim',
			),
			array(
				'field' => 'all_files',
				'label' => 'Include all file attachment',
				'rules' => 'trim',
			),
		);

		role_or_die('members', 'add_member');

		$clone = new stdClass();

		$this->load->model('users/user_m');
		$users = array(''=>'Please select');
		$group_users = $this->user_m->get_many_by(array('group_id'=>'2'));
		if ($group_users)
		{
			foreach($group_users as $u)
			{
				$users[$u->id] = $u->first_name.' '.$u->last_name;
			}
		}
		$this->template->set('users', $users);

		$member = $this->members_m->get_no_profile($id);

		if (empty($member))
		{
			$this->session->set_flashdata('error', 'The member you tried to clone from does not exist.');
			redirect('admin/members');
		}

		//if ($_POST)

		$this->form_validation->set_rules($rules);
		if($this->form_validation->run())
		{
			// empty intID
			unset($member->intID);

			if ($this->input->post('contact_other')<>'y')
			{
				// do not clone contact person
				$member->code_contact_tel = $member->contact_tel = $member->code_contact_fax = $member->contact_fax = $member->contact_email = $member->contact_person = $member->contact_lname = $member->contact_tel = $member->designation = '';
			}

			if ($this->input->post('contact_primary')<>'y')
			{
				// do not clone primary contact
				$member->name_p = $member->name_last_p = $member->designation_p = $member->code_tel_p = $member->telephone_p = $member->code_fax_p = $member->fax_p = $member->email_p = '';
			}

			if ($this->input->post('contact_secondary')<>'y')
			{
				// do not clone secondary contact
				$member->name_s = $member->name_last_s = $member->designation_s = $member->code_tel_s = $member->telephone_s = $member->code_fax_s = $member->fax_s = $member->email_s = '';
			}

			if ($this->input->post('contact_finance')<>'y')
			{
				// do not clone finance contact
				$member->name_f = $member->name_last_f = $member->designation_f = $member->code_tel_f = $member->telephone_f = $member->code_fax_f = $member->fax_f = $member->email_f = '';
			}

			if ($this->input->post('all_answers')<>'y')
			{
				// do not clone finance contact
				$member->q1 = $member->q2 = $member->q3 = $member->q4 = $member->q_usage = '';
			}

			if ($this->input->post('all_files')<>'y')
			{
				// do not clone finance contact
				$member->logo = $member->file = $member->file_certificates = $member->file_additionals = $member->file_sh_group_manager = $member->file_sc_group_manager = '';
			}

			$member->MemberID_2 = NULL;
			// is a user linked to this clone?
			if ($this->input->post('user'))
			{
				$member->MemberID_2 = $this->input->post('user');
			}

			if ($this->input->post('name'))
			{
				$member->title = $this->input->post('name');
				$member->name = $this->input->post('name');
			}

			// sector & category are always empty / not cloned
			$member->type = $this->input->post('type');
			$member->category = $this->input->post('sector');
			$member->sub_category_other = '';

			// reset status
			$member->status = NULL;

			// reset application_sf_id
			$member->application_sf_id = NULL;

			$res = $this->members_m->clonemember($member);
			if ($res)
			{
				// remove MemberID_2
				$this->members_m->update($id, array('MemberID_2'=>''));
				$this->session->set_flashdata('success', 'Member "'.$member->title.'" was cloned successfully.');
				redirect('admin/members');
			}
			else
			{
				$this->template->set('error_msg', 'Failed cloning member "'.$member->title.'".');
			}
		}

		foreach ($rules as $rule)
		{
			$clone->{$rule['field']} = $this->input->post($rule['field']);
		}

		$this->template
			->set('clone', $clone)
			->set('member', $member)
			->build('admin/clone');
	}

	public function edit($id=0)
	{
		role_or_die('members', 'edit_member');
	
		//$membershipapplication = $this->members_m->get_by('intID', $id);
		$membershipapplication = $this->members_m->get($id);

		if (empty($membershipapplication))
		{
			$this->session->set_flashdata('error', 'The member you tried to edit does not exist.');
			redirect('admin/members');
		}

		$this->input->post('org_subcategory');

		$subsidiaries = $this->input->post('sub_company');
		$sub_company = array();
		if (!empty($subsidiaries))
		{
			foreach($subsidiaries['name'] as $k=>$v)
			{
				if ($v)
				{
					$sub_company[$k]['name'] = $v;
					$sub_company[$k]['id'] = $subsidiaries['id'][$k];
				}
			}
			$subsidiary = serialize($sub_company);
		}
		else
		{
			$subsidiary = !empty($membershipapplication->sub_company) ? $membershipapplication->sub_company : serialize(NULL);
		}

		$this->check_dir($this->config_upload['upload_path']);
		$this->load->library('upload', $this->config_upload);
		
		if(!empty($_FILES['logo']['name'])){
		
			if(!$this->upload->do_upload('logo')){ 
				
			}
			else{
				$file = $this->upload->data();
				$filelogo = $file['file_name'];
				if ($file['is_image'])
				{
					$this->load->library('image_lib');
					$filename = $file['file_name'];
					$thumbfile = thumbnail($filename); //substr($filename, 0, -4) . '_thumb' . substr($filename, -4);
					//$medfile = fullname($filename); //substr($filename, 0, -4) . '_full' . substr($filename, -4);
					/*---------------------------------------------------------------------------------
					// create thumb - admin
					*/
					//echo "Full path: " . $file['full_path'] . "<br />";

/*
					$image_cfg['source_image'] = $file['full_path'];
					$image_cfg['image_library'] = 'gd2';
					$image_cfg['maintain_ratio'] = TRUE;
					$image_cfg['width'] = ($file['image_width'] < $this->thumb_width ? $file['image_width'] : $this->thumb_width);
					$image_cfg['height'] = ($file['image_height'] < $this->thumb_height ? $file['image_height'] : $this->thumb_height);
					$image_cfg['create_thumb'] = FALSE;
					$image_cfg['new_image'] = $file['file_path'] . $thumbfile;
					$image_cfg['master_dim'] = 'width';
					$this->image_lib->initialize($image_cfg);
					$img_ok = $this->image_lib->resize();
					unset($image_cfg);
					$this->image_lib->clear();
if (!$img_ok)
	echo "Thumbnail " . $file['file_path'] . $thumbfile . ': ' . $this->image_lib->display_errors() . "<br />\n";
*/
					/*
					/* image resize - medium
					*/
					$image_cfg['source_image'] = $file['full_path'];
					$image_cfg['image_library'] = 'gd2';
					$image_cfg['maintain_ratio'] = TRUE;
					$image_cfg['width'] = ($file['image_width'] < $this->thumb_width ? $file['image_width'] : $this->thumb_width);
					$image_cfg['height'] = ($file['image_height'] < $this->thumb_height ? $file['image_height'] : $this->thumb_height);
					$image_cfg['create_thumb'] = TRUE;
					$image_cfg['new_image'] = $file['file_path'] . $filename; //$thumbfile;
					$image_cfg['master_dim'] = 'width';
					$this->image_lib->initialize($image_cfg);
					$img_ok = $this->image_lib->resize();
					unset($image_cfg);
					$this->image_lib->clear();

					//if (!$img_ok)
					//	echo "Resize: " . $this->image_lib->display_errors() . "<br />\n";

					/*
					*  remove old logo
					*/
					if ( $membershipapplication->logo )
					{
						if (strstr($membershipapplication->logo, '/sites/default/files/'))
						{
							$fname = $_SERVER['DOCUMENT_ROOT'] . $membershipapplication->logo;
							$tname = $_SERVER['DOCUMENT_ROOT'] . thumbnail($membershipapplication->logo);
							//echo '<img class="img-responsive" src="http://www.rspo.org'.$member->logo.'" />'.PHP_EOL;
						}
						elseif(strstr($membershipapplication->logo, 'ma/logo/'))
						{
							$fname = $_SERVER['DOCUMENT_ROOT'] .'/'. $membershipapplication->logo;
						}
						else
						{
							$fname = $_SERVER['DOCUMENT_ROOT'] . UPLOAD_PATH . '/memberlogos/' . $membershipapplication->logo;
							$tname = $_SERVER['DOCUMENT_ROOT'] . UPLOAD_PATH . '/memberlogos/' . thumbnail($membershipapplication->logo);
						}
						if (is_file($fname))
						{
							unlink($fname);
							if (!empty($tname))
								unlink($tname);
						}
					}

				}
			}
		}
		else{
			if ($_POST)
				$filelogo = $this->input->post('upload_logo');
			else
				$filelogo = isset($membershipapplication->logo) ? $membershipapplication->logo : '';
		}
		
		if (!empty($_FILES['file_certificates']['name'][0]))
		{
			$file_certificates = array();
			if ($this->input->post('uploaded_files_cert'))
			{
				$file_certificates = explode(',', $this->input->post('uploaded_files_cert'));
			}
			if($this->upload->do_multi_upload("file_certificates"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();

				foreach($file_uploaded as $files)
				{
					$file_certificates[] = $files['file_name'];
				}
				
				$cert_file_m = implode(',', $file_certificates);
			}
		}
		else{
			if ($_POST)
				$cert_file_m = $this->input->post('uploaded_files_cert');
			else
				$cert_file_m = isset($membershipapplication->file_certificates) ? $membershipapplication->file_certificates : '';
		}

		if (!empty($_FILES['file_additionals']['name'][0]))
		{
			$addfiles = array();
			if ($this->input->post('uploaded_file_additionals'))
			{
				$addfiles = explode(',', $this->input->post('uploaded_file_additionals'));
			}
			if($this->upload->do_multi_upload("file_additionals"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();

				foreach($file_uploaded as $files)
				{
					$addfiles[] = $files['file_name'];
				}
				
				$file_additionals = implode(',', $addfiles);
			}
		}
		else{
			if ($_POST)
				$file_additionals = $this->input->post('uploaded_file_additionals');
			else
				$file_additionals = isset($membershipapplication->file_additionals) ? $membershipapplication->file_additionals : '';
		}

		// smallholder group manager files
		if (!empty($_FILES['file_sh_group_manager']['name'][0]))
		{
			$shfiles = array();
			if ($this->input->post('uploaded_file_sh_group_manager'))
			{
				$shfiles = explode(',', $this->input->post('uploaded_file_sh_group_manager'));
			}

			if($this->upload->do_multi_upload("file_sh_group_manager"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();
				foreach($file_uploaded as $files)
				{
					$shfiles[] = $files['file_name'];
				}
					
				$file_sh_group_manager = implode(',', $shfiles);
			}
		}
		else{
			if ($_POST)
				$file_sh_group_manager = $this->input->post('uploaded_file_sh_group_manager');
			else
				$file_sh_group_manager = isset($membershipapplication->file_sh_group_manager) ? $membershipapplication->file_sh_group_manager : '';
		}

		if ($this->input->post('remove_uploaded_cert'))
		{
			$forremoveimg = explode(',',$cert_file_m);
			$remove_uploaded_cert = $this->input->post('remove_uploaded_cert');
			foreach($remove_uploaded_cert as $r)
			{

				if (($key = array_search($r, $forremoveimg)) !== false) {
//echo " -- removing file... <br />";
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg[$key]);
					}
					else
					{
						unset($forremoveimg[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$cert_file_m = implode(',', $forremoveimg);
		}

		if (!empty($_FILES['file']['name'][0]))
		{
			if($this->upload->do_multi_upload("file"))
				{
					$file = array();
					$file_uploaded = $this->upload->get_multi_upload_data();
					if ($this->input->post('grower_file'))
					{
						$file = explode(',', $this->input->post('grower_file'));
					}

					foreach($file_uploaded as $files)
					{
						$file[] = $files['file_name'];
					}
					
					$file_grower_m = implode(',', $file);
				}
		}
		else{
			if ($_POST)
				$file_grower_m = $this->input->post('grower_file');
			else
				$file_grower_m = isset($membershipapplication->file) ? $membershipapplication->file : '';
		}
		
		$forremoveimg_grower = explode(',',$file_grower_m);
		if ($this->input->post('remove_uploaded_grower'))
		{
			$remove_uploaded_grower = $this->input->post('remove_uploaded_grower');
			foreach($remove_uploaded_grower as $r)
			{
				
				if (($key = array_search($r, $forremoveimg_grower)) !== false) {
	
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg_grower[$key]);
					}
					else
					{
						unset($forremoveimg_grower[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$file = implode(',', $forremoveimg_grower);
		}

		// If we have expiry_date date, use it
		if ($this->input->post('expiry_date') && $this->input->post('status')=='Call for Comment')
		{
			$expiry_date = strtotime(sprintf('%s', $this->input->post('expiry_date')));
		}
		else
		{
			$expiry_date = $membershipapplication->expiry_date;
		}

		// If we have approved_date date, use it
		if ($this->input->post('approved_date') && $this->input->post('status')=='Approved')
		{
			$approved_date = strtotime(sprintf('%s', $this->input->post('approved_date')));
		}
		else
		{
			$approved_date = $membershipapplication->approved_date;
		}

		$pcompany = $this->input->post('parent_company');
		$mtype = $this->input->post('type');
		if ($pcompany == 'none') $pcompany = null;


		$this->form_validation->set_rules($this->validation_rules);
		if($this->form_validation->run()){
			$membershipapp_insert = array(
				'title' 				=> $this->input->post('org_name'),
				'type' 					=> $this->types[$mtype],
				'category' 				=> $this->input->post('category'),
				'profession' 			=> $this->input->post('profession'),
				'name' 					=> $this->input->post('org_name'),
				'address' 				=> $this->input->post('address'),
				'address_city' 			=> $this->input->post('address_city'),
				'address_state' 		=> $this->input->post('address_state'),
				'address_zip' 			=> $this->input->post('address_zip'),
				'country' 				=> $this->input->post('country'),
				'code_telephone' 		=> $this->input->post('code_telephone'),
				'telephone' 			=> $this->input->post('telephone'),
				'code_fax' 				=> $this->input->post('code_fax'),
				'fax' 					=> $this->input->post('fax'),
				'email' 				=> $this->input->post('email'),
				'website'	 			=> $this->input->post('website'),
				'registration_number' 	=> $this->input->post('registration_number'),
				'parent_company' 		=> $pcompany,
				'sub_company'			=> ($pcompany == 'yes' OR $pcompany == 'sub') ? $subsidiary : null,
				'primary_market_ops' 	=> $this->input->post('primary_market_ops'),
				'other_market_ops' 		=> $this->input->post('other_market_ops'),
				'logo' 					=> $filelogo,
				'profile' 				=> $this->input->post('profile'),
				
				'name_p' 		=> $this->input->post('name_p'),
				'name_last_p'	=> $this->input->post('name_last_p'),
				'designation_p' => $this->input->post('designation_p'),
				'code_tel_p' 	=> $this->input->post('code_tel_p'),
				'telephone_p' 	=> $this->input->post('telephone_p'),
				'code_fax_p' 	=> $this->input->post('code_fax_p'),
				'fax_p' 		=> $this->input->post('fax_p'),
				'email_p' 		=> $this->input->post('email_p'),
				'name_s' 		=> $this->input->post('name_s'),
				'name_last_s'	=> $this->input->post('name_last_s'),
				'designation_s' => $this->input->post('designation_s'),
				'code_tel_s' 	=> $this->input->post('code_tel_s'),
				'telephone_s' 	=> $this->input->post('telephone_s'),
				'code_fax_s' 	=> $this->input->post('code_fax_s'),
				'fax_s' 		=> $this->input->post('fax_s'),
				'email_s' 		=> $this->input->post('email_s'),
				
				'contact_person' 	=> $this->input->post('contact_person'),
				'contact_lname'		=> $this->input->post('contact_lname'),
				'designation' 		=> $this->input->post('designation'),
				'code_contact_tel' 		=> $this->input->post('code_contact_tel'),
				'contact_tel'	 	=> $this->input->post('contact_tel'),
				'code_contact_fax' 		=> $this->input->post('code_contact_fax'),
				'contact_fax'	 	=> $this->input->post('contact_fax'),
				'contact_email' 	=> $this->input->post('contact_email'),
				
				'name_f' 		=> $this->input->post('name_f'),
				'name_last_f'	=> $this->input->post('name_last_f'),
				'designation_f' => $this->input->post('designation_f'),
				'code_tel_f' 	=> $this->input->post('code_tel_f'),
				'telephone_f' 	=> $this->input->post('telephone_f'),
				'code_fax_f' 	=> $this->input->post('code_fax_f'),
				'fax_f' 		=> $this->input->post('fax_f'),
				'email_f' 		=> $this->input->post('email_f'),
				
				'q1' 			=> $this->input->post('q1'),
				'q2' 			=> $this->input->post('q2'),
				'q3' 			=> $this->input->post('q3'),
				'q4' 			=> $this->input->post('q4'),
				'q_usage' 		=> $this->input->post('q_usage'),

				'status' 			=> $this->input->post('status'),
				'member_num' 		=> $this->input->post('status')=='Approved'?$this->input->post('member_num'):NULL,
				'expiry_date' 		=> $expiry_date,
				'approved_date' 	=> $approved_date,

				'name_a' 			=> $this->input->post('name_a'),
				'email_a' 			=> $this->input->post('email_a'),
				'designation_a' 	=> $this->input->post('designation_a'),
				'date_2' 			=> $this->input->post('date_2'),
				'profession' 		=> $this->input->post('profession'),
				'file_certificates'	=> $cert_file_m,
				'file_additionals'	=> $file_additionals,
				'file_sh_group_manager'	=> $file_sh_group_manager,
				'file'				=> $file_grower_m,
				'applied_date' 		=> now(),
				'remarks' 			=> $this->input->post('remarks'),
				'newsletter' 		=> $this->input->post('newsletter') ? $this->input->post('newsletter') : 'n',
			);

/*
echo "<pre>\n";
echo "\$membershipapp_insert\n";
print_r($membershipapp_insert);
echo "</pre>\n";

echo "<pre>\n";
echo "\$_POST\n";
print_r($_POST);
echo "</pre>\n";
exit;
*/

			$membership_update = array(
				'status' 				=> $this->input->post('status'),
				'email_a' 				=> $this->input->post('email_a'),
				'parent_company' 		=> $this->input->post('parent_company'),
				'sub_company' 			=> $subsidiary,
				'expiry_date' 			=> $expiry_date
			);

			$member_updated = $this->members_m->update($id, $membershipapp_insert);

			if($member_updated)
				{
					$this->pyrocache->delete_all('members_m');
					$this->session->set_flashdata('success', sprintf( lang('members:member_save_success'), $this->input->post('org_name')) );

					// trigger event to sync to SF
					//if (strtolower($membershipapp_insert['status'])=='approved')
					if ($this->input->post('btnAction') == 'sync')
					{
						$triggered_event = Events::trigger('member_updated', array('id'=>$id, 'input'=>$membershipapp_insert));
						$this->session->set_flashdata('notice', $triggered_event); // <--- comment on live system
					}

					if ($this->input->post('btnAction') == 'send_files')
					{
						$files = array(
							'application_sf_id'=>$membershipapplication->application_sf_id,
							'logo'=>$membershipapplication->logo,
							'file'=>$membershipapplication->file,
							'file_certificates'=>$membershipapplication->file_certificates,
							'file_additionals'=>$membershipapplication->file_additionals,
							'file_sh_group_manager'=>$membershipapplication->file_sh_group_manager,
							'file_sc_group_manager'=>$membershipapplication->file_sc_group_manager,
						);
						$triggered_event = Events::trigger('files_updated', array('id'=>$id, 'member_name'=>$membershipapplication->title, 'input'=>$files));
						$this->session->set_flashdata('notice', $triggered_event); // <--- comment on live system
					}

					($this->input->post('btnAction') == 'save' OR $this->input->post('btnAction') == 'sync') ? redirect('admin/members/edit/'.$id) : redirect('admin/members');
				}
			else{
					$this->session->set_flashdata('error', sprintf( lang('members:member_save_error'), $this->input->post('org_name')) );
					//$this->session->set_flashdata('error', 'Error updating member');
					redirect('admin/members');
				}
		}

		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $rule)
		{
			if ($this->input->post())
			{
				if ($rule['field']=='type')
					$membershipapplication->type = $this->types[$mtype];
				else
					$membershipapplication->{$rule['field']} = $this->input->post($rule['field']);
			}
		}
		
		$membershipapplication->logo = $filelogo;
		$membershipapplication->file = $file_grower_m;
		$membershipapplication->file_certificates = $cert_file_m;
		$membershipapplication->file = implode(',', $forremoveimg_grower);
		if (!empty($forremoveimg))
			$membershipapplication->file_certificates = implode(',', $forremoveimg);
		$membershipapplication->sub_company = $subsidiary;

		//$membershipapplication->type = $this->types[$mtype];

		if (!empty($membershipapplication->name))
			$membershipapplication->name = stripslashes($membershipapplication->name);

		$this->template
			->append_metadata($this->load->view('fragments/wysiwyg', array(), TRUE))
			->append_css('module::members.css')
			->append_css('module::intlTelInput.css')
			->append_js('module::intlTelInput.js')
			->set('membersapp', $membershipapplication)
			->build('admin/application');
			//->build('admin/form-member');
	}


	/**
	 * method to fetch filtered results for content list
	 * @access public
	 * @return void
	 */
	public function ajax_filter()
	{
		$area = $this->input->post('f_area');
		$status = $this->input->post('f_status');
		$type = $this->input->post('f_type');

		$post_data = array();

		if ($status == 'live' OR $status == 'draft')
		{
			$post_data['status'] = $status;
		}

		if ($type)
		{
			$post_data['type'] = $type;
		}

		if ($area != 0)
		{
			$post_data['area_id'] = $area;
		}

		$results = $this->members_m->search($post_data);

		//set the layout to false and load the view
		$this->template
			->set_layout(FALSE)
			->set('members', $results)
			->build('admin/tables/members');
	}
	
	public function pick($id=0)
	{
		$q = $this->input->get('term');
		$res = $this->members_m->get_many_by_name($q);
		foreach($res as $m)
		{
			$members[] = array('value'=>$m->title, 'id'=>$m->intID);
		}

		echo json_encode($members);
	}

	public function sccpick($id=0)
	{
		$q = $this->input->get('term');
		$res = $this->members_m->get_many_by_name($q);
		foreach($res as $m)
		{
			$members[] = array('value'=>$m->title, 'id'=>$m->intID);
		}

		echo json_encode($members);
	}


	public function delete($id = 0)
	{
		role_or_die('members', 'delete_member');

		// Delete one
		$ids = ($id) ? array($id) : $this->input->post('action_to');

		// Go through the array of slugs to delete
		if ( ! empty($ids))
		{
			$post_titles = array();
			$deleted_ids = array();
			foreach ($ids as $id)
			{
				// Get the current page so we can grab the id too
				if ($post = $this->members_m->get($id))
				{
					if ($this->members_m->delete($id))
					{
						// Wipe cache for this model, the content has changed
						$this->pyrocache->delete('members_m');
						$post_titles[] = $post->name;
						$deleted_ids[] = $id;
					}
				}
			}

			// Fire an event. We've deleted one or more blog posts.
			Events::trigger('member_deleted', $deleted_ids);
		}

		// Some members have been deleted
		if ( ! empty($post_titles))
		{
			// Only deleting one page
			if (count($post_titles) == 1)
			{
				$this->session->set_flashdata('success', sprintf($this->lang->line('members:delete_success'), $post_titles[0]));
			}
			// Deleting multiple pages
			else
			{
				$this->session->set_flashdata('success', sprintf($this->lang->line('members:mass_delete_success'), implode('", "', $post_titles)));
			}
		}
		// For some reason, none of them were deleted
		else
		{
			$this->session->set_flashdata('notice', lang('members:delete_error'));
		}

		redirect('admin/members');
	}

	public function action()
	{
		switch ($this->input->post('btnAction'))
		{
			case 'delete':
				$this->delete();
				break;

			default:
				redirect('admin/members');
				break;
		}
	}

	function check_dir($dir)
	{
		// check directory
		$fileOK = array();
		$fdir = explode('/', $dir);
		$ddir = '';
		for($i=0; $i<count($fdir); $i++)
		{
			$ddir .= $fdir[$i] . '/';
			if (!is_dir($ddir))
			{
				if (!@mkdir($ddir, 0777)) {
					$fileOK[] = 'not_ok';
				}
				else
				{
					$fileOK[] = 'ok';
				}
			}
			else
			{
				$fileOK[] = 'ok';
			}
		}
		return $fileOK;
	}

	function fix_last_name()
	{
		
	}

}