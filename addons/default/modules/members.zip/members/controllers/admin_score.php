<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Admin_score extends Admin_Controller
{
	protected $section = 'score';

    protected $upload_cfg = array(
        'upload_path'       => UPLOAD_PATH . 'members_score/',
        'allowed_types'		=> 'pdf',
        'max_size'			=> '100000',
        'remove_spaces'		=> TRUE,
        'overwrite'			=> FALSE,
        'encrypt_name'		=> FALSE,
    );

    protected $validation_rules = array(
        array(
            'field' => 'score',
            'label' => 'Score Card File',
            'rules' => 'trim'
        ),
        array(
            'field' => 'member_id',
            'label' => 'Selected Member',
            'rules' => 'trim|required'
        ),
        array(
            'field' => 'member_name',
            'label' => 'Member\'s Name',
            'rules' => 'trim'
        ),
    );

	public function __construct()
	{
		parent::__construct();

		// Load all the required classes
        $this->load->helper(array('html'));
		$this->load->model('members_m');
		$this->load->library('form_validation');
        $this->load->library('pagination');
        $this->config->load('config');
        $this->lang->load(array('members', 'score'));
	}

  public function index()
 	{
 	    $limit = 20;
        $base_where = array('acop_score_card_not_null' => 'null', 'order_by' => 'title', 'order_dir' => 'asc');
        if ($this->input->post('f_keywords')) $base_where['keywords'] = $this->input->post('f_keywords');

        $total_rows = $this->members_m->count_by($base_where);
        $pagination = create_pagination('admin/members/score/index', $total_rows, $limit, 5);

        $base_where['limit'] = array($pagination['limit'], $pagination['offset']);

        // Using this data, get the relevant results
        $members = $this->members_m->get_many_by($base_where);

 		$this->input->is_ajax_request() and $this->template->set_layout(false);


 		$this->template
 			->title($this->module_details['name'])
            ->append_js('admin/filter.js')
            ->set_partial('filters', 'admin/partials/filters')
 			->set('section', $this->section)
            ->set('pagination', $pagination)
 			->set('members', $members);

        $this->input->is_ajax_request()
            ? $this->template->build('admin/score/tables/score')
            : $this->template->build('admin/score/index');
 	}

    /**
     * Retrieve data member with term/keyword given
     * This is the autocomplete feature for score form
     * @param int $id
     */
    public function pick($id = 0)
    {
        $members = [];
        $q = $this->input->get('term');
        $res = $this->members_m->get_many_by(array(
            'keywords' => $q,
            'order_by' => 'name',
            'order_dir' => 'asc',
            'acop_score_card_is_null' => 'null'
        ));
        foreach ($res as $m) {
            $members[] = array('value' => $m->title, 'id' => $m->intID);
        }

        echo json_encode($members);
    }

    public function create($mid=0)
    {
//        role_or_die('members', 'add_score');
        $this->form_validation->set_rules($this->validation_rules);

        $member = new stdClass();

        if ($mid) {
            $member = $this->members_m->get_by('intID', $mid);
            if (!empty($member)) {
                $this->template
                    ->set('member_name', $member->title)
                    ->set('member_id', $member->intID);
            }
        }

        if ($this->form_validation->run()) {
            // check directory exists
            $this->check_dir($this->upload_cfg['upload_path']);
            $this->load->library('upload', $this->upload_cfg);

            $score_card_array = $this->input->post('acop_score_card');
            if (!empty($_FILES['scores']['name'][0]) ) {
                for ($i = 0; $i < count($_FILES['scores']['name']); $i++) {
                    $_FILES['score']['name']     = $_FILES['scores']['name'][$i];
                    $_FILES['score']['type']     = $_FILES['scores']['type'][$i];
                    $_FILES['score']['tmp_name'] = $_FILES['scores']['tmp_name'][$i];
                    $_FILES['score']['error']     = $_FILES['scores']['error'][$i];
                    $_FILES['score']['size']     = $_FILES['scores']['size'][$i];
                    if($this->upload->do_upload('score')) {
                        $uploaded = $this->upload->data();
                        $score_card_array[] = $uploaded['file_name'];
                    } else {
                        // something wrong
                    }
                }
            }

            $acop_score_card = implode(';', $score_card_array);

            $intID = $this->input->post('member_id');
            $input = array(
                'acop_score_card'	            => $acop_score_card,
                'acop_score_card_addDate'	    => now(),
                'acop_score_card_modifiedDate'	=> now(),
            );

            if ($id = $this->members_m->update($intID, $input)) {
                $this->session->set_flashdata(array('success' => sprintf(lang('score:create_success'), $this->input->post('member_name'))));
                Events::trigger('log_create',
                    array(
                        'input' => (array) $input + array ('intID' => $this->input->post('member_id')),
                        'module_name' => $this->module_details['name'],
                        'text' => "User ".$this->current_user->display_name." uploaded Score Card for Member ".$this->input->post('member_name'),
                        'url' => base_url('admin/members/score/edit/'.$this->input->post('member_id')),
                    ));
                ($this->input->post('btnAction') == 'save_exit') ? redirect('admin/members/score') : redirect('admin/members/score/edit/'.$intID);
            } else {
                //$this->session->set_flashdata(array('error' => sprintf(lang('score:create_error'), $this->input->post('member_name'))));
                $this->template->set('error', sprintf(lang('score:create_error'), $this->input->post('member_name')) );
            }

            // Redirect back to the form or main page
        }

        $this->template
            ->set('member', $member)
            ->build('admin/score/form');
    }

    /**
     *
     * @param int $mid
     */
    public function edit($mid=0)
    {
        $member = new stdClass();

        if ($mid) {
            $member = $this->members_m->get_by('intID', $mid);
            if (!empty($member)) {
                $this->template
                    ->set('member_name', $member->title)
                    ->set('member_id', $member->intID);
            }
        }

        if ($this->input->post()) {
            $remove_files = $this->input->post('remove_score');

            // check directory exists
            $this->check_dir($this->upload_cfg['upload_path']);
            $this->load->library('upload', $this->upload_cfg);

            $score_card_array = $this->input->post('acop_score_card');
            if (!empty($_FILES['scores']['name'][0])) {
                for ($i = 0; $i < count($_FILES['scores']['name']); $i++) {
                    $_FILES['score']['name']     = $_FILES['scores']['name'][$i];
                    $_FILES['score']['type']     = $_FILES['scores']['type'][$i];
                    $_FILES['score']['tmp_name'] = $_FILES['scores']['tmp_name'][$i];
                    $_FILES['score']['error']     = $_FILES['scores']['error'][$i];
                    $_FILES['score']['size']     = $_FILES['scores']['size'][$i];
                    if($this->upload->do_upload('score')) {
                        $uploaded = $this->upload->data();
                        $score_card_array[] = $uploaded['file_name'];
                    } else {
                        // something wrong
                    }
                }
            }

            $acop_score_card = implode(';', $score_card_array);

            $intID = $this->input->post('member_id');
            $input = array(
                'acop_score_card'	            => $acop_score_card,
                'acop_score_card_modifiedDate'	=> now(),
            );

            if ($id = $this->members_m->update($intID, $input)) {

                // unlink the deleted file
                $old_card = explode(';', $member->acop_score_card);
                $new_card = $score_card_array;
                $array_diff = array_diff($old_card, $new_card);
                foreach ($array_diff as $replace) {
                    $this->unlinkfile($replace);
                }

                Events::trigger('log_update',
                    array(
                        'input' => (array) $input + array ('intID' => $this->input->post('member_id')),
                        'old_input' => array (
                            'intID' => $this->input->post('member_id'),
                            'acop_score_card' => $member->acop_score_card,
                            'acop_score_card_modifiedDate' => $member->acop_score_card_modifiedDate
                        ),
                        'module_name' => $this->module_details['name'],
                        'text' => "User ".$this->current_user->display_name." updated Score Card for Member ".$this->input->post('member_name'),
                        'url' => base_url('admin/members/score/edit/'.$this->input->post('member_id')),
                    ));

                $this->session->set_flashdata(array('success' => sprintf(lang('score:edit_success'), $this->input->post('member_name'))));
                ($this->input->post('btnAction') == 'save_exit') ? redirect('admin/members/score') : redirect('admin/members/score/edit/'.$intID);
            } else {
                //$this->session->set_flashdata(array('error' => sprintf(lang('score:create_error'), $this->input->post('member_name'))));
                $this->template->set('error', sprintf(lang('score:edit_error'), $this->input->post('member_name')) );
            }

            // Redirect back to the form or main page
        }

        $this->template
            ->set('member', $member)
            ->build('admin/score/form');
    }

    public function delete($mid = 0)
    {
        if ($mid)
        {
            $member = $this->members_m->get_by('intID', $mid);
            if (!empty($member))
            {
                $this->template
                    ->set('member_name', $member->title)
                    ->set('member_id', $member->intID);
            }

            $remove_files = explode(';', $member->acop_score_card);
            $acop_score_card = null;
            foreach ($remove_files as $remove) {
                $this->unlinkfile($remove);
            }

            $intID = $mid;
            $input = array(
                'acop_score_card'	            => $acop_score_card,
                'acop_score_card_modifiedDate'	=> now(),
            );

            if ($id = $this->members_m->update($intID, $input))
            {
                Events::trigger('log_delete',
                    array(
                        'input' => array (
                            'intID' => $mid,
                            'acop_score_card' => $member->acop_score_card,
                            'acop_score_card_modifiedDate' => $member->acop_score_card_modifiedDate,
                            'acop_score_card_addDate' => $member->acop_score_card_addDate
                        ),
                        'module_name' => $this->module_details['name'],
                        'text' => "User ".$this->current_user->display_name." deleted Score Card for Member ".$member->title,
                        'url' => base_url('admin/members/score/edit/'.$mid),
                    ));

                $this->session->set_flashdata(array('success' => sprintf(lang('score:delete_success'), $member->title)));
                redirect('admin/members/score');
            }
            else
            {
                //$this->session->set_flashdata(array('error' => sprintf(lang('score:create_error'), $this->input->post('member_name'))));
                $this->template->set('error', sprintf(lang('score:delete_error'), $member->title));
            }
        }
    }

    function check_dir($dir) {
        // check directory
        $fileOK = array();
        $fdir = explode('/', $dir);
        $ddir = '';
        for($i=0; $i<count($fdir); $i++)
        {
            $ddir .= $fdir[$i] . '/';
            if (!is_dir($ddir))
            {
                if (!@mkdir($ddir, 0777)) {
                    $fileOK[] = 'not_ok';
                }
                else
                {
                    $fileOK[] = 'ok';
                }
            }
            else
            {
                $fileOK[] = 'ok';
            }
        }
        return $fileOK;

    }
    public function unlinkfile($filename) {

        $stat = array();
        // delete the files

        if (file_exists($this->upload_cfg['upload_path'] . '/' . $filename))
        {
            if (!@unlink($this->upload_cfg['upload_path'] . '/' . $filename))
            {
                $stat[] = 'error';
                $msg[] = sprintf(lang('articles_delete_img_error'), $filename);
            }
        }

        if (in_array('error', $stat))
        {
            $status = 'error';
            $message = implode('<br />', $msg);
        }
        else
        {
            $status = 'success';
            $message = sprintf(lang('delete_img_success'), $filename);
        }

        return (array($status, $message));
    }

    public function import_score_card()
    {
            $file = UPLOAD_PATH . 'members_score/temp.csv';
            $handle = fopen($file,"r");
            $data = [];
            $i = 0;
            $error_count = 0;
            $success_count = 0;
            echo '<pre>';
            do {
                if($i > 1) {
                    $intID = $data[5];
                    $member = $this->members_m->get_by('intID', trim($intID));
                    if (!empty($member))
                    {
                        if (file_exists($this->upload_cfg['upload_path'] . '/' . trim($data[1]).'.pdf')) {
                            $input = array(
                                'acop_score_card'	            => trim($data[1]).'.pdf',
                                'acop_score_card_addDate'	    => now(),
                                'acop_score_card_modifiedDate'	=> now(),
                            );

                            if ($id = $this->members_m->update($intID, $input)) {
                                echo 'member_num: ' . $data[1] . ' | intID: ' . $data[5] .' | Success Updated'. PHP_EOL;
                                $success_count++;
                            } else {
                                echo 'member_num: ' . $data[1] . ' | intID: ' . $data[5] .' | Failed Update'. PHP_EOL;
                                $error_count++;
                            }
                        }
                    } else {
                        echo 'member_num: ' . $data[1] . ' | intID: ' . $data[5] .' | Failed Member not found'. PHP_EOL;
                        $error_count++;
                    }
                }
                $i++;
            } while ($data = fgetcsv($handle,1000,",","'"));

            echo 'Total Success: '.$success_count. PHP_EOL;
            echo 'Total Failed: '.$error_count. PHP_EOL;
            echo 'Total data: '.$i. PHP_EOL;
        //loop through the csv file and insert into database

    }
}
