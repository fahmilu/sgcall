<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Admin Page Layouts controller for the Pages module
 *
 * @author Catalyze Dev Team Sept 2014
 * @package addons\default\Modules\pod
 */
 
class Admin_pncassessment_type extends Admin_Controller {
	
	/**
	 * The current active section
	 * @access protected
	 * @var int
	 */
	protected $section = 'pnc_type';
	
	/**
	 * Array that contains the validation rules
	 * @access protected
	 * @var array
	 */
	protected $validation_rules = array(
		array(
			'field' => 'stage',
			'label' => 'lang:pnc:stage_label',
			'rules' => 'trim|required|max_length[100]|callback__check_title'
		),
		array(
			'field' => 'description',
			'label' => 'lang:pnc:description_label',
			'rules' => 'trim|max_length[500]'
		),
		array(
			'field' => 'position',
			'label' => 'lang:pnc:position_label',
			'rules' => 'trim'
		),
	);
	
	/**
	 * The constructor
	 * 
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('pnctype_m');
		$this->lang->load('pnc');
		
		// Load the validation library along with the rules
		$this->load->library('form_validation');
		$this->form_validation->set_rules($this->validation_rules);
	}
	
	/**
	 * Index method, lists all categories
	 * 
	 * @return void
	 */
	public function index()
	{
		$this->pyrocache->delete_all('modules_m');
		
		// Create pagination links
		$total_rows = $this->pnctype_m->count_all();
		$pagination = create_pagination('admin/pncassessment_type/index', $total_rows, NULL, 5);
			
		// Using this data, get the relevant results
		$pnctypes = $this->pnctype_m->order_by('position')->limit($pagination['limit'], $pagination['offset'])->get_all();

		$this->template
			->title($this->module_details['name'], 'P&amp;C Assessment Type')
			->set('count', $total_rows)
			->set('pnctypes', $pnctypes)
			->set('pagination', $pagination)
			->build('admin/pnctype/index');
	}
	
	/**
	 * Create method, creates a new category
	 *
	 * @return void
	 */
	public function create()
	{
		$last_position = $this->pnctype_m->get_last_position();

		// Validate the data
		if ($this->form_validation->run())
		{
			$input = array(
				'position'	=> $this->input->post('position'),
				'stage'		=> $this->input->post('stage'),
				'description'=> $this->input->post('description'),
			);

			if ($id = $this->pnctype_m->insert($input))
			{
				$this->session->set_flashdata('success', sprintf( lang('pnc:type_add_edit_success'), $this->input->post('title')) );
				$this->input->post('btnAction') == 'save' ? redirect('admin/members/pncassessment_type/edit/'.$id) : redirect('admin/members/pncassessment_type');
			}
			else
			{
				$this->session->set_flashdata('error', lang('pnc:type_add_error'));
				redirect('admin/members/pncassessment_type/create');
			}

		}

		$type = new stdClass();
				
		// Loop through each validation rule
		foreach ($this->validation_rules as $rule)
		{
			$type->{$rule['field']} = set_value($rule['field']);
		}
		
		$this->template
			->title($this->module_details['name'], lang('cat_create_title'))
			->set('last_position', $last_position)
			->set('type', $type)
			->build('admin/pnctype/form');	
	}
	
	/**
	 * Edit method, edits an existing category
	 * 
	 * @param int id The ID of the category to edit
	 * @return void
	 */
	public function edit($id = 0)
	{	
		// Get the category
		$type = $this->pnctype_m->get($id);
		
		// ID specified?
		$type or redirect('admin/members/pncassessment_type/index');

		$last_position = $this->pnctype_m->get_last_position();
		
		// Validate the results
		if ($this->form_validation->run())
		{
			$input = array(
				'position'	=> $this->input->post('position'),
				'stage'		=> $this->input->post('stage'),
				'description'=> $this->input->post('description'),
			);

			$this->pnctype_m->update($id, $input)
				? $this->session->set_flashdata('success', sprintf( lang('pnc:type_add_edit_success'), $this->input->post('title')) )
				: $this->session->set_flashdata('error', lang('pnc:type_edit_error'));
			
			$this->input->post('btnAction') == 'save' ? redirect('admin/members/pncassessment_type/edit/'.$id) : redirect('admin/members/pncassessment_type');
		}
		
		// Loop through each rule
		foreach ($this->validation_rules as $rule)
		{
			if (!empty($_POST))
			{
				if ($this->input->post($rule['field']) !== FALSE)
				{
					$category->{$rule['field']} = $this->input->post($rule['field']);
				}
			}
		}

		$this->template
			->title($this->module_details['name'], sprintf(lang('pnc:type_edit_title'), $type->stage))
			->set('last_position', $last_position)
			->set('type', $type)
			->build('admin/pnctype/form');
	}	

	/**
	 * Delete method, deletes an existing category (obvious isn't it?)
	 * 
	 * @param int id The ID of the category to edit
	 * @return void
	 */
	public function delete($id = 0)
	{	
		$id_array = (!empty($id)) ? array($id) : $this->input->post('action_to');
		
		// Delete multiple
		if (!empty($id_array))
		{
			$deleted = 0;
			$to_delete = 0;
			$deleted_ids = array();
			foreach ($id_array as $id)
			{
				if ($this->pnctype_m->delete($id))
				{
					$deleted++;
					$deleted_ids[] = $id;
				}
				else
				{
					$this->session->set_flashdata('error', sprintf(lang('cat_mass_delete_error'), $id));
				}
				$to_delete++;
			}
			
			if ( $deleted > 0 )
			{
				$this->session->set_flashdata('success', sprintf(lang('cat_mass_delete_success'), $deleted, $to_delete));
			}
			
			// Fire an event. One or more categories have been deleted.
			Events::trigger('articles_category_deleted', $deleted_ids);
		}		
		else
		{
			$this->session->set_flashdata('error', lang('cat_no_select_error'));
		}
		
		redirect('admin/articles/categories/index');
	}
		
	/**
	 * Callback method that checks the title of the category
	 * 
	 * @param string title The title to check
	 * @return bool
	 */
	public function _check_title($title = '')
	{
		$id = $this->input->post('id');
		if ($this->pnctype_m->check_title($title,$id))
		{
			$this->form_validation->set_message('_check_title', sprintf(lang('cat_already_exist_error'), $title));
			return FALSE;
		}

		return TRUE;
	}
	
	/**
	 * Create method, creates a new category via ajax
	 * 
	 * @return void
	 */
	public function create_ajax()
	{
		$type = new stdClass();
		// Loop through each validation rule
		foreach ($this->validation_rules as $rule)
		{
			$type->{$rule['field']} = set_value($rule['field']);
		}
		$this->method = 'create';

		$last_position = $this->pnctype_m->get_last_position();

		$data = array(
			'method' => 'create',
			'type' => $type,
			'last_position' => $last_position,
		);

		if ($this->form_validation->run())
		{
			$input = array(
				'position'	=> $this->input->post('position'),
				'stage'		=> $this->input->post('stage'),
				'description'=> $this->input->post('description'),
			);
			$id = $this->pnctype_m->insert($input);
			
			if ($id > 0)
			{
				$message = sprintf(lang('pnc:type_add_edit_success'), $this->input->post('stage', TRUE));
			}
			else
			{
				$message = lang('pnc:type_add_error');
			}

			return $this->template->build_json(array(
				'message'		=> $message,
				'stage'			=> $this->input->post('stage'),
				'type_id'		=> $id,
				'status'		=> 'ok'
			));
		}
		else
		{
			// Render the view
			$form = $this->load->view('admin/pnctype/form-ajax', $data, TRUE);

			if ($errors = validation_errors())
			{
				return $this->template->build_json(array(
					'message'	=> '<div class="alert error animated fadeIn">'.$errors.'</div>',
					'status'	=> 'error',
					'form'		=> $form
				));
			}

			echo $form;
		}
	}
}