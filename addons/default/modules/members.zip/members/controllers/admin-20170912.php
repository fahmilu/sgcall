<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends Admin_Controller
{
	protected $section = 'members';

	protected $region_country;

	protected $validation_rules = array(
			array(
				'field' => 'type',
				'label' => 'Membership type',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'category',
				'label' => "What is your organisation's category? *",
				'rules' => 'trim',
			),
			array(
				'field' => 'profession',
				'label' => "Organisation's sub-category",
				'rules' => 'trim',
			),
			array(
				'field' => 'org_name',
				'label' => "Organisation's name",
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'address',
				'label' => 'Street name and number *',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'address_city',
				'label' => 'City',
				'rules' => 'trim|htmlspecialchars', //|required
			),
			array(
				'field' => 'address_state',
				'label' => 'State/Province',
				'rules' => 'trim|htmlspecialchars', //|required
			),
			array(
				'field' => 'address_zip',
				'label' => 'Postal/Zip Code',
				'rules' => 'trim|htmlspecialchars', //|required
			),
			array(
				'field' => 'country',
				'label' => 'Country',
				'rules' => 'trim', //|required
			),
			array(
				'field' => 'telephone',
				'label' => 'Telephone',
				'rules' => 'trim', //|required
			),
			array(
				'field' => 'fax',
				'label' => 'Fax',
				'rules' => 'trim',
			),
			array(
				'field' => 'email',
				'label' => 'Email *',
				'rules' => 'trim|valid_email', //|required',
			),
			array(
				'field' => 'website',
				'label' => 'Website ',
				'rules' => 'trim',
			),
			array(
				'field' => 'registration_number',
				'label' => 'What is your registration number? *',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'parent_company',
				'label' => 'Are you a parent company? ',
				'rules' => 'trim',
			),
			array(
				'field' => 'primary_market_ops',
				'label' => 'Primary market operations ',
				'rules' => 'trim',
			),
			array(
				'field' => 'other_market_ops',
				'label' => 'Other market operations ',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'profile',
				'label' => 'Tell us about your organisation ',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'name_p',
				'label' => 'Full name *',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'name_last_p',
				'label' => 'Primary last name',
				'rules' => 'trim|required|htmlspecialchars',
			),
			array(
				'field' => 'designation_p',
				'label' => 'designation_p',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'telephone_p',
				'label' => 'telephone_p',
				'rules' => 'trim',
			),
			array(
				'field' => 'fax_p',
				'label' => 'fax_p',
				'rules' => 'trim',
			),
			array(
				'field' => 'email_p',
				'label' => 'email_p',
				'rules' => 'trim|valid_email',
			),
			array(
				'field' => 'country_p',
				'label' => 'Country',
				'rules' => 'trim',
			),
			array(
				'field' => 'category_p',
				'label' => 'Category',
				'rules' => 'trim',
			),
			array(
				'field' => 'name_s',
				'label' => 'name_s',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'name_last_s',
				'label' => 'Secondary Contact last name',
				'rules' => 'trim|required|htmlspecialchars',
			),
			array(
				'field' => 'designation_s',
				'label' => 'designation_s',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'telephone_s',
				'label' => 'telephone_s',
				'rules' => 'trim',
			),
			array(
				'field' => 'fax_s',
				'label' => 'fax_s',
				'rules' => 'trim',
			),
			array(
				'field' => 'email_s',
				'label' => 'email_s',
				'rules' => 'trim|valid_email', //|required',
			),
			array(
				'field' => 'country_s',
				'label' => 'Country',
				'rules' => 'trim',
			),
			array(
				'field' => 'category_s',
				'label' => 'Category',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_person',
				'label' => 'Contact person first name',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'contact_lname',
				'label' => 'Contact person last name',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'designation',
				'label' => 'designation',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'contact_tel',
				'label' => 'contact_tel',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_fax',
				'label' => 'contact_fax',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_email',
				'label' => 'contact_email',
				'rules' => 'trim|valid_email',
			),
			array(
				'field' => 'country_c',
				'label' => 'Country',
				'rules' => 'trim',
			),
			array(
				'field' => 'category_c',
				'label' => 'Category',
				'rules' => 'trim',
			),
			array(
				'field' => 'name_f',
				'label' => 'name_f',
				'rules' => 'trim|htmlspecialchars', //|required
			),
			array(
				'field' => 'name_last_f',
				'label' => 'Finance Contact last name',
				'rules' => 'trim|htmlspecialchars|required', //|required
			),
			array(
				'field' => 'designation_f',
				'label' => 'designation_f',
				'rules' => 'trim|htmlspecialchars', //|required
			),
			array(
				'field' => 'telephone_f',
				'label' => 'telephone_f',
				'rules' => 'trim', //|required
			),
			array(
				'field' => 'fax_f',
				'label' => 'fax_f',
				'rules' => 'trim',
			),
			array(
				'field' => 'email_f',
				'label' => 'email_f',
				'rules' => 'trim|valid_email', //|required
			),
			array(
				'field' => 'country_f',
				'label' => 'Country',
				'rules' => 'trim',
			),
			array(
				'field' => 'category_f',
				'label' => 'Category',
				'rules' => 'trim',
			),
			array(
				'field' => 'q1',
				'label' => 'q1',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'q2',
				'label' => 'q2',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'q3',
				'label' => 'q3',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'q4',
				'label' => 'q4',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'q_usage',
				'label' => 'q_usage',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'name_a',
				'label' => 'name_a',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'email_a',
				'label' => 'Application Email',
				'rules' => 'trim',
				//'rules' => 'trim|valid_email|required',
			),

			array(
				'field' => 'designation_a',
				'label' => 'designation_a',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'date_2',
				'label' => 'date_2',
				'rules' => 'trim', //|required
			),
			array(
				'field' => 'file',
				'label' => 'file',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'grower_file',
				'label' => 'grower file',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'file_certificates',
				'label' => 'file certificates',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'uploaded_files_cert',
				'label'	=> 'uploaded_files_cert',
				'rules'	=> 'trim',
			),
			array(
				'field' => 'logo',
				'label' => 'logo',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'upload_logo',
				'label' => 'upload_logo',
				'rules' => 'trim|htmlspecialchars', //|required
			),
			array(
				'field' => 'org_subcategory',
				'label' => 'Organisation Subcategory',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_telephone',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_fax',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_contact_tel',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_contact_fax',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_tel_p',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_fax_p',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_tel_s',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_fax_s',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_tel_f',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_fax_f',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'expiry_date',
				'label' => 'Expiry Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'approved_date',
				'label' => 'Approved Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'status',
				'label' => 'Membership Status',
				'rules' => 'trim',
			),
			array(
				'field' => 'member_num',
				'label' => 'Membership Number',
				'rules' => 'trim',
			),
			array(
				'field' => 'remarks',
				'label' => 'Remarks',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'newsletter',
				'label' => 'Newsletter Subscription',
				'rules' => 'trim',
			),
			array(
				'field' => 'applied_date',
				'label' => 'Applied Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'public_comment_start',
				'label' => 'Public Comment Start Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'public_comment_start',
				'label' => 'Public Comment Start Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'admin_comment',
				'label' => 'Admin Comment',
				'rules' => 'trim',
			),
			array(
				'field' => 'sub_category_other',
				'label' => 'Other Sub-category',
				'rules' => 'trim',
			),
			array(
				'field' => 'formerly_known_as',
				'label' => 'Formerly Known As',
				'rules' => 'trim',
			),
			array(
				'field' => 'complete_document_received',
				'label' => 'Complete Document Received',
				'rules' => 'trim',
			),
			array(
				'field' => 'suspended_date',
				'label' => 'Suspended Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'terminated_resigned_on',
				'label' => 'Termination Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'rev_notification',
				'label' => 'REV Notification',
				'rules' => 'trim',
			),
			array(
				'field' => 'acknowledgement',
				'label' => 'Acknowledgement',
				'rules' => 'trim',
			),
			array(
				'field' => 'acknowledgement',
				'label' => 'Acknowledgement',
				'rules' => 'trim',
			),
			array(
				'field' => 'account_currency',
				'label' => 'Account Currency',
				'rules' => 'trim',
			),
			array(
				'field' => 'total_amount_due',
				'label' => 'Total Amount Due',
				'rules' => 'trim',
			),
			array(
				'field' => 'total_amount_due',
				'label' => 'Total Amount Due',
				'rules' => 'trim',
			),
			array(
				'field' => 'proforma_invoice_date',
				'label' => 'Proforma Invoice Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'payment_status',
				'label' => 'Payment Status',
				'rules' => 'trim',
			),
			array(
				'field' => 'payment_received_on',
				'label' => 'Payment Received Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'account_sf_id',
				'label' => 'Account SF ID',
				'rules' => 'trim',
			),
			array(
				'field' => 'application_sf_id',
				'label' => 'Application SF ID',
				'rules' => 'trim',
			),
			array(
				'field' => 'primary_sf_id',
				'label' => 'Primary Contact SF ID',
				'rules' => 'trim',
			),
			array(
				'field' => 'secondary_sf_id',
				'label' => 'Secondary Contact SF ID',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_sf_id',
				'label' => 'Contact Person SF ID',
				'rules' => 'trim',
			),
			array(
				'field' => 'finance_sf_id',
				'label' => 'Finance Contact SF ID',
				'rules' => 'trim',
			),
		);

	protected $country_arrays = array("Afghanistan","Åland Islands","Albania","Algeria","American Samoa","Andorra","Angola","Anguilla","Antarctica","Antigua And Barbuda","Argentina","Armenia","Aruba","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia, Plurinational State Of","Bonaire, Sint Eustatius And Saba","Bosnia And Herzegovina","Botswana","Bouvet Island","Brazil","British Indian Ocean Territory","Brunei Darussalam","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Canada","Cape Verde","Cayman Islands","Central African Republic","Chad","Chile","China","Christmas Island","Cocos (keeling) Islands","Colombia","Comoros","Congo","Congo, The Democratic Republic Of The","Cook Islands","Costa Rica","Côte D'ivoire","Croatia","Cuba","Curaçao","Cyprus","Czech Republic","Denmark","Djibouti","Dominica","Dominican Republic","Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia","Falkland Islands (malvinas)","Faroe Islands","Fiji","Finland","France","French Guiana","French Polynesia","French Southern Territories","Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guadeloupe","Guam","Guatemala","Guernsey","Guinea","Guinea-bissau","Guyana","Haiti","Heard Island And Mcdonald Islands","Holy See (vatican City State)","Honduras","Hong Kong","Hungary","Iceland","India","Indonesia","Iran, Islamic Republic Of","Iraq","Ireland","Isle Of Man","Israel","Italy","Jamaica","Japan","Jersey","Jordan","Kazakhstan","Kenya","Kiribati","North Korea","South Korea","Kuwait","Kyrgyzstan","Lao People's Democratic Republic","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg","Macao","Macedonia","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Martinique","Mauritania","Mauritius","Mayotte","Mexico","Micronesia, Federated States Of","Moldova, Republic Of","Monaco","Mongolia","Montenegro","Montserrat","Morocco","Mozambique","Myanmar","Namibia","Nauru","Nepal","Netherlands","New Caledonia","New Zealand","Nicaragua","Niger","Nigeria","Niue","Norfolk Island","Northern Mariana Islands","Norway","Oman","Pakistan","Palau","Palestinian Territory, Occupied","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Pitcairn","Poland","Portugal","Puerto Rico","Qatar","Réunion","Romania","Russian Federation","Rwanda","Saint Barthélemy","Saint Helena, Ascension And Tristan Da Cunha","Saint Kitts And Nevis","Saint Lucia","Saint Martin (french Part)","Saint Pierre And Miquelon","Saint Vincent And The Grenadines","Samoa","San Marino","Sao Tome And Principe","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Sint Maarten (dutch Part)","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","South Georgia And The South Sandwich Islands","South Sudan","Spain","Sri Lanka","Sudan","Suriname","Svalbard And Jan Mayen","Swaziland","Sweden","Switzerland","Syrian Arab Republic","Taiwan","Tajikistan","Tanzania, United Republic Of","Thailand","Timor-leste","Togo","Tokelau","Tonga","Trinidad And Tobago","Tunisia","Turkey","Turkmenistan","Turks And Caicos Islands","Tuvalu","Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","United States Minor Outlying Islands","Uruguay","Uzbekistan","Vanuatu","Venezuela","Vietnam","Virgin Islands, British","Virgin Islands, U.S.","Wallis And Futuna","Western Sahara","Yemen","Zambia","Zimbabwe",);

	protected $config_upload = array();

	protected $type = array();
	protected $categories = array();
	protected $member_categories = array();
	protected $subcategories = array();
	protected $types_reversed = array();
	protected $member_types = array();
	protected $subcat_growers = array();
	protected $subcat_others = array();
	protected $subcat_popt = array();
	protected $membership_status = array();

	protected $thumb_width = 150;
	protected $thumb_height = 250;
	protected $logo_width = 600;
	protected $logo_height = 400;

	public function __construct()
	{
		parent::__construct();

		$this->db->set_dbprefix('default_');

		$this->load->model(array('members_m','subsidiaries_m'));
		$this->lang->load('members');
		$this->load->helper('filename');

		$this->config->load('config');

		$this->categories = array(
			'om' => array(
				'Banks and Investors',
				'Consumer Goods Manufacturers',
				'Environmental or Nature Conservation Organisations (Non Governmental Organisations)',
				'Oil Palm Growers',
				'Palm Oil Processors and/or Traders',
				'Retailers',
				'Social or Development Organisations (Non Governmental Organisations)',
			),
			'am' => array(
				'Associations',
				'Individuals',
				'Organisations'
			),
			'asc'=> array(
				//'Organisations',
				'Supply Chain Associate',
				'Supply Chain Group Manager'
			)
		);
		$this->member_categories = array(
				'Banks and Investors'=>'Banks and Investors',
				'Consumer Goods Manufacturers'=>'Consumer Goods Manufacturers',
				'Environmental or Nature Conservation Organisations (Non Governmental Organisations)'=>'Environmental or Nature Conservation Organisations (Non Governmental Organisations)',
				'Oil Palm Growers'=>'Oil Palm Growers',
				'Palm Oil Processors and/or Traders'=>'Palm Oil Processors and/or Traders',
				'Retailers'=>'Retailers',
				'Social or Development Organisations (Non Governmental Organisations)'=>'Social or Development Organisations (Non Governmental Organisations)',
				'Individuals'=>'Individuals',
				'Organisations'=>'Organisations',
				'Supply Chain Associate'=>'Supply Chain Associate',
				'Supply Chain Group Manager'=>'Supply Chain Group Manager',
		);

		$this->subcategories = array(
			'Oil Palm Growers' => array(
				'SmallGrower',
				'Smallholder Group Manager'
			),
			'Consumer Goods Manufacturers' => array(
				'Refinery, Edible oils and Food ingredients processors',
				'Only Trading, Logistics and Distributions',
				'Power, Energy and Bio-fuel',
				'Chemicals, Surfactants, and Non-Food ingredients processors',
				'Across the POSC (Plantation, Mill Refining, Trading, Manufacturing & Retailing)',
				'Others'
			),
			'Palm Oil Processors and/or Traders' => array(
				'Refinery, Edible oils and Food ingredients processors',
				'Only Trading, Logistics and Distributions',
				'Power, Energy and Bio-fuel',
				'Chemicals, Surfactants, and Non-Food ingredients processors',
				'Across the POSC (Plantation, Mill Refining, Trading, Manufacturing & Retailing)',
				'Others'
			),
			'Environmental or Nature Conservation Organisations (Non Governmental Organisations)' => array(
				"NGO's"
			),
			'Social or Development Organisations (Non Governmental Organisations)' => array(
				"NGO's"
			),
			'Individuals' => array(
				"Refinery, Edible oils and Food ingeredients processors",
				"Only Trading, Logistics and Distributions",
				"Power, Energy and Bio-fuel",
				"Chemicals, Surfactants, and Non-Food ingredients processors",
				"Across the POSC (Plantation, Mill Refining, Trading, Manufacturing & Retailing)",
				"Others"
			),
			'Supply Chain Associate' => array(
				"Refinery, Edible oils and Food ingeredients processors",
				"Only Trading, Logistics and Distributions",
				"Power, Energy and Bio-fuel",
				"Chemicals, Surfactants, and Non-Food ingredients processors",
				"Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)",
				"Others"
			),
			'Organisations' => array(
				"Refinery, Edible oils and Food ingeredients processors",
				"Only Trading, Logistics and Distributions",
				"Power, Energy and Bio-fuel",
				"Chemicals, Surfactants, and Non-Food ingredients processors",
				"Across the POSC (Plantation, Mill Refining, Trading, Manufacturing & Retailing)",
				"Others"
			),
		);

/*
	    $this->types_reversed = array(
	      ''=>'Select type',
	      'Ordinary Members'=>'om',
	      'Affiliate Members'=>'am',
	      'Associate'=>'asc',
	    );

	    $this->types = array(
	      ''=>'Select type',
	      'om'=>'Ordinary Members',
	      'am'=>'Affiliate Members',
	      'asc'=>'Associate',
	    );

	    $this->types_sf = array(
	      ''=>'Select type',
	      'Ordinary'=>'Ordinary Members',
	      'Affiliate'=>'Affiliate Members',
	      'Supply Chain'=>'Supply Chain Associate',
	    );

	    $this->member_types = array(
	      ''=>'Select type',
	      'Ordinary Members'=>'Ordinary Members',
	      'Affiliate Members'=>'Affiliate Members',
	      'Supply Chain Associate'=>'Supply Chain Associate',
	    );
*/
	    $this->types_reversed = array(
	      ''=>'Select type',
	      'Ordinary'=>'om',
	      'Affiliate'=>'am',
	      'Associate'=>'asc',
	    );

	    $this->types = array(
	      ''=>'Select type',
	      'om'=>'Ordinary',
	      'am'=>'Affiliate',
	      'asc'=>'Associate',
	    );

	    $this->types_sf = array(
	      ''=>'Select type',
	      'Ordinary'=>'Ordinary',
	      'Affiliate'=>'Affiliate',
	      'Associate'=>'Associate',
	    );

	    $this->member_types = array(
	      ''=>'Select type',
	      'Ordinary'=>'Ordinary',
	      'Affiliate'=>'Affiliate',
	      'Associate'=>'Associate',
	    );


		$this->subcat_growers = array(
			'Smallholder Group Manager', 
			'SmallGrower'
		);

		$this->subcat_others = array(
			''=>'Select subcategory',
			'Refinery, Edible oils and Food ingredients processors',
			'Only Trading, Logistics and Distributions',
			'Power, Energy and Bio-fuel',
			'Chemicals, Surfactants, and Non-Food ingredients processors',
			'Across the POSC (Plantation, Mill Refining, Trading, Manufacturing & Retailing)'
		);
		
		$this->subcat_popt = array(
			''=>'Select subcategory',
			'Refinery, Edible oils and Food ingredients processors',
			'Only Trading, Logistics and Distributions',
			'Power, Energy and Bio-fuel',
			'Chemicals, Surfactants, and Non-Food ingredients processors',
			'Across the POSC (Plantation, Mill Refining, Trading, Manufacturing & Retailing)',
			'Others'
		);

		$this->membership_status = array(
			''=>'Select status',
			'Applied'	=> 'Applied',
			'Call for Comment'	=> 'Call for Comment',
			'Due Diligence'		=> 'Due Diligence',
			'Invoicing'		=> 'Invoicing',
			'Pending'	=> 'Pending',
			'Inactive'	=> 'Inactive',
			'Cancelled'	=> 'Cancelled',
			'Accepted'	=> 'Accepted',
			'Active'	=> 'Active',
			'Suspended'	=> 'Suspended',
			'Terminated'=> 'Terminated',
			'Withdrawn' => 'Withdrawn',
			'Resigned'	=> 'Resigned',
			'Deleted'	=> 'Deleted',
			// these two are used only by CMS
			'Approved'	=> 'Approved',
			'Draft'		=> 'Draft',
		);

		$count = $this->members_m->count_all();


		$this->config_upload = array(
			'upload_path' 	=> UPLOAD_PATH . 'memberlogos',
			'allowed_types' => 'gif|jpg|png|pdf',
			'max_size' 		=> '20000',
			'remove_spaces'		=> TRUE,
			'overwrite'			=> FALSE,
			'encrypt_name'		=> FALSE,
		);

		// subsidiaries types:
		$subsidiary_types = array(
			'subsidiary' => 'Subsidiary',
			'management_unit' => 'Management Unit',
			'supply_chain_group_manager' => 'Supply Chain Group Manager',
			'other' => 'Other',
		);	

		// subsidiaries nature of business:
		$subsidiary_nature_of_business = array(
			'Consumer Goods Manufacturers' => 'Consumer Goods Manufacturers',
			'Growers' => 'Growers',
			'Processors and Traders' => 'Processors and Traders',
			'Retailers' => 'Retailers',
		);	

        $this->region_country = $this->config->item('region_country');

		$this->country_arrays = $this->config->item('country_arrays');

		foreach($this->country_arrays as $c)
		{
			$countries[$c] = $c;
		}


        //new country list
        $this->country_list = $this->config->item('country_list');

		//new country list from http://www.countries-list.info/
//        $new_country_arrays = array();
//		$country_list = $this->country_list;
//        array_walk_recursive($country_list, function($a) use (&$new_country_arrays) { $new_country_arrays[] = $a; });
//        $this->new_country_arrays = array_combine($new_country_arrays, $new_country_arrays);
//        ksort($this->new_country_arrays);

        //new country list from https://unstats.un.org/unsd/methodology/m49/
        $this->country_arrays_un = $this->config->item('countries_un');

        $countries_un = array_combine(array_keys($this->country_arrays_un), array_keys($this->country_arrays_un));
        ksort($countries_un);

		$this->template
			->set('region_country', $this->region_country)
			->set('country_arrays', $countries)
			->set('new_country_arrays', $countries_un)
			->set('subsidiary_types', $subsidiary_types)
			->set('subsidiary_nature_of_business', $subsidiary_nature_of_business)
			->set('count', $count)
			->set('member_categories', $this->member_categories)
			->set('categories', $this->categories)
			->set('member_types', $this->member_types)
			->set('types_sf', $this->types_sf)
			->set('types', $this->types)
			->set('types_reversed', $this->types_reversed)
			->set('member_subcategories', $this->subcategories)
			->set('membership_status', $this->membership_status)
			->set('subcat_growers', $this->subcat_growers)
			->set('subcat_others', $this->subcat_others)
			->set('subcat_popt', $this->subcat_popt);
	}

	function __destruct()
	{
		$this->db->set_dbprefix(SITE_REF.'_');
	}

	public function index()
	{
//$this->output->enable_profiler(true);
		//set the base/default where clause
		$base_where = array('status' => 'all');

		//add post values to base_where if f_module is posted
		//$base_where = $this->input->post('f_area') ? $base_where + array('area' => $this->input->post('f_area')) : $base_where;

		$base_where['status'] = $this->input->post('f_status') ? $this->input->post('f_status') : $base_where['status'];

		$base_where['type'] = $this->input->post('f_type') ? $this->input->post('f_type') : NULL;
		$base_where['category'] = $this->input->post('f_category') ? $this->input->post('f_category') : NULL;
		//$base_where['keywords'] = $this->input->post('f_keywords') ? htmlspecialchars($this->input->post('f_keywords'), ENT_QUOTES, "UTF-8") : NULL;
		$base_where['keywords'] = $this->input->post('f_keywords') ? str_ireplace("'", "%", $this->input->post('f_keywords')) : NULL;

		// Create pagination links
		$total_rows = $this->members_m->count_by($base_where);
		$pagination = create_pagination('admin/members/index', $total_rows);

		$base_where['limit'] = array($pagination['limit'], $pagination['offset']);

		// Using this data, get the relevant results
		$members = $this->members_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);

		//do we need to unset the layout because the request is ajax?
		$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

		$this->template
			->title($this->module_details['name'])
			->append_js('admin/filter.js')
			->set('pagination', $pagination)
			->set('members', $members);

		$this->input->is_ajax_request() ? $this->template->build('admin/tables/members') : $this->template->build('admin/index');
	}

	public function editXY($id=0)
	{
echo "\$id: $id<br />\n";
		role_or_die('members', 'edit_member');

		//$membershipapplication = $this->members_m->get_by('intID', $id);
		$membershipapplication = $this->members_m->get($id);
		$membersapp = new stdClass();



		$save = false;
		if ($this->input->post('btnSave'))
		{
			$save = true;
		}

		if ($this->input->post('category') == 'Oil Palm Growers')
		{
			$this->validation_rules['primary_market_ops'] = array(
				'field' => 'primary_market_ops',
				'label' => "Primary Market Operation",
				'rules' => 'trim|required',
			);
			$this->validation_rules['other_market_ops'] = array(
				'field' => 'other_market_ops',
				'label' => "Other Market Operation",
				'rules' => 'trim|required',
			);

			$membershipapplication->category = $this->input->post('category');
		}

		if ($this->input->post('type'))
		{
			$membershipapplication->type = $this->input->post('type');
		}
		
		// check if member has saved session
		$m = $this->members_m->get_by('MemberID_2', $this->current_user->id);
		if (!empty($m))
		{
			if ($m->status == 'Pending')
			{
				redirect('members/logout?u=members/pleasewait');
			}
			$membershipapplication = $m;
		}
		else
		{
			if (empty($membershipapplication->category))
				redirect('members/selecttype');
			$membershipapplication->intID = 0;
		}

		$subsidiaries = $this->input->post('sub_company');
		$sub_company = array();
		if (!empty($subsidiaries))
		{
			foreach($subsidiaries['name'] as $k=>$v)
			{
				if ($v)
				{
					$sub_company[$k]['name'] = $v;
					$sub_company[$k]['id'] = $subsidiaries['id'][$k];
				}
			}
			$subsidiary = serialize($sub_company);
		}
		else
		{
			$subsidiary = !empty($membershipapplication->sub_company) ? $membershipapplication->sub_company : serialize(NULL);
		}

		$this->check_dir($this->config_upload['upload_path']);
		$this->load->library('upload', $this->config_upload);
		
		if(!empty($_FILES['logo']['name'])){
		
			if(!$this->upload->do_upload('logo')){ 
				
			}
			else{
				$filelogo_array = $this->upload->data();
				$filelogo = $filelogo_array['file_name'];
			}
		}
		else{
			if ($_POST)
				$filelogo = $this->input->post('upload_logo');
			else
				$filelogo = isset($membershipapplication->logo) ? $membershipapplication->logo : '';
		}

		if (!empty($_FILES['file_certificates']['name'][0]))
		{
			$file_certificates = array();
			if ($this->input->post('uploaded_files_cert'))
			{
				$file_certificates = explode(',', $this->input->post('uploaded_files_cert'));
			}
			if($this->upload->do_multi_upload("file_certificates"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();

				foreach($file_uploaded as $files)
				{
					$file_certificates[] = $files['file_name'];
				}
				
				$cert_file_m = implode(',', $file_certificates);
			}
		}
		else{
			if ($_POST)
				$cert_file_m = $this->input->post('uploaded_files_cert');
			else
				$cert_file_m = isset($membershipapplication->file_certificates) ? $membershipapplication->file_certificates : '';
		}

		// additional files
		if (!empty($_FILES['file_additionals']['name'][0]))
		{
			$addfiles = array();
			if ($this->input->post('uploaded_file_additionals'))
			{
				$addfiles = explode(',', $this->input->post('uploaded_file_additionals'));
			}
			if($this->upload->do_multi_upload("file_additionals"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();

				foreach($file_uploaded as $files)
				{
					$addfiles[] = $files['file_name'];
				}
				
				$file_additionals = implode(',', $addfiles);
			}
		}
		else{
			if ($_POST)
				$file_additionals = $this->input->post('uploaded_file_additionals');
			else
				$file_additionals = isset($membershipapplication->file_additionals) ? $membershipapplication->file_additionals : '';
		}

		// smallholder group manager files
		if (!empty($_FILES['file_sh_group_manager']['name'][0]))
		{
			$shfiles = array();
			if ($this->input->post('uploaded_file_sh_group_manager'))
			{
				$shfiles = explode(',', $this->input->post('uploaded_file_sh_group_manager'));
			}

			if($this->upload->do_multi_upload("file_sh_group_manager"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();
				foreach($file_uploaded as $files)
				{
					$shfiles[] = $files['file_name'];
				}
					
				$file_sh_group_manager = implode(',', $shfiles);
			}
		}
		else{
			if ($_POST)
				$file_sh_group_manager = $this->input->post('uploaded_file_sh_group_manager');
			else
				$file_sh_group_manager = isset($membershipapplication->file_sh_group_manager) ? $membershipapplication->file_sh_group_manager : '';
		}

//echo "\$cert_file_m: $cert_file_m<br />";
		if ($this->input->post('remove_uploaded_cert'))
		{
			$forremoveimg = explode(',',$cert_file_m);
			$remove_uploaded_cert = $this->input->post('remove_uploaded_cert');
			foreach($remove_uploaded_cert as $r)
			{

				if (($key = array_search($r, $forremoveimg)) !== false) {
//echo " -- removing file... <br />";
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg[$key]);
					}
					else
					{
						unset($forremoveimg[$key]);
						$this->session->set_flashdata('notice', 'Error deleting file '.$r);
					}
				}
			}
			$cert_file_m = implode(',', $forremoveimg);
		}

/*
echo "\$cert_file_m: $cert_file_m<br />";
exit;
*/
		if (!empty($_FILES['file']['name'][0]))
		{
			if($this->upload->do_multi_upload("file"))
				{
					$file = array();
					$file_uploaded = $this->upload->get_multi_upload_data();
					if ($this->input->post('grower_file'))
					{
						$file = explode(',', $this->input->post('grower_file'));
					}

					foreach($file_uploaded as $files)
					{
						$file[] = $files['file_name'];
					}
					
					$file_grower_m = implode(',', $file);
				}
		}
		else{
			if ($_POST)
				$file_grower_m = $this->input->post('grower_file');
			else
				$file_grower_m = isset($membershipapplication->file) ? $membershipapplication->file : '';
		}
		
		$forremoveimg_grower = explode(',',$file_grower_m);
		if ($this->input->post('remove_uploaded_grower'))
		{
			$remove_uploaded_grower = $this->input->post('remove_uploaded_grower');
			foreach($remove_uploaded_grower as $r)
			{
				
				if (($key = array_search($r, $forremoveimg_grower)) !== false) {
	
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg_grower[$key]);
					}
					else
					{
						unset($forremoveimg_grower[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$file = implode(',', $forremoveimg_grower);
		}

		$primary_name = $this->input->post('name_p');
		$primary_email = $this->input->post('email_p');
		$primary_designation = $this->input->post('designation_p');

		$secondary_name = $this->input->post('name_s');
		$secondary_email = $this->input->post('email_s');
		$secondary_designation = $this->input->post('designation_s');

		$this->validation_rules['primary_name'] = array(
			'field' => 'name_p',
			'label' => 'Primary Nomination Full name',
			'rules' => 'trim|required|callback__check_use['.$secondary_name.']',
		);
		$this->validation_rules['secondary_name'] = array(
			'field' => 'name_s',
			'label' => 'Secondary Nomination Full Name',
			'rules' => 'trim|required|callback__check_use['.$primary_name.']',
		);

		$this->validation_rules['primary_email'] = array(
			'field' => 'email_p',
			'label' => 'Primary Nomination Email',
			'rules' => 'trim|required|valid_email|callback__check_use['.$secondary_email.']',
		);

		$this->validation_rules['secondary_email'] = array(
			'field' => 'email_s',
			'label' => 'Secondary Nomination Email',
			'rules' => 'trim|required|valid_email|callback__check_use['.$primary_email.']',
		);
		
		$this->validation_rules['primary_designation'] = array(
			'field' => 'designation_p',
			'label' => 'Primary Nomination Position',
			'rules' => 'trim|required|callback__check_use['.$secondary_designation.']',
		);

		$this->validation_rules['secondary_designation'] = array(
			'field' => 'designation_s',
			'label' => 'Secondary Nomination Position',
			'rules' => 'trim|required|callback__check_use['.$primary_designation.']',
		);

		if ($membershipapplication->category == 'Consumer Goods Manufacturers' OR $membershipapplication->category == 'Palm Oil Processors and/or Traders')
		{
			$this->validation_rules['sub_category'] = array(
				'field' => 'profession',
				'label' => "Organisation's sub-category",
				'rules' => 'trim|required',
			);
		}

		$validated = false;
		if ($save && $this->input->post('btnSave'))
		{
			$validated = true; //$this->form_validation->run();
		}
		elseif ($this->input->post('btnSubmit'))
		{
			$this->form_validation->set_rules($this->validation_rules);
			$validated = $this->form_validation->run();
		}

		if ($this->input->post('applied_date'))
		{
			$a_date = explode('/', $this->input->post('applied_date'));
			$applied_year = $a_date[2];
			$applied_month = $a_date[1];
			$applied_day = $a_date[0];
			$applied_date = mktime(0, 0, 0, $applied_month, $applied_day, $applied_year);
		}
		else
		{
			$applied_date = isset($membershipapplication->applied_date) ? $membershipapplication->applied_date : 0;
		}
//		$applied_date = strtotime(sprintf('%s $s:$s', $this->input->post('applied_date'), date('H'), date('i')));

		if($validated)
		{
			$pcompany = $this->input->post('parent_company');
			$mtype = $this->input->post('type');
			if ($pcompany == 'none') $pcompany = null;
			$input = array(
				'title' 	=> $this->input->post('title'),
				'type' 		=> $mtype,
				'category' 	=> $this->input->post('category'),
				'name' 		=> $this->input->post('org_name'),
				'address' 	=> $this->input->post('address'),
				'address_city' 	=> $this->input->post('address_city'),
				'address_state' => $this->input->post('address_state'),
				'address_zip' 	=> $this->input->post('address_zip'),
				'country' 		=> $this->input->post('country'),
				'telephone' 	=> $this->input->post('telephone'),
				'fax' 			=> $this->input->post('fax'),
				'email' 		=> $this->input->post('email'),
				'website'	 	=> $this->input->post('website'),
				'registration_number' 	=> $this->input->post('registration_number'),
				'parent_company' 		=> $pcompany,
				'sub_company'			=> ($pcompany == 'yes' OR $pcompany == 'sub') ? $subsidiary : null,
				'primary_market_ops' 	=> $this->input->post('primary_market_ops'),
				'other_market_ops' 	=> $this->input->post('other_market_ops'),
				'logo' 				=> $filelogo,
				'profile' 			=> $this->input->post('profile'),
				
				'name_p' 		=> $this->input->post('name_p'),
				'designation_p' => $this->input->post('designation_p'),
				'telephone_p' 	=> $this->input->post('telephone_p'),
				'fax_p' 		=> $this->input->post('fax_p'),
				'email_p' 		=> $this->input->post('email_p'),
				'name_s' 		=> $this->input->post('name_s'),
				'designation_s' => $this->input->post('designation_s'),
				'telephone_s' 	=> $this->input->post('telephone_s'),
				'fax_s' 		=> $this->input->post('fax_s'),
				'email_s' 		=> $this->input->post('email_s'),
				
				'contact_person' 	=> $this->input->post('contact_person'),
				'designation' 		=> $this->input->post('designation'),
				'contact_tel'	 	=> $this->input->post('contact_tel'),
				'contact_fax'	 	=> $this->input->post('contact_fax'),
				'contact_email' 	=> $this->input->post('contact_email'),
				
				'name_f' 		=> $this->input->post('name_f'),
				'designation_f' => $this->input->post('designation_f'),
				'telephone_f' 	=> $this->input->post('telephone_f'),
				'fax_f' 		=> $this->input->post('fax_f'),
				'email_f' 		=> $this->input->post('email_f'),
				
				'q1' => $this->input->post('q1'),
				'q2' => $this->input->post('q2'),
				'q3' => $this->input->post('q3'),
				'q4' => $this->input->post('q4'),
				'q_usage' => $this->input->post('q_usage'),
				
				'name_a' 		=> $this->input->post('name_a'),
				'designation_a' => $this->input->post('designation_a'),
				'email_a'		=> $this->input->post('email_a'),
				'date_2' 		=> $this->input->post('date_2'),
				'profession' 		=> $this->input->post('profession'),
				'file_certificates'	=> $cert_file_m,
				'file_additionals'	=> $file_additionals,
				'file_sh_group_manager'	=> $file_sh_group_manager,
				'file'				=> $file_grower_m,
				'applied_date' 		=> now(),
				'remarks' 			=> $this->input->post('remarks'),
				'newsletter' 		=> $this->input->post('newsletter') ? $this->input->post('newsletter') : 'n',
			);

			$update = false;
			if ($save && $m && $this->input->post('draft_id'))
			{
				// update data
				$update = $this->members_m->update($this->input->post('draft_id'), $input);

/*
				$data = $input;
				$data['from'] = "membership@rspo.org";
				$data['from'] = "okky@catalyzecommunications.com";
				$data['to']		= $input['email_a'];
				$data['email']	= $input['email_a'];
				$data['slug']	= 'membership-application';
				Events::trigger('email', $data, 'array');

				$data_admin = $input;
				$data_admin['from']		= $input['email_a'];
				$data_admin['app_id']	= $this->input->post('draft_id');
				$data_admin['to']		= Settings::get('contact_email');
				$data_admin['email']	= $data_admin['to'];
				$data_admin['slug']		= 'membership-application-admin';
				Events::trigger('email', $data_admin, 'array');
*/
			}
			else
			{
				$input['MemberID_2'] = $this->current_user->id;
				if ($m && $this->input->post('draft_id'))
				{
					// update -> change status to Pending
					$input['status'] = 'Pending';
					$update = $this->members_m->update($this->input->post('draft_id'), $input);
					if ($update)
						$update = $this->input->post('draft_id');
				}
				else
				{
					// insert new one (member clicks submit without saving
					$update = $this->members_m->insert($input);
				}

				if (!$save)
				{
					// send notification to submitter first
					$data = $input;
					$data['from'] 			= "membership@rspo.org";
					$data['slug']			= 'membership-application';
					$data['to']				= $input['email_a'];
					$data['email']			= $input['email_a'];
					$data['name']			= 'RSPO Membership';
					Events::trigger('email', $data, 'array');

					$data_admin = $input;
					$data_admin['app_id']	= $update;
					$data['from']			= $input['email_a'];
					$data_admin['to']		= Settings::get('contact_email');;
					$data_admin['email']	= $data_admin['to'];
					$data_admin['slug']		= 'membership-application-admin';
					//here add
					$data_admin['org_name']	= $this->input->post('org_name');
					$data_admin['parent_company']	= $pcompany;
					$data_admin['sub_company']	= ($pcompany == 'yes' OR $pcompany == 'sub') ? $subsidiary : null;
					$data_admin['address']		= $this->input->post('address');
					$data_admin['address_city']	= $this->input->post('address_city');
					$data_admin['address_state']	= $this->input->post('address_state');
					$data_admin['address_zip']		= $this->input->post('address_zip');
					$data_admin['country']		= $this->input->post('country');
					$data_admin['telephone']	= $this->input->post('telephone');
					$data_admin['fax']			= $this->input->post('fax');
					$data_admin['email_form']	= $this->input->post('email');
					$data_admin['website']		= $this->input->post('website');
					// end add
					Events::trigger('email', $data_admin, 'array');

					redirect('members/logout?u=members/submitted');
				}

				if ($update)
					$membershipapplication->intID = $update;
			}

			if($update)
			{
				if ($save)
					$this->session->set_flashdata('success', 'Your form was saved successfully.');
				else
					$this->session->set_flashdata('success', 'Your application has been submitted successfully to RSPO.');
				redirect('members/application');
			}
			else
			{
				$this->session->set_flashdata('error', 'Error Add');
				if ($save)
					$this->session->set_flashdata('error', 'We have difficulties saving your form. Please try again or report it to us.');
				else
					$this->session->set_flashdata('error', 'We have difficulties submitting your application. Please try again or report it to us.');
				redirect('members/application');
			}
		}
		
		// Go through all the known fields and get the post values
		if ($_POST)
		{
			foreach ($this->validation_rules as $rule)
			{
				$membershipapplication->{$rule['field']} = $this->input->post($rule['field']);
			}
		}

		$membershipapplication->logo = $filelogo;
		$membershipapplication->file = $file_grower_m;
		$membershipapplication->file_certificates = $cert_file_m;
		$membershipapplication->file = implode(',', $forremoveimg_grower);
		//$membershipapplication->file_certificates = implode(',', $forremoveimg);
		$membershipapplication->sub_company = $subsidiary;
		//$membershipapplication->org_name = $membershipapplication->name;

		$membershipapplication->name_a = $this->input->post('name_a') ? $this->input->post('name_a') : $this->current_user->first_name . ( $this->current_user->last_name ? ' ' . $this->current_user->last_name : '' );
		$membershipapplication->email_a = $this->input->post('email_a') ? $this->input->post('email_a') : $this->current_user->email;

		$this->template
			->title('Member Application')
			->set_breadcrumb('Members', 'members')
			->set_breadcrumb('Application')
			//->append_css('main.css')
			//->append_js('jquery.steps.min.js')
			//->append_js('bootstrap-filestyle.js')
			->set('membersapp', $membershipapplication)
			->build('admin/form-member');
			//->build('applications/application');
	}

	public function create()
	{
		role_or_die('members', 'add_member');
	
		$membershipapplication = new stdClass(); //$this->members_m->get($id);

/*
		if (empty($membershipapplication))
		{
			$this->session->set_flashdata('error', 'The member you tried to edit does not exist.');
			redirect('admin/members');
		}

		$this->input->post('org_subcategory');
*/

		$subsidiaries = $this->input->post('sub_company');
		$sub_company = array();
		if (!empty($subsidiaries))
		{
			foreach($subsidiaries['name'] as $k=>$v)
			{
				if ($v)
				{
					$sub_company[$k]['name'] = $v;
					$sub_company[$k]['id'] = $subsidiaries['id'][$k];
				}
			}
			$subsidiary = serialize($sub_company);
		}
		else
		{
			$subsidiary = !empty($membershipapplication->sub_company) ? $membershipapplication->sub_company : serialize(NULL);
		}

		$this->check_dir($this->config_upload['upload_path']);
		$this->load->library('upload', $this->config_upload);
		
		if(!empty($_FILES['logo']['name'])){
		
			if(!$this->upload->do_upload('logo')){ 
				
			}
			else{
				$filelogo_array = $this->upload->data();
				$filelogo = $filelogo_array['file_name'];
			}
		}
		else{
			if ($_POST)
				$filelogo = $this->input->post('upload_logo');
			else
				$filelogo = isset($membershipapplication->logo) ? $membershipapplication->logo : '';
		}
		
		if (!empty($_FILES['file_certificates']['name'][0]))
		{
			$file_certificates = array();
			if ($this->input->post('uploaded_files_cert'))
			{
				$file_certificates = explode(',', $this->input->post('uploaded_files_cert'));
			}
			if($this->upload->do_multi_upload("file_certificates"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();

				foreach($file_uploaded as $files)
				{
					$file_certificates[] = $files['file_name'];
				}
				
				$cert_file_m = implode(',', $file_certificates);
			}
		}
		else{
			if ($_POST)
				$cert_file_m = $this->input->post('uploaded_files_cert');
			else
				$cert_file_m = isset($membershipapplication->file_certificates) ? $membershipapplication->file_certificates : '';
		}

		if (!empty($_FILES['file_additionals']['name'][0]))
		{
			$addfiles = array();
			if ($this->input->post('uploaded_file_additionals'))
			{
				$addfiles = explode(',', $this->input->post('uploaded_file_additionals'));
			}
			if($this->upload->do_multi_upload("file_additionals"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();

				foreach($file_uploaded as $files)
				{
					$addfiles[] = $files['file_name'];
				}
				
				$file_additionals = implode(',', $addfiles);
			}
		}
		else{
			if ($_POST)
				$file_additionals = $this->input->post('uploaded_file_additionals');
			else
				$file_additionals = isset($membershipapplication->file_additionals) ? $membershipapplication->file_additionals : '';
		}

		// smallholder group manager files
		if (!empty($_FILES['file_sh_group_manager']['name'][0]))
		{
			$shfiles = array();
			if ($this->input->post('uploaded_file_sh_group_manager'))
			{
				$shfiles = explode(',', $this->input->post('uploaded_file_sh_group_manager'));
			}

			if($this->upload->do_multi_upload("file_sh_group_manager"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();
				foreach($file_uploaded as $files)
				{
					$shfiles[] = $files['file_name'];
				}
					
				$file_sh_group_manager = implode(',', $shfiles);
			}
		}
		else{
			if ($_POST)
				$file_sh_group_manager = $this->input->post('uploaded_file_sh_group_manager');
			else
				$file_sh_group_manager = isset($membershipapplication->file_sh_group_manager) ? $membershipapplication->file_sh_group_manager : '';
		}

		if ($this->input->post('remove_uploaded_cert'))
		{
			$forremoveimg = explode(',',$cert_file_m);
			$remove_uploaded_cert = $this->input->post('remove_uploaded_cert');
			foreach($remove_uploaded_cert as $r)
			{

				if (($key = array_search($r, $forremoveimg)) !== false) {
//echo " -- removing file... <br />";
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg[$key]);
					}
					else
					{
						unset($forremoveimg[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$cert_file_m = implode(',', $forremoveimg);
		}

		if (!empty($_FILES['file']['name'][0]))
		{
			if($this->upload->do_multi_upload("file"))
				{
					$file = array();
					$file_uploaded = $this->upload->get_multi_upload_data();
					if ($this->input->post('grower_file'))
					{
						$file = explode(',', $this->input->post('grower_file'));
					}

					foreach($file_uploaded as $files)
					{
						$file[] = $files['file_name'];
					}
					
					$file_grower_m = implode(',', $file);
				}
		}
		else{
			if ($_POST)
				$file_grower_m = $this->input->post('grower_file');
			else
				$file_grower_m = isset($membershipapplication->file) ? $membershipapplication->file : '';
		}
		
		$forremoveimg_grower = explode(',',$file_grower_m);
		if ($this->input->post('remove_uploaded_grower'))
		{
			$remove_uploaded_grower = $this->input->post('remove_uploaded_grower');
			foreach($remove_uploaded_grower as $r)
			{
				
				if (($key = array_search($r, $forremoveimg_grower)) !== false) {
	
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg_grower[$key]);
					}
					else
					{
						unset($forremoveimg_grower[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$file = implode(',', $forremoveimg_grower);
		}

		// If we have a useful date, use it
		if ($this->input->post('expiry_date'))
		{
			$expiry_date = strtotime(sprintf('%s', $this->input->post('expiry_date')));
		}
		else
		{
			$expiry_date = NULL;
		}

		// If we have approved_date date, use it
		if ($this->input->post('approved_date') && $this->input->post('status')=='Approved')
		{
			$approved_date = strtotime(sprintf('%s', $this->input->post('approved_date')));
		}
		else
		{
			$approved_date = NULL;
		}

		$this->form_validation->set_rules($this->validation_rules);
		if($this->form_validation->run()){
			$pcompany = $this->input->post('parent_company');
			$mtype = $this->input->post('type');
			if ($pcompany == 'none') $pcompany = null;
			$membershipapp_insert = array(
				'title' 				=> $this->input->post('org_name'),
				'type' 					=> $this->types[$mtype],
				'category' 				=> $this->input->post('category'),
				'profession' 			=> $this->input->post('profession'),
				'name' 					=> $this->input->post('org_name'),
				'address' 				=> $this->input->post('address'),
				'address_city' 			=> $this->input->post('address_city'),
				'address_state' 		=> $this->input->post('address_state'),
				'address_zip' 			=> $this->input->post('address_zip'),
				'country' 				=> $this->input->post('country'),
				'code_telephone' 		=> $this->input->post('code_telephone'),
				'telephone' 			=> $this->input->post('telephone'),
				'code_fax' 				=> $this->input->post('code_fax'),
				'fax' 					=> $this->input->post('fax'),
				'email' 				=> $this->input->post('email'),
				'website'	 			=> $this->input->post('website'),
				'registration_number' 	=> $this->input->post('registration_number'),
				'parent_company' 		=> $pcompany,
				'sub_company'			=> ($pcompany == 'yes' OR $pcompany == 'sub') ? $subsidiary : null,
				'primary_market_ops' 	=> $this->input->post('primary_market_ops'),
				'other_market_ops' 		=> $this->input->post('other_market_ops'),
				'logo' 					=> $filelogo,
				'profile' 				=> $this->input->post('profile'),
				
				'name_p' 		=> $this->input->post('name_p'),
				'name_last_p' 	=> $this->input->post('name_last_p'),
				'designation_p' => $this->input->post('designation_p'),
				'code_tel_p' 	=> $this->input->post('code_tel_p'),
				'telephone_p' 	=> $this->input->post('telephone_p'),
				'code_fax_p' 	=> $this->input->post('code_fax_p'),
				'fax_p' 		=> $this->input->post('fax_p'),
				'email_p' 		=> $this->input->post('email_p'),
				'name_s' 		=> $this->input->post('name_s'),
				'name_last_s' 	=> $this->input->post('name_last_s'),
				'designation_s' => $this->input->post('designation_s'),
				'code_tel_s' 	=> $this->input->post('code_tel_s'),
				'telephone_s' 	=> $this->input->post('telephone_s'),
				'code_fax_s' 	=> $this->input->post('code_fax_s'),
				'fax_s' 		=> $this->input->post('fax_s'),
				'email_s' 		=> $this->input->post('email_s'),
				
				'contact_person' 	=> $this->input->post('contact_person'),
				'contact_lname' 	=> $this->input->post('contact_lname'),
				'designation' 		=> $this->input->post('designation'),
				'code_contact_tel' 		=> $this->input->post('code_contact_tel'),
				'contact_tel'	 	=> $this->input->post('contact_tel'),
				'code_contact_fax' 		=> $this->input->post('code_contact_fax'),
				'contact_fax'	 	=> $this->input->post('contact_fax'),
				'contact_email' 	=> $this->input->post('contact_email'),
				
				'name_f' 		=> $this->input->post('name_f'),
				'name_last_f' 	=> $this->input->post('name_last_f'),
				'designation_f' => $this->input->post('designation_f'),
				'code_tel_f' 	=> $this->input->post('code_tel_f'),
				'telephone_f' 	=> $this->input->post('telephone_f'),
				'code_fax_f' 	=> $this->input->post('code_fax_f'),
				'fax_f' 		=> $this->input->post('fax_f'),
				'email_f' 		=> $this->input->post('email_f'),
				
				'q1' 			=> $this->input->post('q1'),
				'q2' 			=> $this->input->post('q2'),
				'q3' 			=> $this->input->post('q3'),
				'q4' 			=> $this->input->post('q4'),
				'q_usage' 		=> $this->input->post('q_usage'),

				'status' 			=> $this->input->post('status'),
				'member_num' 		=> $this->input->post('status')=='Approved'?$this->input->post('member_num'):NULL,
				'expiry_date' 		=> $expiry_date,
				'approved_date' 	=> $approved_date,

				'name_a' 			=> $this->input->post('name_a'),
				'email_a' 			=> $this->input->post('email_a'),
				'designation_a' 	=> $this->input->post('designation_a'),
				'date_2' 			=> $this->input->post('date_2'),
				'profession' 		=> $this->input->post('profession'),
				'file_certificates'	=> $cert_file_m,
				'file_additionals'	=> $file_additionals,
				'file_sh_group_manager'	=> $file_sh_group_manager,
				'file'				=> $file_grower_m,
				'applied_date' 		=> now(),
				'remarks' 			=> $this->input->post('remarks'),
				'newsletter' 		=> $this->input->post('newsletter') ? $this->input->post('newsletter') : 'n',

				'account_sf_id' 			=> $this->input->post('account_sf_id'),
				'application_sf_id' 		=> $this->input->post('application_sf_id'),
				'primary_sf_id' 			=> $this->input->post('primary_sf_id'),
				'secondary_sf_id' 			=> $this->input->post('secondary_sf_id'),
				'contact_sf_id' 			=> $this->input->post('contact_sf_id'),
				'finance_sf_id' 			=> $this->input->post('finance_sf_id'),
			);

/*
echo "<pre>\n";
echo "\$membershipapp_insert\n";
print_r($membershipapp_insert);
echo "</pre>\n";

echo "<pre>\n";
echo "\$_POST\n";
print_r($_POST);
echo "</pre>\n";
exit;
*/

			$membership_update = array(
				'status' 				=> $this->input->post('status'),
				'email_a' 				=> $this->input->post('email_a'),
				'parent_company' 		=> $this->input->post('parent_company'),
				'sub_company' 			=> $subsidiary,
				'expiry_date' 			=> $expiry_date
			);

			$id = $this->members_m->insert($membershipapp_insert);
			if($id)
				{
					$this->pyrocache->delete_all('members_m');
					$this->session->set_flashdata('success', sprintf( lang('memberss:member_save_success'), $this->input->post('org_name')) );

					if ($this->input->post('btnAction') == 'sync')
					{
						$triggered_event = Events::trigger('member_updated', array('id'=>$id, 'input'=>$membershipapp_insert));
						$this->session->set_flashdata('notice', $triggered_event); // <--- comment on live system
					}

					$membershipapplication = $this->members_m->get($id);
					if ($this->input->post('btnAction') == 'send_files')
					{
						$files = array(
							'application_sf_id'=>$membershipapplication->application_sf_id,
							'logo'=>$membershipapplication->logo,
							'file'=>$membershipapplication->file,
							'file_certificates'=>$membershipapplication->file_certificates,
							'file_additionals'=>$membershipapplication->file_additionals,
							'file_sh_group_manager'=>$membershipapplication->file_sh_group_manager,
							'file_sc_group_manager'=>$membershipapplication->file_sc_group_manager,
						);
						$triggered_event = Events::trigger('files_updated', array('id'=>$id, 'member_name'=>$membershipapplication->title, 'input'=>$files));
						$this->session->set_flashdata('notice', $triggered_event); // <--- comment on live system
					}

					$this->input->post('btnAction') == 'save' ? redirect('admin/members/edit/'.$id) : redirect('admin/members');
				}
			else{
					$this->session->set_flashdata('error', sprintf( lang('memberss:member_save_error'), $this->input->post('org_name')) );
					//$this->session->set_flashdata('error', 'Error updating member');
					redirect('admin/members');
				}
		}

		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $rule)
		{
			//if ($this->input->post())
			//{
				$membershipapplication->{$rule['field']} = $this->input->post($rule['field']);
			//}
		}
		
		$membershipapplication->logo = $filelogo;
		$membershipapplication->file = $file_grower_m;
		$membershipapplication->file_certificates = $cert_file_m;
		$membershipapplication->file = implode(',', $forremoveimg_grower);
		if (!empty($forremoveimg))
			$membershipapplication->file_certificates = implode(',', $forremoveimg);
		$membershipapplication->sub_company = $subsidiary;
		$membershipapplication->name = $membershipapplication->org_name;

		$this->template
			->append_metadata($this->load->view('fragments/wysiwyg', array(), TRUE))
			->append_css('module::members.css')
			->append_css('module::intlTelInput.css')
			->append_js('module::intlTelInput.js')
			->set('membersapp', $membershipapplication)
			->build('admin/application');
			//->build('admin/form-member');
	}

	public function memberclone($id=0)
	{
		$rules = array(
			array(
				'field' => 'user',
				'label' => 'User Link',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'type',
				'label' => 'Category',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'sector',
				'label' => 'Sector',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'name',
				'label' => 'Organisation/Company Name',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'contact_primary',
				'label' => 'Primary Contact',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_secondary',
				'label' => 'Secondary Contact',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_finance',
				'label' => 'Finance Contact',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_other',
				'label' => 'Contact Person',
				'rules' => 'trim',
			),
			array(
				'field' => 'all_answers',
				'label' => 'Include all answers',
				'rules' => 'trim',
			),
			array(
				'field' => 'all_files',
				'label' => 'Include all file attachment',
				'rules' => 'trim',
			),
		);

		role_or_die('members', 'add_member');

		$clone = new stdClass();

		$this->load->model('users/user_m');
		$users = array(''=>'Please select');
		$group_users = $this->user_m->get_many_by(array('group_id'=>'2'));
		if ($group_users)
		{
			foreach($group_users as $u)
			{
				$users[$u->id] = $u->first_name.' '.$u->last_name;
			}
		}
		$this->template->set('users', $users);

		$member = $this->members_m->get_no_profile($id);

		if (empty($member))
		{
			$this->session->set_flashdata('error', 'The member you tried to clone from does not exist.');
			redirect('admin/members');
		}

		//if ($_POST)

		$this->form_validation->set_rules($rules);
		if($this->form_validation->run())
		{
			// empty intID
			unset($member->intID);

			if ($this->input->post('contact_other')<>'y')
			{
				// do not clone contact person
				$member->code_contact_tel = $member->contact_tel = $member->code_contact_fax = $member->contact_fax = $member->contact_email = $member->contact_person = $member->contact_lname = $member->contact_tel = $member->designation = '';
			}

			if ($this->input->post('contact_primary')<>'y')
			{
				// do not clone primary contact
				$member->name_p = $member->name_last_p = $member->designation_p = $member->code_tel_p = $member->telephone_p = $member->code_fax_p = $member->fax_p = $member->email_p = '';
			}

			if ($this->input->post('contact_secondary')<>'y')
			{
				// do not clone secondary contact
				$member->name_s = $member->name_last_s = $member->designation_s = $member->code_tel_s = $member->telephone_s = $member->code_fax_s = $member->fax_s = $member->email_s = '';
			}

			if ($this->input->post('contact_finance')<>'y')
			{
				// do not clone finance contact
				$member->name_f = $member->name_last_f = $member->designation_f = $member->code_tel_f = $member->telephone_f = $member->code_fax_f = $member->fax_f = $member->email_f = '';
			}

			if ($this->input->post('all_answers')<>'y')
			{
				// do not clone finance contact
				$member->q1 = $member->q2 = $member->q3 = $member->q4 = $member->q_usage = '';
			}

			if ($this->input->post('all_files')<>'y')
			{
				// do not clone finance contact
				$member->logo = $member->file = $member->file_certificates = $member->file_additionals = $member->file_sh_group_manager = $member->file_sc_group_manager = '';
			}

			$member->MemberID_2 = NULL;
			// is a user linked to this clone?
			if ($this->input->post('user'))
			{
				$member->MemberID_2 = $this->input->post('user');
			}

			if ($this->input->post('name'))
			{
				$member->title = $this->input->post('name');
				$member->name = $this->input->post('name');
			}

			// sector & category are always empty / not cloned
			$member->type = $this->input->post('type');
			$member->category = $this->input->post('sector');
			$member->sub_category_other = '';

			// reset status
			$member->status = NULL;

			// reset application_sf_id
			$member->application_sf_id = NULL;

			$res = $this->members_m->clonemember($member);
			if ($res)
			{
				// remove MemberID_2
				$this->members_m->update($id, array('MemberID_2'=>''));
				$this->session->set_flashdata('success', 'Member "'.$member->title.'" was cloned successfully.');
				redirect('admin/members');
			}
			else
			{
				$this->template->set('error_msg', 'Failed cloning member "'.$member->title.'".');
			}
		}

		foreach ($rules as $rule)
		{
			$clone->{$rule['field']} = $this->input->post($rule['field']);
		}

		$this->template
			->set('clone', $clone)
			->set('member', $member)
                ->build('admin/clone');
    }

    public function edit($id = 0) {
        role_or_die('members', 'edit_member');

        //$membershipapplication = $this->members_m->get_by('intID', $id);
        $membershipapplication = $this->members_m->get($id);

        if (empty($membershipapplication)) {
            $this->session->set_flashdata('error', 'The member you tried to edit does not exist.');
            redirect('admin/members');
        }

        $this->input->post('org_subcategory');

        $subsidiaries = $this->input->post('sub_company');
        $sub_company = array();
        if (!empty($subsidiaries)) {
            foreach ($subsidiaries['name'] as $k => $v) {
                if ($v) {
                    $sub_company[$k]['name'] = $v;
                    $sub_company[$k]['id'] = $subsidiaries['id'][$k];
                }
            }
            $subsidiary = serialize($sub_company);
        } else {
            $subsidiary = !empty($membershipapplication->sub_company) ? $membershipapplication->sub_company : serialize(NULL);
        }

/* *
if (!empty($_POST))
{
	echo "<pre>\n";
	print_r($_POST);
	exit;
}
/* */

        $this->check_dir($this->config_upload['upload_path']);
        $this->load->library('upload', $this->config_upload);

        if (!empty($_FILES['logo']['name'])) {

            if (!$this->upload->do_upload('logo')) {
                
            } else {
                $file = $this->upload->data();
                $filelogo = $file['file_name'];
                if ($file['is_image']) {
                    $this->load->library('image_lib');
                    $filename = $file['file_name'];
                    $thumbfile = thumbnail($filename); //substr($filename, 0, -4) . '_thumb' . substr($filename, -4);
                    //$medfile = fullname($filename); //substr($filename, 0, -4) . '_full' . substr($filename, -4);
                    /* ---------------------------------------------------------------------------------
                      // create thumb - admin
                     */
                    //echo "Full path: " . $file['full_path'] . "<br />";

                    /*
                      $image_cfg['source_image'] = $file['full_path'];
                      $image_cfg['image_library'] = 'gd2';
                      $image_cfg['maintain_ratio'] = TRUE;
                      $image_cfg['width'] = ($file['image_width'] < $this->thumb_width ? $file['image_width'] : $this->thumb_width);
                      $image_cfg['height'] = ($file['image_height'] < $this->thumb_height ? $file['image_height'] : $this->thumb_height);
                      $image_cfg['create_thumb'] = FALSE;
                      $image_cfg['new_image'] = $file['file_path'] . $thumbfile;
                      $image_cfg['master_dim'] = 'width';
                      $this->image_lib->initialize($image_cfg);
                      $img_ok = $this->image_lib->resize();
                      unset($image_cfg);
                      $this->image_lib->clear();
                      if (!$img_ok)
                      echo "Thumbnail " . $file['file_path'] . $thumbfile . ': ' . $this->image_lib->display_errors() . "<br />\n";
                     */
                    /*
                      /* image resize - medium
                     */
                    $image_cfg['source_image'] = $file['full_path'];
                    $image_cfg['image_library'] = 'gd2';
                    $image_cfg['maintain_ratio'] = TRUE;
                    $image_cfg['width'] = ($file['image_width'] < $this->thumb_width ? $file['image_width'] : $this->thumb_width);
                    $image_cfg['height'] = ($file['image_height'] < $this->thumb_height ? $file['image_height'] : $this->thumb_height);
                    $image_cfg['create_thumb'] = TRUE;
                    $image_cfg['new_image'] = $file['file_path'] . $filename; //$thumbfile;
                    $image_cfg['master_dim'] = 'width';
                    $this->image_lib->initialize($image_cfg);
                    $img_ok = $this->image_lib->resize();
                    unset($image_cfg);
                    $this->image_lib->clear();

                    //if (!$img_ok)
                    //	echo "Resize: " . $this->image_lib->display_errors() . "<br />\n";

                    /*
                     *  remove old logo
                     */
                    if ($membershipapplication->logo) {
                        if (strstr($membershipapplication->logo, '/sites/default/files/')) {
                            $fname = $_SERVER['DOCUMENT_ROOT'] . $membershipapplication->logo;
                            $tname = $_SERVER['DOCUMENT_ROOT'] . thumbnail($membershipapplication->logo);
                            //echo '<img class="img-responsive" src="http://www.rspo.org'.$member->logo.'" />'.PHP_EOL;
                        } elseif (strstr($membershipapplication->logo, 'ma/logo/')) {
                            $fname = $_SERVER['DOCUMENT_ROOT'] . '/' . $membershipapplication->logo;
                        } else {
                            $fname = $_SERVER['DOCUMENT_ROOT'] . UPLOAD_PATH . '/memberlogos/' . $membershipapplication->logo;
                            $tname = $_SERVER['DOCUMENT_ROOT'] . UPLOAD_PATH . '/memberlogos/' . thumbnail($membershipapplication->logo);
                        }
                        if (is_file($fname)) {
                            unlink($fname);
                            if (!empty($tname))
                                unlink($tname);
                        }
                    }
                }
            }
        }
        else {
            if ($_POST)
                $filelogo = $this->input->post('upload_logo');
            else
                $filelogo = isset($membershipapplication->logo) ? $membershipapplication->logo : '';
        }

        if (!empty($_FILES['file_certificates']['name'][0])) {
            $file_certificates = array();
            if ($this->input->post('uploaded_files_cert')) {
                $file_certificates = explode(',', $this->input->post('uploaded_files_cert'));
            }
            if ($this->upload->do_multi_upload("file_certificates")) {
                $file_uploaded = $this->upload->get_multi_upload_data();

                foreach ($file_uploaded as $files) {
                    $file_certificates[] = $files['file_name'];
                }

                $cert_file_m = implode(',', $file_certificates);
            }
        } else {
            if ($_POST)
                $cert_file_m = $this->input->post('uploaded_files_cert');
            else
                $cert_file_m = isset($membershipapplication->file_certificates) ? $membershipapplication->file_certificates : '';
        }

        if (!empty($_FILES['file_additionals']['name'][0])) {
            $addfiles = array();
            if ($this->input->post('uploaded_file_additionals')) {
                $addfiles = explode(',', $this->input->post('uploaded_file_additionals'));
            }
            if ($this->upload->do_multi_upload("file_additionals")) {
                $file_uploaded = $this->upload->get_multi_upload_data();

                foreach ($file_uploaded as $files) {
                    $addfiles[] = $files['file_name'];
                }

                $file_additionals = implode(',', $addfiles);
            }
        } else {
            if ($_POST)
                $file_additionals = $this->input->post('uploaded_file_additionals');
            else
                $file_additionals = isset($membershipapplication->file_additionals) ? $membershipapplication->file_additionals : '';
        }

        // smallholder group manager files
        if (!empty($_FILES['file_sh_group_manager']['name'][0])) {
            $shfiles = array();
            if ($this->input->post('uploaded_file_sh_group_manager')) {
                $shfiles = explode(',', $this->input->post('uploaded_file_sh_group_manager'));
            }

            if ($this->upload->do_multi_upload("file_sh_group_manager")) {
                $file_uploaded = $this->upload->get_multi_upload_data();
                foreach ($file_uploaded as $files) {
                    $shfiles[] = $files['file_name'];
                }

                $file_sh_group_manager = implode(',', $shfiles);
            }
        } else {
            if ($_POST)
                $file_sh_group_manager = $this->input->post('uploaded_file_sh_group_manager');
            else
                $file_sh_group_manager = isset($membershipapplication->file_sh_group_manager) ? $membershipapplication->file_sh_group_manager : '';
        }

        if ($this->input->post('remove_uploaded_cert')) {
            $forremoveimg = explode(',', $cert_file_m);
            $remove_uploaded_cert = $this->input->post('remove_uploaded_cert');
            foreach ($remove_uploaded_cert as $r) {

                if (($key = array_search($r, $forremoveimg)) !== false) {
//echo " -- removing file... <br />";
                    // remove the file
                    if (is_file($_SERVER['DOCUMENT_ROOT'] . '/' . UPLOAD_PATH . 'memberlogos/' . $r) && unlink($_SERVER['DOCUMENT_ROOT'] . '/' . UPLOAD_PATH . 'memberlogos/' . $r)) {
                        unset($forremoveimg[$key]);
                    } else {
                        unset($forremoveimg[$key]);
                        $this->session->set_flashdata('info', 'Error deleting file ' . $r);
                    }
                }
            }
            $cert_file_m = implode(',', $forremoveimg);
        }

        if (!empty($_FILES['file']['name'][0])) {
            if ($this->upload->do_multi_upload("file")) {
                $file = array();
                $file_uploaded = $this->upload->get_multi_upload_data();
                if ($this->input->post('grower_file')) {
                    $file = explode(',', $this->input->post('grower_file'));
                }

                foreach ($file_uploaded as $files) {
                    $file[] = $files['file_name'];
                }

                $file_grower_m = implode(',', $file);
            }
        } else {
            if ($_POST)
                $file_grower_m = $this->input->post('grower_file');
            else
                $file_grower_m = isset($membershipapplication->file) ? $membershipapplication->file : '';
        }

        $forremoveimg_grower = explode(',', $file_grower_m);
        if ($this->input->post('remove_uploaded_grower')) {
            $remove_uploaded_grower = $this->input->post('remove_uploaded_grower');
            foreach ($remove_uploaded_grower as $r) {

                if (($key = array_search($r, $forremoveimg_grower)) !== false) {

                    // remove the file
                    if (is_file($_SERVER['DOCUMENT_ROOT'] . '/' . UPLOAD_PATH . 'memberlogos/' . $r) && unlink($_SERVER['DOCUMENT_ROOT'] . '/' . UPLOAD_PATH . 'memberlogos/' . $r)) {
                        unset($forremoveimg_grower[$key]);
                    } else {
                        unset($forremoveimg_grower[$key]);
                        $this->session->set_flashdata('info', 'Error deleting file ' . $r);
                    }
                }
            }
            $file = implode(',', $forremoveimg_grower);
        }

        // If we have expiry_date date, use it
        if ($this->input->post('expiry_date') && $this->input->post('status') == 'Call for Comment') {
            $expiry_date = strtotime(sprintf('%s', $this->input->post('expiry_date')));
        } else {
            $expiry_date = $membershipapplication->expiry_date;
        }

        // If we have approved_date date, use it
        if ($this->input->post('approved_date') && $this->input->post('status') == 'Approved') {
            $approved_date = strtotime(sprintf('%s', $this->input->post('approved_date')));
        } else {
            $approved_date = $membershipapplication->approved_date;
        }


        // if we have applied_date, use it!
        if ($this->input->post('applied_date')) {
            $a_date = explode('-', $this->input->post('applied_date'));
            $applied_year = $a_date[0];
            $applied_month = $a_date[1];
            $applied_day = $a_date[2];
            $applied_date = mktime(0, 0, 0, $applied_month, $applied_day, $applied_year);
        } else {
            $applied_date = isset($membershipapplication->applied_date) ? $membershipapplication->applied_date : 0;
        }

        $pcompany = $this->input->post('parent_company');
        $mtype = $this->input->post('type');
        if ($pcompany == 'none')
            $pcompany = null;


        $this->form_validation->set_rules($this->validation_rules);
        if ($this->form_validation->run()) {
            $membershipapp_insert = array(
                'title' => $this->input->post('org_name'),
                'type' => $this->types[$mtype],
                'category' => $this->input->post('category'),
                'profession' => $this->input->post('profession'),
                'name' => $this->input->post('org_name'),
                'address' => $this->input->post('address'),
                'address_city' => $this->input->post('address_city'),
                'address_state' => $this->input->post('address_state'),
                'address_zip' => $this->input->post('address_zip'),
                'country' => $this->input->post('country'),
                'code_telephone' => $this->input->post('code_telephone'),
                'telephone' => $this->input->post('telephone'),
                'code_fax' => $this->input->post('code_fax'),
                'fax' => $this->input->post('fax'),
                'email' => $this->input->post('email'),
                'website' => $this->input->post('website'),
                'registration_number' => $this->input->post('registration_number'),
                'parent_company' => $pcompany,
                'sub_company' => ($pcompany == 'yes' OR $pcompany == 'sub') ? $subsidiary : null,
                'primary_market_ops' => $this->input->post('primary_market_ops'),
                'other_market_ops' => $this->input->post('other_market_ops'),
                'logo' => $filelogo,
                'profile' => $this->input->post('profile'),
                'name_p' => $this->input->post('name_p'),
                'name_last_p' => $this->input->post('name_last_p'),
                'designation_p' => $this->input->post('designation_p'),
                'code_tel_p' => $this->input->post('code_tel_p'),
                'telephone_p' => $this->input->post('telephone_p'),
                'code_fax_p' => $this->input->post('code_fax_p'),
                'fax_p' => $this->input->post('fax_p'),
                'email_p' => $this->input->post('email_p'),
                'name_s' => $this->input->post('name_s'),
                'name_last_s' => $this->input->post('name_last_s'),
                'designation_s' => $this->input->post('designation_s'),
                'code_tel_s' => $this->input->post('code_tel_s'),
                'telephone_s' => $this->input->post('telephone_s'),
                'code_fax_s' => $this->input->post('code_fax_s'),
                'fax_s' => $this->input->post('fax_s'),
                'email_s' => $this->input->post('email_s'),
                'contact_person' => $this->input->post('contact_person'),
                'contact_lname' => $this->input->post('contact_lname'),
                'designation' => $this->input->post('designation'),
                'code_contact_tel' => $this->input->post('code_contact_tel'),
                'contact_tel' => $this->input->post('contact_tel'),
                'code_contact_fax' => $this->input->post('code_contact_fax'),
                'contact_fax' => $this->input->post('contact_fax'),
                'contact_email' => $this->input->post('contact_email'),
                'name_f' => $this->input->post('name_f'),
                'name_last_f' => $this->input->post('name_last_f'),
                'designation_f' => $this->input->post('designation_f'),
                'code_tel_f' => $this->input->post('code_tel_f'),
                'telephone_f' => $this->input->post('telephone_f'),
                'code_fax_f' => $this->input->post('code_fax_f'),
                'fax_f' => $this->input->post('fax_f'),
                'email_f' => $this->input->post('email_f'),
                'q1' => $this->input->post('q1'),
                'q2' => $this->input->post('q2'),
                'q3' => $this->input->post('q3'),
                'q4' => $this->input->post('q4'),
                'q_usage' => $this->input->post('q_usage'),
                'status' => $this->input->post('status'),
                'member_num' => $this->input->post('member_num'),
                //'member_num' => $this->input->post('status') == 'Approved' ? $this->input->post('member_num') : NULL,
                'expiry_date' => $expiry_date,
                'approved_date' => $approved_date,
                'name_a' => $this->input->post('name_a'),
                'email_a' => $this->input->post('email_a'),
                'designation_a' => $this->input->post('designation_a'),
                'date_2' => $this->input->post('date_2'),
                'profession' => $this->input->post('profession'),
                'file_certificates' => $cert_file_m,
                'file_additionals' => $file_additionals,
                'file_sh_group_manager' => $file_sh_group_manager,
                'file' => $file_grower_m,
                'applied_date' => $applied_date, //now(),
                'remarks' => $this->input->post('remarks'),
                'newsletter' => $this->input->post('newsletter') ? $this->input->post('newsletter') : 'n',
                'account_sf_id' => $this->input->post('account_sf_id'),
                'application_sf_id' => $this->input->post('application_sf_id'),
                'primary_sf_id' => $this->input->post('primary_sf_id'),
                'secondary_sf_id' => $this->input->post('secondary_sf_id'),
                'contact_sf_id' => $this->input->post('contact_sf_id'),
                'finance_sf_id' => $this->input->post('finance_sf_id'),
                'greenpalm_member_num' => $this->input->post('greenpalm_member_num'),
                'survey' => $this->input->post('survey')=='yes'?'1':'0',
                'strModifyDate' => date('Y-m-d', now()),
                'strModifyPerson' => $this->current_user->id,
            );

            //if ($this->input->post('MemberID_2'))
            if (isset($_POST['MemberID_2'])) {
                $membershipapp_insert['MemberID_2'] = $this->input->post('MemberID_2') ? $this->input->post('MemberID_2') : 0;
            }

            $membership_update = array(
                'status' => $this->input->post('status'),
                'email_a' => $this->input->post('email_a'),
                'parent_company' => $this->input->post('parent_company'),
                'sub_company' => $subsidiary,
                'expiry_date' => $expiry_date
            );

            /*             *
              echo "<pre>\n";
              echo "\$membershipapp_insert\n";
              print_r($membershipapp_insert);
              echo "</pre>\n";

              echo "<pre>\n";
              echo "\$_POST\n";
              print_r($_POST);
              echo "</pre>\n";
              exit;
              /* */

            $member_updated = $this->members_m->update($id, $membershipapp_insert);

            if ($member_updated) {
                $this->applyChangesToTemp($id, $membershipapp_insert);

				// process the subsidiaries
				$subsidiary_num = count($_POST['sub_id']);
				$is_rspo_member = $this->input->post('gm_is_rspo_num_dummy');
				for($i=0; $i<$subsidiary_num; $i++)
				{
					if (!$_POST['gm_name'][$i])
					{
	                	$this->session->set_flashdata('notice', 'Group Member with empty <b>Group Member Name</b> was ignored');
						continue;
					}

					$subsidiary_inputs = array(
						'id' => $_POST['sub_id'][$i],
						'member_intID' => $id,
						'name' => $_POST['gm_name'][$i],
						'type' => $_POST['gm_type'][$i],
						'other_type' => strtolower($_POST['gm_type'][$i])=='other'?$_POST['gm_type_other'][$i]:NULL,
						'nature_of_business' => $_POST['gm_nature_of_business'][$i],
						'country' => $_POST['gm_country'][$i],
						'region' => $_POST['gm_region'][$i],
						'is_rspo_num' => $is_rspo_member[$i]=='yes'?'yes':NULL,
						'rspo_membership_num' => $is_rspo_member[$i]=='yes'?$_POST['rspo_membership_num'][$i]:NULL,
						'firstname' => $_POST['gm_firstname'][$i],
						'lastname' => $_POST['gm_lastname'][$i],
						'email' => $_POST['gm_email'][$i],
						'phone' => $_POST['gm_phone'][$i],
					);
/**
echo "<pre>\n";
echo "\$is_rspo_member:\n";
print_r($is_rspo_member);
echo "<hr />\n";
echo "\$subsidiary_inputs:\n";
print_r($subsidiary_inputs);
/**/

					if ($_POST['remove_sub_id'][$i])
					{
						// delete this subsidiary
						//if (!$this->db->delete('membership_subsidiaries', array('id'=>$_POST['remove_sub_id'][$i])));
						if ($this->subsidiaries_m->delete($_POST['remove_sub_id'][$i]));
						{
							$notify_message[] = 'Group Member "'.$_POST['gm_name'][$i].'" was successfully deleted.';
						}
					}
					else
					{
						if (is_numeric($_POST['sub_id'][$i]) && empty($_POST['remove_sub_id'][$i]))
						{
							// existing subsidiaries
							if (!$this->subsidiaries_m->update($_POST['sub_id'][$i], $subsidiary_inputs))
							{
								$err_message[] = 'Failed saving Group Member '.$_POST['gm_name'][$i];
							}
						}
						else
						{
							// new subsidiaries
							unset($subsidiary_inputs['id']);
							if (!$this->subsidiaries_m->insert($subsidiary_inputs))
							{
								$err_message[] = 'Sorry, but we have difficulties saving Group Member '.$_POST['gm_name'][$i].'. Please try creating it again.';
							}
						}
					}

				}

/*
if (!empty($_POST))
{
	echo "<pre>\n";
	print_r($_POST);
	exit;
}
*/

				if (!empty($err_message))
				{
                	$this->session->set_flashdata('error', implode('<br />', $err_message));
				}

				if (!empty($notify_message))
				{
                	$this->session->set_flashdata('notice', implode('<br />', $notify_message));
				}

                $this->pyrocache->delete_all('members_m');

                $this->session->set_flashdata('success', sprintf(lang('members:member_save_success'), $this->input->post('org_name')));

                // trigger event to sync to SF
                //if (strtolower($membershipapp_insert['status'])=='approved')
                if ($this->input->post('btnAction') == 'sync') {
                    $triggered_event = Events::trigger('member_updated', array('id' => $id, 'input' => $membershipapp_insert));
                    //$this->session->set_flashdata('notice', $triggered_event); // <--- comment on live system
                }

                if ($this->input->post('btnAction') == 'send_files') {
                    $files = array(
                        'application_sf_id' => $membershipapplication->application_sf_id,
                        'logo' => $membershipapplication->logo,
                        'file' => $membershipapplication->file,
                        'file_certificates' => $membershipapplication->file_certificates,
                        'file_additionals' => $membershipapplication->file_additionals,
                        'file_sh_group_manager' => $membershipapplication->file_sh_group_manager,
                        'file_sc_group_manager' => $membershipapplication->file_sc_group_manager,
                    );
                    $triggered_event = Events::trigger('files_updated', array('id' => $id, 'member_name' => $membershipapplication->title, 'input' => $files));
                    $this->session->set_flashdata('notice', $triggered_event); // <--- comment on live system
                }

                ($this->input->post('btnAction') == 'save' OR $this->input->post('btnAction') == 'sync') ? redirect('admin/members/edit/' . $id) : redirect('admin/members');
            } else {
                $this->session->set_flashdata('error', sprintf(lang('members:member_save_error'), $this->input->post('org_name')));
                $this->session->set_flashdata('notice', $this->db->error()['message']);
                redirect('admin/members');
            }
        }

        // Go through all the known fields and get the post values
        foreach ($this->validation_rules as $rule) {
            if ($this->input->post()) {
                if ($rule['field'] == 'type')
                    $membershipapplication->type = $this->types[$mtype];
                else
                    $membershipapplication->{$rule['field']} = $this->input->post($rule['field']);
            }
        }

        $membershipapplication->logo = $filelogo;
        $membershipapplication->file = $file_grower_m;
        $membershipapplication->file_certificates = $cert_file_m;
        $membershipapplication->file = implode(',', $forremoveimg_grower);
        if (!empty($forremoveimg))
            $membershipapplication->file_certificates = implode(',', $forremoveimg);
        $membershipapplication->sub_company = $subsidiary;

        //$membershipapplication->type = $this->types[$mtype];

        if (!empty($membershipapplication->name))
            $membershipapplication->name = stripslashes($membershipapplication->name);

        $this->load->model('users/user_m');
        $users = array('' => 'Please select');
        $group_users = $this->user_m->get_many_by(array('group_id' => '2'));
        if ($group_users) {
            foreach ($group_users as $u) {
                $users[$u->id] = $u->first_name . ' ' . $u->last_name;
            }
        }
        $this->template->set('users', $users);

        if ($membershipapplication->MemberID_2) {
            $member_user = $this->user_m->get(array('id' => $membershipapplication->MemberID_2));
            $this->template->set('member_user', $member_user);
        }
        
        $subsidiaries = $this->subsidiaries_m->get_many_by('member_intID', $membershipapplication->intID);

        $this->template
                ->append_metadata($this->load->view('fragments/wysiwyg', array(), TRUE))
                ->append_css('module::members.css')
                ->append_css('module::members-profile.css')
                ->append_css('module::intlTelInput.css')
                ->append_js('module::intlTelInput.js')
                ->set('membersapp', $membershipapplication)
                ->set('subsidiaries', $subsidiaries)
                ->build('admin/application');
        //->build('admin/form-member');
    }

    public function applyChangesToTemp($intID, $input)
    {
        $this->load->model('members_temp_m');
        $member = $this->members_m->get_by('intID',$intID);
        if (empty($member)) {
            return false;
        }

        if ($member->survey == '1') {
            return false;
        }

        $member_temp = $this->members_temp_m->get_by('intID',$intID);
        if (! $member_temp) {
            return false;
        }

        $data = [
            'website' => $input['website'],
            'name_p' => $input['name_p'],
            'designation_p' => $input['designation_p'],
            'code_tel_p' => $input['code_tel_p'],
            'telephone_p' => $input['telephone_p'],
            'code_fax_p' => $input['code_fax_p'],
            'fax_p' => $input['fax_p'],
            'email_p' => $input['email_p'],
            'name_s' => $input['name_s'],
            'designation_s' => $input['designation_s'],
            'code_tel_s' => $input['code_tel_s'],
            'telephone_s' => $input['telephone_s'],
            'code_fax_s' => $input['code_fax_s'],
            'fax_s' => $input['fax_s'],
            'email_s' => $input['email_s'],
            'contact_person' => $input['contact_person'],
            'designation' => $input['designation'],
            'code_contact_tel' => $input['code_contact_tel'],
            'contact_tel' => $input['contact_tel'],
            'code_contact_fax' => $input['code_contact_fax'],
            'contact_fax' => $input['contact_fax'],
            'contact_email' => $input['contact_email'],
            'name_f' => $input['name_f'],
            'designation_f' => $input['designation_f'],
            'code_tel_f' => $input['code_tel_f'],
            'telephone_f' => $input['telephone_f'],
            'code_fax_f' => $input['code_fax_f'],
            'fax_f' => $input['fax_f'],
            'email_f' => $input['email_f'],
            'name_last_p' => $input['name_last_p'],
            'name_last_s' => $input['name_last_s'],
            'contact_lname' => $input['contact_lname'],
            'name_last_f' => $input['name_last_f'],
        ];

        return $this->members_temp_m->update($intID, $data);
    }


	/**
	 * method to fetch filtered results for content list
	 * @access public
	 * @return void
	 */
	public function ajax_filter()
	{
		$area = $this->input->post('f_area');
		$status = $this->input->post('f_status');
		$type = $this->input->post('f_type');

		$post_data = array();

		if ($status == 'live' OR $status == 'draft')
		{
			$post_data['status'] = $status;
		}

		if ($type)
		{
			$post_data['type'] = $type;
		}

		if ($area != 0)
		{
			$post_data['area_id'] = $area;
		}

		$results = $this->members_m->search($post_data);

		//set the layout to false and load the view
		$this->template
			->set_layout(FALSE)
			->set('members', $results)
			->build('admin/tables/members');
	}
	
	public function pick($id=0)
	{
		$q = $this->input->get('term');
		$res = $this->members_m->get_many_by_name($q);
		foreach($res as $m)
		{
			$members[] = array('value'=>$m->title, 'id'=>$m->intID);
		}

		echo json_encode($members);
	}

	public function sccpick($id=0)
	{
		$q = $this->input->get('term');
		$res = $this->members_m->get_many_by_name($q);
		foreach($res as $m)
		{
			$members[] = array('value'=>$m->title, 'id'=>$m->intID);
		}

		echo json_encode($members);
	}

	public function lhpick($id=0)
	{
		$q = $this->input->get('term');
		$res = $this->members_m->get_many_by_name($q);

		foreach($res as $m)
		{
			$members[] = array('value'=>$m->title, 'id'=>$m->intID, 'membership_number'=>$m->member_num, 'slug'=>url_title(strtolower($m->title)));
		}

		echo json_encode($members);
	}


	public function delete($id = 0)
	{
		role_or_die('members', 'delete_member');

		// Delete one
		$ids = ($id) ? array($id) : $this->input->post('action_to');

		// Go through the array of slugs to delete
		if ( ! empty($ids))
		{
			$post_titles = array();
			$deleted_ids = array();
			foreach ($ids as $id)
			{
				// Get the current page so we can grab the id too
				if ($post = $this->members_m->get($id))
				{
					if ($this->members_m->delete($id))
					{
						// Wipe cache for this model, the content has changed
						$this->pyrocache->delete('members_m');
						$post_titles[] = $post->name;
						$deleted_ids[] = $id;
					}
				}
			}

			// Fire an event. We've deleted one or more blog posts.
			Events::trigger('member_deleted', $deleted_ids);
		}

		// Some members have been deleted
		if ( ! empty($post_titles))
		{
			// Only deleting one page
			if (count($post_titles) == 1)
			{
				$this->session->set_flashdata('success', sprintf($this->lang->line('members:delete_success'), $post_titles[0]));
			}
			// Deleting multiple pages
			else
			{
				$this->session->set_flashdata('success', sprintf($this->lang->line('members:mass_delete_success'), implode('", "', $post_titles)));
			}
		}
		// For some reason, none of them were deleted
		else
		{
			$this->session->set_flashdata('notice', lang('members:delete_error'));
		}

		redirect('admin/members');
	}

	public function action()
	{
		switch ($this->input->post('btnAction'))
		{
			case 'delete':
				$this->delete();
				break;

			default:
				redirect('admin/members');
				break;
		}
	}

	function check_dir($dir)
	{
		// check directory
		$fileOK = array();
		$fdir = explode('/', $dir);
		$ddir = '';
		for($i=0; $i<count($fdir); $i++)
		{
			$ddir .= $fdir[$i] . '/';
			if (!is_dir($ddir))
			{
				if (!@mkdir($ddir, 0777)) {
					$fileOK[] = 'not_ok';
				}
				else
				{
					$fileOK[] = 'ok';
				}
			}
			else
			{
				$fileOK[] = 'ok';
			}
		}
		return $fileOK;
	}

	function import_csv()
	{
		if(!empty($_FILES['userfile']['tmp_name'])){
		
			$csv = $this->_csv_process($_FILES['userfile']['tmp_name']);
			if ($csv)
			{
				$res = array();
				foreach($csv as $i=>$data)
				{
					if ($data['intID'] && is_numeric($data['intID']))
					{
						$input = array('title'=>$data['company'], 'name'=>$data['company']);
						if ($this->members_m->update($data['intID'], $input))
						{
							$res['ok'][] = $data;
						}
						else
						{
							$res['error'][] = $data;
						}
					}
				}

				$this->template->set('res', $res);
			}
			else
			{
				echo "NO CSV!<br />\n";
			}
		}

		$this->template
			->set('csv', !empty($csv)?$csv:NULL)
			->build('admin/imports/form');
	}

	private function _csv_process($file)
	{
		if (!$file) return false;
		$row = 0;
		$csv = array();

		$header = array(
			'intID',
			'company',
			'member_num',
			'status',
		);

		ini_set('auto_detect_line_endings',TRUE);

		if (($handle = fopen($file, "rb")) !== FALSE) {
			while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
				$num = count($data);

				if ($row===0)
				{
					$row++;
					continue;
				}

				$row++;

				for ($c=0; $c < $num; $c+=4) {
					//if ($row===0) continue;
					$csv[] = array(
						$header[$c] => utf8_encode($data[$c]),
						$header[$c+1] => htmlspecialchars_decode($data[$c+1]), //utf8_encode($data[$c+1]),
						//$header[$c+2] => utf8_encode($data[$c+2]),
						//$header[$c+3] => $data[$c+3],
					);
				}

			}

			fclose($handle);
			unlink($file);

			return $csv;
		}
	}

	function create_soundex()
	{
echo '
<!doctype html>

<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]> <html class="no-js" lang="en"> 		   <![endif]-->

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>Title of the Page</title>

	<!--[if lt IE 9]>
		<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

	<style>
		* html, body, body * {
			font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
		}
		li {padding-bottom: 10px;}
	</style>
	<script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
<script>
$(document).ready(function(){



});
</script>

</head>

<body>

';
		$query = "SELECT intID, title, name FROM default_membership";
		$res = $this->db->query($query);
		if (!$res)
		{
			echo "Failed querying database...";
			exit;
		}
		$members = $res->result(); //$this->members_m->get_all();
		echo "<ol>\n";
		foreach($members as $member)
		{
			$words = preg_split('/((^\p{P}+)|(\p{P}*\s+\p{P}*)|(\p{P}+$))/', $member->title ? $member->title : $member->name, -1, PREG_SPLIT_NO_EMPTY);
			$soundexWords = array();
			foreach ( $words as $word)
			{
				if (strlen($word)<3)
					continue;
				else
					$soundexWords[] = soundex($word);
			}
			$member_soundex = implode(' ', $soundexWords);
			if ($this->_simpleUpdate($member->intID, array('member_soundex'=>$member_soundex)))
				echo "<li>Member <b>" . $member->title . "</b> processed succesfully<br />[$member_soundex]</li>\n";
			else
				echo "<li>Failed processing " . $member->title . " intID: " . $member->intID . "</li>";
		}
		echo "</ol>\n";
echo '


</body>
</html>
';	}

	private function _simpleUpdate($id=0, $input=array())
	{
		//return true;
		if (!$id) return false;
		return $this->db->where('intID', $id)->update('membership', $input);
	}

	public function userdropdown($id=0)
	{
		$this->load->model('users/user_m');
		$users = array(''=>'Please select');
		$group_users = $this->user_m->get_many_by(array('group_id'=>'2'));
		if ($group_users)
		{
			foreach($group_users as $u)
			{
				$users[$u->id] = $u->first_name.' '.$u->last_name;
			}
		}
		return $this->load->view('admin/userdropdown', array('users'=>$users, 'intID'=>$id), TRUE);
	}

	public function newsubsidiaries()
	{
		$mixed = false;

		$query = "SELECT intID,title,status,sub_company FROM `default_membership` where sub_company is not null and (status = 'Approved' OR status = 'Suspended') LIMIT 5";
		$this->db->select("intID,title,type,category,address,address_city,address_state,address_zip,sub_company,telephone,fax,email,country, contact_person, contact_fname,designation,contact_email,contact_tel,name_p,name_last_p,telephone_p,fax_p,email_p,name_s,name_last_s,telephone_s,fax_s,email_s, name_f,name_last_f,telephone_f,fax_f,email_f,approved_date,member_num,status");

		if ($mixed)
			$this->db->where("status = 'Approved' OR status = 'Suspended'");
		else
			$this->db->where("sub_company is not null and (status = 'Approved' OR status = 'Suspended')");

		//$this->db->limit(5);
		$res = $this->db->get('membership')->result();

		#echo "<pre>";

		if ($res)
		{
			foreach($res as $r)
			{
				$subs = unserialize($r->sub_company);
				if (is_array($subs))
				{
					foreach($subs as $s)
					{
						if (!$s['name'])
						{
							$r->subsidiaries = array();
							continue;
						}
						else
						{
							$r->subsidiaries[] = $s['name'];
						}
					}
					//print_r($subs);
					//echo "<hr />\n";
				}
				else
				{
					$r->subsidiaries = array();
				}
			}

			#print_r($res);
			#exit;

			echo '<table width="100%" border="1">'.PHP_EOL;

			// header
			echo "<tr>\n";
			echo "	<th>No.</th><th>Member</th><th>Subsidiaries</th>";
			echo "<th>Country</th><th>Membership No.</th><th>Sector</th><th>Category</th>";
			echo "	<th>Primary Contact</th><th>Primary Phone</th><th>Primary Email</th>";
			echo "	<th>Secondary Contact</th><th>Secondary Phone</th><th>Secondary Email</th>";
			echo "	<th>Finance Contact</th><th>Finance Phone</th><th>Finance Email</th>";
			echo "	<th>Other Contact</th><th>Other Phone</th><th>Other Email</th>";
			echo "	<th>Status</th>";
			echo "	<th>Approved Date</th>";
			echo "\n";
			echo "</tr>\n";

			$i=1;

			if ($mixed)
			{
				foreach($res as $r)
				{
					echo "<tr>\n";
					echo "	<td>".$i."</td>";
					echo "	<td>".$r->title."</td>";
					echo !empty($r->subsidiaries) ? "	<td>".implode("|", $r->subsidiaries)."</td>" : "<td>-</td>";
					echo "	<td>".$r->country."</td>";
					echo "	<td>".$r->member_num."</td>";
					echo "	<td>".$r->type."</td>";
					echo "	<td>".$r->category."</td>";
					echo "	<td>".$r->name_p."</td>";
					echo "	<td>".$r->telephone_p."</td>";
					echo "	<td>".$r->email_p."</td>";
					echo "	<td>".$r->name_s."</td>";
					echo "	<td>".$r->telephone_s."</td>";
					echo "	<td>".$r->email_s."</td>";
					echo "	<td>".$r->name_f."</td>";
					echo "	<td>".$r->telephone_f."</td>";
					echo "	<td>".$r->email_f."</td>";
					echo "	<td>".$r->contact_person."</td>";
					echo "	<td>".$r->contact_tel."</td>";
					echo "	<td>".$r->contact_email."</td>";
					echo "	<td>".$r->status."</td>";
					echo "	<td>".date("d M Y", $r->approved_date)."</td>";
					echo "</tr>\n";
					$i++;
				}
				echo "</table>\n";
			}
			else
			{
				foreach($res as $r)
				{
					if (empty($r->subsidiaries))
					{
						continue;
					}
					else
					{
						echo "<tr>\n";
						echo "	<td>".$i."</td>";
						echo "	<td>".$r->title."</td>";
						echo !empty($r->subsidiaries) ? "	<td>".implode("|", $r->subsidiaries)."</td>" : "<td>-</td>";
						echo "	<td>".$r->country."</td>";
						echo "	<td>".$r->member_num."</td>";
						echo "	<td>".$r->type."</td>";
						echo "	<td>".$r->category."</td>";
						echo "	<td>".$r->name_p."</td>";
						echo "	<td>".$r->telephone_p."</td>";
						echo "	<td>".$r->email_p."</td>";
						echo "	<td>".$r->name_s."</td>";
						echo "	<td>".$r->telephone_s."</td>";
						echo "	<td>".$r->email_s."</td>";
						echo "	<td>".$r->name_f."</td>";
						echo "	<td>".$r->telephone_f."</td>";
						echo "	<td>".$r->email_f."</td>";
						echo "	<td>".$r->contact_person."</td>";
						echo "	<td>".$r->contact_tel."</td>";
						echo "	<td>".$r->contact_email."</td>";
						echo "	<td>".$r->status."</td>";
						echo "	<td>".date("d M Y", $r->approved_date)."</td>";
						echo "</tr>\n";
						$i++;
					}
				}
				echo "</table>\n";
			}
		}

	}

	public function subsidiaries()
	{
		$mixed = false;

		$query = "SELECT intID,title,status,sub_company FROM `default_membership` where sub_company is not null and (status = 'Approved' OR status = 'Suspended') LIMIT 5";
		$this->db->select("intID,title,type,category,address,address_city,address_state,address_zip,sub_company,telephone,fax,email,country, contact_person, contact_fname,designation,contact_email,contact_tel,name_p,name_last_p,telephone_p,fax_p,email_p,name_s,name_last_s,telephone_s,fax_s,email_s, name_f,name_last_f,telephone_f,fax_f,email_f,approved_date,member_num,status");

		if ($mixed)
			$this->db->where("status = 'Approved' OR status = 'Suspended'");
		else
			$this->db->where("sub_company is not null and (status = 'Approved' OR status = 'Suspended')");

		//$this->db->limit(5);
		$res = $this->db->get('membership')->result();

		#echo "<pre>";

		if ($res)
		{
			foreach($res as $r)
			{
				$subs = unserialize($r->sub_company);
				if (is_array($subs))
				{
					foreach($subs as $s)
					{
						if (!$s['name'])
						{
							$r->subsidiaries = array();
							continue;
						}
						else
						{
							$r->subsidiaries[] = $s['name'];
						}
					}
					//print_r($subs);
					//echo "<hr />\n";
				}
				else
				{
					$r->subsidiaries = array();
				}
			}

			#print_r($res);
			#exit;

			echo '<table width="100%" border="1">'.PHP_EOL;

			// header
			echo "<tr>\n";
			echo "	<th>No.</th><th>Member</th><th>Subsidiaries</th>";
			echo "<th>Country</th><th>Membership No.</th><th>Sector</th><th>Category</th>";
			echo "	<th>Primary Contact</th><th>Primary Phone</th><th>Primary Email</th>";
			echo "	<th>Secondary Contact</th><th>Secondary Phone</th><th>Secondary Email</th>";
			echo "	<th>Finance Contact</th><th>Finance Phone</th><th>Finance Email</th>";
			echo "	<th>Other Contact</th><th>Other Phone</th><th>Other Email</th>";
			echo "	<th>Status</th>";
			echo "	<th>Approved Date</th>";
			echo "\n";
			echo "</tr>\n";

			$i=1;

			if ($mixed)
			{
				foreach($res as $r)
				{
					echo "<tr>\n";
					echo "	<td>".$i."</td>";
					echo "	<td>".$r->title."</td>";
					echo !empty($r->subsidiaries) ? "	<td>".implode("|", $r->subsidiaries)."</td>" : "<td>-</td>";
					echo "	<td>".$r->country."</td>";
					echo "	<td>".$r->member_num."</td>";
					echo "	<td>".$r->type."</td>";
					echo "	<td>".$r->category."</td>";
					echo "	<td>".$r->name_p."</td>";
					echo "	<td>".$r->telephone_p."</td>";
					echo "	<td>".$r->email_p."</td>";
					echo "	<td>".$r->name_s."</td>";
					echo "	<td>".$r->telephone_s."</td>";
					echo "	<td>".$r->email_s."</td>";
					echo "	<td>".$r->name_f."</td>";
					echo "	<td>".$r->telephone_f."</td>";
					echo "	<td>".$r->email_f."</td>";
					echo "	<td>".$r->contact_person."</td>";
					echo "	<td>".$r->contact_tel."</td>";
					echo "	<td>".$r->contact_email."</td>";
					echo "	<td>".$r->status."</td>";
					echo "	<td>".date("d M Y", $r->approved_date)."</td>";
					echo "</tr>\n";
					$i++;
				}
				echo "</table>\n";
			}
			else
			{
				foreach($res as $r)
				{
					if (empty($r->subsidiaries))
					{
						continue;
					}
					else
					{
						echo "<tr>\n";
						echo "	<td>".$i."</td>";
						echo "	<td>".$r->title."</td>";
						echo !empty($r->subsidiaries) ? "	<td>".implode("|", $r->subsidiaries)."</td>" : "<td>-</td>";
						echo "	<td>".$r->country."</td>";
						echo "	<td>".$r->member_num."</td>";
						echo "	<td>".$r->type."</td>";
						echo "	<td>".$r->category."</td>";
						echo "	<td>".$r->name_p."</td>";
						echo "	<td>".$r->telephone_p."</td>";
						echo "	<td>".$r->email_p."</td>";
						echo "	<td>".$r->name_s."</td>";
						echo "	<td>".$r->telephone_s."</td>";
						echo "	<td>".$r->email_s."</td>";
						echo "	<td>".$r->name_f."</td>";
						echo "	<td>".$r->telephone_f."</td>";
						echo "	<td>".$r->email_f."</td>";
						echo "	<td>".$r->contact_person."</td>";
						echo "	<td>".$r->contact_tel."</td>";
						echo "	<td>".$r->contact_email."</td>";
						echo "	<td>".$r->status."</td>";
						echo "	<td>".date("d M Y", $r->approved_date)."</td>";
						echo "</tr>\n";
						$i++;
					}
				}
				echo "</table>\n";
			}
		}

	}

	public function get_region($country)
    {
	    //$country = $this->input->post('c');

//echo "\$country: $country\n";
//print_r($this->region_country);

	    if ($country && !empty($this->country_arrays_un[$country]))
	    {
            exit(json_encode(['status' => true, 'data' => $this->country_arrays_un[$country]]));
	    }
	    else
	    {
            exit(json_encode(['status' => false]));
	    }

/*
        if (isset($this->region_country[$_POST['country']])) {
            echo json_encode(['status' => true, 'data' => $this->region_country[$_POST['country']]]);
        } else {
            echo json_encode(['status' => false]);
        }
*/
    }

    public function countrycode($country)
    {

        if ($country)
        {
            foreach ($this->country_list as $key => $val) {
                $country_code = array_search(urldecode($country), $val);
                if ($country_code !== false) {
                    exit(strtolower($country_code));
                }
            }
        }
//
//        $countries = array(
//            "Afghanistan" => "af",
//            "Åland Islands" => "ax",
//            "Albania" => "al",
//            "Algeria" => "dz",
//            "American Samoa" => "as",
//            "Andorra" => "ad",
//            "Angola" => "ao",
//            "Anguilla" => "ai",
//            "Antarctica" => "aq",
//            "Antigua And Barbuda" => "ag",
//            "Argentina" => "ar",
//            "Armenia" => "am",
//            "Aruba" => "aw",
//            "Australia" => "au",
//            "Austria" => "at",
//            "Azerbaijan" => "az",
//            "Bahamas" => "bs",
//            "Bahrain" => "bh",
//            "Bangladesh" => "bd",
//            "Barbados" => "bb",
//            "Belarus" => "by",
//            "Belgium" => "be",
//            "Belize" => "bz",
//            "Benin" => "bj",
//            "Bermuda" => "bm",
//            "Bhutan" => "bt",
//            "Bolivia, Plurinational State Of" => "bo",
//            "Bonaire, Sint Eustatius And Saba" => "bq",
//            "Bosnia And Herzegovina" => "ba",
//            "Botswana" => "bw",
//            "Bouvet Island" => "bv",
//            "Brazil" => "br",
//            "British Indian Ocean Territory" => "io",
//            "Brunei Darussalam" => "bn",
//            "Bulgaria" => "bg",
//            "Burkina Faso" => "bf",
//            "Burundi" => "bi",
//            "Cambodia" => "kh",
//            "Cameroon" => "cm",
//            "Canada" => "ca",
//            "Cape Verde" => "cv",
//            "Cayman Islands" => "ky",
//            "Central African Republic" => "cf",
//            "Chad" => "td",
//            "Chile" => "cl",
//            "China" => "cn",
//            "Christmas Island" => "cx",
//            "Cocos (keeling) Islands" => "cc",
//            "Colombia" => "co",
//            "Comoros" => "km",
//            "Congo" => "cg",
//            "Congo, The Democratic Republic Of The" => "cd",
//            "Cook Islands" => "ck",
//            "Costa Rica" => "cr",
//            "Côte D'ivoire" => "ci",
//            "Croatia" => "hr",
//            "Cuba" => "cu",
//            "Curaçao" => "cw",
//            "Cyprus" => "cy",
//            "Czech Republic" => "cz",
//            "Denmark" => "dk",
//            "Djibouti" => "dj",
//            "Dominica" => "dm",
//            "Dominican Republic" => "do",
//            "Ecuador" => "ec",
//            "Egypt" => "eg",
//            "El Salvador" => "sv",
//            "Equatorial Guinea" => "gq",
//            "Eritrea" => "er",
//            "Estonia" => "ee",
//            "Ethiopia" => "et",
//            "Falkland Islands (malvinas)" => "fk",
//            "Faroe Islands" => "fo",
//            "Fiji" => "fj",
//            "Finland" => "fi",
//            "France" => "fr",
//            "French Guiana" => "gf",
//            "French Polynesia" => "pf",
//            "French Southern Territories" => "tf",
//            "Gabon" => "ga",
//            "Gambia" => "gm",
//            "Georgia" => "ge",
//            "Germany" => "de",
//            "Ghana" => "gh",
//            "Gibraltar" => "gi",
//            "Greece" => "gr",
//            "Greenland" => "gl",
//            "Grenada" => "gd",
//            "Guadeloupe" => "gp",
//            "Guam" => "gu",
//            "Guatemala" => "gt",
//            "Guernsey" => "gg",
//            "Guinea" => "gn",
//            "Guinea-bissau" => "gw",
//            "Guyana" => "gy",
//            "Haiti" => "ht",
//            "Heard Island And Mcdonald Islands" => "hm",
//            "Holy See (vatican City State)" => "va",
//            "Honduras" => "hn",
//            "Hong Kong" => "hk",
//            "Hungary" => "hu",
//            "Iceland" => "is",
//            "India" => "in",
//            "Indonesia" => "id",
//            "Iran, Islamic Republic Of" => "ir",
//            "Iraq" => "iq",
//            "Ireland" => "ie",
//            "Isle Of Man" => "im",
//            "Israel" => "il",
//            "Italy" => "it",
//            "Jamaica" => "jm",
//            "Japan" => "jp",
//            "Jersey" => "je",
//            "Jordan" => "jo",
//            "Kazakhstan" => "kz",
//            "Kenya" => "ke",
//            "Kiribati" => "ki",
//            "North Korea" => "kp",
//            "South Korea" => "kr",
//            "Kuwait" => "kw",
//            "Kyrgyzstan" => "kg",
//            "Lao People's Democratic Republic" => "la",
//            "Latvia" => "lv",
//            "Lebanon" => "lb",
//            "Lesotho" => "ls",
//            "Liberia" => "lr",
//            "Libya" => "ly",
//            "Liechtenstein" => "li",
//            "Lithuania" => "lt",
//            "Luxembourg" => "lu",
//            "Macao" => "mo",
//            "Macedonia, The Former Yugoslav Republic Of" => "mk",
//            "Madagascar" => "mg",
//            "Malawi" => "mw",
//            "Malaysia" => "my",
//            "Maldives" => "mv",
//            "Mali" => "ml",
//            "Malta" => "mt",
//            "Marshall Islands" => "mh",
//            "Martinique" => "mq",
//            "Mauritania" => "mr",
//            "Mauritius" => "mu",
//            "Mayotte" => "yt",
//            "Mexico" => "mx",
//            "Micronesia, Federated States Of" => "fm",
//            "Moldova, Republic Of" => "md",
//            "Monaco" => "mc",
//            "Mongolia" => "mn",
//            "Montenegro" => "me",
//            "Montserrat" => "ms",
//            "Morocco" => "ma",
//            "Mozambique" => "mz",
//            "Myanmar" => "mm",
//            "Namibia" => "na",
//            "Nauru" => "nr",
//            "Nepal" => "np",
//            "Netherlands" => "nl",
//            "New Caledonia" => "nc",
//            "New Zealand" => "nz",
//            "Nicaragua" => "ni",
//            "Niger" => "ne",
//            "Nigeria" => "ng",
//            "Niue" => "nu",
//            "Norfolk Island" => "nf",
//            "Northern Mariana Islands" => "mp",
//            "Norway" => "no",
//            "Oman" => "om",
//            "Pakistan" => "pk",
//            "Palau" => "pw",
//            "Palestinian Territory, Occupied" => "ps",
//            "Panama" => "pa",
//            "Papua New Guinea" => "pg",
//            "Paraguay" => "py",
//            "Peru" => "pe",
//            "Philippines" => "ph",
//            "Pitcairn" => "pn",
//            "Poland" => "pl",
//            "Portugal" => "pt",
//            "Puerto Rico" => "pr",
//            "Qatar" => "qa",
//            "Réunion" => "re",
//            "Romania" => "ro",
//            "Russian Federation" => "ru",
//            "Rwanda" => "rw",
//            "Saint Barthélemy" => "bl",
//            "Saint Helena, Ascension And Tristan Da Cunha" => "sh",
//            "Saint Kitts And Nevis" => "kn",
//            "Saint Lucia" => "lc",
//            "Saint Martin (french Part)" => "mf",
//            "Saint Pierre And Miquelon" => "pm",
//            "Saint Vincent And The Grenadines" => "vc",
//            "Samoa" => "ws",
//            "San Marino" => "sm",
//            "Sao Tome And Principe" => "st",
//            "Saudi Arabia" => "sa",
//            "Senegal" => "sn",
//            "Serbia" => "rs",
//            "Seychelles" => "sc",
//            "Sierra Leone" => "sl",
//            "Singapore" => "sg",
//            "Sint Maarten (dutch Part)" => "sx",
//            "Slovakia" => "sk",
//            "Slovenia" => "si",
//            "Solomon Islands" => "sb",
//            "Somalia" => "so",
//            "South Africa" => "za",
//            "South Georgia And The South Sandwich Islands" => "gs",
//            "South Sudan" => "ss",
//            "Spain" => "es",
//            "Sri Lanka" => "lk",
//            "Sudan" => "sd",
//            "Suriname" => "sr",
//            "Svalbard And Jan Mayen" => "sj",
//            "Swaziland" => "sz",
//            "Sweden" => "se",
//            "Switzerland" => "ch",
//            "Syrian Arab Republic" => "sy",
//            "Taiwan" => "tw",
//            "Tajikistan" => "tj",
//            "Tanzania, United Republic Of" => "tz",
//            "Thailand" => "th",
//            "Timor-leste" => "tl",
//            "Togo" => "tg",
//            "Tokelau" => "tk",
//            "Tonga" => "to",
//            "Trinidad And Tobago" => "tt",
//            "Tunisia" => "tn",
//            "Turkey" => "tr",
//            "Turkmenistan" => "tm",
//            "Turks And Caicos Islands" => "tc",
//            "Tuvalu" => "tv",
//            "Uganda" => "ug",
//            "Ukraine" => "ua",
//            "United Arab Emirates" => "ae",
//            "United Kingdom" => "gb",
//            "United States" => "us",
//            "United States Minor Outlying Islands" => "um",
//            "Uruguay" => "uy",
//            "Uzbekistan" => "uz",
//            "Vanuatu" => "vu",
//            "Venezuela, Bolivarian Republic Of" => "ve",
//            "Vietnam" => "vn",
//            "Virgin Islands, British" => "vg",
//            "Virgin Islands, U.S." => "vi",
//            "Wallis And Futuna" => "wf",
//            "Western Sahara" => "eh",
//            "Yemen" => "ye",
//            "Zambia" => "zm",
//            "Zimbabwe" => "zw"
//        );
//
//        //$c = $this->input->post('c');
//        if ($country && isset($countries[urldecode($country)])) {
//            echo $countries[urldecode($country)];
//        }
    }

	public function countrydiff()
	{
		$array1 = $this->region_country;
		$array2 = $this->config->item('country_arrays');
		$result = array_diff($array1, $array2);
		echo "<pre>";
		print_r($result);
		echo "<hr />\n";
		$result = array_diff($array2, $array1);
		echo "<pre>";
		print_r($result);
	}

	public function userunlink()
	{
		$memberid = $this->input->post('memberid');
		if ($memberid)
		{
			$step_msg = 'Error unlinking user to member.';
			$res = $this->members_m->update($memberid, array('MemberID_2'=>0));
			if ($res)
			{
				return $this->template->build_json(array(
					'status' 	=> 'ok',
					'msg'		=> 'Member was unlinked successfully.',
					'html'		=> $this->userdropdown($memberid),
				));
			}
			else
			{
				return $this->template->build_json(array(
					'status' 	=> 'error',
					'msg'		=> "Sorry there was an error unlinking the user.\nPlease try again or report this to the developer.",
					'debug'		=> $this->db->error()['message'],
				));
			}
		}
		else
		{
			return $this->template->build_json(array(
				'status' 	=> 'error',
				'msg'		=> "Sorry, could not identify which member to unlink."
			));
		}
	}
        
        
    public function import_excel() {

        $upload_cfg = array(
            'allowed_types' => 'xlsx',
            'max_size' => '10000',
            'remove_spaces' => true,
            'overwrite' => false,
            'encrypt_name' => false,
        );

        //$this->load->library('phpexcel');
        $this->load->library('PHPExcel');
        $this->load->model('subsidiaries_m');

        $output = $csv = null;


        if (!empty($_POST)) {
            if (!empty($_FILES['csv_file']['name']) && !empty($_FILES['csv_file']['tmp_name'])) {
                try {

                    $objPHPExcel = PHPExcel_IOFactory::load($_FILES['csv_file']['tmp_name']);
                } catch (Exception $e) {
                    $this->resp->success = false;
                    $this->resp->msg = 'Error Uploading file';
                    echo json_encode($this->resp);
                    exit;
                }

                $csv = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
                if ($csv) {
                    $subsidiaries = [];
                    $members = [];
                    $member = [];
                    
                    foreach ($csv as $key => $value) {
                        if ($key > 1) { //check if not header
                            
                            if($value['A'] != '') {
                                if(count($member) > 0){
                                    $members[] = $member;
                                }
                                $member = [];
                                $member['intID'] = $value['A'];
                                $member['application_sf_id'] = $value['B'];
                                $member['name'] = $value['C'];
                                $member['status'] = $value['E'];
                                $member['member_num'] = $value['F'];
                                $member['type'] = $value['G'];
                                $member['category'] = $value['H'];
                            }
                            if ($value['D'] != '') {
                                $subsidiary = [];
                                $subsidiary['intID'] = $member['intID'];
                                $subsidiary['member_intID'] = $member['intID'];
                                $subsidiary['name'] = $value['D'];
                                $subsidiary['type'] = 'subsidiary';
                                $subsidiaries[] = $subsidiary;
                                
                                //delete subsidiary list with intID
                                
                                $this->subsidiaries_m->delete_by_intID($member['intID']);
                            }
                        }
                    }
                    if (count($member) > 0) {
                        $members[] = $member;
                    }
                    
                    $this->members_m->update_members($members);
                    foreach ($subsidiaries as $subsidiary) {
                        $this->subsidiaries_m->insert($subsidiary);
                    }

                    $status = 'success';
                    $status_message = 'Importing Excel was successful';

                    $this->session->set_flashdata($status, $status_message);
                    redirect('admin/members/import_excel');
                    
                } else {
                    $messages['error'] = 'Unable to process the CSV. Please make sure the file you uploaded is in recognisable XL format.';
                    $this->template->set('messages', $messages);
                }
            } else {
                $messages['error'] = 'Please upload the CSV file to import';
                $this->template->set('messages', $messages);
            }
        }

        if (!empty($input_company))
            $output = $input_company;

        $this->template
                ->set('csv', !empty($csv) ? $csv : NULL)
                ->build('admin/imports/form');
    }

	public function extractmembers()
	{
		$mixed = false;

		//$this->db->select("intID,title,type,category,address,address_city,address_state,address_zip,sub_company,telephone,fax,email,country, contact_person, contact_fname,designation,contact_email,contact_tel,name_p,name_last_p,telephone_p,fax_p,email_p,name_s,name_last_s,telephone_s,fax_s,email_s, name_f,name_last_f,telephone_f,fax_f,email_f,approved_date,member_num,status");

		$this->db->where('status', 'Approved')->order_by('title');

		//$this->db->limit(5);
		$res = $this->db->get('membership')->result();

		#echo "<pre>";

		if ($res)
		{

			echo '
<!doctype html>

		<head>
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
		
		    <title>Members Extract</title>
		
			<!--[if lt IE 9]>
				<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<![endif]-->
		
			<style>
				*, html {
					font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
				}
			</style>
			<script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
		<script>
		$(document).ready(function(){



		});
		</script>

		</head>

		<body>

';


			echo '<table width="100%" border="1">'.PHP_EOL;

			// header
			echo "<tr>\n";
			echo "	<th>No.</th><th>intID</th><th>Member</th>";
			echo "<th>Country</th><th>Membership No.</th><th>Sector</th><th>Category</th>";
			echo "	<th>Primary Contact</th><th>Primary Phone</th><th>Primary Email</th>";
			echo "	<th>Secondary Contact</th><th>Secondary Phone</th><th>Secondary Email</th>";
			echo "	<th>Finance Contact</th><th>Finance Phone</th><th>Finance Email</th>";
			echo "	<th>Other Contact</th><th>Other Phone</th><th>Other Email</th>";
			echo "	<th>Status</th>";
			echo "	<th>Approved Date</th>";
			echo "\n";
			echo "</tr>\n";

			$i=1;

			foreach($res as $r)
			{
				echo "<tr>\n";
				echo "	<td>".$i."</td>";
				echo "	<td>".$r->intID."</td>";
				echo "	<td>".$r->title."</td>";
				//echo !empty($r->subsidiaries) ? "	<td>".implode("|", $r->subsidiaries)."</td>" : "<td>-</td>";
				echo "	<td>".$r->country."</td>";
				echo "	<td>".$r->member_num."</td>";
				echo "	<td>".$r->type."</td>";
				echo "	<td>".$r->category."</td>";
				echo "	<td>".$r->name_p.' '.$r->name_last_p."</td>";
				echo "	<td>".$r->telephone_p."</td>";
				echo "	<td>".$r->email_p."</td>";
				echo "	<td>".$r->name_s.' '.$r->name_last_s."</td>";
				echo "	<td>".$r->telephone_s."</td>";
				echo "	<td>".$r->email_s."</td>";
				echo "	<td>".$r->name_f.' '.$r->name_last_f."</td>";
				echo "	<td>".$r->telephone_f."</td>";
				echo "	<td>".$r->email_f."</td>";
				echo "	<td>".$r->contact_person.' '.$r->contact_lname."</td>";
				echo "	<td>".$r->contact_tel."</td>";
				echo "	<td>".$r->contact_email."</td>";
				echo "	<td>".$r->status."</td>";
				echo "	<td>".date("d M Y", $r->approved_date)."</td>";
				echo "</tr>\n";
				$i++;
			}

			echo "</table>\n";

		}

echo '

</body>
</html>
';

	}


	// list all subsidiaries in the database
	public function getsubsidiaries()
	{
		$mixed = false;

		//$this->db->select("intID,title,type,category,address,address_city,address_state,address_zip,sub_company,telephone,fax,email,country, contact_person, contact_fname,designation,contact_email,contact_tel,name_p,name_last_p,telephone_p,fax_p,email_p,name_s,name_last_s,telephone_s,fax_s,email_s, name_f,name_last_f,telephone_f,fax_f,email_f,approved_date,member_num,status");

		$this->db->select('membership_subsidiaries.*, membership.title');
		$this->db->where('membership.survey', '1')->order_by('member_intID');

		$this->db->join('membership', 'membership.intID = membership_subsidiaries.member_intID');

		//$this->db->limit(5);
		$res = $this->db->get('membership_subsidiaries')->result();

		#echo "<pre>";

		if ($res)
		{

			echo '
<!doctype html>

		<head>
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
		
		    <title>Members Extract</title>
		
			<!--[if lt IE 9]>
				<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<![endif]-->
		
			<style>
				*, html {
					font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
				}
			</style>
			<script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
		<script>
		$(document).ready(function(){



		});
		</script>

		</head>

		<body>

';


			echo '<table width="100%" border="1">'.PHP_EOL;

			// header
			echo "<tr>\n";
			echo "	<th>No.</th>";
			echo "	<th>Parent intID</th>";
			echo "	<th>Parent Company</th>";
			echo "	<th>GM Name</th>";
			echo "	<th>GM Type</th>";
			echo "	<th>Nature of Business</th>";
			echo "	<th>Country</th>";
			echo "	<th>Region</th>";
			echo "	<th>Membership No.</th>";
			echo "	<th>Contact</th>";
			echo "	<th>Contact Phone</th>";
			echo "	<th>Contact Email</th>";
			echo "	<th>Last update</th>";
			echo "\n";
			echo "</tr>\n";

			$i=1;

			foreach($res as $r)
			{
				echo "<tr>\n";
				echo "	<td>".$i."</td>";
				echo "	<td>".$r->member_intID."</td>";
				echo "	<td>".$r->title."</td>";
				echo "	<td>".$r->name."</td>";

				if (strtolower($r->type)=='other')
					echo "	<td>Other: ".$r->other_type."</td>";
				else
					echo "	<td>".humanize($r->type)."</td>";

				echo "	<td>".$r->nature_of_business."</td>";

				echo "	<td>".$r->country."</td>";
				echo "	<td>".$r->region."</td>";
				echo "	<td>".$r->rspo_membership_num."</td>";

				echo "	<td>".$r->firstname.' '.$r->lastname."</td>";
				echo "	<td> ".$r->phone."</td>";
				echo "	<td>".$r->email."</td>";
				echo "	<td>".($r->updated_on?date("d M Y", $r->updated_on):' -')."</td>";
				echo "</tr>\n";
				$i++;
			}

			echo "</table>\n";

		}

echo '

</body>
</html>
';

	}
}