<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends Admin_Controller
{
	protected $section = 'scc';

	protected $validation_rules = array(

		array(
			'field' => 'facility',
			'label' => 'lang:scc:facility_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'mid',
			'label' => 'lang:scc:mill_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'member_name',
			'label' => 'lang:scc:member_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'supply_option',
			'label' => 'lang:scc:supply_option_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'application_date',
			'label' => 'lang:scc:application_date_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'approval_date',
			'label' => 'lang:scc:approval_date_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'certification_expiry_date',
			'label' => 'lang:scc:expiry_date_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'file',
			'label' => 'lang:scc:files_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'file_2',
			'label' => 'lang:scc:files_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'file_3',
			'label' => 'lang:scc:files_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'file_text_1',
			'label' => 'lang:scc:files_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'file_text_2',
			'label' => 'lang:scc:files_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'file_text_3',
			'label' => 'lang:scc:files_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'online_status',
			'label' => 'lang:scc:status_label',
			'rules' => 'trim|required'
		),
	);

	protected $upload_cfg = array(
		'allowed_types'		=> 'jpg|gif|png|jpeg|pdf',
		'max_size'			=> '10000',
		'remove_spaces'		=> TRUE,
		'overwrite'			=> FALSE,
		'encrypt_name'		=> FALSE,
	);

	protected $supply_options = array(
		'Book &amp; Claim'	=> 'Book &amp; Claim',
		'Mass Balance'		=> 'Mass Balance',
		'Segregated'		=> 'Segregated',
		'Identity Preserved'=> 'Identity Preserved',
	);

	public function __construct()
	{
		parent::__construct();
		$this->load->model(array('members_m', 'scc_m'));
		$this->lang->load(array('members', 'scc'));

		$this->upload_cfg['upload_path'] = UPLOAD_PATH . 'scc';
	}

	public function index()
	{
		//set the base/default where clause
		$base_where = array('status' => 'all');//, 'order'=>'created_on', 'sort'=>'desc');

		$base_where['keywords'] = $this->input->post('f_keywords') ? $this->input->post('f_keywords') : NULL;

		// Create pagination links
		$total_rows = $this->scc_m->count_by($base_where);
		$pagination = create_pagination('admin/members/scc/index', $total_rows, NULL, 5);

		$base_where['limit'] = array($pagination['limit'], $pagination['offset']);

		// Using this data, get the relevant results
		$sccs = $this->scc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);

		//do we need to unset the layout because the request is ajax?
		$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

		$this->template
			->title($this->module_details['name'])
			->append_js('admin/filter.js')
			->set('count', $total_rows)
			->set('pagination', $pagination)
			->set('sccs', $sccs);

		$this->input->is_ajax_request() ? $this->template->build('admin/scc/tables/scc') : $this->template->build('admin/scc/index');
	}

	public function create($mid=0)
	{
		$scc = new stdClass();

		if ($mid)
		{
			$member = $this->members_m->get_by('intID', $mid);
			if (!empty($member))
			{
				$this->template
					->set('member_name', $member->title)
					->set('member_id', $member->intID);
			}
		}

		$this->form_validation->set_rules($this->validation_rules);


		if ($this->input->post('application_date'))
		{
			$application_date = strtotime(sprintf('%s %s:%s', $this->input->post('application_date'), 0, 0));
		}
		else
		{
			$application_date = 0;
		}

		if ($this->input->post('approval_date'))
		{
			$approval_date = strtotime(sprintf('%s %s:%s', $this->input->post('approval_date'), 0, 0));
		}
		else
		{
			$approval_date = 0;
		}

		if ($this->input->post('certification_expiry_date'))
		{
			$certification_expiry_date = strtotime(sprintf('%s %s:%s', $this->input->post('certification_expiry_date'), 0, 0));
		}
		else
		{
			$certification_expiry_date = 0;
		}

		$isUp = $this->input->post('online_status') == 'live' ? '1' : '0';

		// check directory exists
		$this->check_dir($this->upload_cfg['upload_path']);
		$this->load->library('upload', $this->upload_cfg);

		if (!empty($_FILES['file']['name']) )
		{
			if($this->upload->do_upload("file"))
			{
				$uploaded = $this->upload->data();
				$file = $uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$file = $this->input->post('file_text_1');
		}

		if (!empty($_FILES['file_2']['name']) )
		{
			if($this->upload->do_upload("file_2"))
			{
				$uploaded = $this->upload->data();
				$file_2 = $uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$file_2 = $this->input->post('file_text_2');
		}

		if (!empty($_FILES['file_3']['name']) )
		{
			if($this->upload->do_upload("file_3"))
			{
				$uploaded = $this->upload->data();
				$file_3 = $uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$file_3 = $this->input->post('file_text_3');
		}

/*
echo "\$file: $file; \$file_2: $file_2; \$file_3: $file_3; <br />\n";
exit;
*/

		if ($this->input->post('remove_file'))
		{
			$remove = $this->input->post('remove_file');
			if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$remove) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$remove))
			{
				$file = NULL;
			}
			else
			{
				$this->session->set_flashdata('info', 'Error deleting file '.$remove);
			}
		}

		if ($this->input->post('remove_file_2'))
		{
			$remove = $this->input->post('remove_file_2');
			if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$remove) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$remove))
			{
				$file_2 = NULL;
			}
			else
			{
				$this->session->set_flashdata('info', 'Error deleting file '.$remove);
			}
		}

		if ($this->input->post('remove_file_3'))
		{
			$remove = $this->input->post('remove_file_3');
			if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$remove) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$remove))
			{
				$file_3 = NULL;
			}
			else
			{
				$this->session->set_flashdata('info', 'Error deleting file '.$remove);
			}
		}

		if ($this->form_validation->run())
		{
			$input = array(
				'strModifyDate'		=> now(),
				'strModifyPerson'	=> $this->current_user->id,
				'mid'				=> $this->input->post('member_id'),
				'facility'			=> $this->input->post('facility'),
				'isUp'				=> $isUp,
				'supply_option'		=> $this->input->post('supply_options') ? implode("\r\n", $this->input->post('supply_options')) : NULL,
				'application_date'	=> $application_date,
				'approval_date'		=> $approval_date,
				'certification_expiry_date'	=> $certification_expiry_date,
				'file'				=> $file,
				'file_2'			=> $file_2,
				'file_3'			=> $file_3,
				'date'				=> now(),
			);

			if ($id = $this->scc_m->insert($input))
			{
				$this->pyrocache->delete_all('scc_m');
				$this->session->set_flashdata(array('success' => sprintf(lang('scc:create_success'), $this->input->post('member_name'))));
				($this->input->post('btnAction') == 'save_exit') ? redirect('admin/members/scc') : redirect('admin/members/scc/edit/'.$id);
			}
			else
			{
				//$this->session->set_flashdata(array('error' => sprintf(lang('scc:create_error'), $this->input->post('member_name'))));
				$this->template->set('error', sprintf(lang('scc:create_error'), $this->input->post('member_name')) );
			}

			// Redirect back to the form or main page
		}

		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $key => $field)
		{
			if ($field['field'] != 'file' AND $field['field'] != 'file_2' AND $field['field'] != 'file_3')
				$scc->$field['field'] = set_value($field['field']);
		}

		$scc->application_date 			= $application_date;
		$scc->approval_date 			= $approval_date;
		$scc->certification_expiry_date = $certification_expiry_date;
		$scc->mid 						= $this->input->post('member_id');
		$scc->file 						= $file;
		$scc->file_2 					= $file_2;
		$scc->file_3 					= $file_3;
		$scc->file_text_1 				= $file;
		$scc->file_text_2 				= $file_2;
		$scc->file_text_3 				= $file_3;
		$scc->supply_option 			= $this->input->post('supply_options') ? implode("\r\n", $this->input->post('supply_options')) : NULL;

		$scc->isUp = $isUp;

		$this->template
			//->append_metadata($this->load->view('fragments/wysiwyg', array(), TRUE))
			->set('supply_options', $this->supply_options)
			->set('scc', $scc)
			->build('admin/scc/form');
	}
	

	public function edit($id=0)
	{
		$id OR redirect('members/admin/scc');

		$scc = $this->scc_m->get($id);

		$this->form_validation->set_rules($this->validation_rules);


		if ($this->input->post('application_date'))
		{
			$application_date = strtotime(sprintf('%s %s:%s', $this->input->post('application_date'), 0, 0));
		}
		else
		{
			$application_date = $scc->application_date;
		}

		if ($this->input->post('approval_date'))
		{
			$approval_date = strtotime(sprintf('%s %s:%s', $this->input->post('approval_date'), 0, 0));
		}
		else
		{
			$approval_date = $scc->approval_date;
		}

		if ($this->input->post('certification_expiry_date'))
		{
			$certification_expiry_date = strtotime(sprintf('%s %s:%s', $this->input->post('certification_expiry_date'), 0, 0));
		}
		else
		{
			$certification_expiry_date = $scc->certification_expiry_date;;
		}

		$isUp = $this->input->post('online_status') == 'live' ? '1' : $scc->isUp;

		// check directory exists
		$this->check_dir($this->upload_cfg['upload_path']);
		$this->load->library('upload', $this->upload_cfg);

		if (!empty($_FILES['file']['name']) )
		{
			if($this->upload->do_upload("file"))
			{
				$uploaded = $this->upload->data();
				$file = $uploaded['file_name'];
				$this->remove_file($this->input->post('file_text_1'));
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$file = $scc->file;
		}

		if (!empty($_FILES['file_2']['name']) )
		{
			if($this->upload->do_upload("file_2"))
			{
				$uploaded = $this->upload->data();
				$file_2 = $uploaded['file_name'];
				$this->remove_file($this->input->post('file_text_2'));
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$file_2 = $scc->file_2;
		}

		if (!empty($_FILES['file_3']['name']) )
		{
			if($this->upload->do_upload("file_3"))
			{
				$uploaded = $this->upload->data();
				$file_3 = $uploaded['file_name'];
				$this->remove_file($this->input->post('file_text_3'));
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$file_3 = $scc->file_3;
		}

/*
echo "\$file: $file; \$file_2: $file_2; \$file_3: $file_3; <br />\n";
exit;
*/

		if ($this->input->post('remove_file'))
		{
			$remove = $this->input->post('remove_file');
			if ( $this->remove_file($remove) )
			{
				$file = NULL;
			}
			else
			{
				$this->session->set_flashdata('info', 'Error deleting file '.$remove);
			}
		}

		if ($this->input->post('remove_file_2'))
		{
			$remove = $this->input->post('remove_file_2');
			if ( $this->remove_file($remove) )
			{
				$file_2 = NULL;
			}
			else
			{
				$this->session->set_flashdata('info', 'Error deleting file '.$remove);
			}
		}

		if ($this->input->post('remove_file_3'))
		{
			$remove = $this->input->post('remove_file_3');
			if ( $this->remove_file($remove) )
			{
				$file_3 = NULL;
			}
			else
			{
				$this->session->set_flashdata('info', 'Error deleting file '.$remove);
			}
		}

		if ($this->form_validation->run())
		{
			$input = array(
				'strAddDate'		=> now(),
				'strAddPerson'		=> $this->current_user->id,
				'mid'				=> $this->input->post('member_id'),
				'facility'			=> $this->input->post('facility'),
				'isUp'				=> $isUp,
				'supply_option'		=> $this->input->post('supply_options') ? implode("\r\n", $this->input->post('supply_options')) : NULL,
				'application_date'	=> $application_date,
				'approval_date'		=> $approval_date,
				'certification_expiry_date'	=> $certification_expiry_date,
				'file'				=> $file,
				'file_2'			=> $file_2,
				'file_3'			=> $file_3,
				'date'				=> now(),
			);

			if ($this->scc_m->update($id, $input))
			{
				$this->pyrocache->delete_all('scc_m');
				$this->session->set_flashdata(array('success' => sprintf(lang('scc:create_success'), $this->input->post('member_name'))));
				($this->input->post('btnAction') == 'save_exit') ? redirect('admin/members/scc') : redirect('admin/members/scc/edit/'.$id);
			}
			else
			{
				//$this->session->set_flashdata(array('error' => sprintf(lang('scc:create_error'), $this->input->post('member_name'))));
				$this->template->set('error', sprintf(lang('scc:create_error'), $this->input->post('member_name')) );
			}

			// Redirect back to the form or main page
		}

		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $key => $field)
		{
			if (isset($_POST[$field['field']]))
			{
				if ($field['field'] != 'file' AND $field['field'] != 'file_2' AND $field['field'] != 'file_3')
					$scc->$field['field'] = set_value($field['field']);
			}
		}

		$scc->application_date 			= $application_date;
		$scc->approval_date 			= $approval_date;
		$scc->certification_expiry_date = $certification_expiry_date;
		//$scc->mid 						= $this->input->post('member_id');
		$scc->file 						= $file;
		$scc->file_2 					= $file_2;
		$scc->file_3 					= $file_3;
		$scc->file_text_1 				= $file;
		$scc->file_text_2 				= $file_2;
		$scc->file_text_3 				= $file_3;
		$scc->supply_option 			= $this->input->post('supply_options') ? implode("\r\n", $this->input->post('supply_options')) : $scc->supply_option;

		$scc->isUp = $isUp;

		$this->template
			//->append_metadata($this->load->view('fragments/wysiwyg', array(), TRUE))
			->set('supply_options', $this->supply_options)
			->set('scc', $scc)
			->build('admin/scc/form');
	}


	public function editOLD($id=0)
	{
		$scc = $this->scc_m->get($id);

		$this->form_validation->set_rules($this->validation_rules);

		if ($this->input->post('notification_date'))
		{
			$date = $this->input->post('notification_date'); //strtotime(sprintf('%s %s:%s', $this->input->post('notification_date'), 0, 0));
		}
		else
		{
			$date = $scc->date;
		}

		if ($this->input->post('assessment_date'))
		{
			$assessment_date = strtotime(sprintf('%s %s:%s', $this->input->post('assessment_date'), 0, 0));
		}
		else
		{
			$assessment_date = $scc->assessment_date;
		}

		if ($this->input->post('final_report_date'))
		{
			$final_report_date = strtotime(sprintf('%s %s:%s', $this->input->post('final_report_date'), 0, 0));
		}
		else
		{
			$final_report_date = $scc->final_report_date;
		}

		if ($this->input->post('report_accepted_date'))
		{
			$report_accepted_date = strtotime(sprintf('%s %s:%s', $this->input->post('report_accepted_date'), 0, 0));
		}
		else
		{
			$report_accepted_date = $scc->report_accepted_date;
		}

		// check directory exists
		$this->check_dir($this->upload_cfg['upload_path']);
		$this->load->library('upload', $this->upload_cfg);

		if (!empty($_FILES['certificate']))
		{
			if($this->upload->do_upload("certificate"))
			{
				$file_certificate = $this->upload->data();
				$scc->certificate = $file_certificate['file_name'];
			}
		}

		if (!empty($_FILES['uploaded']['name'][0]))
		{
			if($this->upload->do_multi_upload("uploaded"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();
				foreach($file_uploaded as $file)
				{
					$uploaded[] = $file['file_name'];
				}
				$scc->uploaded = implode(',', $uploaded);
				$uploaded += explode(',', $this->input->post('uploaded_files'));
			}
		}
		else
		{
			$uploaded = explode(',', $scc->uploaded);
		}

		if (!empty($_FILES['notification_1']['name']) )
		{
			if($this->upload->do_upload("notification_1"))
			{
				$notification_uploaded = $this->upload->data();
				$notification = $notification_uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$notification = $this->input->post('notification_file_1');
		}

		if (!empty($_FILES['notification_2']['name']) )
		{
			if($this->upload->do_upload("notification_2"))
			{
				$notification_uploaded = $this->upload->data();
				$notification_2 = $notification_uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$notification_2 = $this->input->post('notification_file_2');
		}

		if (!empty($_FILES['notification_3']['name']) )
		{
			if($this->upload->do_upload("notification_3"))
			{
				$notification_uploaded = $this->upload->data();
				$notification_3 = $notification_uploaded['file_name'];
			}
			else
			{
				// something wrong
			}
		}
		else
		{
			$notification_3 = $this->input->post('notification_file_3');
		}


		if ($this->input->post('remove_notification'))
		{
			$rn = $this->input->post('remove_notification');
			foreach($rn as $r)
			{
				if (($key = array_search($r, $notifications)) !== false) {
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$r))
					{
						unset($notifications[$key]);
					}
					else
					{
						unset($notifications[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$scc->notification = implode(',', $notifications);
		}

		if ($this->input->post('remove_uploaded'))
		{
			$remove_uploaded = $this->input->post('remove_uploaded');
			foreach($remove_uploaded as $r)
			{
				if (($key = array_search($r, $uploaded)) !== false) {
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'pnc/'.$r))
					{
						unset($uploaded[$key]);
					}
					else
					{
						unset($uploaded[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$scc->uploaded = implode(',', $uploaded);
		}

		if ($this->form_validation->run())
		{
			$certificate_file = !empty($scc->certificate) ? $scc->certificate : $this->input->post('certificate_file');
			$uploaded_files = $this->input->post('uploaded_files') . (!empty($uploaded)?','.implode(',', $uploaded):'');
			$cb_id = (int)$this->input->post('cb_id');

			$input = array(
				'updated_on'		=> now(),
				'updated_by'		=> $this->current_user->id,
				'mill'				=> $this->input->post('mill'),
				'isUp'				=> $this->input->post('online_status') == 'live' ? '1' : '0',
				'date'				=> $date,
				'mid'				=> $this->input->post('member_id'),
				'certification_body'=> $cb_id ? '' : $this->input->post('certification_body'),
				'cb_id'				=> $cb_id,
				'assessment_type'	=> $this->input->post('assessment_type'),
				'status'			=> $this->input->post('status'),
				//'notification_date'	=> $date,
				'assessment_date'	=> $assessment_date,
				'subremarks'		=> $this->input->post('subremarks'),
				'certificate_file'	=> $certificate_file,
				'notification'		=> $notification,
				'notification_2'	=> $notification_2,
				'notification_3'	=> $notification_3,
				'uploaded'			=> implode(',', $uploaded),
				'final_report_date'	=> $final_report_date,
				'remarks'			=> $this->input->post('remarks'),
				'report_accepted_date'=> $report_accepted_date,
			);

			if ($this->scc_m->update($id, $input))
			{
				$this->pyrocache->delete_all('pnc_m');
				$this->session->set_flashdata(array('success' => sprintf(lang('scc:edit_success'), $this->input->post('member_name'))));
				($this->input->post('btnAction') == 'save_exit') ? redirect('admin/members/scc') : redirect('admin/members/scc/edit/'.$id);
			}
			else
			{
				$this->session->set_flashdata(array('error' => sprintf(lang('scc:edit_error'), $this->input->post('member_name'))));
				$this->template->set('error', sprintf(lang('scc:edit_error'), $this->input->post('member_name')) );
			}

			// Redirect back to the form or main page
		}

		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $key => $field)
		{
			if (isset($_POST[$field['field']]))
			{
				$scc->$field['field'] = set_value($field['field']);
			}
		}

		$scc->date = $date;
		$scc->assessment_date = $assessment_date;
		$scc->final_report_date = $final_report_date;
		$scc->report_accepted_date = $report_accepted_date;

		$this->template
			//->append_metadata($this->load->view('fragments/wysiwyg', array(), TRUE))
			->set('pnc', $pnc)
			->build('admin/pnc/form');
	}

	/**
	 * method to fetch filtered results for content list
	 * @access public
	 * @return void
	 */
	public function ajax_filter()
	{
		$area = $this->input->post('f_area');
		$status = $this->input->post('f_status');
		$type = $this->input->post('f_type');

		$post_data = array();

		if ($status == 'live' OR $status == 'draft')
		{
			$post_data['status'] = $status;
		}

		if ($type)
		{
			$post_data['type'] = $type;
		}

		if ($area != 0)
		{
			$post_data['area_id'] = $area;
		}

		$results = $this->members_m->search($post_data);

		//set the layout to false and load the view
		$this->template
			->set_layout(FALSE)
			->set('members', $results)
			->build('admin/tables/members');
	}

	public function remove_file($file)
	{
		$full = $_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'scc/'.$file;
		if (file_exists($full))
		{
			if (is_file($full))
			{
				if (unlink($full))
					return TRUE;
				else
					return FALSE;
			}
			return TRUE;
		}
		else
		{
			// file dissapear, maybe has been deleted?
			return TRUE;
		}
	}

	/**
	 * Check attachment dir, and create accordingly
	 *
	 * @param string Directory to check
	 * @return array
	 */
	function check_dir($dir)
	{
		// check directory
		$fileOK = array();
		$fdir = explode('/', $dir);
		$ddir = '';
		for($i=0; $i<count($fdir); $i++)
		{
			$ddir .= $fdir[$i] . '/';
			if (!is_dir($ddir))
			{
				if (!@mkdir($ddir, 0777)) {
					$fileOK[] = 'not_ok';
				}
				else
				{
					$fileOK[] = 'ok';
				}
			}
			else
			{
				$fileOK[] = 'ok';
			}
		}
		return $fileOK;

	}

}