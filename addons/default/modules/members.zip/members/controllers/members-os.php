<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Members extends Public_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('members_m');
	}

	public function index($slug='')
	{
		if ($slug)
		{
			$this->_view($slug);
		}
		else
		{
			//set the base/default where clause
			$base_where = array('status' => array('Approved', 'Call for Comments') );

			//add post values to base_where if f_module is posted
			//$base_where = $this->input->post('f_area') ? $base_where + array('area' => $this->input->post('f_area')) : $base_where;

			//$base_where['status'] = $this->input->post('f_status') ? $this->input->post('f_status') : $base_where['status'];

			$base_where['type'] = $this->input->post('f_type') ? $this->input->post('f_type') : NULL;

			// Create pagination links
			$total_rows = $this->members_m->count_by($base_where);
			$pagination = create_pagination('members/page/', $total_rows, NULL, 3);

			$base_where['limit'] = array($pagination['limit'], $pagination['offset']);

			// Using this data, get the relevant results
			$members = $this->members_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);

			//do we need to unset the layout because the request is ajax?
			$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

			$this->template
				->title($this->module_details['name'])
				//->append_js('admin/filter.js')
				->set('pagination', $pagination)
				->set('members', $members);
	
			$this->input->is_ajax_request() ? $this->template->build('ajax/members') : $this->template->build('index');
		}

	}

	private function _view($slug)
	{
		$slug or redirect('members');

		$member = $this->members_m->get_by(array('intID'=>$slug, 'status'=>'Approved', 'isDeleted'=>'0'));
		if (!empty($member))
		{
			$this->template
				->title($member->name)
				//->append_js('admin/filter.js')
				->set('member', $member);
	
			$this->input->is_ajax_request() ? $this->template->build('ajax/view') : $this->template->build('view');
		}
		else
		{
			$this->session->set_flashdata('error', lang('members:member_not_exist_error'));
			redirect('members');
		}

	}

}