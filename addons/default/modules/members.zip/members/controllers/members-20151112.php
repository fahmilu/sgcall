<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Members extends Public_Controller
{
	public $meta_description = "Information on Roundtable on Sustainable Palm Oil (RSPO) membership, its benefits, how to apply and more.";
	
	protected $section = 'members';

	protected $scg_member_checked = false;

	protected $country_arrays = array("Afghanistan","Åland Islands","Albania","Algeria","American Samoa","Andorra","Angola","Anguilla","Antarctica","Antigua And Barbuda","Argentina","Armenia","Aruba","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia, Plurinational State Of","Bonaire, Sint Eustatius And Saba","Bosnia And Herzegovina","Botswana","Bouvet Island","Brazil","British Indian Ocean Territory","Brunei Darussalam","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Canada","Cape Verde","Cayman Islands","Central African Republic","Chad","Chile","China","Christmas Island","Cocos (keeling) Islands","Colombia","Comoros","Congo","Congo, The Democratic Republic Of The","Cook Islands","Costa Rica","Côte D'ivoire","Croatia","Cuba","Curaçao","Cyprus","Czech Republic","Denmark","Djibouti","Dominica","Dominican Republic","Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia","Falkland Islands (malvinas)","Faroe Islands","Fiji","Finland","France","French Guiana","French Polynesia","French Southern Territories","Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guadeloupe","Guam","Guatemala","Guernsey","Guinea","Guinea-bissau","Guyana","Haiti","Heard Island And Mcdonald Islands","Holy See (vatican City State)","Honduras","Hong Kong","Hungary","Iceland","India","Indonesia","Iran, Islamic Republic Of","Iraq","Ireland","Isle Of Man","Israel","Italy","Jamaica","Japan","Jersey","Jordan","Kazakhstan","Kenya","Kiribati","North Korea","South Korea","Kuwait","Kyrgyzstan","Lao People's Democratic Republic","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg","Macao","Macedonia","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Martinique","Mauritania","Mauritius","Mayotte","Mexico","Micronesia, Federated States Of","Moldova, Republic Of","Monaco","Mongolia","Montenegro","Montserrat","Morocco","Mozambique","Myanmar","Namibia","Nauru","Nepal","Netherlands","New Caledonia","New Zealand","Nicaragua","Niger","Nigeria","Niue","Norfolk Island","Northern Mariana Islands","Norway","Oman","Pakistan","Palau","Palestinian Territory, Occupied","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Pitcairn","Poland","Portugal","Puerto Rico","Qatar","Réunion","Romania","Russian Federation","Rwanda","Saint Barthélemy","Saint Helena, Ascension And Tristan Da Cunha","Saint Kitts And Nevis","Saint Lucia","Saint Martin (french Part)","Saint Pierre And Miquelon","Saint Vincent And The Grenadines","Samoa","San Marino","Sao Tome And Principe","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Sint Maarten (dutch Part)","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","South Georgia And The South Sandwich Islands","South Sudan","Spain","Sri Lanka","Sudan","Suriname","Svalbard And Jan Mayen","Swaziland","Sweden","Switzerland","Syrian Arab Republic","Taiwan","Tajikistan","Tanzania, United Republic Of","Thailand","Timor-leste","Togo","Tokelau","Tonga","Trinidad And Tobago","Tunisia","Turkey","Turkmenistan","Turks And Caicos Islands","Tuvalu","Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","United States Minor Outlying Islands","Uruguay","Uzbekistan","Vanuatu","Venezuela","Vietnam","Virgin Islands, British","Virgin Islands, U.S.","Wallis And Futuna","Western Sahara","Yemen","Zambia","Zimbabwe",);
	
	protected $validation_rules = array(
			array(
				'field' => 'type',
				'label' => 'Membership type',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'category',
				'label' => "Organisation's category",
				'rules' => 'trim|required',
			),
			'sub_category' => array(
				'field' => 'profession',
				'label' => "Organisation's sub-category",
				'rules' => 'trim',
			),
			array(
				'field' => 'org_name',
				'label' => "Organisation's name",
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'address',
				'label' => 'Street and number',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'address_city',
				'label' => 'City',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'address_state',
				'label' => 'State/Province',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'address_zip',
				'label' => 'Postal/Zip Code',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'country',
				'label' => 'Country',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'telephone',
				'label' => 'Telephone',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'fax',
				'label' => 'Fax',
				'rules' => 'trim',
			),
			array(
				'field' => 'email',
				'label' => 'Email',
				'rules' => 'trim|valid_email|required',
			),
			array(
				'field' => 'website',
				'label' => 'Website ',
				'rules' => 'trim',
			),
			array(
				'field' => 'registration_number',
				'label' => 'Organisation\'s registration',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'parent_company',
				'label' => 'Are you a parent company? ',
				'rules' => 'trim',
			),
			array(
				'field' => 'primary_market_ops',
				'label' => 'Primary market operations ',
				'rules' => 'trim',
			),
			array(
				'field' => 'other_market_ops',
				'label' => 'Other market operations ',
				'rules' => 'trim',
			),
			array(
				'field' => 'profile',
				'label' => 'Organisation\'s description ',
				'rules' => 'trim|required|htmlspecialchars',
			),
			'primary_name'=>array(
				'field' => 'name_p',
				'label' => 'Primary Nomination First name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			'primary_name_last_p'=>array(
				'field' => 'name_last_p',
				'label' => 'Primary Nomination Last name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			'primary_designation'=>array(
				'field' => 'designation_p',
				'label' => 'Primary Nomination Position',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'telephone_p',
				'label' => 'Primary Nomination Phone No.',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'fax_p',
				'label' => 'Primary Nomination Fax No.',
				'rules' => 'trim',
			),
			'primary_email'=>array(
				'field' => 'email_p',
				'label' => 'Primary Nomination Email',
				'rules' => 'trim|valid_email|required',
			),
			'secondary_name'=>array(
				'field' => 'name_s',
				'label' => 'Secondary Nomination First Name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			'secondary_name_last_s'=>array(
				'field' => 'name_last_s',
				'label' => 'Secondary Nomination Last Name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			'secondary_designation'=>array(
				'field' => 'designation_s',
				'label' => 'Secondary Nomination Position',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'telephone_s',
				'label' => 'Secondary Nomination Phone No.',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'fax_s',
				'label' => 'Secondary Nomination Fax No.',
				'rules' => 'trim',
			),
			'secondary_email'=>array(
				'field' => 'email_s',
				'label' => 'Secondary Nomination Email',
				'rules' => 'trim|valid_email|required',
			),
			array(
				'field' => 'contact_person',
				'label' => 'Contact Person\'s First Name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			array(
				'field' => 'contact_lname',
				'label' => 'Contact Person\'s Last Name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			array(
				'field' => 'designation',
				'label' => 'Contact Person\'s Position',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'contact_tel',
				'label' => 'Contact Person\'s Phone No.',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'contact_fax',
				'label' => 'Contact Person\'s Fax No.',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_email',
				'label' => 'Contact Person\'s Email',
				'rules' => 'trim|valid_email|required',
			),
			array(
				'field' => 'name_f',
				'label' => 'Finance\'s First Name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			array(
				'field' => 'name_last_f',
				'label' => 'Finance\'s Last Name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			array(
				'field' => 'designation_f',
				'label' => 'Finance\'s Position',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'telephone_f',
				'label' => 'Finance\'s Phone No.',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'fax_f',
				'label' => 'Finance\'s Fax No.',
				'rules' => 'trim',
			),
			array(
				'field' => 'email_f',
				'label' => 'Finance\'s Email',
				'rules' => 'trim|valid_email|required',
			),
			'production_area' => array(
				'field' => 'production_area',
				'label' => 'Production area',
				'rules' => 'trim',
			),
			'q1' => array(
				'field' => 'q1',
				'label' => 'Question #1',
				'rules' => 'trim|htmlspecialchars|required',
			),
			'q2' => array(
				'field' => 'q2',
				'label' => 'Question #2',
				'rules' => 'trim|htmlspecialchars|required',
			),
			'q3' => array(
				'field' => 'q3',
				'label' => 'Question #3',
				'rules' => 'trim|htmlspecialchars|required',
			),
			'q4' => array(
				'field' => 'q4',
				'label' => 'Question #4',
				'rules' => 'trim|htmlspecialchars',
			),
			'q_usage' => array(
				'field' => 'q_usage',
				'label' => 'Palm oil &amp; derivative annual usage',
				'rules' => 'trim',
			),
			array(
				'field' => 'name_a',
				'label' => 'Applicant\'s Full Name',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'designation_a',
				'label' => 'Applicant\'s Position',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'email_a',
				'label' => 'Applicant\'s Email',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'date_2',
				'label' => 'date_2',
				'rules' => 'trim',
			),
/*
			array(
				'field' => 'logo',
				'label' => 'Organisation\'s Logo',
				'rules' => 'trim',
			),
*/
			array(
				'field' => 'file',
				'label' => 'file',
				'rules' => 'trim',
			),
			array(
				'field' => 'grower_file',
				'label' => 'grower file',
				'rules' => 'trim',
			),
/*
			array(
				'field' => 'file_certificates',
				'label' => 'file certificates',
				'rules' => 'trim',
			),
*/
			array(
				'field' => 'uploaded_files_cert',
				'label'	=> 'uploaded_files_cert',
				'rules'	=> 'trim',
			),
			array(
				'field' => 'upload_logo',
				'label' => 'upload_logo',
				'rules' => 'trim',
			),
			array(
				'field' => 'applied_date',
				'label' => 'Application Date',
				'rules' => 'trim',
			),
			array(
				'field' => 'newsletter',
				'label' => 'Newsletter Subscription',
				'rules' => 'trim',
			),
			array(
				'field' => 'remarks',
				'label' => 'Other information to support member application',
				'rules' => 'trim|htmlspecialchars',
			),
			array(
				'field' => 'code_telephone',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_fax',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_contact_tel',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_contact_fax',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_tel_p',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_fax_p',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_tel_s',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_fax_s',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_tel_f',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'code_fax_f',
				'label' => 'Country Code',
				'rules' => 'trim',
			),
			array(
				'field' => 'sub_company[name][]',
				'label' => 'Subsidiary company',
				'rules' => 'trim|htmlspecialchars',
			),
			'supporting_docs' => array(
				'field' => 'div_files_cert[]',
				'label' => 'Supporting documents',
				'rules' => 'trim|htmlspecialchars',
			),
			'sh_group_manager_docs' => array(
				'field' => 'div_file_sh_group_manager[]',
				'label' => 'Smallholder Group Manager documents',
				'rules' => 'trim|htmlspecialchars',
			),
			'additional_docs' => array(
				'field' => 'div_file_additionals[]',
				'label' => 'Additional documents',
				'rules' => 'trim|htmlspecialchars',
			),
			'sc_group_manager_docs' => array(
				'field' => 'div_file_sc_group_manager[]',
				'label' => 'Supply Chain Group Manager document',
				'rules' => 'trim|htmlspecialchars',
			),
			'scg_manager_members' => array(
				'field' => 'scg_manager_members[]',
				'label' => 'Number of members managed',
				'rules' => 'trim|htmlspecialchars|callback__check_scg_members',
			),
			array(
				'field' => 'scg_manager_consumption[]',
				'label' => 'Total consumption',
				'rules' => 'trim|numeric',
			),
		);

	protected $validation_member = array(
			array(
				'field' => 'profile',
				'label' => 'Organisation\'s description ',
				'rules' => 'trim|required|htmlspecialchars',
			),
			array(
				'field' => 'address',
				'label' => 'Street and number',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'address_city',
				'label' => 'City',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'address_state',
				'label' => 'State/Province',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'address_zip',
				'label' => 'Postal/Zip Code',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'country',
				'label' => 'Country',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'telephone',
				'label' => 'Telephone',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'fax',
				'label' => 'Fax',
				'rules' => 'trim',
			),
			array(
				'field' => 'email',
				'label' => 'Email',
				'rules' => 'trim|valid_email|required',
			),
			array(
				'field' => 'website',
				'label' => 'Website ',
				'rules' => 'trim',
			),
			'production_area' => array(
				'field' => 'production_area',
				'label' => 'Production area',
				'rules' => 'trim',
			),
			'q1' => array(
				'field' => 'q1',
				'label' => 'Question #1',
				'rules' => 'trim|htmlspecialchars|required',
			),
			'q2' => array(
				'field' => 'q2',
				'label' => 'Question #2',
				'rules' => 'trim|htmlspecialchars|required',
			),
			'q3' => array(
				'field' => 'q3',
				'label' => 'Question #3',
				'rules' => 'trim|htmlspecialchars|required',
			),
			'q4' => array(
				'field' => 'q4',
				'label' => 'Question #4',
				'rules' => 'trim|htmlspecialchars',
			),
			'q_usage' => array(
				'field' => 'q_usage',
				'label' => 'Palm oil &amp; derivative annual usage',
				'rules' => 'trim',
			),
			'primary_name'=>array(
				'field' => 'name_p',
				'label' => 'Primary Nomination Full name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			'primary_name_last_p'=>array(
				'field' => 'name_last_p',
				'label' => 'Primary Nomination Last name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			'primary_designation'=>array(
				'field' => 'designation_p',
				'label' => 'Primary Nomination Position',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'telephone_p',
				'label' => 'Primary Nomination Phone No.',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'fax_p',
				'label' => 'Primary Nomination Fax No.',
				'rules' => 'trim',
			),
			'primary_email'=>array(
				'field' => 'email_p',
				'label' => 'Primary Nomination Email',
				'rules' => 'trim|valid_email|required',
			),
			'secondary_name'=>array(
				'field' => 'name_s',
				'label' => 'Secondary Nomination Full Name',
				'rules' => 'trim|htmlspecialchars|required',
			),
			'secondary_name_last_s'=>array(
				'field' => 'name_last_s',
				'label' => 'Secondary Nomination Last Name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			'secondary_designation'=>array(
				'field' => 'designation_s',
				'label' => 'Secondary Nomination Position',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'telephone_s',
				'label' => 'Secondary Nomination Phone No.',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'fax_s',
				'label' => 'Secondary Nomination Fax No.',
				'rules' => 'trim',
			),
			'secondary_email'=>array(
				'field' => 'email_s',
				'label' => 'Secondary Nomination Email',
				'rules' => 'trim|valid_email|required',
			),
			array(
				'field' => 'contact_person',
				'label' => 'Contact Person\'s First Name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			array(
				'field' => 'contact_lname',
				'label' => 'Contact Person\'s Last Name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			array(
				'field' => 'designation',
				'label' => 'Contact Person\'s Position',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'contact_tel',
				'label' => 'Contact Person\'s Phone No.',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'contact_fax',
				'label' => 'Contact Person\'s Fax No.',
				'rules' => 'trim',
			),
			array(
				'field' => 'contact_email',
				'label' => 'Contact Person\'s Email',
				'rules' => 'trim|valid_email|required',
			),
			array(
				'field' => 'name_f',
				'label' => 'Finance\'s Full Name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			array(
				'field' => 'name_last_f',
				'label' => 'Finance\'s Last Name',
				'rules' => 'trim|max_length[100]|htmlspecialchars|required',
			),
			array(
				'field' => 'designation_f',
				'label' => 'Finance\'s Position',
				'rules' => 'trim|htmlspecialchars|required',
			),
			array(
				'field' => 'telephone_f',
				'label' => 'Finance\'s Phone No.',
				'rules' => 'trim|required',
			),
			array(
				'field' => 'fax_f',
				'label' => 'Finance\'s Fax No.',
				'rules' => 'trim',
			),
			array(
				'field' => 'email_f',
				'label' => 'Finance\'s Email',
				'rules' => 'trim|valid_email|required',
			),
			'scg_manager_members' => array(
				'field' => 'scg_manager_members[]',
				'label' => 'Number of members managed',
				'rules' => 'trim|htmlspecialchars|callback__check_scg_members',
			),
	);

	protected $changes = array(
		'profile'		=> 'Description',
		'address'		=> 'Address',
		'address_city'	=> 'City',
		'address_state'	=> 'State/Province',
		'address_zip'	=> 'Post Code',
		'country'		=> 'Country',
		'telephone'		=> 'Telephone',
		'fax'			=> 'Fax',
		'email'			=> 'Email',
		'website'		=> 'Website',
		'production_area'=> 'Production Area',
		'name_p' 		=> 'Primary Nomination - Name',
		'designation_p' => 'Primary Nomination - Position',
		'code_tel_p' 	=> 'Primary Nomination - Phone Number',
		'telephone_p' 	=> 'Primary Nomination - Phone Number',
		'code_fax_p' 	=> 'Primary Nomination - Fax Number',
		'fax_p' 		=> 'Primary Nomination - Fax Number',
		'email_p' 		=> 'Primary Nomination - Email Address',
		'name_s' 		=> 'Secondary Nomination - Name',
		'designation_s' => 'Secondary Nomination - Position',
		'code_tel_s' 	=> 'Secondary Nomination - Phone Number',
		'telephone_s' 	=> 'Secondary Nomination - Phone Number',
		'code_fax_s' 	=> 'Secondary Nomination - Fax Number',
		'fax_s' 		=> 'Secondary Nomination - Fax Number',
		'email_s' 		=> 'Secondary Nomination - Email Address',
		'contact_person' 	=> 'Contact Person - Name',
		'designation' 		=> 'Contact Person - Position',
		'code_contact_tel' 	=> 'Contact Person - Phone Number',
		'contact_tel'	 	=> 'Contact Person - Phone Number',
		'code_contact_fax' 	=> 'Contact Person - Fax Number',
		'contact_fax'	 	=> 'Contact Person - Fax Number',
		'contact_email' 	=> 'Contact Person - Email Address',
		'name_f' 		=> 'Financial Contact - Name',
		'designation_f' => 'Financial Contact - Position',
		'code_tel_f' 	=> 'Financial Contact - Phone Number',
		'telephone_f' 	=> 'Financial Contact - Phone Number',
		'code_fax_f' 	=> 'Financial Contact - Fax Number',
		'fax_f' 		=> 'Financial Contact - Fax Number',
		'email_f' 		=> 'Financial Contact - Email Address',
		'q1'			=> 'Question #1',
		'q2'			=> 'Question #2',
		'q3'			=> 'Question #3',
		'q4'			=> 'Question #4',
		'scg_manager_members' => 'Supply chain group members',
		'logo'			=> 'Uploaded new logo',
	);

	protected $subcat_growers = array('Smallholder Group Manager', 'Small growers');

	protected $subcat_others = array(
		'Refinery, Edible oils and Food ingredients processors',
		'Only Trading, Logistics and Distributions',
		'Power, Energy and Bio-fuel',
		'Chemicals, Surfactants, and Non-Food ingredients processors',
		'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)'
	);
	protected $subcat_popt = array(
		'Refinery, Edible oils and Food ingredients processors',
		'Only Trading, Logistics and Distributions',
		'Power, Energy and Bio-fuel',
		'Chemicals, Surfactants, and Non-Food ingredients processors',
		'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)',
		'Others'
	);

	protected $subcategories = array(
		'Oil Palm Growers' => array('Smallholder Group Manager'=>'Smallholder Group Manager', 'Small growers'=>'Small growers'),

		'Consumer Goods Manufacturers' => array(
			'Refinery, Edible oils and Food ingredients processors'=>'Refinery, Edible oils and Food ingredients processors',
			'Only Trading, Logistics and Distributions'=>'Only Trading, Logistics and Distributions',
			'Power, Energy and Bio-fuel'=>'Power, Energy and Bio-fuel',
			'Chemicals, Surfactants, and Non-Food ingredients processors'=>'Chemicals, Surfactants, and Non-Food ingredients processors',
			'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)'=>'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)',
			'Others'=>'Others'
		),
		'Palm Oil Processors and Traders' => array(
			'Refinery, Edible oils and Food ingredients processors'=>'Refinery, Edible oils and Food ingredients processors',
			'Only Trading, Logistics and Distributions'=>'Only Trading, Logistics and Distributions',
			'Power, Energy and Bio-fuel'=>'Power, Energy and Bio-fuel',
			'Chemicals, Surfactants, and Non-Food ingredients processors'=>'Chemicals, Surfactants, and Non-Food ingredients processors',
			'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)'=>'Across the POSC (Plantation, Mill, Refining, Trading, Manufacturing & Retailing)',
			'Others'=>'Others'
		),
	);

	protected $categories = array(
		'affiliate' => array('Organisations'=>'Organisations', 'Individuals'=>'Individuals'),
		'sca' => array('Organisation'=>'Organisation', 'Supply Chain Group Manager'=>'Supply Chain Group Manager'),
	);

	protected $thumb_width = 150;
	protected $thumb_height = 250;
	protected $logo_width = 600;
	protected $logo_height = 400;

	public function __construct()
	{
		parent::__construct();

		// read from the same table as rspo.org
		$this->db->set_dbprefix('default_');

		$this->load->model(array('members_m', 'pnc_m', 'scc_m'));
		$this->load->library('form_validation');
		$this->load->helper(array('filesize', 'filename'));

		$countries['All'] = 'All countries';
		foreach($this->country_arrays as $c)
		{
			$countries[$c] = $c;
		}

		$member_categories = array(
			'' => 'All sectors',
			'Banks and Investors'=>'Banks and Investors',
			'Consumer Goods Manufacturers'=>'Consumer Goods Manufacturers',
			'Environmental and Conservation NGOs'=>'Environmental and Conservation NGOs',
			'Oil Palm Growers'=>'Oil Palm Growers',
			'Palm Oil Processors and Traders'=>'Palm Oil Processors and Traders',
			'Retailers'=>'Retailers',
			'Social and Developmental NGOs'=>'Social and Developmental NGOs',
			'Individuals'=>'Individuals',
			'Organisations'=>'Organisations',
			'Supply Chain Group Manager'=>'Supply Chain Group Manager',
		);

	    $member_types = array(
			'' => 'All Categories',
			'Ordinary Members'=>'Ordinary Members',
			'Affiliate Members'=>'Affiliate Members',
			'Supply Chain Associate'=>'Supply Chain Associate',
	    );

		$this->config_upload = array(
			'upload_path' 	=> UPLOAD_PATH . 'memberlogos',
			'allowed_types' => 'gif|jpg|png|pdf|doc|docx|xls|xlsx|kml|kmz',
			'max_size' 		=> '20000',
			'remove_spaces'		=> TRUE,
			'overwrite'			=> FALSE,
			'encrypt_name'		=> FALSE,
		);

		foreach($this->country_arrays as $c)
		{
			$member_countries[$c] = $c;
		}

		if(SITE_REF=='bcn'){
			$meta_descriptionpage = "了解可持续棕榈油圆桌倡议会议(RSPO)会员资格，现有会员及申请方式";
		}
		else{
			$meta_descriptionpage = "Information on Roundtable on Sustainable Palm Oil (RSPO) membership, its benefits, how to apply and more.";
		}

		if ($this->input->get('otokowok')==='otokowok')
		{
			$this->output->enable_profiler(TRUE);
		}

		$this->template
			->append_css('responsive_recaptcha.css')
			//->set('meta_description', $this->meta_description)
			->set_metadata('description', $meta_descriptionpage)
			->set('member_categories', $member_categories)
			->set('member_subcategories', $this->subcategories)
			->set('member_types', $member_types)
			->set('member_countries', $countries)
			->set('country_arrays', $countries)
			->set('country_single_arrays', $countries);
	}

	function __destruct()
	{
		$this->db->set_dbprefix(SITE_REF.'_');
	}

	public function index($slug='')
	{
		$search = $this->input->get('member_country');
		
		if ($slug && strtolower($slug) <> 'all' && strtolower($slug) <> 'page')
		{

			if (method_exists($this->module, $slug))
			{
				call_user_func(array($this->controller, $slug));
			}
			else
			{
				if (func_num_args() > 1)
				{
					$arg_list = func_get_args();
					$slug = implode('/', $arg_list);
				}
				$this->_view($slug);
			}

		}
		else
		{
			$query = new stdClass();
			$pagination_suffix = array();
			//set the base/default where clause
			$base_where = array();
			//$base_where = array('status' => array('Approved', 'Call for Comments') );
			$base_where = array( 'status' => 'Approved' );

			//add post values to base_where if f_module is posted
			//$base_where = $this->input->post('f_area') ? $base_where + array('area' => $this->input->post('f_area')) : $base_where;

			if ($this->input->get('show_only'))
			{
				if ($this->input->get('show_only') <> 'members')
					$base_where['show_only'] = $this->input->get('show_only');
			}

			if ($this->input->get('keywords'))
			{
				$base_where['keywords'] = str_ireplace("'", "%", $this->input->get('keywords')); //$this->input->get('keywords');
				//$base_where['keywords'] = $this->input->get('keywords');
				$query->keywords = $this->input->get('keywords'); //$base_where['keywords'];
				$pagination_suffix[] = 'keywords='.$this->input->get('keywords'); //$base_where['keywords'];
				//var_dump($base_where['keywords']);
			}
			else
			{
				$query->keywords = NULL;
			}

			if ($this->input->get('member_type'))
			{
				$base_where['type'] = $this->input->get('member_type');
				$query->member_type = $base_where['type'];
				$pagination_suffix[] = 'member_type='.$base_where['type'];
			}
			else
			{
				$query->member_type = NULL;
			}

			if ($this->input->get('member_category'))
			{
				$base_where['category'] = $this->input->get('member_category');
				$query->member_category = $base_where['category'];
				$pagination_suffix[] = 'member_category='.$base_where['category'];
			}
			else
			{
				$query->member_category = NULL;
			}

			$query_country = $this->input->get('member_country');
			if ($query_country &&  strtolower($query_country) <> 'all')
			{
				$base_where['country'] = $this->input->get('member_country');
				$query->member_country = $base_where['country'];
				$pagination_suffix[] = 'member_country='.$base_where['country'];
			}
			else
			{
				$query->member_country = NULL;
			}

			$query->show_only = NULL;
			/*
			echo "<pre>";
			echo "\$base_where:\n";
			print_r($base_where);
			echo "<hr />\n";
			echo "\$this->input->get('show_only'): ".$this->input->get('show_only')."\n";
			echo "</pre>";
			exit;
			*/

			// Create pagination links
			if (!empty($base_where['show_only']))
			{
				switch($base_where['show_only'])
				{
					case 'scc_report':
						$total_rows = $this->scc_m->count_by($base_where);
						$pagination = create_pagination('members/page/', $total_rows, NULL, 3);
						$base_where['limit'] = array($pagination['limit'], $pagination['offset']);
						$members = $this->scc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
						$tobuild = 'scc/member-search';
						//$tobuild = 'scc/index';
						$this->template->set('sccs', $members);
						$query->show_only = 'scc_report';
						break;

					case 'pnc_report':
						$total_rows = $this->pnc_m->count_by($base_where);
						$pagination = create_pagination('members/page/', $total_rows, NULL, 3);
						$base_where['limit'] = array($pagination['limit'], $pagination['offset']);
						$members = $this->pnc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
						$assessments = $this->pnc_m->get_assessment_type();
						foreach($assessments as $a)
						{
							$ass_type[$a->id] = $a->stage;
						}
						$this->template->set('assessment_type', $ass_type);
						$tobuild = 'pnc/member-search';
						//$tobuild = 'pnc/index';
						$this->template->set('pncs', $members);
						$query->show_only = 'pnc_report';
						break;

					default:
						$total_rows = $this->members_m->count_by($base_where);
						$pagination = create_pagination('members/page/', $total_rows, NULL, 3);
						$base_where['limit'] = array($pagination['limit'], $pagination['offset']);
						$base_where['order'] = 'approved_date';
						$base_where['sort'] = 'desc';
						$members = $this->members_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
						break;
				}
			}
			else
			{
				$total_rows = $this->members_m->count_by($base_where);
				$pagination = create_pagination('members/page/', $total_rows, NULL, 3);
				$base_where['limit'] = array($pagination['limit'], $pagination['offset']);
				$base_where['order'] = 'approved_date';
				$base_where['sort'] = 'desc';
				$members = $this->members_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
			}

			// Using this data, get the relevant results
			//$members = $this->members_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
			
			if(SITE_REF == "bcn"){
				$metadesc = '了解可持续棕榈油圆桌倡议会议(RSPO)会员资格，现有会员及申请方式';
				$metakey = '';
			}
			else{
				$metadesc = 'Information on Roundtable on Sustainable Palm Oil (RSPO) membership, its benefits, how to apply and more.';
				$metakey = '';
			}
			
			$this->template
				//->title($this->module_details['name'])
				->set_metadata('description', $metadesc)
				->set_metadata('keywords', $metakey)
				->set('query', $query)
				->set('pagination', $pagination)
				->set('members', $members);

			//do we need to unset the layout because the request is ajax?
			$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';
			if (!empty($base_where['show_only']))
			{
				if(SITE_REF == "bcn"){
					$this->template
					->set('page_title', '查找会员')
					->title('查找会员')
					->set_breadcrumb('RSPO会员', 'members')
					->set_breadcrumb('查找会员')
					->build($tobuild);
				}
				else{
					$this->template
					->set('page_title', 'Search reports')
					->title('Search reports')
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb('Search Reports')
					->build($tobuild);
				}
			}
			else
			{
				if (!empty($slug))
				{
					if (!empty($_GET))
						if(SITE_REF == "bcn"){
							$this->template
							->set_breadcrumb('RSPO会员', 'members')
							->set_breadcrumb('查找会员');
						}
						else{
							$this->template
							->set_breadcrumb('Members', 'members')
							->set_breadcrumb('Search Members');
						}
					else
						if(SITE_REF == "bcn"){
							$this->template
							->title('查找会员')
							->set_breadcrumb('RSPO会员', 'members')
							->set_breadcrumb('查找会员');
						}
						else{
							$this->template
							->title('Search members')
							->set_breadcrumb('Members', 'members')
							->set_breadcrumb('Search Members');
						}
						
				}
				else
				{
					if (!empty($_GET))
						if(SITE_REF == "bcn"){
							$this->template
							->title('查找会员')
							->set_breadcrumb('RSPO会员', 'members')
							->set_breadcrumb('查找会员');
						}
						else{
							$this->template
							->title('Search members')
							->set_breadcrumb('Members', 'members')
							->set_breadcrumb('Search Members');
						}
						
					/*
					else
						$this->template->set_breadcrumb('View All');
					*/
				}
				
				if (empty($pagination_suffix) && strtolower($slug) <> 'all' && empty($search))
				{
					if(SITE_REF == "bcn"){
						$this->template
							//->set('page_title', 'Search reports')
							->title('RSPO会员')
							->set_breadcrumb('RSPO会员')
							->build('index-cn');
							
						$this->db->set_dbprefix('default_');
					}else{
						$this->template
						->set_breadcrumb('Members')
						->build('index');
					}	
				}
				else
				{
					$this->input->is_ajax_request() ? $this->template->build('ajax/members') : (SITE_REF=='bcn' ? $this->template->build('all') : $this->template->build('all'));
				}
			}
		}
	}

	public function indexOS($slug='')
	{
		$search = $this->input->get('member_country');

		if ($slug && strtolower($slug) <> 'all' && strtolower($slug) <> 'page')
		{

			if (method_exists($this->module, $slug))
			{
				call_user_func(array($this->controller, $slug));
			}
			else
			{
				if (func_num_args() > 1)
				{
					$arg_list = func_get_args();
					$slug = implode('/', $arg_list);
				}
				$this->_view($slug);
			}

		}
		else
		{
			$query = new stdClass();
			$pagination_suffix = array();
			//set the base/default where clause
			$base_where = array();
			//$base_where = array('status' => array('Approved', 'Call for Comments') );
			$base_where = array( 'status' => 'Approved' );

			//add post values to base_where if f_module is posted
			//$base_where = $this->input->post('f_area') ? $base_where + array('area' => $this->input->post('f_area')) : $base_where;

			if ($this->input->get('show_only'))
			{
				if ($this->input->get('show_only') <> 'members')
					$base_where['show_only'] = $this->input->get('show_only');
			}

			if ($this->input->get('keywords'))
			{
				$base_where['keywords'] = $this->input->get('keywords');
				$query->keywords = $base_where['keywords'];
				$pagination_suffix[] = 'keywords='.$base_where['keywords'];
			}
			else
			{
				$query->keywords = NULL;
			}

			if ($this->input->get('member_type'))
			{
				$base_where['type'] = $this->input->get('member_type');
				$query->member_type = $base_where['type'];
				$pagination_suffix[] = 'member_type='.$base_where['type'];
			}
			else
			{
				$query->member_type = NULL;
			}

			if ($this->input->get('member_category'))
			{
				$base_where['category'] = $this->input->get('member_category');
				$query->member_category = $base_where['category'];
				$pagination_suffix[] = 'member_category='.$base_where['category'];
			}
			else
			{
				$query->member_category = NULL;
			}

			$query_country = $this->input->get('member_country');
			if ($query_country &&  strtolower($query_country) <> 'all')
			{
				$base_where['country'] = $this->input->get('member_country');
				$query->member_country = $base_where['country'];
				$pagination_suffix[] = 'member_country='.$base_where['country'];
			}
			else
			{
				$query->member_country = NULL;
			}

			$query->show_only = NULL;
/*
echo "<pre>";
echo "\$base_where:\n";
print_r($base_where);
echo "<hr />\n";
echo "\$this->input->get('show_only'): ".$this->input->get('show_only')."\n";
echo "</pre>";
exit;
*/


			// Create pagination links
			if (!empty($base_where['show_only']))
			{
				switch($base_where['show_only'])
				{
					case 'scc_report':
						$total_rows = $this->scc_m->count_by($base_where);
						$pagination = create_pagination('members/page/', $total_rows, NULL, 3);
						$base_where['limit'] = array($pagination['limit'], $pagination['offset']);
						$members = $this->scc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
						$tobuild = 'scc/member-search';
						//$tobuild = 'scc/index';
						$this->template->set('sccs', $members);
						$query->show_only = 'scc_report';
						break;

					case 'pnc_report':
						$total_rows = $this->pnc_m->count_by($base_where);
						$pagination = create_pagination('members/page/', $total_rows, NULL, 3);
						$base_where['limit'] = array($pagination['limit'], $pagination['offset']);
						$members = $this->pnc_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
						$assessments = $this->pnc_m->get_assessment_type();
						foreach($assessments as $a)
						{
							$ass_type[$a->id] = $a->stage;
						}
						$this->template->set('assessment_type', $ass_type);
						$tobuild = 'pnc/member-search';
						//$tobuild = 'pnc/index';
						$this->template->set('pncs', $members);
						$query->show_only = 'pnc_report';
						break;

					default:
						$total_rows = $this->members_m->count_by($base_where);
						$pagination = create_pagination('members/page/', $total_rows, NULL, 3);
						$base_where['limit'] = array($pagination['limit'], $pagination['offset']);
						$members = $this->members_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
						break;
				}
			}
			else
			{
				$total_rows = $this->members_m->count_by($base_where);
				$pagination = create_pagination('members/page/', $total_rows, NULL, 3);
				$base_where['limit'] = array($pagination['limit'], $pagination['offset']);
				$members = $this->members_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
			}

			// Using this data, get the relevant results
			//$members = $this->members_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);
			$this->template
				->title('Members')
				->set('query', $query)
				->set('pagination', $pagination)
				->set('members', $members);

			//do we need to unset the layout because the request is ajax?
			$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

			if (!empty($base_where['show_only']))
			{
				$this->template
					->title('Search reports')
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb('Search Reports')
					->build($tobuild);
			}
			else
			{
				if (!empty($slug))
				{
					if (!empty($_GET))
						$this->template
							->set_breadcrumb('Members', 'members')
							->set_breadcrumb('Search MembersZ');
					else
						$this->template
							->title('Search members')
							->set_breadcrumb('Members', 'members')
							->set_breadcrumb('Search Members');
				}
				else
				{
					if (!empty($_GET))
						$this->template
							->title('Search members')
							->set_breadcrumb('Members', 'members')
							->set_breadcrumb('Search Members');
/*
					else
						$this->template->set_breadcrumb('View All');
*/
				}

				if (empty($pagination_suffix) && strtolower($slug) <> 'all' && empty($search))
				{
					$this->template
						->set_breadcrumb('Members')
						->build('index');
				}
				else
				{
					$this->input->is_ajax_request() ? $this->template->build('ajax/members') : $this->template->build('all');
				}
			}
		}

	}

	private function _view($slug)
	{

		$slug or redirect('members');

		if (!empty($this->current_user->id) && group_has_role('members', 'view_member'))
		{
			$member = $this->members_m->get($slug);
		}
		else
		{
			//$member = $this->members_m->get_by(array('intID'=>$slug, 'status'=>'Approved', 'isDeleted'=>'0'));
			$member = $this->members_m->get($slug);
		}

		if (!empty($member))
		{
			if ( ( strtolower(trim($member->status)) <> 'approved') &&
				(
					(!empty($this->current_user->group) && $this->current_user->group=='admin') OR (!empty($this->current_user->id) && $this->current_user->id == $member->MemberID_2)
				)
			)
			{
				$ok_to_show = true;
			}
			elseif (strtolower(trim($member->status)) == 'approved')
			{
				$ok_to_show = true;
			}
			else
			{
				$ok_to_show = false;
				show_404();
			}

			if ($ok_to_show)
			{
				$member->name = str_ireplace("\\", "", stripslashes($member->title) );
				$member->title = $member->name;
				$this->load->model('scc_m');
				if (!empty($member->mid))
					$member->scc = $this->scc_m->get_many_by(array('intID'=>$member->intID, 'expired'=>true));
				else
					$member->scc = null;

				$member->parent_member = $this->members_m->get_parent_member($member->intID);

				$this->template
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb($member->name)
					->title($member->name, 'Member')
					->set('sccs', $member->scc)
					//->append_js('admin/filter.js')
					->set('member', $member);

				//$this->input->is_ajax_request() ? $this->template->build('ajax/view') : $this->template->build('view-primary');

				if ($member->parent_company == 'y' OR $member->parent_company == 'yes')
				{
					$this->template->build('view-primary');
				}
				elseif ($member->parent_company == 'sub')
				{
					//$member->parent_member = array_values(unserialize($member->sub_company));
					$this->template->build('view-subsidiary');
				}
				else
				{
					//$this->template->build('view');
					$this->template->build('view-subsidiary');
				}
			}

		}
		else
		{
			// reset back to SITE_REF
			$this->db->set_dbprefix(SITE_REF.'_');

			// check if we have the page
			$this->load->model('pages/page_m');
			$page = $this->page_m->get_by_uri('members/'.$slug, true);
			if ($page)
			{
				$url_segments = $this->uri->total_segments() > 0 ? $this->uri->segment_array() : null;

				if ($url_segments = explode('/', $page->base_uri) and count($url_segments) > 1)
				{
					// we dont care about the last one
					//array_shift($url_segments);
		
					// This array of parents in the cache?
					if ( ! $parents = $this->pyrocache->get('page_m/'.md5(implode('/', $url_segments))))
					{
						$parents = $breadcrumb_segments = array();
		
						foreach ($url_segments as $segment)
						{
							$breadcrumb_segments[] = $segment;
		
							$parents[] = $this->pyrocache->model('page_m', 'get_by_uri', array($breadcrumb_segments, true, true));
						}
		
						// Cache for next time
						$this->pyrocache->write($parents, 'page_m/'.md5(implode('/', $url_segments)));
					}

					$count_parent = count($parents);
					foreach ($parents as $idx => $parent_page)
					{
						if ($idx == $count_parent-1)
							$this->template->set_breadcrumb($parent_page->title);
							//$this->template->set_breadcrumb($parent_page->meta_title ? $parent_page->meta_title : $parent_page->title);
						else
							$this->template->set_breadcrumb($parent_page->title, $parent_page->uri);
					}
				}
				$this->template
					->title($page->meta_title ? $page->meta_title : $page->title)
					->set('page', $page)
					->build('view-page');
			}
			else
			{
				$this->session->set_flashdata('error', lang('members:member_not_exist_error'));
				//redirect('members/all');
				if(SITE_REF == "bcn"){
					/* $this->template
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb($member->name); */
					
					redirect('members/all');

					$this->db->set_dbprefix('default_');
				}else{
					/* $this->template
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb($member->name); */
					
					redirect('members/all');
				}
			}

		}

	}

	private function _viewOS($slug)
	{
		$slug or redirect('members');

		//$member = $this->members_m->get_by(array('intID'=>$slug, 'status'=>'Approved', 'isDeleted'=>'0'));
		$member = $this->members_m->get($slug);

		//$this->template

		if (!empty($member))
		{
			$this->load->model('scc_m');
			$member->scc = $this->scc_m->get_many_by(array('mid'=>$member->mid?$member->mid:$member->intID, 'expired'=>true));
			$member->parent_member = $this->members_m->get_parent_member($member->intID);

			$this->template
				->set_breadcrumb('Members', 'members')
				->set_breadcrumb($member->name)
				->title($member->name, 'Member')
				->set('sccs', $member->scc)
				//->append_js('admin/filter.js')
				->set('member', $member);

			//$this->input->is_ajax_request() ? $this->template->build('ajax/view') : $this->template->build('view-primary');

			if ($member->parent_company == 'y')
			{
				$this->template->build('view-primary');
			}
			elseif (!empty($member->parent_member))
			{
				$this->template->build('view-subsidiary');
			}
			else
			{
				//$this->template->build('view');
				$this->template->build('view-subsidiary');
			}
		}
		else
		{
			// reset back to SITE_REF
			$this->db->set_dbprefix(SITE_REF.'_');

			// check if we have the page
			$this->load->model('pages/page_m');
			$page = $this->page_m->get_by_uri('members/'.$slug, true);
			if ($page)
			{
				$url_segments = $this->uri->total_segments() > 0 ? $this->uri->segment_array() : null;

				if ($url_segments = explode('/', $page->base_uri) and count($url_segments) > 1)
				{
					// we dont care about the last one
					//array_shift($url_segments);
		
					// This array of parents in the cache?
					if ( ! $parents = $this->pyrocache->get('page_m/'.md5(implode('/', $url_segments))))
					{
						$parents = $breadcrumb_segments = array();
		
						foreach ($url_segments as $segment)
						{
							$breadcrumb_segments[] = $segment;
		
							$parents[] = $this->pyrocache->model('page_m', 'get_by_uri', array($breadcrumb_segments, true, true));
						}
		
						// Cache for next time
						$this->pyrocache->write($parents, 'page_m/'.md5(implode('/', $url_segments)));
					}

					$count_parent = count($parents);
					foreach ($parents as $idx => $parent_page)
					{
						if ($idx == $count_parent-1)
							$this->template->set_breadcrumb($parent_page->title);
						else
							$this->template->set_breadcrumb($parent_page->title, $parent_page->uri);
					}
				}
				$this->template
					->title($page->meta_title ? $page->meta_title : $page->title)
					->set('page', $page)
					->build('view-page');
			}
			else
			{
				$this->session->set_flashdata('error', lang('members:member_not_exist_error'));
				//redirect('members/all');
				if(SITE_REF == "bcn"){
					/* $this->template
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb($member->name); */
					
					redirect('members/all');

					$this->db->set_dbprefix('default_');
				}else{
					/* $this->template
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb($member->name); */
					
					redirect('members/all');
				}
			}

		}

	}

	public function pleasewait()
	{
		if(SITE_REF == "bcn"){
			$this->template
			->title('Member application')
			->set_breadcrumb('RSPO会员', 'members')
			->set_breadcrumb('Application In Process')
			->build('applications/wait');
		}
		else{
			$this->template
			->title('Member application')
			->set_breadcrumb('Members', 'members')
			->set_breadcrumb('Application In Process')
			->build('applications/wait');
		}
	}

	public function selecttype()
	{
		$this->db->set_dbprefix(SITE_REF.'_');
		
		if (empty($this->current_user->id) )
		{
			$this->session->set_flashdata('error', 'You need to login to submit a member application. If you haven\'t registered, please do so by filling in the form below.');
			$this->session->set_flashdata('redirect_to', 'members/selecttype');
			redirect('members/apply');
			//exit;
		}
		else
		{
			if ($this->current_user->group <> 'user')
			{
				$this->session->set_flashdata('error', 'Sorry, you are not registered as an applying member. If you think you should be, please contact us <a href="mailto:membership@rspo.org?Subject=Unable to complete application due to wrong user access.">here</a>, or <a href="'.site_url('members/logout/members/apply').'">logout</a>.');
				//redirect('members/all');
				if(SITE_REF == "bcn"){
					/* $this->template
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb('Select Membership Category'); */
					
					redirect('members/all');

					$this->db->set_dbprefix('default_');
				}else{
					/* $this->template
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb('Select Membership Category'); */
					
					redirect('members/all');
				}
			}
			//exit;
		}

		$m = $this->members_m->get_by('MemberID_2', $this->current_user->id);
		if (!empty($m))
		{
			redirect('members/application');
		}

		$this->template
			->title('Member application')
			->set_breadcrumb('Members', 'members')
			->set_breadcrumb('Select Membership Category')
			->build('applications/select-type');
	}

	public function application()
	{
		$this->db->set_dbprefix(SITE_REF.'_');
		
		if (empty($this->current_user->id) )
		{
			$this->session->set_flashdata('error', 'You need to login to submit a member application. If you haven\'t registered, please do so by filling in the form below.');
			redirect('members/apply');
			//exit;
		}
		else
		{
			if ($this->current_user->group <> 'user')
			{
				$this->session->set_flashdata('error', 'Sorry, you are not registered as an applying member. If you think you should be, please contact us <a href="mailto:membership@rspo.org?Subject=Unable to complete application due to wrong user access.">here</a>, or <a href="'.site_url('members/logout/members/apply').'">logout</a>.');
				//redirect('members/all');
				if(SITE_REF == "bcn"){
					/* $this->template
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb('Application'); */
					
					redirect('members/all');

					$this->db->set_dbprefix('default_');
				}else{
					/* $this->template
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb('Application'); */
					
					redirect('members/all');
				}
			}
			//exit;
		}

		$save = false;
		if ($this->input->post('btnSave'))
		{
			$save = true;
		}

		// process empty element in array fields
		if (!empty($_POST['div_files_cert']) && count($_POST['div_files_cert']) > 1)
		{
			foreach($_POST['div_files_cert'] as $i => $f)
			{
				if (empty($f) && $i != 0)
					unset($_POST['div_files_cert'][$i]);
			}
		}
		if (!empty($_POST['div_file_additionals']) && count($_POST['div_file_additionals']) > 1)
		{
			foreach($_POST['div_file_additionals'] as $i => $f)
			{
				if (empty($f) && $i != 0)
					unset($_POST['div_file_additionals'][$i]);
			}
		}
		if (!empty($_POST['div_file_sh_group_manager']) && count($_POST['div_file_sh_group_manager']) > 1)
		{
			foreach($_POST['div_file_sh_group_manager'] as $i => $f)
			{
				if (empty($f) && $i != 0)
					unset($_POST['div_file_sh_group_manager'][$i]);
			}
		}


		if ($this->input->post('category') == 'Oil Palm Growers')
		{
			$this->validation_rules['primary_market_ops'] = array(
				'field' => 'primary_market_ops',
				'label' => "Primary Market Operation",
				'rules' => 'trim|required',
			);
/*
			$this->validation_rules['other_market_ops'] = array(
				'field' => 'other_market_ops',
				'label' => "Other Market Operation",
				'rules' => 'trim|required',
			);
*/
			if ($this->input->post('uploaded_files_cert') == '')
			{
				$this->validation_rules['supporting_docs'] = array(
					'field' => 'div_files_cert[]',
					'label' => 'Supporting documents',
					'rules' => 'trim|required|htmlspecialchars',
				);
			}

			if ($this->input->post('profession')=='Smallholder Group Manager')
			{
				if ($this->input->post('uploaded_file_additionals') == '')
				{
					$this->validation_rules['additional_docs'] = array(
						'field' => 'div_file_additionals[]',
						'label' => 'Additional documents',
						'rules' => 'trim|required|htmlspecialchars',
					);
				}
				if ($this->input->post('uploaded_file_sh_group_manager') == '')
				{
					$this->validation_rules['sh_group_manager_docs'] = array(
						'field' => 'div_file_sh_group_manager[]',
						'label' => 'Documents for Smallholder Group Manager',
						'rules' => 'trim|required|htmlspecialchars',
					);
				}
			}
			elseif ($this->input->post('profession')=='Small growers')
			{
				if ($this->input->post('uploaded_file_additionals') == '')
				{
					$this->validation_rules['additional_docs'] = array(
						'field' => 'div_file_additionals[]',
						'label' => 'Additional documents',
						'rules' => 'trim|required|htmlspecialchars',
					);
				}
			}

		}

		if ($this->input->post('type') == 'Affiliate' OR $this->input->post('type') == 'Affiliate Members' OR $this->input->post('type') == 'Associate' OR $this->input->post('type') == 'Supply Chain Associate')
		{
			$this->validation_rules['q1'] = array(
				'field' => 'q1',
				'label' => 'q1',
				'rules' => 'trim',
			);
			$this->validation_rules['q2'] = array(
				'field' => 'q2',
				'label' => 'q2',
				'rules' => 'trim',
			);
			$this->validation_rules['q3'] = array(
				'field' => 'q3',
				'label' => 'q3',
				'rules' => 'trim',
			);
			$this->validation_rules['q4'] = array(
				'field' => 'q4',
				'label' => 'q4',
				'rules' => 'trim',
			);
		}

		if ($this->input->post('type') == 'Associate' OR $this->input->post('type') == 'Supply Chain Associate')
		{
			if ($this->input->post('category')=='Supply Chain Group Manager')
			{
				$this->validation_rules['scg_manager_members'] = array(
					'field' => 'scg_manager_members[]',
					'label' => 'List of members',
					'rules' => 'trim|htmlspecialchars|required|callback__check_scg_members',
				);
			}
			else
			{
				$this->validation_rules['q_usage'] = array(
					'field' => 'q_usage',
					'label' => 'Palm oil &amp; derivative annual usage',
					'rules' => 'trim|required',
				);
			}
		}
		elseif ($this->input->post('type') == 'Ordinary' OR $this->input->post('type') == 'Ordinary Members')
		{
			if ($this->input->post('category')=='Oil Palm Growers')
			{
				$this->validation_rules['production_area'] = array(
					'field' => 'production_area',
					'label' => 'Production area',
					'rules' => 'trim|required',
				);
			}
			else{
				$this->validation_rules['production_area'] = array(
					'field' => 'production_area',
					'label' => 'Production area',
					'rules' => 'trim',
				);
			}
		}
		

		$membershipapplication = new stdClass();
		$membersapp = new stdClass();

		if ($this->input->post('category'))
		{
			$membershipapplication->category = $this->input->post('category');
		}

		if ($this->input->post('type'))
		{
			$membershipapplication->type = $this->input->post('type');
		}
		
		// check if member has saved session
		$m = $this->members_m->get_by('MemberID_2', $this->current_user->id);
		if (!empty($m))
		{
			if ($m->status == 'Applied')
			{
				redirect('members/logout?u=members/pleasewait');
			}
			elseif ( $m->status == 'Approved' OR strtolower($m->status) == 'call for comment' )
			{
				redirect('members/profile');
				exit;
			}
			//elseif ($m->status == 'draft')

			$membershipapplication = $m;
		}
		else
		{
			if (empty($membershipapplication->category))
				redirect('members/selecttype');
			$membershipapplication->intID = 0;
		}

		if ($this->input->post('scg_manager_members'))
		{
			$scg_members = serialize($this->input->post('scg_manager_members'));
		}
		else
		{
			$scg_members = !empty($membershipapplication->scg_manager_members) ? $membershipapplication->scg_manager_members : '';
		}


		$subsidiaries = $this->input->post('sub_company');
		$sub_company = array();
		if (!empty($subsidiaries))
		{
			foreach($subsidiaries['name'] as $k=>$v)
			{
				if ($v)
				{
					$sub_company[$k]['name'] = $v;
					$sub_company[$k]['id'] = $subsidiaries['id'][$k];
				}
			}
			$subsidiary = serialize($sub_company);
		}
		else
		{
			$subsidiary = !empty($membershipapplication->sub_company) ? $membershipapplication->sub_company : serialize(NULL);
		}

		$this->check_dir($this->config_upload['upload_path']);
		$this->load->library('upload', $this->config_upload);
		//$this->load->library('MY_Upload');
		
		if(!empty($_FILES['logo']['name'])){
		
			if(!$this->upload->do_upload('logo')){ 
				
			}
			else{
				$filelogo_array = $this->upload->data();
				$filelogo = $filelogo_array['file_name'];
			}
		}
		else{
			if ($_POST)
				$filelogo = $this->input->post('upload_logo');
			else
				$filelogo = isset($membershipapplication->logo) ? $membershipapplication->logo : '';
		}

		if (!empty($_FILES['file_certificates']['name'][0]))
		{
			$file_certificates = array();
			if ($this->input->post('uploaded_files_cert'))
			{
				$file_certificates = explode(',', $this->input->post('uploaded_files_cert'));
			}
			if($this->upload->do_multi_upload("file_certificates"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();

				foreach($file_uploaded as $files)
				{
					$file_certificates[] = $files['file_name'];
				}
				
				$cert_file_m = implode(',', $file_certificates);
			}
		}
		else{
			if ($_POST)
				$cert_file_m = $this->input->post('uploaded_files_cert');
			else
				$cert_file_m = isset($membershipapplication->file_certificates) ? $membershipapplication->file_certificates : '';
		}

		// additional files
		if (!empty($_FILES['file_additionals']['name'][0]))
		{
			$addfiles = array();
			if ($this->input->post('uploaded_file_additionals'))
			{
				$addfiles = explode(',', $this->input->post('uploaded_file_additionals'));
			}
			if($this->upload->do_multi_upload("file_additionals"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();

				foreach($file_uploaded as $files)
				{
					$addfiles[] = $files['file_name'];
				}
				
				$file_additionals = implode(',', $addfiles);
			}
		}
		else{
			if ($_POST)
				$file_additionals = $this->input->post('uploaded_file_additionals');
			else
				$file_additionals = isset($membershipapplication->file_additionals) ? $membershipapplication->file_additionals : '';
		}


		if ($this->input->post('remove_uploaded_additionals'))
		{
			$remove_file_additionals = explode(',',$file_additionals);
			$remove_uploaded_additionals = $this->input->post('remove_uploaded_additionals');
			foreach($remove_uploaded_additionals as $r)
			{

				if (($key = array_search($r, $remove_file_additionals)) !== false) {
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($remove_file_additionals[$key]);
					}
					else
					{
						unset($remove_file_additionals[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$file_additionals = implode(',', $remove_file_additionals);
		}

/*
if (!empty($_POST))
{
	echo "<pre>\n";
	echo "\$file_additionals:\n";
	print_r($file_additionals);
	echo "</pre>\n";
	exit;
}
*/


		// smallholder group manager files
		if (!empty($_FILES['file_sh_group_manager']['name'][0]))
		{
			$shfiles = array();
			if ($this->input->post('uploaded_file_sh_group_manager'))
			{
				$shfiles = explode(',', $this->input->post('uploaded_file_sh_group_manager'));
			}

			if($this->upload->do_multi_upload("file_sh_group_manager"))
			{
				$file_uploaded = $this->upload->get_multi_upload_data();
				foreach($file_uploaded as $files)
				{
					$shfiles[] = $files['file_name'];
				}
					
				$file_sh_group_manager = implode(',', $shfiles);
			}
		}
		else{
			if ($_POST)
				$file_sh_group_manager = $this->input->post('uploaded_file_sh_group_manager');
			else
				$file_sh_group_manager = isset($membershipapplication->file_sh_group_manager) ? $membershipapplication->file_sh_group_manager : '';
		}

		if ($this->input->post('remove_file_sh_group_manager'))
		{
			$remove_file_sh_group_manager = explode(',',$file_sh_group_manager);
			$remove_uploaded_file_sh_group_manager = $this->input->post('remove_file_sh_group_manager');
			foreach($remove_uploaded_file_sh_group_manager as $r)
			{

				if (($key = array_search($r, $remove_file_sh_group_manager)) !== false) {
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($remove_file_sh_group_manager[$key]);
					}
					else
					{
						unset($remove_file_sh_group_manager[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$file_sh_group_manager = implode(',', $remove_file_sh_group_manager);
		}


		if ($this->input->post('remove_uploaded_cert'))
		{
			$forremoveimg = explode(',',$cert_file_m);
			$remove_uploaded_cert = $this->input->post('remove_uploaded_cert');
			foreach($remove_uploaded_cert as $r)
			{

				if (($key = array_search($r, $forremoveimg)) !== false) {
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg[$key]);
					}
					else
					{
						unset($forremoveimg[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$cert_file_m = implode(',', $forremoveimg);
		}

		if (!empty($_FILES['file']['name'][0]))
		{
			if($this->upload->do_multi_upload("file"))
				{
					$file = array();
					$file_uploaded = $this->upload->get_multi_upload_data();
					if ($this->input->post('grower_file'))
					{
						$file = explode(',', $this->input->post('grower_file'));
					}

					foreach($file_uploaded as $files)
					{
						$file[] = $files['file_name'];
					}
					
					$file_grower_m = implode(',', $file);
				}
		}
		else{
			if ($_POST)
				$file_grower_m = $this->input->post('grower_file');
			else
				$file_grower_m = isset($membershipapplication->file) ? $membershipapplication->file : '';
		}
		
		$forremoveimg_grower = explode(',',$file_grower_m);
		if ($this->input->post('remove_uploaded_grower'))
		{
			$remove_uploaded_grower = $this->input->post('remove_uploaded_grower');
			foreach($remove_uploaded_grower as $r)
			{
				
				if (($key = array_search($r, $forremoveimg_grower)) !== false) {
	
					// remove the file
					if (is_file($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r) && unlink($_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH.'memberlogos/'.$r))
					{
						unset($forremoveimg_grower[$key]);
					}
					else
					{
						unset($forremoveimg_grower[$key]);
						$this->session->set_flashdata('info', 'Error deleting file '.$r);
					}
				}
			}
			$file = implode(',', $forremoveimg_grower);
		}

		$primary_name = $this->input->post('name_p');
		$primary_email = $this->input->post('email_p');
		$primary_designation = $this->input->post('designation_p');

		$secondary_name = $this->input->post('name_s');
		$secondary_email = $this->input->post('email_s');
		$secondary_designation = $this->input->post('designation_s');

		$this->validation_rules['primary_name'] = array(
			'field' => 'name_p',
			'label' => 'Primary Nomination First name',
			'rules' => 'trim|max_length[100]|required|callback__check_use['.$secondary_name.']',
		);
		
		$this->validation_rules['secondary_name'] = array(
			'field' => 'name_s',
			'label' => 'Secondary Nomination First Name',
			'rules' => 'trim|max_length[100]|required|callback__check_use['.$primary_name.']',
		);

		$this->validation_rules['primary_email'] = array(
			'field' => 'email_p',
			'label' => 'Primary Nomination Email',
			'rules' => 'trim|required|valid_email|callback__check_use['.$secondary_email.']',
		);

		$this->validation_rules['secondary_email'] = array(
			'field' => 'email_s',
			'label' => 'Secondary Nomination Email',
			'rules' => 'trim|required|valid_email|callback__check_use['.$primary_email.']',
		);
		
		$this->validation_rules['primary_designation'] = array(
			'field' => 'designation_p',
			'label' => 'Primary Nomination Position',
			'rules' => 'trim|required|callback__check_use['.$secondary_designation.']',
		);

		$this->validation_rules['secondary_designation'] = array(
			'field' => 'designation_s',
			'label' => 'Secondary Nomination Position',
			'rules' => 'trim|required|callback__check_use['.$primary_designation.']',
		);

		if ($membershipapplication->category == 'Consumer Goods Manufacturers' OR $membershipapplication->category == 'Palm Oil Processors and Traders')
		{
			$this->validation_rules['sub_category'] = array(
				'field' => 'profession',
				'label' => "Organisation's sub-category",
				'rules' => 'trim|required',
			);
		}

		$validated = false;
		if ($save && $this->input->post('btnSave'))
		{
			$validated = true; //$this->form_validation->run();
		}
		elseif ($this->input->post('btnSubmit'))
		{
			$this->form_validation->set_rules($this->validation_rules);
			$validated = $this->form_validation->run();
		}


		if ($this->input->post('applied_date'))
		{
			$a_date = explode('/', $this->input->post('applied_date'));
			$applied_year = $a_date[2];
			$applied_month = $a_date[1];
			$applied_day = $a_date[0];
			$applied_date = mktime(0, 0, 0, $applied_month, $applied_day, $applied_year);
		}
		else
		{
			$applied_date = isset($membershipapplication->applied_date) ? $membershipapplication->applied_date : 0;
		}
//		$applied_date = strtotime(sprintf('%s $s:$s', $this->input->post('applied_date'), date('H'), date('i')));

		if($validated)
		{
			$pcompany = $this->input->post('parent_company');
			if ($pcompany == 'none') $pcompany = null;
			$input = array(
				'title' 	=> $this->input->post('org_name'),
				'type' 		=> $this->input->post('type'),
				'category' 	=> $this->input->post('category'),
				'name' 		=> $this->input->post('org_name'),
				'address' 	=> $this->input->post('address'),
				'address_city' 	=> $this->input->post('address_city'),
				'address_state' => $this->input->post('address_state'),
				'address_zip' 	=> $this->input->post('address_zip'),
				'country' 		=> $this->input->post('country'),
				'code_telephone' => $this->input->post('code_telephone'),
				'telephone' 	=> $this->input->post('telephone'),
				'code_fax' 				=> $this->input->post('code_fax'),
				'fax' 			=> $this->input->post('fax'),
				'email' 		=> $this->input->post('email'),
				'website'	 	=> $this->input->post('website'),
				'registration_number' 	=> $this->input->post('registration_number'),
				'parent_company' 		=> $pcompany,
				'sub_company'			=> ($pcompany == 'yes' OR $pcompany == 'sub') ? $subsidiary : null,
				'primary_market_ops' 	=> $this->input->post('primary_market_ops'),
				'other_market_ops' 	=> $this->input->post('other_market_ops'),
				'logo' 				=> $filelogo,
				'profile' 			=> $this->input->post('profile'),
				'production_area' 	=> $this->input->post('production_area'),
				'scg_manager_members' 	=> $scg_members,

				'name_p' 		=> $this->input->post('name_p'),
				'designation_p' => $this->input->post('designation_p'),
				'code_tel_p' 	=> $this->input->post('code_tel_p'),
				'telephone_p' 	=> $this->input->post('telephone_p'),
				'code_fax_p' 	=> $this->input->post('code_fax_p'),
				'fax_p' 		=> $this->input->post('fax_p'),
				'email_p' 		=> $this->input->post('email_p'),
				'name_s' 		=> $this->input->post('name_s'),
				'designation_s' => $this->input->post('designation_s'),
				'code_tel_s' 	=> $this->input->post('code_tel_s'),
				'telephone_s' 	=> $this->input->post('telephone_s'),
				'code_fax_s' 	=> $this->input->post('code_fax_s'),
				'fax_s' 		=> $this->input->post('fax_s'),
				'email_s' 		=> $this->input->post('email_s'),
				
				'contact_person' 	=> $this->input->post('contact_person'),
				'designation' 		=> $this->input->post('designation'),
				'code_contact_tel' 		=> $this->input->post('code_contact_tel'),
				'contact_tel'	 	=> $this->input->post('contact_tel'),
				'code_contact_fax' 		=> $this->input->post('code_contact_fax'),
				'contact_fax'	 	=> $this->input->post('contact_fax'),
				'contact_email' 	=> $this->input->post('contact_email'),
				
				'name_f' 		=> $this->input->post('name_f'),
				'designation_f' => $this->input->post('designation_f'),
				'code_tel_f' 	=> $this->input->post('code_tel_f'),
				'telephone_f' 	=> $this->input->post('telephone_f'),
				'code_fax_f' 	=> $this->input->post('code_fax_f'),
				'fax_f' 		=> $this->input->post('fax_f'),
				'email_f' 		=> $this->input->post('email_f'),
				
				'q1' => $this->input->post('q1'),
				'q2' => $this->input->post('q2'),
				'q3' => $this->input->post('q3'),
				'q4' => $this->input->post('q4'),
				'q_usage' => $this->input->post('q_usage'),
				
				'name_a' 		=> $this->input->post('name_a'),
				'designation_a' => $this->input->post('designation_a'),
				'email_a'		=> $this->input->post('email_a'),
				'date_2' 		=> $this->input->post('date_2'),
				'profession' 		=> $this->input->post('profession'),
				'file_certificates'	=> $cert_file_m,
				'file_additionals'	=> $file_additionals,
				'file_sh_group_manager'	=> $file_sh_group_manager,
				'file'				=> $file_grower_m,
				'applied_date' 		=> now(),
				'remarks' 			=> $this->input->post('remarks'),
				'newsletter' 		=> $this->input->post('newsletter') ? $this->input->post('newsletter') : 'n',
				
				'contact_lname'		=> $this->input->post('contact_lname'),
				'name_last_p'		=> $this->input->post('name_last_p'),
				'name_last_s'		=> $this->input->post('name_last_s'),
				'name_last_f'		=> $this->input->post('name_last_f'),
			);

			$update = false;


			if ($save)
			{

				$input['status']='draft';
				$input['MemberID_2'] = $this->current_user->id;

				if ($m && $this->input->post('draft_id'))
				{
					// update data
					$update = $this->members_m->update($this->input->post('draft_id'), $input);
					if ($update)
						$update = $this->input->post('draft_id');
				}
				else
				{
					// update data
					$input['strAddDate'] = date('Y-m-d H:i', now());
					$update = $this->members_m->insert($input);
				}

				if ($update)
				{

					/********** send mail when saving ***********/
					$sendmail = false; // false = not sending, true = sending

					$datenow = date('l jS F Y h:i:s A');

					$subsidiary_unserialize = unserialize($subsidiary);
					if ($subsidiary_unserialize)
					{
						$sub = "";
						foreach($subsidiary_unserialize as $name)
						{
							$sub .= "- ".$name['name']."<br />\n";
						}
					}
					else
					{
						$sub = NULL;
					}
					// send notification to submitter first
					$data = $input;
					$data['from'] 			= "membership@rspo.org";
					$data['slug']			= 'membership-application';
					$data['to']				= $this->input->post('email_a');
					$data['email']			= $this->input->post('email_a');
					$data['name']			= 'RSPO Membership';
					$data['name_submitter']	= $this->input->post('name_a');
					if ($sendmail) Events::trigger('email', $data, 'array');
					
					$data_admin = $input;
					$data_admin['app_id']	= $update;
					$data_admin['from']		= "membership@rspo.org";//$input['email_a'];
					$data_admin['to']		= Settings::get('membership_application_email') ? Settings::get('membership_application_email') : Settings::get('contact_email');
					$data_admin['email']	= $data_admin['to'];
					$data_admin['slug']		= 'membership-application-admin';
					$data_admin['datenow']		= $datenow;
					//here add 
					$data_admin['name']				= 'RSPO Membership';
					$data_admin['org_name']			= $this->input->post('org_name');
					$data_admin['parent_company']	= $pcompany;
					$data_admin['sub_company']  	= ($pcompany == 'yes' OR $pcompany == 'sub') ? $sub : null;

					$data_admin['address']			= $this->input->post('address');
					$data_admin['address_city']		= $this->input->post('address_city');
					$data_admin['address_state']	= $this->input->post('address_state');
					$data_admin['address_zip']		= $this->input->post('address_zip');
					$data_admin['country']		= $this->input->post('country');
					$data_admin['telephone']	= $this->input->post('code_telephone') . ' ' . $this->input->post('telephone');
					$data_admin['fax']			= $this->input->post('code_fax') . ' ' . $this->input->post('fax');
					$data_admin['email_form']	= $this->input->post('email');
					$data_admin['website']		= $this->input->post('website');
					// end add
					if ($sendmail) Events::trigger('email', $data_admin, 'array');
				}
				else
				{
					$this->session->set_flashdata('error', 'Sorry, we have difficulties saving your data..');
				}
/*
echo "<pre>";
print_r($data_admin);
echo "</pre>";
exit;
*/
				/********** send mail when saving ***********/
			}
			else
			{
				$input['MemberID_2'] = $this->current_user->id;
				if ($m && $this->input->post('draft_id'))
				{
					// update -> change status to applied
					//$input['status'] = 'Draft'; // <--- for testing purpose
					$input['status'] = 'Applied'; // <--- for live site!!!
					$input['strModifyDate'] = date('Y-m-d', now());
					$update = $this->members_m->update($this->input->post('draft_id'), $input);
					if ($update)
						$update = $this->input->post('draft_id');
				}
				else
				{
					// insert new one (member clicks submit without saving
					$input['status'] = 'Applied';
					//$input['status'] = 'Draft'; // <--- for testing purpose
					$input['strAddDate'] = date('Y-m-d H:i', now());
					$update = $this->members_m->insert($input);
				}

				if (!$save)
				{
					// sync to SF
					$triggered_event = Events::trigger('member_updated', array('id'=>$update, 'input'=>$input));
					//$this->session->set_flashdata('notice', $triggered_event);

					// retrieve newly entered membership data
					$member_data = $this->members_m->get($update);

					// check for files
					$files = array(
						'application_sf_id'=>$member_data->application_sf_id,
						'logo'=>$member_data->logo,
						'file'=>$member_data->file,
						'file_certificates'=>$member_data->file_certificates,
						'file_additionals'=>$member_data->file_additionals,
						'file_sh_group_manager'=>$member_data->file_sh_group_manager,
						'file_sc_group_manager'=>$member_data->file_sc_group_manager,
					);
					// try sync to SF
					if ($member_data->application_sf_id OR $member_data->logo OR $member_data->file OR $member_data->file_certificates OR $member_data->file_additionals OR $member_data->file_sh_group_manager OR $member_data->file_sc_group_manager )
						$triggered_event = Events::trigger('files_updated', array('id'=>$update, 'member_name'=>$member_data->title, 'input'=>$files));

					$datenow = date('l jS F Y h:i:s A');
					
					$subsidiary_unserialize = unserialize($subsidiary);
					if ($subsidiary_unserialize)
					{
						$sub = "<ul>\n";
						foreach($subsidiary_unserialize as $name)
						{
							$sub .= "<li>".$name['name']."</li>\n";
						}
						$sub .= "</ul>\n";
					}
					else
					{
						$sub = NULL;
					}

					// if live, change to true
					$sendtosubmitter = true;

					// send notification to submitter first
					$data = $input;
					$data['from'] 			= "membership@rspo.org";
					$data['slug']			= 'membership-application';
					$data['to']				= $this->input->post('email_a');
					$data['email']			= $this->input->post('email_a');
					$data['name']			= 'RSPO Membership';
					$data['name_submitter']	= $this->input->post('name_a');
					if ($sendtosubmitter) Events::trigger('email', $data, 'array');
					
					$data_admin = $input;
					$data_admin['app_id']	= $update;
					$data_admin['from']		= "membership@rspo.org";//$input['email_a'];
					//$data_admin['to']		= Settings::get('contact_email');
					$data_admin['to']		= Settings::get('membership_application_email') ? Settings::get('membership_application_email') : Settings::get('contact_email');
					$data_admin['email']	= $data_admin['to'];
					$data_admin['slug']		= 'membership-application-admin';
					$data_admin['datenow']		= $datenow;
					//here add 
					$data_admin['org_name']			= $this->input->post('org_name');
					$data_admin['name']				= 'RSPO Membership';
					$data_admin['parent_company']	= $pcompany;
					$data_admin['sub_company']  	= ($pcompany == 'yes' OR $pcompany == 'sub') ? $sub : '-';

					$data_admin['address']			= $this->input->post('address');
					$data_admin['address_city']		= $this->input->post('address_city');
					$data_admin['address_state']	= $this->input->post('address_state');
					$data_admin['address_zip']		= $this->input->post('address_zip');
					$data_admin['country']		= $this->input->post('country');
					$data_admin['telephone']	= $this->input->post('code_telephone') . ' ' . $this->input->post('telephone');
					$data_admin['fax']			= $this->input->post('fax') ? $this->input->post('code_fax') . ' ' . $this->input->post('fax') : '-';
					$data_admin['email_form']	= $this->input->post('email');
					$data_admin['website']		= $this->input->post('website');
					// end add
					if ($sendtosubmitter) Events::trigger('email', $data_admin, 'array');

					redirect('members/logout?u=members/submitted'); // <-- live sistem
//					redirect('members/application'); // <-- for testing purposes
				}

				if ($update)
					$membershipapplication->intID = $update;
			}

			if($update)
			{
				if (!$membershipapplication->mid)
				{
					$last_mid = $this->members_m->get_last_mid();
					if ($last_mid)
					{
						$input['mid'] = $last_mid + 1;
					}
					else
					{
						$input['mid'] = $update;
					}
					$this->members_m->update($update, $input);
				}

				if ($save)
					$this->session->set_flashdata('success', '<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>Your form was saved successfully.');
				else
					$this->session->set_flashdata('success', 'Your application has been submitted successfully to RSPO.');
				redirect('members/application');
			}
			else
			{
				if ($save)
					$this->session->set_flashdata('error', 'We have difficulties saving your form. Please try again or report it to us.');
				else
					$this->session->set_flashdata('error', 'We have difficulties submitting your application. Please try again or report it to us.');
				redirect('members/application');
			}
		}
		
		// Go through all the known fields and get the post values
		if ($_POST)
		{
			foreach ($this->validation_rules as $rule)
			{
				//if (isset($_POST[$rule['field']]))
					$membershipapplication->{$rule['field']} = $this->input->post($rule['field']);
			}
		}

		$membershipapplication->logo = $filelogo;
		$membershipapplication->file = $file_grower_m;
		$membershipapplication->file_certificates = $cert_file_m; //!empty($cert_file_m) ? $cert_file_m : '';
		$membershipapplication->file_additionals = $file_additionals; //!empty($cert_file_m) ? $cert_file_m : '';
		$membershipapplication->file_sh_group_manager = $file_sh_group_manager; //!empty($cert_file_m) ? $cert_file_m : '';
		$membershipapplication->scg_manager_members = $scg_members;


		$membershipapplication->file = implode(',', $forremoveimg_grower);
		//$membershipapplication->file_certificates = implode(',', $forremoveimg);
		$membershipapplication->sub_company = $subsidiary;
		if (isset($membershipapplication->org_name))
			$membershipapplication->name = $membershipapplication->org_name;
		elseif (empty($membershipapplication->name))
			$membershipapplication->name = '';

		$membershipapplication->name_a = $this->input->post('name_a') ? $this->input->post('name_a') : $this->current_user->first_name . ( $this->current_user->last_name ? ' ' . $this->current_user->last_name : '' );
		$membershipapplication->email_a = $this->input->post('email_a') ? $this->input->post('email_a') : $this->current_user->email;

		$this->template
			->title('Member application')
			->set_breadcrumb('Members', 'members')
			->set_breadcrumb('Application')
			->append_css('main.css')
			//->append_js('jquery.steps.min.js')
			->append_js('bootstrap-filestyle.js')
			->set('membersapp', $membershipapplication)
			->build('applications/application');
			//->build('applications/application');
	}

	public function submitted()
	{
		$this->template
			->title('Member application')
			->set_breadcrumb('Members', 'members')
			->set_breadcrumb('Application Submitted')
			->build('applications/submitted');
	}

	/**
	 * Method to log the user out of the system
	 */
	public function logout($slug='')
	{
		$redirect_to = '';
		$u = $this->input->get('u');
		if ($u)
		{
			$redirect_to = $u;
			$this->session->set_userdata('redirect_to', $redirect_to);
		}

		// allow third party devs to do things right before the user leaves
		Events::trigger('pre_user_logout');

		$this->ion_auth->logout();

		if ($this->input->is_ajax_request())
		{
			exit(json_encode(array('status' => true, 'message' => lang('user:logged_out'))));
		}
		else
		{
			$this->session->set_flashdata('success', lang('user:logged_out'));
			$redirect_to ? redirect($redirect_to) : redirect('');
		}
	}

	/**
	 * Activated page.
	 *
	 * Shows an activated messages and a login form.
	 */
	public function activated()
	{
		//if they are logged in redirect them to the home page
		if ($this->current_user)
		{
			redirect(base_url());
		}

		$this->template->activated_email = ($email = $this->session->flashdata('activated_email')) ? $email : '';

		$this->template
			->title('Members | Activated')
			->set_breadcrumb('Members', 'members')
			->set_breadcrumb('Activated')
			->build('member/activated');
	}

	public function activate($id=0, $code='')
	{
		// Get info from email
		if ($this->input->post('email'))
		{
			$this->template->activate_user = $this->ion_auth->get_user_by_email($this->input->post('email'));
			$id = $this->template->activate_user->id;
		}

		if (!$code)
			$code = ($this->input->post('activation_code')) ? $this->input->post('activation_code') : $code;

		// If user has supplied both bits of information
		if ($id and $code)
		{
			// Try to activate this user
			if ($this->ion_auth->activate($id, $code))
			{
				$this->session->set_flashdata('activated_email', $this->ion_auth->messages());

				// trigger an event for third party devs
				Events::trigger('post_user_activation', $id);
				$data['to'] = $this->input->post('email');
				$data['from'] = Settings::get('contact_email');
				$data['slug'] = 'activation-successful';
				Events::trigger('email', $data, 'array');
				redirect('members/activated');
			}
			else
			{
				$this->template->error_string = 'We were unable to activate your account, or it has been activated. Please login <a href="'.site_url('members/login').'">here</a>';//$this->ion_auth->errors();
			}
		}

		$this->template
			->title(lang('user:activate_account_title'))
			->set_breadcrumb(lang('user:activate_label'), 'member/activate')
			->build('member/activate');
	}

	public function login()
	{
		$this->db->set_dbprefix(SITE_REF.'_');
		
		// Check post and session for the redirect place
		$redirect_to = ($this->input->post('redirect_to')) 
			? trim(urldecode($this->input->post('redirect_to')))
			: $this->session->userdata('redirect_to');

		// Any idea where we are heading after login?
		if ( ! $_POST and $args = func_get_args())
		{
			$this->session->set_userdata('redirect_to', $redirect_to = implode('/', $args));
		}

		// Get the user data
		$user = (object) array(
			'email' => $this->input->post('email'),
			'password' => $this->input->post('password')
		);

		$validation = array(
			array(
				'field' => 'email',
				'label' => 'e-mail',
				'rules' => 'required|trim|callback__check_login'
			),
			array(
				'field' => 'password',
				'label' => 'password',
				'rules' => 'required|min_length['.$this->config->item('min_password_length', 'ion_auth').']|max_length['.$this->config->item('max_password_length', 'ion_auth').']'
			),
		);

		// Set the validation rules
		$this->form_validation->set_rules($validation);
		
		$this->db->set_dbprefix(SITE_REF.'_');
		
		// If the validation worked, or the user is already logged in
		if ($this->form_validation->run() or $this->current_user)
		{
			// Kill the session
			$this->session->unset_userdata('redirect_to');

			$redirect_to = 'members/selecttype';

			$user = $this->ion_auth->get_user_by_email($user->email);

			// check if member has saved session
			if (!empty($user->id))
			{
				$m = $this->members_m->count_by( array('MemberID_2'=>$user->id, 'status'=>'Draft') );
				if ($m)
					$redirect_to = 'members/application';
			}

			// trigger a post login event for third party devs
			Events::trigger('post_user_login');

			if ($this->input->is_ajax_request())
			{
				$user->password = '';
				$user->salt = '';

				exit(json_encode(array('status' => true, 'message' => 'You have logged in successfully. If you are not being redirected, please <a href="'.site_url('members/application').'">click here</a>.', 'data' => $user, 'redirect_to'=>site_url($redirect_to))));
			}
			else
			{
				$this->session->set_flashdata('success', lang('user:logged_in'));
			}

			// Don't allow protocols or cheeky requests
			if (strpos($redirect_to, ':') !== false and strpos($redirect_to, site_url()) !== 0)
			{
				// Just login to the homepage
				redirect('');
			}

			// Passes muster, on your way
			else
			{
				redirect('members/profile');
				//redirect($redirect_to ? $redirect_to : '');
			}
		}

		if ($_POST and $this->input->is_ajax_request())
		{
			exit(json_encode(array('status' => false, 'message' => validation_errors())));
		}

		$error_string = NULL;
		if ($_POST)
		{
			$error_string = validation_errors();
		}

		$this->template
			->title('Members login')
			->set('error_string', $error_string)
			->set_breadcrumb('Members', 'members')
			->set_breadcrumb('Login')
			->build('applications/login', array(
				'_user' => $user,
				'redirect_to' => $redirect_to,
			));
	}

	public function register()
	{
		if (!$this->input->is_ajax_request())
			redirect('members/apply');

		$error = null;
		$recaptchaOK = false;
		$resp = null;
		$this->load->library('recaptchalib');

		if (!empty($_POST["recaptcha_response_field"])) {
			$resp = $this->recaptchalib->recaptcha_check_answer(Settings::get('recaptcha_private'),
				$_SERVER["REMOTE_ADDR"],
				$_POST["recaptcha_challenge_field"],
				$_POST["recaptcha_response_field"]);
			if ($resp->is_valid) {
				$recaptchaOK = TRUE;
			} else {
				# set the error code so that we can display it
				$error = $resp->error;
				//$this->template->set('recaptcha_error', '<div class="alert animated alert-danger">Please enter the text you see in the Captcha image.</div>');
				//$recaptcha = $this->recaptchalib->recaptcha_get_html(Settings::get('recaptcha_public'), $error);
				$message = array(
					'status' => "error",
					'message'	=> "Incorrect CAPTCHA. Please enter the text you see in the CAPTCHA image.",
					//'recaptcha' => $recaptcha,
				);
				echo json_encode($message);
				exit;
			}

		}
		elseif ($_POST && empty($_POST["recaptcha_response_field"]))
		{
			$recaptcha = $this->recaptchalib->recaptcha_get_html(Settings::get('recaptcha_public'), $error);
			$message = array(
				'status' => "error",
				'message'	=> "Please enter the text you see in the Captcha image.",
				'recaptcha' => $recaptcha,
			);
			echo json_encode($message);
			exit;
		}
		elseif ($_POST)
		{
			$this->template->set('recaptcha_error', '<div class="alert animated alert-danger">Please enter the text you see above</div>');
		}
		
		$recaptcha = $this->recaptchalib->recaptcha_get_html(Settings::get('recaptcha_public'), $error);

		$checked = ($this->input->post('agree_cod') && $this->input->post('agree_pp'));
		if (!$checked)
		{
			$message = array(
				'status' => "error",
				'message'	=> "Please check both the Code of Conduct and Privacy Policy agreement checkboxes"
			);
			echo json_encode($message);
			exit;
		}

		$this->load->model('users/user_m');
		$this->load->helper('users/user');
		$this->lang->load('users/user');

		$msg = 'nothing';
/*
		if ($this->current_user)
		{
			$this->session->set_flashdata('notice', lang('user:already_logged_in'));
			redirect();
		}
*/

		/* show the disabled registration message */
/*
		if ( ! Settings::get('enable_registration'))
		{
			$this->template
				->title(lang('user:register_title'))
				->build('disabled');
			return;
		}
*/

		// Validation rules
		$validation = array(
			array(
				'field' => 'password',
				'label' => lang('global:password'),
				'rules' => 'required|min_length['.$this->config->item('min_password_length', 'ion_auth').']|max_length['.$this->config->item('max_password_length', 'ion_auth').']'
			),
			array(
				'field' => 'email',
				'label' => lang('global:email'),
				'rules' => 'required|max_length[60]|valid_email|callback__email_check',
			),
			array(
				'field' => 'full_name',
				'label' => 'Full name',
				'rules' => 'required|max_length[100]',
			),
			array(
				'field' => 'username',
				'label' => lang('user:username'),
				'rules' => Settings::get('auto_username') ? '' : 'required|alpha_dot_dash|min_length[3]|max_length[20]|callback__username_check',
			),
		);

		// --------------------------------
		// Merge streams and users validation
		// --------------------------------
		// Why are we doing this? We need
		// any fields that are required to
		// be filled out by the user when
		// registering.
		// --------------------------------

		$name = $this->input->post('full_name');
		if ($name)
		{

			$fn = explode(' ', $name, 2);
			$first_name = $fn[0];
			$last_name = isset($fn[1]) ? $fn[1] : '';

		}

		$_POST['first_name'] = $first_name;
		$_POST['last_name'] = $last_name;

		// Get the profile fields validation array from streams
		$this->load->driver('Streams');
		$profile_validation = $this->streams->streams->validation_array('profiles', 'users');

		// Remove display_name
		foreach ($profile_validation as $key => $values)
		{
			if ($values['field'] == 'display_name')
			{
				unset($profile_validation[$key]);
				break;
			}
		}

		// Set the validation rules
		//$this->form_validation->set_rules(array_merge($validation, $profile_validation));

		// Get user profile data. This will be passed to our
		// streams insert_entry data in the model.
		$assignments = $this->streams->streams->get_assignments('profiles', 'users');

		// This is the required profile data we have from
		// the register form
		$profile_data = array();

		// Get the profile data to pass to the register function.
		foreach ($assignments as $assign)
		{
			if ($assign->field_slug != 'display_name')
			{
				if (isset($_POST[$assign->field_slug]))
				{
					$profile_data[$assign->field_slug] = escape_tags($this->input->post($assign->field_slug));
				}
			}
		}

		// --------------------------------

		// Set the validation rules
		$this->form_validation->set_rules($validation);

		$user = new stdClass();

		// Set default values as empty or POST values
		foreach ($validation as $rule)
		{
			$user->{$rule['field']} = $this->input->post($rule['field']) ? escape_tags($this->input->post($rule['field'])) : null;
		}

		// Are they TRYing to submit?
		if ($_POST)
		{
			if ($this->form_validation->run())
			{
				// Check for a bot usin' the old fashioned
				// don't fill this input in trick.
				if (escape_tags($this->input->post('d0ntf1llth1s1n')) !== ' ')
				{
					$this->session->set_flashdata('error', lang('user:register_error'));
					redirect(current_url());
				}

				$email = escape_tags($this->input->post('email'));
				$password = escape_tags($this->input->post('password'));

				// --------------------------------
				// Auto-Username
				// --------------------------------
				// There are no guarantees that we 
				// will have a first/last name to
				// work with, so if we don't, use
				// an alternate method.
				// --------------------------------

				if (Settings::get('auto_username'))
				{
					if ($this->input->post('first_name') and $this->input->post('last_name'))
					{
						$this->load->helper('url');
						$username = url_title(escape_tags($this->input->post('first_name')).'.'.escape_tags($this->input->post('last_name')), '-', true);

						// do they have a long first name + last name combo?
						if (strlen($username) > 19)
						{
							// try only the last name
							$username = url_title(escape_tags($this->input->post('last_name')), '-', true);

							if (strlen($username) > 19)
							{
								// even their last name is over 20 characters, snip it!
								$username = substr($username, 0, 20);
							}
						}
					}
					else
					{
						// If there is no first name/last name combo specified, let's
						// user the identifier string from their email address
						$email_parts = explode('@', $email);
						$username = $email_parts[0];
					}

					// Usernames absolutely need to be unique, so let's keep
					// trying until we get a unique one
					$i = 1;

					$username_base = $username;

					while ($this->db->where('username', $username)
						->count_all_results('users') > 0)
					{
						// make sure that we don't go over our 20 char username even with a 2 digit integer added
						$username = substr($username_base, 0, 18).$i;

						++$i;
					}
				}
				else
				{
					// The user specified a username, so let's use that.
					$username = escape_tags($this->input->post('username'));
				}

				// --------------------------------

				// Do we have a display name? If so, let's use that.
				// Othwerise we can use the username.
				if ( ! isset($profile_data['display_name']) or ! $profile_data['display_name'])
				{
					$profile_data['display_name'] = $username;
				}

				// We are registering with a null group_id so we just
				// use the default user ID in the settings.
				$id = $this->ion_auth->register($username, $password, $email, null, $profile_data);

				// Try to create the user
				if ($id > 0)
				{
					$status = 'ok';

					// Convert the array to an object
					$user->username = $username;
					$user->display_name = $username;
					$user->email = $email;
					$user->password = $password;

					// trigger an event for third party devs
					Events::trigger('post_user_register', $id);

					/* send the internal registered email if applicable */
					if (Settings::get('registered_email'))
					{
						$this->load->library('user_agent');
						$datenow = date('l jS F Y h:i:s A');
						
						Events::trigger('email', array(
							'name' => $user->display_name,
							'sender_ip' => $this->input->ip_address(),
							'sender_agent' => $this->agent->browser().' '.$this->agent->version(),
							'sender_os' => $this->agent->platform(),
							'slug' => 'registered',
							'datenow' => $datenow,
							'email' => $email,
							'user_registered_id' => $id,
							'to' => Settings::get('contact_email'),
						), 'array');
					}

					// show the "you need to activate" page while they wait for their email
					if ((int)Settings::get('activation_email') === 1)
					{
						$msg = $this->ion_auth->messages();
						//$this->session->set_flashdata('notice', $this->ion_auth->messages());
						//redirect('users/activate');
					}
					// activate instantly
					elseif ((int)Settings::get('activation_email') === 2)
					{
						$this->ion_auth->activate($id, false);

						$this->ion_auth->login(escape_tags($this->input->post('email')), escape_tags($this->input->post('password')));
						redirect($this->config->item('register_redirect', 'ion_auth'));
					}
					else
					{
						$this->ion_auth->deactivate($id);

						/* show that admin needs to activate your account */
						$msg = lang('user:activation_by_admin_notice');
						//$this->session->set_flashdata('notice', lang('user:activation_by_admin_notice'));
						//redirect('users/register'); /* bump it to show the flash data */
					}
				}

				// Can't create the user, show why
				else
				{
					$status = 'error';
					$msg = $this->ion_auth->errors();
					//$this->template->error_string = $this->ion_auth->errors();
				}
			}
			else
			{
				// Return the validation error
				$status = 'error';
				$msg = $this->form_validation->error_string();
				//$this->template->error_string = $this->form_validation->error_string();
			}
			$message['status'] = $status;
			$message['message'] = $msg;
		}

		// Is there a user hash?
		else {

			if (($user_hash = $this->session->userdata('user_hash')))
			{
				// Convert the array to an object
				$user->email = ( ! empty($user_hash['email'])) ? $user_hash['email'] : '';
				$user->username = $user_hash['nickname'];
			}
		}

		echo json_encode($message);

		// --------------------------------
		// Create profile fields.
		// --------------------------------

		// Anything in the post?

/*
		$this->template->set('profile_fields', $this->streams->fields->get_stream_fields('profiles', 'users', $profile_data));

		// --------------------------------

		$this->template
			->title(lang('user:register_title'))
			->set('_user', $user)
			->build('register');
*/
	}

	public function apply()
	{
		$recaptchaOK = false;
		$resp = $error = null;
		$this->load->library('recaptchalib');

		if (!empty($_POST["recaptcha_response_field"])) {
			$resp = $this->recaptchalib->recaptcha_check_answer(Settings::get('recaptcha_private'),
				$_SERVER["REMOTE_ADDR"],
				$_POST["recaptcha_challenge_field"],
				$_POST["recaptcha_response_field"]);
			if ($resp->is_valid) {
				$recaptchaOK = TRUE;
			} else {
				# set the error code so that we can display it
				$error = $resp->error;
				$this->template->set('recaptcha_error', '<div class="alert animated alert-danger">Please enter the text you see above</div>');
			}
		}
		elseif ($_POST)
		{
			$this->template->set('recaptcha_error', '<div class="alert animated alert-danger">Please enter the text you see above</div>');
		}

		$recaptcha = $this->recaptchalib->recaptcha_get_html(Settings::get('recaptcha_public'), $error);
		
		$this->db->set_dbprefix(SITE_REF.'_');
		
		if (!empty($this->current_user->id))
		{
			if ($this->current_user->group == 'user')
			{
				//$m = $this->members_m->count_by( array('MemberID_2'=>$this->current_user->id, 'status'=>'Draft') );
				$m = $this->members_m->get_by('MemberID_2', $this->current_user->id);
				if (!empty($m))
				{
					if ($m && strtolower($m->status) == 'draft')
						//redirect('members/application');
						if(SITE_REF == "bcn"){
							$this->template
							->set_breadcrumb('RSPO会员', 'members')
							->set_breadcrumb('成为会员');
							
							redirect('members/application-cn');

							$this->db->set_dbprefix('default_');
						}else{
							/* $this->template
							->set_breadcrumb('Members', 'members')
							->set_breadcrumb('Member Application');
							 */
							redirect('members/application');
						}
					
					elseif ( $m && (strtolower($m->status) == 'approved' OR strtolower($m->status) == 'call for comment') )
						//redirect('members/profile');
						
						if(SITE_REF == "bcn"){
							$this->template
							->set_breadcrumb('RSPO会员', 'members')
							->set_breadcrumb('成为会员');
							redirect('members/profile-cn');

							$this->db->set_dbprefix('default_');
						}else{
							/* $this->template
							->set_breadcrumb('Members', 'members')
							->set_breadcrumb('Member Application');
							 */
							redirect('members/profile');
						}
					else
					{
						$this->session->set_flashdata('error', 'Sorry, we cannot verify your data.');
						redirect('members/logout');
					}
				}
				else
					//redirect('members/selecttype');
				
					if(SITE_REF == "bcn"){
						$this->template
							->set_breadcrumb('RSPO会员', 'members')
							->set_breadcrumb('成为会员');
						redirect('members/selecttype-cn');

						$this->db->set_dbprefix('default_');
					}else{
						/* $this->template
						->set_breadcrumb('Members', 'members')
						->set_breadcrumb('Member Application');
						 */
						redirect('members/selecttype');
					}
			}
			else
			{
				$this->session->set_flashdata('error', 'Sorry, you are not registered as an applying member. If you think you should be, please contact us <a href="mailto:membership@rspo.org?Subject=Unable to complete application due to wrong user access.">here</a>, or <a href="'.site_url('members/logout/members/apply').'">logout</a>.');
				//redirect('members/all');
				
				if(SITE_REF == "bcn"){
					$this->template
					->set_breadcrumb('RSPO会员', 'members')
					->set_breadcrumb('成为会员');
					redirect('members/all');

					$this->db->set_dbprefix('default_');
				}else{
					/* $this->template
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb('Member Application');
					 */
					redirect('members/all');
				}
			}
		}

		$ips = array('127.0.0.1', '139.193.11.136', '121.121.25.158');
		$visitor_ip = $_SERVER['REMOTE_ADDR'];

		$override = false;

		if (in_array($visitor_ip, $ips))
			$override = true;

		if(SITE_REF == "bcn"){
			$this->template
			//->append_js('module::bootstrap.min.js')
			//->append_js('module::responsive-tabs.js')
			//->set('membersapp', $membershipapplication)
			->title('成为会员')
			->set('recaptcha', $recaptcha)
			->set_breadcrumb('RSPO会员', 'members')
			->set_breadcrumb('成为会员')
			->build('applications/apply-cn');
			
			$this->db->set_dbprefix('default_');
		}else{
			$this->template
			//->append_js('module::bootstrap.min.js')
			//->append_js('module::responsive-tabs.js')
			//->set('membersapp', $membershipapplication)
			->title('Member application')
			->set('recaptcha', $recaptcha)
			->set_breadcrumb('Members', 'members')
			->set_breadcrumb('Member Application')
			->build('applications/apply');
		}
		
		/*
		if ($override)
			$this->template->build('applications/apply');
		else
			$this->template->build('applications/apply-closed');
		*/
	}

	public function getlog()
	{
		if (empty($this->current_user->id)) return false;

		$member = $this->members_m->get_by(array('MemberID_2'=>$this->current_user->id));
		if (!empty($member))
		{
			$offset = $this->input->post('offset');
			$total_rows = $this->members_m->count_editlog( array( 'member_id' => $member->intID) );
			$pagination = create_pagination('members/getlog', $total_rows);
			$logs = $this->members_m->limit($pagination['limit'], $offset)->get_editlog_by(array( 'member_id' => $member->intID));
			$ret['log_loaded'] = (int)$offset;
			$ret['logs'] = $this->load->view('partials/member_log', array('logs'=>$logs), TRUE);
			$ret['id'] = count($logs) - $offset;
			echo json_encode($ret);

/*
			$this->template
				->set_layout(FALSE)
				->set('log_count', count($logs))
				->set('logs', $logs);
				//->build('member_log');
*/
		}
		else
		{
			return false;
		}
	}

	public function profile()
	{
		if (empty($this->current_user->id))
		{
			$this->session->set_userdata('redirect_to', site_url('members/profile') );
			//redirect('members/login');
			if(SITE_REF == "bcn"){
				/* $this->template
				->set_breadcrumb('Members', 'members')
				->set_breadcrumb('Member Application');
				 */
				redirect('members/login-cn');

				$this->db->set_dbprefix('default_');
			}else{
				/* $this->template
				->set_breadcrumb('Members', 'members')
				->set_breadcrumb('Member Application');
				 */
				redirect('members/login');
			}
			
			exit;
		}

		$member = $this->members_m->get_by(array('MemberID_2'=>$this->current_user->id));

		if (empty($member))
		{
			$this->session->set_flashdata('error', lang('members:empty_member_data'));
			redirect('members');
		}

		//if (strtolower($member->status) <> 'approved' AND strtolower($member->status) <> 'call for comment')
		if (strtolower($member->status) <> 'approved')
		{
			//redirect('members/apply');
			if(SITE_REF == "bcn"){
				/* $this->template
				->set_breadcrumb('Members', 'members')
				->set_breadcrumb('Member Application');
				 */
				redirect('members/apply-cn');

				$this->db->set_dbprefix('default_');
			}else{
				/* $this->template
				->set_breadcrumb('Members', 'members')
				->set_breadcrumb('Member Application');
				 */
				redirect('members/apply');
			}
		}

		$member_ori = $member;

		$this->load->library('form_validation');

		if ($this->input->post('scg_manager_members'))
		{
			$scg_members = serialize($this->input->post('scg_manager_members'));
		}
		else
		{
			$scg_members = !empty($member->scg_manager_members) ? $member->scg_manager_members : '';
		}

		$this->check_dir($this->config_upload['upload_path']);
		$this->load->library('upload', $this->config_upload);
		//$this->load->library('MY_Upload');
		
		if(!empty($_FILES['logo']['name'])){
			if(!$this->upload->do_upload('logo')){ 
			}
			else{
				$file = $this->upload->data();
				$filelogo = $file['file_name'];
				if ($file['is_image'])
				{
					$this->load->library('image_lib');
					$filename = $file['file_name'];
					$thumbfile = thumbnail($filename); //substr($filename, 0, -4) . '_thumb' . substr($filename, -4);
					//$medfile = fullname($filename); //substr($filename, 0, -4) . '_full' . substr($filename, -4);
					/*---------------------------------------------------------------------------------
					// create thumb - admin
					*/
					//echo "Full path: " . $file['full_path'] . "<br />";

					/*
					$image_cfg['source_image'] = $file['full_path'];
					$image_cfg['image_library'] = 'gd2';
					$image_cfg['maintain_ratio'] = TRUE;
					$image_cfg['width'] = ($file['image_width'] < $this->thumb_width ? $file['image_width'] : $this->thumb_width);
					$image_cfg['height'] = ($file['image_height'] < $this->thumb_height ? $file['image_height'] : $this->thumb_height);
					$image_cfg['create_thumb'] = FALSE;
					$image_cfg['new_image'] = $file['file_path'] . $thumbfile;
					$image_cfg['master_dim'] = 'width';
					$this->image_lib->initialize($image_cfg);
					$img_ok = $this->image_lib->resize();
					unset($image_cfg);
					$this->image_lib->clear();
					if (!$img_ok)
						echo "Thumbnail " . $file['file_path'] . $thumbfile . ': ' . $this->image_lib->display_errors() . "<br />\n";
					*/
					/*
					/* image resize - medium
					*/
					$image_cfg['source_image'] = $file['full_path'];
					$image_cfg['image_library'] = 'gd2';
					$image_cfg['maintain_ratio'] = TRUE;
					$image_cfg['width'] = ($file['image_width'] < $this->thumb_width ? $file['image_width'] : $this->thumb_width);
					$image_cfg['height'] = ($file['image_height'] < $this->thumb_height ? $file['image_height'] : $this->thumb_height);
					$image_cfg['create_thumb'] = TRUE;
					$image_cfg['new_image'] = $file['file_path'] . $filename; //$thumbfile;
					$image_cfg['master_dim'] = 'width';
					$this->image_lib->initialize($image_cfg);
					$img_ok = $this->image_lib->resize();
					unset($image_cfg);
					$this->image_lib->clear();

					//if (!$img_ok)
					//	echo "Resize: " . $this->image_lib->display_errors() . "<br />\n";

					/*
					*  remove old logo
					*/
					if ( $member->logo )
					{
						if (strstr($member->logo, '/sites/default/files/'))
						{
							$fname = $_SERVER['DOCUMENT_ROOT'] . $member->logo;
							$tname = $_SERVER['DOCUMENT_ROOT'] . thumbnail($member->logo);
							//echo '<img class="img-responsive" src="http://www.rspo.org'.$member->logo.'" />'.PHP_EOL;
						}
						elseif(strstr($member->logo, 'ma/logo/'))
						{
							$fname = $_SERVER['DOCUMENT_ROOT'] .'/'. $member->logo;
						}
						else
						{
							$fname = $_SERVER['DOCUMENT_ROOT'] . UPLOAD_PATH . '/memberlogos/' . $member->logo;
							$tname = $_SERVER['DOCUMENT_ROOT'] . UPLOAD_PATH . '/memberlogos/' . thumbnail($member->logo);
						}
						if (is_file($fname))
						{
							unlink($fname);
							if (!empty($tname))
								unlink($tname);
						}
					}

				}
			}
		}
		else{
			if ($_POST)
				$filelogo = $this->input->post('upload_logo');
			else
				$filelogo = isset($member->logo) ? $member->logo : '';
		}
		if ($this->input->post('currentPassword') && ( $this->input->post('newPassword') OR $this->input->post('confirmNewPassword') ) )
		{
			$this->validation_member['currentpassword'] = array(
				'field' => 'currentPassword',
				'label' => 'Current Password',
				'rules' => 'min_length[6]|max_length[20]|callback__check_password'
			);
			$this->validation_member['password'] = array(
				'field' => 'newPassword',
				'label' => 'New Password',
				'rules' => 'required|min_length[6]|max_length[20]'
			);
			$this->validation_member['password2'] = array(
				'field' => 'confirmNewPassword',
				'label' => 'Confirm New Password',
				'rules' => 'required|matches[newPassword]'
			);
		}

		$this->form_validation->set_rules($this->validation_member);
		if ($this->form_validation->run())
		{

			// Get our secure post
			$secure_post = $this->input->post();

            foreach ($secure_post as &$post) {
                $post = escape_tags($post);
            }

			$input = array(
				'address' 	=> $secure_post['address'],
				'address_city' 	=> $secure_post['address_city'],
				'address_state' => $secure_post['address_state'],
				'address_zip' 	=> $secure_post['address_zip'],
				'country' 		=> $secure_post['country'],
				//'code_telephone' => $secure_post['code_telephone'],
				'telephone' 	=> $secure_post['telephone'],
				//'code_fax' 		=> $secure_post['code_fax'],
				'fax' 			=> $secure_post['fax'],
				'email' 		=> $secure_post['email'],
				'website'	 	=> $secure_post['website'],

				'logo' 				=> $filelogo,
				'profile' 			=> $secure_post['profile'],

				'production_area' 	=> !empty($secure_post['production_area']) ? $secure_post['production_area'] : NULL,
				'scg_manager_members' 	=> $scg_members,

				'name_p' 		=> $this->input->post('name_p'),
				'designation_p' => $this->input->post('designation_p'),
				'code_tel_p' 	=> $this->input->post('code_tel_p'),
				'telephone_p' 	=> $this->input->post('telephone_p'),
				'code_fax_p' 	=> $this->input->post('code_fax_p'),
				'fax_p' 		=> $this->input->post('fax_p'),
				'email_p' 		=> $this->input->post('email_p'),
				'name_s' 		=> $this->input->post('name_s'),
				'designation_s' => $this->input->post('designation_s'),
				'code_tel_s' 	=> $this->input->post('code_tel_s'),
				'telephone_s' 	=> $this->input->post('telephone_s'),
				'code_fax_s' 	=> $this->input->post('code_fax_s'),
				'fax_s' 		=> $this->input->post('fax_s'),
				'email_s' 		=> $this->input->post('email_s'),
				'contact_person' 	=> $this->input->post('contact_person'),
				'designation' 		=> $this->input->post('designation'),
				'code_contact_tel' 		=> $this->input->post('code_contact_tel'),
				'contact_tel'	 	=> $this->input->post('contact_tel'),
				'code_contact_fax' 		=> $this->input->post('code_contact_fax'),
				'contact_fax'	 	=> $this->input->post('contact_fax'),
				'contact_email' 	=> $this->input->post('contact_email'),
				'name_f' 		=> $this->input->post('name_f'),
				'designation_f' => $this->input->post('designation_f'),
				'code_tel_f' 	=> $this->input->post('code_tel_f'),
				'telephone_f' 	=> $this->input->post('telephone_f'),
				'code_fax_f' 	=> $this->input->post('code_fax_f'),
				'fax_f' 		=> $this->input->post('fax_f'),
				'email_f' 		=> $this->input->post('email_f'),
/* */
				
				'q1' => $secure_post['q1'],
				'q2' => $secure_post['q2'],
				'q3' => $secure_post['q3'],
				'q4' => $secure_post['q4'],
				//'q_usage' => $secure_post['q_usage'],
				
				'newsletter' 		=> !empty($secure_post['newsletter']) ? $secure_post['newsletter'] : 'n',
				
				'name_last_p' 		=> $this->input->post('name_last_p'),
				'name_last_s' 		=> $this->input->post('name_last_s'),
				'contact_lname' 	=> $this->input->post('contact_lname'),
				'name_last_f' 		=> $this->input->post('name_last_f'),
			);

			if ($member->intID && $this->members_m->update($member->intID, $input))
			{
				$edit_log = array(
					'member_id'		=> $member->intID,
					'date'			=> now(),
					'status'		=> 'success'
				);
				$edit_log['changes'] = '';
				$this->session->set_flashdata('status', 'success');
				foreach ($this->changes as $field => $desc)
				{
					if ($field=='scg_manager_members[]') $field = 'scg_manager_members';
					if ( $input[$field] != $member_ori->{$field} && !empty($member_ori->{$field}) )
					{
						$edit_log['changes'] .= $this->changes[$field] . '<br />';
					}
					// logo upload
/*
					if ( !empty($filelogo) && $filelogo <> $member_ori->logo && !empty($member_ori->logo) )
						$edit_log['changes'] .= $this->changes['logo'] . '<br />';
*/
				}

				if ($this->input->post('currentPassword') && $this->input->post('newPassword') && $this->input->post('confirmNewPassword') )
				{
					$pword = $this->ion_auth_model->hash_password($this->input->post('newPassword'), $this->current_user->salt);
					if ($this->members_m->change_password($this->current_user->id, $pword))
					{
						//Events::trigger('post_user_update');
						$this->session->set_flashdata('notice', 'Your password has been sucessfully changed.');
						$edit_log['changes'] .= 'Password change was successful<br />';
					}
					else
					{
						$this->session->set_flashdata('status', 'pwerror');
						$this->session->set_flashdata('error', 'Error changing your password. (Note: it <strong>has not</strong> been changed)');
						$edit_log['changes'] .= 'Password change failed<br />';
					}

				}

				$edit_log['changes'] = trim($edit_log['changes'], '<br />');
				if (!empty($edit_log['changes']))
					$this->members_m->editlog($edit_log);

				$sf_input = $input;
				$sf_input['title'] = $member->title?$member->title:$member->name;
				$triggered_event = Events::trigger('member_updated', array('id'=>$member->intID, 'input'=>$input));
//echo "\$triggered_event: $triggered_event<br />\n";
//				exit;
				//$this->session->set_flashdata('notice', $triggered_event);

			}
			else
			{
				$this->session->set_flashdata('status', 'error');
			}
			
			//redirect('members/profile');
			if(SITE_REF == "bcn"){
				/* $this->template
				->set_breadcrumb('Members', 'members')
				->set_breadcrumb('Member Application');
				 */
				redirect('members/profile-cn');

				$this->db->set_dbprefix('default_');
			}else{
				/* $this->template
				->set_breadcrumb('Members', 'members')
				->set_breadcrumb('Member Application');
				 */
				redirect('members/profile');
			}
		}

		// Go through all the known fields and get the post values
		if ($_POST)
		{
			foreach ($this->validation_member as $rule)
			{
				//if (isset($_POST[$rule['field']]))
				$member->{$rule['field']} = $this->input->post($rule['field']);
			}
		}

		$member->logo = $filelogo;
		$member->scg_manager_members = $scg_members;

		$logs = $this->members_m->limit($this->settings->records_per_page)->get_editlog_by(array( 'member_id' => $member->intID));
		$log_count = $this->members_m->count_editlog(array( 'member_id' => $member->intID));

		$this->template
				->title('Member', $member->name)
				->set('log_count', $log_count)
				->set('logs', $logs)
				->set('member', $member)
				->set_breadcrumb('Members', 'profile')
				->set_breadcrumb('Profile');
       			//->build('edit-profile');
				
			if(SITE_REF == "bcn"){
				/* $this->template
				->set_breadcrumb('Members', 'members')
				->set_breadcrumb('Member Application');
				 */
				 
				$this->template->build('edit-profile-cn');
				
				//redirect('members/profile-cn');

				$this->db->set_dbprefix('default_');
			}else{
				/* $this->template
				->set_breadcrumb('Members', 'members')
				->set_breadcrumb('Member Application');
				 */
				
				$this->template->build('edit-profile');
				
				//redirect('members/profile');
			}
    }

	public function applyOLD()
	{
		if (!empty($this->current_user->id))
		{
			if ($this->current_user->group == 'user')
			{
				$m = $this->members_m->count_by( array('MemberID_2'=>$this->current_user->id, 'status'=>'Draft') );
				if ($m)
					redirect('members/application');
				else
					redirect('members/selecttype');
			}
			else
			{
				$this->session->set_flashdata('error', 'Sorry, you are not registered as an applying member. If you think you should be, please contact us <a href="mailto:membership@rspo.org?Subject=Unable to complete application due to wrong user access.">here</a>, or <a href="'.site_url('members/logout/members/apply').'">logout</a>.');
				//redirect('members/all');
				if(SITE_REF == "bcn"){
					/* $this->template
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb('Member Application'); */
					
					redirect('members/all');

					$this->db->set_dbprefix('default_');
				}else{
					/* $this->template
					->set_breadcrumb('Members', 'members')
					->set_breadcrumb('Member Application'); */
					
					redirect('members/all');
				}
			}
		}
		$membershipapplication = new stdClass();
		$membersapp = new stdClass();
		
		
		$this->check_dir($this->config_upload['upload_path']);
		
		
		
		$this->form_validation->set_rules($this->validation_rules);
		if($this->form_validation->run()){
			
			$membershipapp_insert = array(
				'title' 	=> $this->input->post('title'),
				'type' 		=> $this->input->post('type'),
				'category' 	=> $this->input->post('category'),
				'name' 		=> $this->input->post('org_name'),
				'address' 	=> $this->input->post('address'),
				'address_city' 	=> $this->input->post('address_city'),
				'address_state' => $this->input->post('address_state'),
				'address_zip' 	=> $this->input->post('address_zip'),
				'country' 		=> $this->input->post('country'),
				'telephone' 	=> $this->input->post('telephone'),
				'fax' 			=> $this->input->post('fax'),
				'email' 		=> $this->input->post('email'),
				'website'	 	=> $this->input->post('website'),
				'registration_number' 	=> $this->input->post('registration_number'),
				'parent_company' 		=> $this->input->post('parent_company'),
				'primary_market_ops' 	=> $this->input->post('primary_market_ops'),
				'other_market_ops' 	=> $this->input->post('other_market_ops'),
				'logo' 				=> $filelogo,
				'profile' 			=> $this->input->post('profile'),
				
				'name_p' 		=> $this->input->post('name_p'),
				'designation_p' => $this->input->post('designation_p'),
				'telephone_p' 	=> $this->input->post('telephone_p'),
				'fax_p' 		=> $this->input->post('fax_p'),
				'email_p' 		=> $this->input->post('email_p'),
				'name_s' 		=> $this->input->post('name_s'),
				'designation_s' => $this->input->post('designation_s'),
				'telephone_s' 	=> $this->input->post('telephone_s'),
				'fax_s' 		=> $this->input->post('fax_s'),
				'email_s' 		=> $this->input->post('email_s'),
				
				'contact_person' 	=> $this->input->post('contact_person'),
				'designation' 		=> $this->input->post('designation'),
				'contact_tel'	 	=> $this->input->post('contact_tel'),
				'contact_fax'	 	=> $this->input->post('contact_fax'),
				'contact_email' 	=> $this->input->post('contact_email'),
				
				'name_f' 		=> $this->input->post('name_f'),
				'designation_f' => $this->input->post('designation_f'),
				'telephone_f' 	=> $this->input->post('telephone_f'),
				'fax_f' 		=> $this->input->post('fax_f'),
				'email_f' 		=> $this->input->post('email_f'),
				
				'q1' => $this->input->post('q1'),
				'q2' => $this->input->post('q2'),
				'q3' => $this->input->post('q3'),
				'q4' => $this->input->post('q4'),
				'q_usage' => $this->input->post('q_usage'),
				
				'name_a' 		=> $this->input->post('name_a'),
				'designation_a' => $this->input->post('designation_a'),
				'date_2' 		=> $this->input->post('date_2'),
				'profession' 		=> $this->input->post('org_subcategory'),
				'file_certificates'	=> $cert_file_m,
				'file'				=> $file_grower_m,
			);
			
			if($this->members_m->insert($membershipapp_insert))
				{
					$this->session->set_flashdata('success', 'Success Add');
					//redirect('members/membership_app');
				}
			else{
					$this->session->set_flashdata('error', 'Error Add');
					//redirect('members/membership_app');
				}
		}
		
/*
		// Go through all the known fields and get the post values
		foreach ($this->validation_rules as $rule)
		{
			$membershipapplication->{$rule['field']} = $this->input->post($rule['field']);
		}
		
		$membershipapplication->logo = $filelogo;
		$membershipapplication->file = $file_grower_m;
		$membershipapplication->file_certificates = $cert_file_m;
		$membershipapplication->file = implode(',', $forremoveimg_grower);
		$membershipapplication->file_certificates = implode(',', $forremoveimg);
*/

		$redirect_to = $this->session->flashdata('redirect_to');

		$this->template
			//->append_js('module::bootstrap.min.js')
			//->append_js('module::responsive-tabs.js')
			->set('membersapp', $membershipapplication)
			->build('applications/apply');
	}

	public function forget($code=null)
	{
		$this->template->title(lang('user:reset_password_title'));

		if (PYRO_DEMO)
		{
			show_error(lang('global:demo_restrictions'));
		}

		//if user is logged in they don't need to be here
		if ($this->current_user)
		{
			if ($this->input->is_ajax_request())
			{
				exit(json_encode(array('status' => false, 'message' => lang('user:already_logged_in') )));
			}
			else
			{
				$this->session->set_flashdata('error', lang('user:already_logged_in'));
				redirect('');
			}
		}

		if ($this->input->post('email'))
		{
			$uname = (string) $this->input->post('user_name');
			$email = (string) $this->input->post('email');

			if ( ! $uname and ! $email)
			{
				// they submitted with an empty form, abort
				$this->template->set('error_string', $this->ion_auth->errors())
					->build('reset_pass');
			}

			if ( ! ($user_meta = $this->ion_auth->get_user_by_email($email)))
			{
				$user_meta = $this->ion_auth->get_user_by_username($email);
			}

			// have we found a user?
			if ($user_meta)
			{
				$new_password = $this->ion_auth->forgotten_password($user_meta->email);

				if ($new_password)
				{
					//set success message

					if ($this->input->is_ajax_request())
					{
						exit(json_encode(array('status' => true, 'message' => lang('user:password_reset_message') )));
					}
					else
					{
						$this->template->success_string = lang('user:password_reset_message');
					}
				}
				else
				{
					// Set an error message explaining the reset failed
					if ($this->input->is_ajax_request())
					{
						exit(json_encode(array('status' => false, 'message' => $this->ion_auth->errors() )));
					}
					else
					{
						$this->template->error_string = $this->ion_auth->errors();
					}
				}
			}
			else
			{
				//wrong username / email combination
				if ($this->input->is_ajax_request())
				{
					exit(json_encode(array('status' => false, 'message' => lang('user:forgot_incorrect') )));
				}
				else
				{
					$this->template->error_string = lang('user:forgot_incorrect');
				}
			}
		}

		if (!$code) $code = $this->input->post('code');
		// code is supplied in url so lets try to reset the password
		if ($code)
		{
			// verify reset_code against code stored in db
			$reset = $this->ion_auth->forgotten_password_complete($code);

			// did the password reset?
			if ($reset)
			{
				if ($this->input->is_ajax_request())
				{
					exit(json_encode(array('status' => true, 'message' => lang('user:password_reset_message') )));
				}
				else
				{
					redirect('members/reset_complete');
				}
			}
			else
			{
				// nope, set error message
				if ($this->input->is_ajax_request())
				{
					exit(json_encode(array('status' => false, 'message' => $this->ion_auth->errors() )));
				}
				else
				{
					$this->template->error_string = $this->ion_auth->errors();
				}
			}
		}

		$this->template
			->title(lang('user:password_reset_title'))
			->set_breadcrumb('Members', 'members')
			->set_breadcrumb('Password Recovery')
			->build('member/reset_pass');
	}

	/**
	 * Password reset is finished
	 */
	public function reset_complete()
	{
		//if user is logged in they don't need to be here. and should use profile options
		if ($this->current_user)
		{
			$this->session->set_flashdata('error', lang('user:already_logged_in'));
			redirect('members');
		}

		$this->template
			->title(lang('user:password_reset_title'))
			->build('member/reset_pass_complete');
	}

	function check_dir($dir)
	{
		// check directory
		$fileOK = array();
		$fdir = explode('/', $dir);
		$ddir = '';
		for($i=0; $i<count($fdir); $i++)
		{
			$ddir .= $fdir[$i] . '/';
			if (!is_dir($ddir))
			{
				if (!@mkdir($ddir, 0777)) {
					$fileOK[] = 'not_ok';
				}
				else
				{
					$fileOK[] = 'ok';
				}
			}
			else
			{
				$fileOK[] = 'ok';
			}
		}
		return $fileOK;
	}

	function _check_password()
	{
		$this->load->model('users/ion_auth_model');
		$ret = $this->ion_auth_model->hash_password_db($this->current_user->id, $this->input->post('currentPassword'));
		if ($ret != $this->current_user->password)
		{
			$this->form_validation->set_message('_check_password', 'The current password you entered is incorrect.');
			return false;
		}
		return true;
	}

	/**
	 * Username check
	 *
	 * @author Ben Edmunds
	 *
	 * @param string $username The username to check.
	 *
	 * @return bool
	 */
	public function _username_check($username)
	{
		if ($this->ion_auth->username_check($username))
		{
			$this->form_validation->set_message('_username_check', lang('user:error_username'));
			return false;
		}

		return true;
	}

	/**
	 * Email check
	 *
	 * @author Ben Edmunds
	 *
	 * @param string $email The email to check.
	 *
	 * @return bool
	 */
	public function _email_check($email)
	{
		if ($this->ion_auth->email_check($email))
		{
			$this->form_validation->set_message('_email_check', lang('user:error_email'));
			return false;
		}

		return true;
	}

	/**
	 * Callback method used during login
	 *
	 * @param str $email The Email address
	 *
	 * @return bool
	 */
	public function _check_login($email)
	{
		$remember = false;
		if ($this->input->post('remember') == 1)
		{
			$remember = true;
		}

		if ($this->ion_auth->login($email, $this->input->post('password'), $remember))
		{
			return true;
		}

		Events::trigger('login_failed', $email);
		error_log('Login failed for user '.$email);

		$this->form_validation->set_message('_check_login', $this->ion_auth->errors());
		return false;
	}

	public function _check_scg_members()
	{
		if (!$this->scg_member_checked)
		{
			if ($this->input->post('scg_manager_members'))
			{
				$m = $this->input->post('scg_manager_members');
				$c = count($m);
				for($i=0; $i<$c; $i+=2)
				{
					if ($m[$i+1] > 500)
					{
						$this->form_validation->set_message('_check_scg_members', 'Palm Oil Consumption should be less than 500 MT.');
						return false;
					}
				}
			}
			$this->scg_member_checked = true;
		}
		return true;
	}


	public function _check_use($field1='', $field2='')
	{
		if ($field1 == $field2)
		{
			$msg = "Primary and Secondary Nomination cannot be the same person.";
			$this->form_validation->set_message('_check_use', $msg);
			return false;
		}

		return true;
	}

	// pick a member for auto-suggest
	public function pick($id=0)
	{
		$q = $this->input->get('term');
		$res = $this->members_m->get_many_by_name($q);
		foreach($res as $m)
		{
			$members[] = array('value'=>$m->title, 'id'=>$m->intID);
		}

		echo json_encode($members);
	}

	public function countrycode()
	{
		$countries = array("Afghanistan" => "af","Åland Islands" => "ax","Albania" => "al","Algeria" => "dz","American Samoa" => "as","Andorra" => "ad","Angola" => "ao","Anguilla" => "ai","Antarctica" => "aq","Antigua And Barbuda" => "ag","Argentina" => "ar","Armenia" => "am","Aruba" => "aw","Australia" => "au","Austria" => "at","Azerbaijan" => "az","Bahamas" => "bs","Bahrain" => "bh","Bangladesh" => "bd","Barbados" => "bb","Belarus" => "by","Belgium" => "be","Belize" => "bz","Benin" => "bj","Bermuda" => "bm","Bhutan" => "bt","Bolivia, Plurinational State Of" => "bo","Bonaire, Sint Eustatius And Saba" => "bq","Bosnia And Herzegovina" => "ba","Botswana" => "bw","Bouvet Island" => "bv","Brazil" => "br","British Indian Ocean Territory" => "io","Brunei Darussalam" => "bn","Bulgaria" => "bg","Burkina Faso" => "bf","Burundi" => "bi","Cambodia" => "kh","Cameroon" => "cm","Canada" => "ca","Cape Verde" => "cv","Cayman Islands" => "ky","Central African Republic" => "cf","Chad" => "td","Chile" => "cl","China" => "cn","Christmas Island" => "cx","Cocos (keeling) Islands" => "cc","Colombia" => "co","Comoros" => "km","Congo" => "cg","Congo, The Democratic Republic Of The" => "cd","Cook Islands" => "ck","Costa Rica" => "cr","Côte D'ivoire" => "ci","Croatia" => "hr","Cuba" => "cu","Curaçao" => "cw","Cyprus" => "cy","Czech Republic" => "cz","Denmark" => "dk","Djibouti" => "dj","Dominica" => "dm","Dominican Republic" => "do","Ecuador" => "ec","Egypt" => "eg","El Salvador" => "sv","Equatorial Guinea" => "gq","Eritrea" => "er","Estonia" => "ee","Ethiopia" => "et","Falkland Islands (malvinas)" => "fk","Faroe Islands" => "fo","Fiji" => "fj","Finland" => "fi","France" => "fr","French Guiana" => "gf","French Polynesia" => "pf","French Southern Territories" => "tf","Gabon" => "ga","Gambia" => "gm","Georgia" => "ge","Germany" => "de","Ghana" => "gh","Gibraltar" => "gi","Greece" => "gr","Greenland" => "gl","Grenada" => "gd","Guadeloupe" => "gp","Guam" => "gu","Guatemala" => "gt","Guernsey" => "gg","Guinea" => "gn","Guinea-bissau" => "gw","Guyana" => "gy","Haiti" => "ht","Heard Island And Mcdonald Islands" => "hm","Holy See (vatican City State)" => "va","Honduras" => "hn","Hong Kong" => "hk","Hungary" => "hu","Iceland" => "is","India" => "in","Indonesia" => "id","Iran, Islamic Republic Of" => "ir","Iraq" => "iq","Ireland" => "ie","Isle Of Man" => "im","Israel" => "il","Italy" => "it","Jamaica" => "jm","Japan" => "jp","Jersey" => "je","Jordan" => "jo","Kazakhstan" => "kz","Kenya" => "ke","Kiribati" => "ki","North Korea" => "kp","South Korea" => "kr","Kuwait" => "kw","Kyrgyzstan" => "kg","Lao People's Democratic Republic" => "la","Latvia" => "lv","Lebanon" => "lb","Lesotho" => "ls","Liberia" => "lr","Libya" => "ly","Liechtenstein" => "li","Lithuania" => "lt","Luxembourg" => "lu","Macao" => "mo","Macedonia, The Former Yugoslav Republic Of" => "mk","Madagascar" => "mg","Malawi" => "mw","Malaysia" => "my","Maldives" => "mv","Mali" => "ml","Malta" => "mt","Marshall Islands" => "mh","Martinique" => "mq","Mauritania" => "mr","Mauritius" => "mu","Mayotte" => "yt","Mexico" => "mx","Micronesia, Federated States Of" => "fm","Moldova, Republic Of" => "md","Monaco" => "mc","Mongolia" => "mn","Montenegro" => "me","Montserrat" => "ms","Morocco" => "ma","Mozambique" => "mz","Myanmar" => "mm","Namibia" => "na","Nauru" => "nr","Nepal" => "np","Netherlands" => "nl","New Caledonia" => "nc","New Zealand" => "nz","Nicaragua" => "ni","Niger" => "ne","Nigeria" => "ng","Niue" => "nu","Norfolk Island" => "nf","Northern Mariana Islands" => "mp","Norway" => "no","Oman" => "om","Pakistan" => "pk","Palau" => "pw","Palestinian Territory, Occupied" => "ps","Panama" => "pa","Papua New Guinea" => "pg","Paraguay" => "py","Peru" => "pe","Philippines" => "ph","Pitcairn" => "pn","Poland" => "pl","Portugal" => "pt","Puerto Rico" => "pr","Qatar" => "qa","Réunion" => "re","Romania" => "ro","Russian Federation" => "ru","Rwanda" => "rw","Saint Barthélemy" => "bl","Saint Helena, Ascension And Tristan Da Cunha" => "sh","Saint Kitts And Nevis" => "kn","Saint Lucia" => "lc","Saint Martin (french Part)" => "mf","Saint Pierre And Miquelon" => "pm","Saint Vincent And The Grenadines" => "vc","Samoa" => "ws","San Marino" => "sm","Sao Tome And Principe" => "st","Saudi Arabia" => "sa","Senegal" => "sn","Serbia" => "rs","Seychelles" => "sc","Sierra Leone" => "sl","Singapore" => "sg","Sint Maarten (dutch Part)" => "sx","Slovakia" => "sk","Slovenia" => "si","Solomon Islands" => "sb","Somalia" => "so","South Africa" => "za","South Georgia And The South Sandwich Islands" => "gs","South Sudan" => "ss","Spain" => "es","Sri Lanka" => "lk","Sudan" => "sd","Suriname" => "sr","Svalbard And Jan Mayen" => "sj","Swaziland" => "sz","Sweden" => "se","Switzerland" => "ch","Syrian Arab Republic" => "sy","Taiwan, Province Of China" => "tw","Tajikistan" => "tj","Tanzania, United Republic Of" => "tz","Thailand" => "th","Timor-leste" => "tl","Togo" => "tg","Tokelau" => "tk","Tonga" => "to","Trinidad And Tobago" => "tt","Tunisia" => "tn","Turkey" => "tr","Turkmenistan" => "tm","Turks And Caicos Islands" => "tc","Tuvalu" => "tv","Uganda" => "ug","Ukraine" => "ua","United Arab Emirates" => "ae","United Kingdom" => "gb","United States" => "us","United States Minor Outlying Islands" => "um","Uruguay" => "uy","Uzbekistan" => "uz","Vanuatu" => "vu","Venezuela, Bolivarian Republic Of" => "ve","Viet Nam" => "vn","Virgin Islands, British" => "vg","Virgin Islands, U.S." => "vi","Wallis And Futuna" => "wf","Western Sahara" => "eh","Yemen" => "ye","Zambia" => "zm","Zimbabwe" => "zw");

		$c = $this->input->post('c');
		if ($c)
		{
			echo $countries[urldecode($c)];
		}
	}

	public function cron()
	{
		if ($this->input->is_cli_request())
		{
			echo "You are running this from the command line\n";
		}
		else
			echo "You are NOT running this from the command line\n";
		
	}

	public function list_country()
	{
?>
<!doctype html>

<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]> <html class="no-js" lang="en"> 		   <![endif]-->

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>Title of the Page</title>

	<!--[if lt IE 9]>
		<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

	<style>
		* html {
			font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
		}
	</style>
	<script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
<script>
$(document).ready(function(){



});
</script>

</head>

<body>

<?
		foreach($this->country_arrays as $country)
		{
			echo "$country<br />";
		}
?>

</body>
</html>
<?
	}

}