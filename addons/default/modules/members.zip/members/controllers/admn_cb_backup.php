<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Admin_cb extends Admin_Controller
{
	protected $section = 'cb';

	protected $country_arrays = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vatican City", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");

	protected $validation_rules = array(
		'name' => array(
			'field' => 'name',
			'label' => 'lang:cb:name_label',
			'rules' => 'trim|htmlspecialchars|required|max_length[250]|required'
		),
		'slug' => array(
			'field' => 'slug',
			'label' => 'lang:global:slug',
			'rules' => 'trim|alpha_dot_dash|max_length[250]|callback__check_slug|required'
			//'rules' => 'trim|alpha_dot_dash|max_length[100]|callback__check_slug'
		),
		array(
			'field' => 'status',
			'label' => 'lang:cb:status_label',
			'rules' => 'trim|alpha|required'
		),
		array(
			'field' => 'certification[]',
			'label' => 'lang:cb:certification_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'accreditation',
			'label' => 'lang:cb:accreditation_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'cb_number',
			'label' => 'lang:cb:cb_number_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'pic_and_position',
			'label' => 'lang:cb:pic_and_position_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'phone',
			'label' => 'lang:cb:phone_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'mobile',
			'label' => 'lang:cb:mobile_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'fax',
			'label' => 'lang:cb:fax_label',
			'rules' => 'trim'
		),
		array(
			'field' => 'email',
			'label' => 'lang:cb:email_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'website',
			'label' => 'lang:cb:website_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'address',
			'label' => 'lang:cb:address_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'country',
			'label' => 'lang:cb:country_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'geographical',
			'label' => 'lang:cb:geographical_label',
			'rules' => 'trim|required'
		),
		array(
			'field' => 'red_auditor',
			'label' => 'lang:cb:red_auditor_label',
			'rules' => 'trim|required'
		),
	);

	public function __construct()
	{
		parent::__construct();
		$this->load->model(array('members_m', 'cb_m'));
		$this->lang->load(array('members', 'cb'));

		$cb_certifications = array(
				'scc'=>'Supply Chain Certificate',
				'pnc'=>'Principles and Criteria',
		);

		$count = $this->cb_m->count_all();

		$countries[''] = 'Select country';
		foreach($this->country_arrays as $c)
		{
			$countries[$c] = $c;
		}

		$this->template
			->set('count', $count)
			->set('countries', $countries)
			->set('cb_certifications', $cb_certifications)
			;
	}

	public function index()
	{
		//set the base/default where clause
		$base_where = array('status' => 'all');
		
		$base_where['keywords'] = $this->input->post('f_keywords') ? $this->input->post('f_keywords') : NULL;
		$base_where['status'] = $this->input->post('f_status') ? $this->input->post('f_status') : NULL;

		// Create pagination links
		$total_rows = $this->cb_m->count_by($base_where);
		$pagination = create_pagination('admin/members/cb/index', $total_rows, NULL, 5);

		$base_where['limit'] = array($pagination['limit'], $pagination['offset']);

		// Using this data, get the relevant results
		$cbs = $this->cb_m->limit($pagination['limit'], $pagination['offset'])->get_many_by($base_where);

		//do we need to unset the layout because the request is ajax?
		$this->input->is_ajax_request() ? $this->template->set_layout(FALSE) : '';

		$this->template
			->title($this->module_details['name'])
			->append_js('admin/filter.js')
			//->set('count', $total_rows)
			->set('pagination', $pagination)
			->set('cbs', $cbs);

		$this->input->is_ajax_request() ? $this->template->build('admin/cb/tables/cb') : $this->template->build('admin/cb/index');
		
		//$this->template->build('admin/cb/index');
	}

	public function edit($id=0)
	{
		role_or_die('cb', 'edit_cb');

		$id OR redirect('members/admin/cb');

		$cb = $this->cb_m->get($id);

		if (empty($cb))
		{
			$this->output->set_flashdata('error', lang('cb:cb_does_not_exist'));
			redirect('admin/cb');
		}

		$this->form_validation->set_rules(array_merge($this->validation_rules, array(
			'slug' => array(
				'field' => 'slug',
				'label' => 'lang:global:slug',
				'rules' => 'trim|required|alpha_dot_dash|max_length[250]|callback__check_slug['.$id.']'
			),
		)));

		$certifications = NULL;
		if ($this->input->post('certification'))
		{
			$certifications = implode(',', $this->input->post('certification'));
		}

		//$this->form_validation->set_rules($this->validation_rules);

		if ($this->form_validation->run())
		{
			// They are trying to put this live
			if ($this->input->post('status') == 'live')
			{
				role_or_die('cb', 'publish_cb');
			}

			$input = array(
				'status'			=> $this->input->post('status'),
				'slug'				=> $this->input->post('slug'),
				'certification'		=> $certifications,
				'accreditation'		=> $this->input->post('accreditation'),
				'cb_number'			=> $this->input->post('cb_number'),
				'name'				=> $this->input->post('name'),
				'pic_and_position'	=> $this->input->post('pic_and_position'),
				'phone'				=> $this->input->post('phone'),
				'mobile'			=> $this->input->post('mobile'),
				'fax'				=> $this->input->post('fax'),
				'email'				=> $this->input->post('email'),
				'website'			=> $this->input->post('website'),
				'address'			=> $this->input->post('address'),
				'country'			=> $this->input->post('country'),
				'geographical'		=> $this->input->post('geographical'),
				'red_auditor'		=> $this->input->post('red_auditor') ? $this->input->post('red_auditor') : 'no',
				'updated_on'		=> now(),
				'updated_by'		=> $this->current_user->id,
			);

			if ($this->cb_m->update($id, $input))
			{
				$this->pyrocache->delete_all('cb_m');
				$this->session->set_flashdata('success', sprintf($this->lang->line('cb:edit_success'), $this->input->post('name')));
			}
			else
			{
				$this->session->set_flashdata('error', sprintf($this->lang->line('cb:edit_error'), $this->input->post('name')));
			}

			// Redirect back to the form or main page
			$this->input->post('btnAction') == 'save_exit' ? redirect('admin/members/cb') : redirect('admin/members/cb/edit/' . $id);
		}

		if (!empty($_POST))
		{
			foreach ($this->validation_rules as $key => $field)
			{
				$cb->$field['field'] = set_value($field['field']);
			}
			$cb->certification = $certifications;
		}


		$this->template
			->append_metadata($this->load->view('fragments/wysiwyg', array(), TRUE))
			->set('cb', $cb)
			->build('admin/cb/form');
	}

	public function create()
	{
		$this->form_validation->set_rules($this->validation_rules);

		$created_on = now();

		$slug = url_title($this->input->post('name'));

		$certifications = NULL;
		if ($this->input->post('certification'))
		{
			$certifications = implode(',', $this->input->post('certification'));
		}

		if ($this->form_validation->run())
		{
			// They are trying to put this live
			if ($this->input->post('status') == 'live')
			{
				role_or_die('cb', 'add_cb');
			}

			$input = array(
				'status'			=> $this->input->post('status'),
				'slug'				=> $slug,
				'certification'		=> $certifications,
				'accreditation'		=> $this->input->post('accreditation'),
				'cb_number'			=> $this->input->post('cb_number'),
				'name'				=> $this->input->post('name'),
				'pic_and_position'	=> $this->input->post('pic_and_position'),
				'phone'				=> $this->input->post('phone'),
				'mobile'			=> $this->input->post('mobile'),
				'fax'				=> $this->input->post('fax'),
				'email'				=> $this->input->post('email'),
				'website'			=> $this->input->post('website'),
				'address'			=> $this->input->post('address'),
				'country'			=> $this->input->post('country'),
				'geographical'		=> $this->input->post('geographical'),
				'red_auditor'		=> $this->input->post('red_auditor') ? $this->input->post('red_auditor') : 'no',
				'created_on'		=> now(),
				'created_by'		=> $this->current_user->id,
			);

			if ($id = $this->cb_m->insert($input))
			{
				$this->pyrocache->delete_all('cb_m');
				$this->session->set_flashdata('success', sprintf($this->lang->line('cb:add_success'), $this->input->post('name')));
			}
			else
			{
				$this->session->set_flashdata('error', lang('cb:add_error'));
			}

			// Redirect back to the form or main page
			$this->input->post('btnAction') == 'save_exit' ? redirect('admin/members/cb') : redirect('admin/members/cb/edit/' . $id);
		}
		else
		{
			// Go through all the known fields and get the post values
			$cb = new stdClass;
			foreach ($this->validation_rules as $key => $field)
			{
				$cb->$field['field'] = set_value($field['field']);
			}
			$cb->created_on = $created_on;
		}

		$cb->certification = $certifications;

		$this->template
			->title($this->module_details['name'], lang('cb:create_title'))
			//->append_metadata($this->load->view('fragments/wysiwyg', array(), TRUE))
			->set('cb', $cb)
			->build('admin/cb/form');
	}
	
	public function action()
	{
		switch ($this->input->post('btnAction'))
		{
			case 'delete':
				$this->delete();
				break;

			default:
				redirect('admin/members/cb');
				break;
		}
	}
	
	public function delete($id=0)
	{
		role_or_die('members', 'delete_cb');

		// Delete one
		$ids = ($id) ? array($id) : $this->input->post('action_to');

		// Go through the array of slugs to delete
		if ( ! empty($ids))
		{
			$post_titles = array();
			$deleted_ids = array();
			foreach ($ids as $id)
			{
				// Get the current page so we can grab the id too
				if ($scc = $this->cb_m->get($id))
				{
					if ($this->cb_m->delete($id))
					{
						// Wipe cache for this model, the content has changed
						$this->pyrocache->delete_all('cb_m');
						$post_titles[] = $scc->name;
						$deleted_ids[] = $id;
					}
				}
			}
		}

		// Some pages have been deleted
		if ( ! empty($post_titles))
		{
			// Only deleting one page
			if (count($post_titles) == 1)
			{
				$this->session->set_flashdata('success', sprintf($this->lang->line('cb:delete_success'), $post_titles[0]));
			}
			// Deleting multiple pages
			else
			{
				$this->session->set_flashdata('success', sprintf($this->lang->line('cb:mass_delete_success'), implode('", "', $post_titles)));
			}
		}
		// For some reason, none of them were deleted
		else
		{
			$this->session->set_flashdata('notice', lang('cb:delete_error'));
		}

		redirect('admin/members/cb');
	}

	public function pick($id=0)
	{
		$q = $this->input->get('term');
		$cbodies = $this->cb_m->get_many_by_name($q);
		foreach($cbodies as $cb)
		{
			$cbs[] = array('value'=>$cb->name, 'id'=>$cb->id);
		}

		echo json_encode($cbs);
	}
	
	public function view($id=0)
	{
		$cb = $this->cb_m->get($id);
		
		//do we need to unset the layout because the request is ajax?
		$this->input->is_ajax_request() and $this->template->set_layout(false);

		$this->template
			->title($this->module_details['name'])
			->set('cb', $cb);

		$this->template->build('admin/cb/view');
	}
	
	/**
	 * method to fetch filtered results for content list
	 * @access public
	 * @return void
	 */
	public function ajax_filter()
	{
		$area = $this->input->post('f_area');
		$status = $this->input->post('f_status');
		$type = $this->input->post('f_type');

		$post_data = array();

		if ($status == 'live' OR $status == 'draft')
		{
			$post_data['status'] = $status;
		}

		if ($type)
		{
			$post_data['type'] = $type;
		}

		if ($area != 0)
		{
			$post_data['area_id'] = $area;
		}

		$results = $this->members_m->search($post_data);

		//set the layout to false and load the view
		$this->template
			->set_layout(FALSE)
			->set('members', $results)
			->build('admin/members/cb/tables/cb');
	}
	
	public function _check_slug($slug, $id = null)
	{
		$this->form_validation->set_message('_check_slug', sprintf(lang('cb:already_exist_error'), $this->input->post('name')));
		return $this->cb_m->check_slug($slug, $id);

	}

}