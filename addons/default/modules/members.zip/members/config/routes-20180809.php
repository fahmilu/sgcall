<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
| 	www.your-site.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://www.codeigniter.com/user_guide/general/routing.html
*/

$route['members/admin/survey']					= 'admin_survey';
$route['members/admin/survey(/:any)?']			= 'admin_survey$1';

// admin
$route['members/admin(/:any)?']					= 'admin$1';

/*
$route['members/admin/pncassessment(/:any)?']	= 'admin_pncassessment$1';
$route['members/admin/cb(/:any)?']				= 'admin_cb$1';
*/

/*
$route['members/admin/scc']						= 'admin_scc';
$route['members/admin/scc(/:any)?']				= 'admin_scc$1';
*/

$route['members/admin_pncassessment(/:any)?']	= 'admin_pncassessment$1';
$route['members/admin_pncassessment_type(/:any)?']	= 'admin_pncassessment_type$1';
$route['members/admin_cb(/:any)?']				= 'admin_cb$1';

$route['members/admin_scc']						= 'admin_scc';
$route['members/admin_scc(/:any)?']				= 'admin_scc$1';


/*
apply
apply_membership_type
apply_organisation_detail
apply_contact_detail
apply_supporting_detail
*/

$route['members/online_application?'] 			= 'members/online_application';

$route['members/status-of-complaints?'] 			= 'status_of_complaints/index';
$route['members/status-of-complaints/view/(:num)?'] = 'status_of_complaints/view/$1';
$route['members/status-of-complaints(/:any)']		= 'status_of_complaints/index$1';

$route['members/status_of_complaints?'] 			= 'status_of_complaints/index';
$route['members/status_of_complaints/view/(:num)?'] = 'status_of_complaints/view/$1';
$route['members/status_of_complaints(/:any)']		= 'status_of_complaints/index$1';

$route['members/certification_bodies?'] 			= 'certification_bodies/index';
$route['members/certification_bodies(/:any)']		= 'certification_bodies/index$1';

// pnc certificate
/*
$route['members/principles-and-criteria-assessment-progress'] 			= 'pncassessment/index';
$route['members/principles-and-criteria-assessment-progress/page(/:any)']	= 'pncassessment/index$1';
$route['members/principles-and-criteria-assessment-progress(/:any)']	= 'pncassessment/index$1';
*/
$route['members/pncassessment?'] 								= 'pncassessment/index';
$route['members/pncassessment/public-announcement?'] 			= 'pncassessment/publicannouncement';
$route['members/pncassessment/public-announcement/(/:any)']		= 'pncassessment/publicannouncement$1';
$route['members/pncassessment/public-announcement/page(/:any)']	= 'pncassessment/publicannouncement$1';
$route['members/pncassessment/page/(/:any)']					= 'pncassessment/index$1';
$route['members/pncassessment(/:any)']							= 'pncassessment/index$1';

//$route['members/current_list_of__supply_chain_certification/page/(:any)?'] = 'current_list_of__supply_chain_certification/index/';
$route['members/current_list_of_supply_chain_certification'] 			= 'current_list_of_supply_chain_certification/index';
$route['members/current_list_of_supply_chain_certification/page/(/:any)']	= 'current_list_of_supply_chain_certification/index$1';
$route['members/current_list_of_supply_chain_certification(/:any)']	= 'current_list_of_supply_chain_certification/index$1';


// public
$route['members/sitemap.xml']			= 'sitemap/xml';

$route['members/forget(/:any)?']				= 'members/forget$1';
$route['members/change_pass(/:any)?']			= 'members/change_pass$1';

$route['members/myrspo-login']					= 'members/login';
$route['members/myrspo-registration']					= 'members/myrspo';
$route['members/myrspo-registration-successful?']	= 'members/myrspo_success';
$route['members/myrspo-set-password(/:any)?']			= 'members/myrspo_set_password$1';
$route['members/resend_myrspo_activation(/:any)?']		= 'members/resend_myrspo_activation$1';
$route['members/myrspo-resend-verification-email']		= 'members/myrspo_resend_verify';
$route['members/myrspo-account-activation']	   			= 'members/myrspo_activate';
$route['members/myrspo-account-activation(/:num)(/:any)']	   	= 'members/myrspo_activate$1$2';

//added by Koyan
$route['members/preview-docs(/:any)']		    = 'members/preview_docs$1';
$route['members/refresh_captcha']         		= 'members/refresh_captcha';
$route['members/register_validation']         		= 'members/register_validation';
$route['members/change-sector(/:num)']		    = 'members/reset_application$1';
$route['members/preview-docs(/:any)']		    = 'members/preview_docs$1';

$route['members/activate(/:any)?']				= 'members/activate$1';
$route['members/page(/:num)?']					= 'members/index/all$2';
$route['members/all?']							= 'members/index/all';
$route['members/all(/:any)?']					= 'members/index$1';
/* $route['members/all-cn?']						= 'members/index-cn/all-cn';
$route['members/all-cn(/:any)?']				= 'members/index-cn$1'; */
$route['members(/:num)(/:any)']					= 'members/index$1$2';
$route['members(/:any)?']						= 'members/index$1';

//added by  DWI
$route['members/profile(/:any)']         		= 'members/profile$1';	


