(function ($) {
	$(function () {

		$('a#addnewtype').colorbox({
			srollable: false,
			innerWidth: 600,
			innerHeight: 280,
			href: SITE_URL + 'admin/members/pncassessment_type/create_ajax',
			onComplete: function () {
				$.colorbox.resize();
				var $form_categories = $('form#pnctype');
				$form_categories.removeAttr('action');
				$form_categories.live('submit', function (e) {

					var form_data = $(this).serialize();

					$.ajax({
						url: SITE_URL + 'admin/members/pncassessment_type/create_ajax',
						type: "POST",
						data: form_data,
						success: function (obj) {

							if (obj.status == 'ok') {

								//succesfull db insert do this stuff
								var $select = $('select[name=assessment_type]');
								//append to dropdown the new option
								$select.append('<option value="' + obj.type_id + '" selected="selected">' + obj.stage + '</option>');
								$select.trigger("liszt:updated");
								// TODO work this out? //uniform workaround
								$(document.getElementById('pnctype')).find('li').first().find('span').html(obj.stage);

								//close the colorbox
								$.colorbox.close();
							} else {
								//no dice

								//append the message to the dom
								var $cboxLoadedContent = $(document.getElementById('cboxLoadedContent'));
								$cboxLoadedContent.html(obj.message + obj.form);
								//$cboxLoadedContent.find('p').first().show();
								$.colorbox.resize();
							}
						}
					});
					e.preventDefault();
				});

			}
		});

	});
})(jQuery);