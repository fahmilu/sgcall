<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
 *
 *   C A U T I O N !    B E W A R E !    A T T E N T I O N !!
 *
 *   You are editing the _LIVE VERSION_!!
 *
 */
	


/**
 * Members Events Class
 *
 * @author      Okky Sari
 * @author		Catalyze Web Team
 * @package		Modules\Members
 */
class Events_Members {

	protected $ci;

	// flag whether we have logged-in to SF or not
	protected $connected = false;

	// connect result or what we get upon successful connect/login to SF
	protected $connect_result = array();

	protected $member_application_sf_id = NULL;
	protected $member_account_sf_id = NULL;

/*
	// draft site
	protected $token_endpoint = 'https://cs6.salesforce.com/services/oauth2/token';
	protected $client_id = '3MVG9e2mBbZnmM6nTNqVlELiUikb8p2HRge5g_g5oB_N2plyzmHjsSesn07qx51wcBKOzzqFBlaQFY45Qmyj6';
	protected $client_secret = '4348439042887395801';
	protected $username = 'salesforce@rspo.org.fullcopy';
	//protected $password = 'RsP@6789rspo';
	protected $password = 'RsP@6789rspoXYZ';
	protected $grant_type = 'password';
*/

	// live/production site
	// this URL is as suggested on the email trail with Lava:
	//protected $token_endpoint = 'https://rspo.my.salesforce.com/services/Soap/c/24.0/0DF300000000K4S';
	//protected $token_endpoint = 'https://rspo.my.salesforce.com/services/oauth2/token';
	//
	// And this is the original one:
	protected $token_endpoint = 'https://rspo.my.salesforce.com/services/oauth2/token';
	//
	protected $client_id = '3MVG9Y6d_Btp4xp4K05uPbH0gHSA6py3z9kQ_YohiABp.woFx9uQYBUYsyDkOjZOKv1_27cWJzNNcLeD.4oaG';
	protected $client_secret = '1655856903773371555';
	protected $username = 'salesforce@rspo.org';
	protected $password = 'RsP@6789rspo';
	protected $grant_type = 'password';

	protected $instance_url;

	protected $email_cc = 'okky@catalyzecommunications.com,nazri.rm@rspo.org';

    public function __construct()
    {
        $this->ci =& get_instance();

        //register the email event
        Events::register('member_updated', array($this, 'sf_push'));
        Events::register('files_updated', array($this, 'push_files'));

        Events::register('member_cfc_submitted', array($this, 'push_comment'));
        Events::register('user_deleted', array($this, 'unlink_user'));

        Events::register('tls', array($this, 'sf_test'));

		// GM update
        Events::register('gm_updated', array($this, 'gm_push'));

		// push both SF & GM
        Events::register('both_updated', array($this, 'push_all'));

        //push email to mailchimp after member approved
        Events::register('member_approval', array($this, 'mailchimp_update'));
    }
    
    /**
     * Signing up all contact (contact person, primary, secondary, and fincance)
     * to mailchimp, by member intID given and list id given
     *
     * @param $input array { $intID string the id of membership, $list string id of list for mailchimp default value: 50c368626b }
     * @return array of Message for log
     */
	public function mailchimp_update($input)
	{
        $this->ci->load->model('mailchimp/mailchimp_m');
        $this->ci->load->model('oauth2/oauth2_m');
        $this->ci->load->library('mailchimp/mcapi', $this->ci->mailchimp_m->get_api_key());

        // - get all contact detail from member (primary, secondary, finance, contact person)
        $this->ci->load->model('members/members_m');
        $member = $this->ci->members_m->get_by('intID', $input['intID']);

        if (!$member) {
            return array('Error! (Signing up Mailchimp) Member with id given not found');
        }

        $user_list = array();

        //get contact person detail
        $user_contact = array();
        $user_contact['EMAIL'] = !empty($member->contact_email) ? $member->contact_email : '';
        $user_contact['NAME']['FNAME'] = !empty($member->contact_person) ? $member->contact_person : '';
        $user_contact['NAME']['LNAME'] = !empty($member->contact_lname) ? $member->contact_lname : '';
        $user_list[] = $user_contact;

        //get primary contact detail
        $user_primary = array();
        $user_primary['EMAIL'] = !empty($member->email_p) ? $member->email_p : '';
        $user_primary['NAME']['FNAME'] = !empty($member->name_p) ? $member->name_p : '';
        $user_primary['NAME']['LNAME'] = !empty($member->name_last_p) ? $member->name_last_p : '';
        $user_list[] = $user_primary;

        //get primary contact detail
        $user_secondary = array();
        $user_secondary['EMAIL'] = !empty($member->email_s) ? $member->email_s : '';
        $user_secondary['NAME']['FNAME'] = !empty($member->name_s) ? $member->name_s : '';
        $user_secondary['NAME']['LNAME'] = !empty($member->name_last_s) ? $member->name_last_s : '';
        $user_list[] = $user_secondary;

        //get primary contact detail
        $user_finance = array();
        $user_finance['EMAIL'] = !empty($member->email_f) ? $member->email_f : '';
        $user_finance['NAME']['FNAME'] = !empty($member->name_f) ? $member->name_f : '';
        $user_finance['NAME']['LNAME'] = !empty($member->name_last_f) ? $member->name_last_f : '';
        $user_list[] = $user_finance;

        // - call mailchimp model for signup
        $res = array();
        foreach ($user_list as $user) {
           if (!empty($user['EMAIL'])) {
               if (!empty($user['NAME']['FNAME'])) {
                   $result = $this->ci->mailchimp_m->api_addemail($this->ci->mcapi, $user['EMAIL'], $input['list'], $user['NAME']);
               } else {
                   $result = $this->ci->mailchimp_m->api_addemail($this->ci->mcapi, $user['EMAIL'], $input['list']);
               }

               if (strpos($result, 'Success') !== false) {
                   $result_msg = '(Mailchimp) Signing up '. $user['EMAIL'] .' was successful';
               } else {
                   $result_msg =  '(Mailchimp) Signing up '. $user['EMAIL'] .' was failed';
               }
               $res[] = $result_msg;
           }
        }

        return $res;
	}

	function _sf_connect()
	{
		exit;
	}

	public function sf_push($data=array())
	{
		$sf_owner_id = '00590000000fN1L';

		$email_recipient	= 'hl.kuah@rspo.org';
		$email_from			= 'membership@rspo.org';

		if (empty($data['id']))
		{
			return false;

		}

		$strModifyDate = date('Y-m-d', now());

		$this->ci->load->model('oauth2/oauth2_m');
		$this->ci->load->library('oauth2/my_nusoap');
		$this->ci->load->helper('file');

		// variables for email notification
		// - sf_date		date
		// - member_id		member's intID
		// - member			member's name
		// - sf_status		status (probably always error)
		// - sf_message		custom message (can be SF error message?)
		$edata['sf_date'] 	= date('d-M-Y H:i', now());
		$edata['member_id'] = $data['id'];
		$edata['member'] 	= $data['input']['title'];

		$this->ci->oauth2_m->error_log('info', 'SF Client: transaction starts' );

		$fields = array(
			'grant_type'=>$this->grant_type,
			'client_id'=>$this->client_id,
			'client_secret'=>$this->client_secret,
			'username'=>$this->username,
			'password'=>$this->password,
		);

		$connect_result = $this->fetchURL($this->token_endpoint, $fields);

/* *
echo "<pre>\n";
echo "\$connect_result:"."<br />\n";
print_r($connect_result);
echo "</pre>\n";
exit;
/* */

		$json = $json_user = '';
		if (!$connect_result)
		{
			$edata['sf']			= $data;
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= 'SF Client: failed to connect.';

			$this->send_email($edata);
			$this->ci->oauth2_m->error_log('error', 'SF Client: failed to connect.');
			if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: Failed connecting to SF');
			return false;
		}
		else
		{
			$json = json_decode($connect_result);

			if (!empty($json->error))
			{
					$edata['sf']			= $data;
					$edata['from'] 			= $email_from;//"membership@rspo.org";
					$edata['slug']			= 'sf-integration';
					$edata['to']			= $email_recipient;
					$edata['name']			= 'RSPO Membership';
					$edata['sf_status']		= 'Error';
					$edata['sf_message']	= !empty($json->error_description)?$json->error_description:'cannot login';
					$this->send_email($edata);
					$this->ci->oauth2_m->error_log('error', 'SF Client: '.!empty($json->error_description)?$json->error_description:'cannot login');
					if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: '.!empty($json->error_description)?$json->error_description:'cannot login');
					return false;
			}
			else
			{
				$token = !empty($json->access_token) ? $json->access_token : NULL;
				$id = !empty($json->id) ? $json->id : NULL;
				$this->instance_url = $json->instance_url;
				$id = 'https://cs6.salesforce.com/services/Soap/c/27.0';
				$issued_at = date('d-m-Y H:i:s', $json->issued_at/1000);
				if (empty($token))
				{
					$edata['from'] 			= $email_from;//"membership@rspo.org";
					$edata['slug']			= 'sf-integration';
					$edata['to']			= $email_recipient;
					$edata['name']			= 'RSPO Membership';
					$edata['sf_status']		= 'Error';
					$edata['sf_message']	= !empty($json->error_description)?$json->error_description:'cannot login';
					$this->send_email($edata);
					$this->ci->oauth2_m->error_log('error', 'SF Client: '.!empty($json->error_description)?$json->error_description:'cannot login');
					if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: '.!empty($json->error_description)?$json->error_description:'cannot login');
					return false;
				}
			}
			$this->ci->oauth2_m->error_log('success', 'SF Client: connected to SF.');
			$this->connected = true;
			$this->connect_result = $connect_result;
		}

		$wsdl_file = $_SERVER['DOCUMENT_ROOT'].'/'.ADDONPATH . 'modules/oauth2/libraries/inserter.xml';

		// client using nusoap
		if (!file_exists($wsdl_file))
		{
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= 'Could not find file inserter.xml.';
			$this->send_email($edata);
			$this->ci->oauth2_m->error_log('error', 'SF Client: inserter.xml does not exist.');
			if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: could not find inserter.xml file');
			return false;
		}

		$client = new nusoap_client($wsdl_file, TRUE);
		$client->soap_defencoding = 'utf-8';
		$error  = $client->getError();

		if ($error)
		{
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= $error;
			$this->send_email($edata);
			$this->ci->oauth2_m->error_log('error', 'SF Client: ' . $error);
			if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: error setting up SF client.<br />'.$error);
			return false;
		}

		$row = $data['input'];


		$header = "<SessionHeader><sessionId>$token</sessionId></SessionHeader>";
		$client->setHeaders($header);

/**
if ($data['id']==7910)
{
	echo "<pre>\n";
	echo "\$token: $token\n\n";
	echo "\$header: $header\n\n";
	exit;
}
**/
//echo "\$header: $header<br />";
//exit;

		$member = $this->ci->oauth2_m->get_member($data['id']);

		$member_intid = null;


		// SF account fields
		$account_data = array(
			'acc' => array(
				//'OwnerId' => $sf_owner_id,
				'CMS_IntID__c' => $member->intID,
				'Name'		=> !empty($member->title) ? htmlspecialchars_decode($member->title, ENT_QUOTES) : htmlspecialchars_decode($member->name, ENT_QUOTES),
				'Phone'		=> $row['code_telephone'] . ' ' . $row['telephone'],
				'ShippingStreet'	=> htmlspecialchars_decode($row['address'], ENT_QUOTES), // SF: one field
				'ShippingCity'	=> htmlspecialchars_decode($row['address_city'], ENT_QUOTES), // SF: one field
				'ShippingState'	=> htmlspecialchars_decode($row['address_state'], ENT_QUOTES), // SF: one field
				'ShippingPostalCode'	=> $row['address_zip'], // SF: one field
				'ShippingCountry'	=> $row['country'], // SF: one field
				'Description'		=> htmlspecialchars_decode($row['profile'], ENT_QUOTES),
				'Fax'		=> $row['code_fax'] . ' ' . $row['fax'],
				'Website'	=> $row['website'],
				'Type'		=> 'Membership Account',
				'Types__c'	=> 'Membership Account',
				'CurrencyIsoCode' => !empty($member->account_currency)?$member->account_currency:'EUR',
			),
		);

/*
if ($data['id']==1332 OR $member->intID == '1332' OR $member_intid == '1332')
{
	echo "<pre>\n";
	echo "\$token: $token\n\n";
	echo "\$header: $header\n\n";
	print_r($account_data);
	exit;
}
*/


		/* ---------------------------------------*
			for live system, comment ob_start()!
		------------------------------------------*/
		//ob_start();

		$acc_result = array();

		if ($member->account_sf_id)
		{
$at = "\n-- <b>updateAccount</b>\n\n";
			$account_data['acc']['Id'] = $member->account_sf_id;
			$acc_result = $client->call("updateAccount", array('parameters'=>$account_data));
		}
		else
		{
$at = "\n-- <b>createAccount</b>\n\n";
			$acc_result = $client->call("createAccount", array('parameters'=>$account_data));
		}

/*
if ($member && $member->intID = 7910)
{
	$member_intid = $member->intID;
	echo "<pre>\n";
	echo "\$at:$at\n\$acc_result:\n\n";
	print_r($acc_result);
	echo "\n<hr />\n";
	print_r($account_data);
	exit;
}
*/


		// this is the original line
		//$this->member_account_sf_id = $acc_result['result'];
		$this->member_account_sf_id = !empty($acc_result['result']) ? $acc_result['result'] : NULL;

		$return_message = array();

		// error?
		if ($client->fault)
		{
			$error = $client->getError();
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= $error;
			$this->send_email($edata);

			if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: error synchronizing Account<br />'.$error);
			$this->ci->oauth2_m->error_log('error', 'SF Client ('.$member->title.'): ' . $error);
			if (!empty($return_message) && empty($data['frontend']))
				$this->ci->session->set_flashdata('notice', implode("<br />", $return_message));
			return false;
		}
		else
		{
			$return_message[] = 'SF Account sync\'ed successfully ('.$acc_result['result'].')';
			$account_sf_id = $member->account_sf_id;
			if (!empty($member->account_sf_id) && !empty($acc_result['result']) && $member->account_sf_id==$acc_result['result'] )
			{
				$old_data = TRUE;
			}
			else
			{
				$old_data = FALSE;
			}
			$update_account = $this->ci->oauth2_m->save_member($member->intID,
				array(
					//'old_data'=> $old_data,
					'account_sf_id'=>$acc_result['result'],
					'strModifyDate'=>$strModifyDate
				),
				$old_data
			);

			if ($update_account)
			{
				$message = 'SF Client Account Id ('.$member->title.'): account successfully synced';
				$this->ci->oauth2_m->error_log('success', $message );
			}
			else
			{
				$message = 'SF Client Account Id ('.$member->title.'): failed sync-ing account to SF';
				$this->ci->oauth2_m->error_log('error', $message );
				return false;
			}
		}

		//$contact_default_type_id = '012N000000090gfIAA';
		$contact_default_type_id = '01290000001AoetAAC';

		// primary
		$fpname = !$row['name_last_p'] ? '' : $row['name_p'];
		$lpname = !$row['name_last_p'] ? $row['name_p'] : $row['name_last_p'];
		$primary_full_name = $fpname.' '.$lpname;

		// secondary
		$fsname = !$row['name_last_s'] ? '' : $row['name_s'];
		$lsname = !$row['name_last_s'] ? $row['name_s'] : $row['name_last_s'];
		$secondary_full_name = $fsname.' '.$lsname;

		// contact person
		$fcname = !$row['contact_lname'] ? '' : $row['contact_person'];
		$lcname = !$row['contact_lname'] ? $row['contact_person'] : $row['contact_lname'];
		$contact_full_name = $fcname.' '.$lcname;

		// finance
		$ffname = !$row['name_last_f'] ? '' : $row['name_f'];
		$lfname = !$row['name_last_f'] ? $row['name_f'] : $row['name_last_f'];
		$finance_full_name = $ffname.' '.$lfname;

		// from events-ori.php starts
		$fname = !$row['name_last_p'] ? '' : $row['name_p'];
		$lname = !$row['name_last_p'] ? $row['name_p'] : $row['name_last_p'];
		$primary_full_name = $fname.' '.$lname;

		$contact_data['primary'] = array(
			'cnt' => array(
				//'OwnerId' => $sf_owner_id,
				'CMS_IntID__c' => $member->intID,
				'AccountId' => $acc_result['result'],
				'Email'		=> $row['email_p'],
				'FirstName'	=> $fname,
				'LastName'	=> $lname,
				'RecordTypeId' => $contact_default_type_id,
				'Primary_contact__c' => TRUE,
				'Financial_contact_for_membership_fee__c' => (bool)($row['name_p'] == $row['name_f']),
				'Senior_representative_author_commitment__c' => (bool)($row['name_p'] == $row['contact_person']),
				'Secondary_Nomination_Contact__c' => (bool)($row['name_p'] == $row['name_s']),
				'Title' 	=> $row['designation_p'],
				'Phone'	=> $row['telephone_p'], //$row['code_tel_p'] . ' ' . $row['telephone_p'],
				'Fax'	=> $row['fax_p'], //$row['code_fax_p'] . ' ' . $row['fax_p'],
				'Country_Cont__c' => !empty($member->country_p)?$member->country_p:$member->country,
			),
		);
		if ($member->primary_sf_id)
		{
			$contact_data['primary']['cnt']['Id'] = $member->primary_sf_id;
		}


		// secondary
		$fname = !$row['name_last_s'] ? '' : $row['name_s'];
		$lname = !$row['name_last_s'] ? $row['name_s'] : $row['name_last_s'];
		$secondary_full_name = $fname.' '.$lname;
		if ($primary_full_name <> $secondary_full_name)
		{
			$contact_data['secondary'] = array(
					'cnt' => array(
						//'OwnerId' => $sf_owner_id,
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['email_s'],
						'FirstName'	=> $fname,
						'LastName'	=> $lname,
						'Title' 	=> $row['designation_s'],
						'Phone'	=> $row['telephone_s'], //$row['code_tel_s'] . ' ' . $row['telephone_s'],
						'Fax'	=> $row['fax_s'], //$row['code_fax_s'] . ' ' . $row['fax_s'],
						'RecordTypeId' => $contact_default_type_id,
						'Secondary_Nomination_Contact__c' => TRUE,
						'Country_Cont__c' => !empty($member->country_s)?$member->country_s:$member->country,
					),
				);
			if ($member->secondary_sf_id)
			{
				$contact_data['secondary']['cnt']['Id'] = $member->secondary_sf_id;
			}
		}

		// contact person
		$fname = !$row['contact_lname'] ? '' : $row['contact_person'];
		$lname = !$row['contact_lname'] ? $row['contact_person'] : $row['contact_lname'];
		$contact_full_name = $fname.' '.$lname;
		if ($primary_full_name <> $contact_full_name AND $secondary_full_name <> $contact_full_name)
		{
			$contact_data['contact'] = array(
					'cnt' => array(
						//'OwnerId' => $sf_owner_id,
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['contact_email'],
						'FirstName'	=> $fname,
						'LastName'	=> $lname,
						'Senior_representative_author_commitment__c' => TRUE,
						'Title' 	=> $row['designation'],
						'Phone'	=> $row['contact_tel'], //$row['code_contact_tel'] . ' ' . $row['contact_tel'],
						'Fax'	=> $row['contact_fax'], //$row['code_contact_fax'] . ' ' . $row['contact_fax'],
						'RecordTypeId' => $contact_default_type_id,
						'Country_Cont__c' => !empty($member->country_c)?$member->country_c:$member->country,
					),
				);
			if ($member->contact_sf_id)
			{
				$contact_data['contact']['cnt']['Id'] = $member->contact_sf_id;
			}
		}

		// finance
		$fname = !$row['name_last_f'] ? '' : $row['name_f'];
		$lname = !$row['name_last_f'] ? $row['name_f'] : $row['name_last_f'];
		$finance_full_name = $fname.' '.$lname;
		if ($primary_full_name <> $finance_full_name AND $secondary_full_name <> $finance_full_name AND $contact_full_name <> $finance_full_name)
		{
			$contact_data['finance'] = array(
					'cnt' => array(
						//'OwnerId' => $sf_owner_id,
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['email_f'],
						'FirstName'	=> $fname,
						'LastName'	=> $lname,
						'Financial_contact_for_membership_fee__c' => TRUE,
						'Senior_representative_author_commitment__c' => (bool)($row['name_f'] == $row['contact_person']),
						'Title' 	=> $row['designation_f'],
						'Phone'	=> $row['telephone_f'], //$row['code_tel_f'] . ' ' . $row['telephone_f'],
						'Fax'	=> $row['fax_f'], //$row['code_fax_f'] . ' ' . $row['fax_f'],
						'RecordTypeId' => $contact_default_type_id,
						'Country_Cont__c' => !empty($member->country_f)?$member->country_f:$member->country,
					),
				);
			if ($member->finance_sf_id)
			{
				$contact_data['finance']['cnt']['Id'] = $member->finance_sf_id;
			}
		}

		$db_fields = array(
			'account' => 'account_sf_id',
			'application' => 'application_sf_id',
			'primary' => 'primary_sf_id',
			'secondary' => 'secondary_sf_id',
			'finance' => 'finance_sf_id',
			'contact' => 'contact_sf_id',
		);
		$cnt_result = array();
		if (!empty($acc_result['result']))
		{
			foreach($contact_data as $key => $val)
			{
                ob_start();
				echo "<pre>\n";
				echo "\nContact Struct sent to SF:\n";
				print_r($val);
				echo "\n</pre>\n";
				$contact_array_data = ob_get_contents();
				ob_end_flush();
				$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.') Contact struct: '.$contact_array_data);

				if ( !empty($member->$db_fields[$key]) )
				{
					$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): updating '.$db_fields[$key].': '.$member->$db_fields[$key] );
					$cnt_result[$key] = $client->call("updateContact", array('parameters'=>$val));
				}
				else
				{
					$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): creating '.$db_fields[$key].': '.$member->$db_fields[$key] );
					$cnt_result[$key] = $client->call("createContact", array('parameters'=>$val));
				}

//echo "Updating: $key<br />\n";

				if ($client->fault)
				{
					$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): '.$db_fields[$key].' - contact exists');
					$fault_string = $cnt_result[$key]['faultstring'];
					$pattern = '/value on record with id: ([a-z0-9]*):/i';
					$preg = preg_match($pattern, $fault_string, $matches);
					$current_sf_id = $matches[1];

					if ($current_sf_id)
					{

						$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): setting '.$key.'_sf_id to '.$current_sf_id);

						// update db with sf id from the error message
						$input = array($key.'_sf_id'=>$current_sf_id);

						$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): saving '.$key.'_sf_id to DB');
						if ($this->ci->oauth2_m->save_member($member->intID, $input))
						{
							$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): saving '.$key.'_sf_id to DB was successful');
							// push it back to SF using updateContact
							$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): pushing back to SF using updateContact');
							$val['cnt']['Id'] = $current_sf_id;
							$cnt_result[$key] = $client->call("updateContact", array('parameters'=>$val));
							if ($client->fault)
							{
								$error 					= $client->getError();
								$edata['from'] 			= $email_from;//"membership@rspo.org";
								$edata['slug']			= 'sf-integration';
								$edata['to']			= $email_recipient;
								$edata['name']			= 'RSPO Membership';
								$edata['sf_status']		= 'Error';
								$edata['sf_message']	= 'Error pushing '.$key.' to SF<br />'.$error;
								$this->send_email($edata);
								$this->ci->oauth2_m->error_log('error', 'SF Client ('.$member->title.'): '.$db_fields[$key].': '.$error );
								$return_message[] = 'Contact ('.$key.') did not sync.';
								return false;
							}
							else
							{
								$return_message[] = 'Contact ('.$key.': '.$cnt_result[$key]['result'].') sync\'ed successfully.';
								$this->ci->oauth2_m->error_log('success', 'SF Client ('.$member->title.'): '.$db_fields[$key].': '.$cnt_result[$key]['result'] );
	
							}
						}
						else
						{
							$return_message[] = 'Contact ('.$key.': '.$cnt_result[$key]['result'].') failed to sync.';
							$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): saving '.$key.'_sf_id to DB');
						}

					}
					else
					{
						$return_message[] = 'Contact ('.$key.': '.$cnt_result[$key]['result'].') failed to sync.';
						$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): saving '.$key.'_sf_id to DB');
					}

/* *
echo "<pre>";
echo "\$member->intID: ".$member->intID."\n";
echo "\$current_sf_id: $current_sf_id\n";
echo "\$key: $key\n";
echo "</pre>\n";
echo "<pre>\$val:\n";
print_r($val);
echo "</pre>\n";

echo "<pre>\n";
echo "SF: Result\n";
print_r($cnt_result[$key]);
echo "</pre>";
exit;
/* */
				}
				else
				{
					$return_message[] = 'Contact ('.$key.': '.$cnt_result[$key]['result'].') sync\'ed successfully.';
					if ( empty($member->$db_fields[$key]) )
					{
						// update db:
						$this->ci->oauth2_m->save_member($member->intID, array($db_fields[$key]=>$cnt_result[$key]['result']));
					}
					$this->ci->oauth2_m->error_log('success', 'SF Client ('.$member->title.'): '.$db_fields[$key].': '.$cnt_result[$key]['result'] );
				}
			}
		}

		// tweak the results
		/** primary & secondary **/
		if ($primary_full_name == $secondary_full_name)
		{
			$cnt_result['secondary']['result'] = $cnt_result['primary']['result'];
		}

		/** primary & contact **/
		if ($primary_full_name == $contact_full_name)
		{
			$cnt_result['contact']['result'] = $cnt_result['primary']['result'];
		}

		/** primary & finance **/
		if ($primary_full_name == $finance_full_name)
		{
			$cnt_result['finance']['result'] = $cnt_result['primary']['result'];
		}

		/** secondary & contact **/
		if ($secondary_full_name == $contact_full_name)
		{
			$cnt_result['contact']['result'] = $cnt_result['secondary']['result'];
		}

		/** secondary & finance **/
		if ($secondary_full_name == $finance_full_name)
		{
			$cnt_result['finance']['result'] = $cnt_result['secondary']['result'];
		}

		/** contact & finance **/
		if ($contact_full_name == $finance_full_name)
		{
			$cnt_result['finance']['result'] = $cnt_result['contact']['result'];
		}

		$sf_types = array(
			'Ordinary Members'=>'Ordinary',
			'Affiliate Members'=>'Affiliate',
			'Affiliate Member'=>'Affiliate',
			'Supply Chain Associate'=>'Associate',
		);

		$old_types = array(
			'Ordinary Members', 'Affiliate Members', 'Affiliate Member', 'Supply Chain Associate'
		);

		// check and change old types
		if (in_array($member->type, $old_types) && !empty($sf_types[$member->type]))
		{
			$member_type = $sf_types[$member->type];
		}
		else
		{
			$member_type = $member->type;
		}


		$old_categories = array('Palm Oil Processors and Traders', 'Environmental and Conservation NGOs', 'Social and Developmental NGOs', 'Banks & Investors');

		$sf_categories = array(
			'Palm Oil Processors and Traders'=>'Palm Oil Processors and/or Traders',
			'Environmental and Conservation NGOs'=>'Environmental or Nature Conservation Organisations (Non Governmental Organisations)',
			'Social and Developmental NGOs'=>'Social or Development Organisations (Non Governmental Organisations)',
			'Banks & Investors'=>'Banks and Investors'
		);
		// check and change old categories
		if (in_array($member->category, $old_categories) && !empty($sf_categories[$member->category]))
		{
			$member_category = $sf_categories[$member->category];
		}
		else
		{
			$member_category = $member->category;
		}

		// process application
		$app_result = '';
		if ( !empty($cnt_result) && !empty($acc_result['result']) )
		{
			if ($member->parent_company=='sub')
			{
				$tmp_parent_company = unserialize($member->sub_company);
				$parent_company = $tmp_parent_company[1]['name'];
				$subsidiaries = '';
			}
			elseif ($member->parent_company=='yes')
			{
				$parent_company = $subsidiaries = '';
				$tmp_subsidiaries = unserialize($member->sub_company);
				if (!empty($tmp_subsidiaries))
				{
					$tmp_sub = array();
					foreach($tmp_subsidiaries as $ts)
					{
						$tmp_sub[] = $ts['name'];
					}
					$subsidiaries = implode(', ', $tmp_sub);
				}
			}
			else
			{
				$parent_company = '';
				$subsidiaries = '';
			}

			if ($member->status == 'Call for Comment')
				$member_status='Call For Comment';
			elseif ($member->status == 'Approved')
				$member_status='Active';
			else
				$member_status = $member->status;

			$applied_date = date('Y-m-d', $member->applied_date);

			if ($member->greenpalm_member_num)
			{
				if ($member->application_sf_id=='')
				{
					if ($member->remarks && !stristr($member->remarks, 'GreenPalm Membership No'))
						$member->remarks .= ', GreenPalm Membership No.: '.$member->greenpalm_member_num;
					else
						$member->remarks = 'GreenPalm Membership No.: '.$member->greenpalm_member_num;
				}
			}

			$member->remarks = strip_tags( str_ireplace( array('<br />', '<br>'), ' - ',  htmlspecialchars_decode($member->remarks) ) );

			$application_data = array(
				'app' => array(
					//'OwnerId' => $sf_owner_id,
					'Account__c'	=> $acc_result['result'],	// AccountId from account creation
					'Name'		=> !empty($member->title) ? $member->title : $member->name,	 	// title
					'type__c'	=> $member_type, //$sf_types[$member->type], 	// type (ordinary members is ordinary at SF)
					'Sector__c'	=> $member_category, //$member->category,			// category
					'Sub_Sector__c' => $member->profession=='Select subcategory'?'':$member->profession,		// sub-category/profession
					'Business_Registration_Number__c' => $member->registration_number, 	// registration_number
					'Application_Contact__c' => !empty($cnt_result['contact']['result']) ? $cnt_result['contact']['result'] : '',			// ID of who made the application
					'Person_For_Membership_Fee_c__c' => $cnt_result['finance']['result'],	// ID for financial
					'Primary_Contact_Person_c__c' => '', 									// ID for primary contact
					'Primary_Representative__c' => $cnt_result['primary']['result'],		// ID for primary contact
					'Secondary_Representative__c' => $cnt_result['secondary']['result'],	// ID for secondary
					'Answer8__c' => htmlspecialchars_decode($row['q1'], ENT_QUOTES),				// Q1
					'Answer6__c' => htmlspecialchars_decode($row['q2'], ENT_QUOTES),				// Q2
					'Answer7__c' => htmlspecialchars_decode($row['q3'], ENT_QUOTES),				// Q3
					'Answer9__c' => htmlspecialchars_decode($row['q4'], ENT_QUOTES),				// Q4
					'Answer10__c' => $member->q_usage,						// q_usage
					'Comment_Fee_Reduction__c' => $member->production_area,
					'Status__c' 	=> $member_status, //$member->status=='Call for Comment'?'Call For Comment':$member->status,	// membership status
					'Email__c'		=> $member->email,
					'Primary_Market_Operation_Application_GIn__c' => $member->primary_market_ops == 'World' ? 'Rest of the World' : $member->primary_market_ops,
					'Other_Market_Operations_Application_GInf__c' => $member->other_market_ops,
					'Old_Name__c'	=> $member->name_a,				// person made the application
					'Other_Person_Designation__c' => $member->designation_a,		// designation
					//'App_received_apply_date__c' => 0,
					'App_received_apply_date__c' => $applied_date,
					//'Received_c__c' => $submitted_date, // moved to below
					'URL_Membership__c' => 'http://www.rspo.org/members/'.$member->intID,	// member profile URL
					'CMS_IntID__c' => $member->intID,
					'Comment_a__c' => $member->remarks,
					'Parent__c' => $parent_company,  // parent and subsidiaries
					'Subsidiary__c' => $subsidiaries, //$member->sub_company, // are now unlinked
					//'Fee_Euro__c' => $member->total_amount_due,
				),
			);


			if (!$member->applied_date)
			{
				$application_data['app']['Received_c__c'] = $submitted_date;
			}

/*
if ($data['id']==1332 OR $member->intID == '1332' OR $member_intid == '1332')
{
	echo "<pre>\n";
	echo "\$token: $token\n\n";
	echo "\$header: $header\n\n";
	print_r($application_data);
	exit;
}
*/

			if ($member->application_sf_id)
			{
				$application_data['app']['Id'] = $member->application_sf_id;
				$app_result = $client->call("updateApplication", array('parameters'=>$application_data));
			}
			else
			{
				$application_data['app']['Account_Description__c'] = $member->profile;
				$app_result = $client->call("createApplication", array('parameters'=>$application_data));
			}

			if ($client->fault)
			{
				$error 					= $client->getError();
				$edata['from'] 			= $email_from;//"membership@rspo.org";
				$edata['slug']			= 'sf-integration';
				$edata['to']			= $email_recipient;
				$edata['name']			= 'RSPO Membership';
				$edata['sf_status']		= 'Error';
				$edata['sf_message']	= 'Error pushing '.$key.' to SF<br />'.$error;
				$this->send_email($edata);
				$this->ci->oauth2_m->error_log('error', 'SF Client ('.$member->title.'): Application sync; '.$error );
				if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Client ('.$member->title.'): Application sync; '.$error);
				if (!empty($return_message) && empty($data['frontend']))
					$this->ci->session->set_flashdata('notice', implode("<br />", $return_message));
				return false;
			}
			else
			{
				if ( empty($member->application_sf_id) )
				{
					if (!empty($member->application_sf_id) && !empty($app_result['result']) && $member->application_sf_id==$app_result['result'] )
					{
						$old_data = TRUE;
					}
					else
					{
						$old_data = FALSE;
					}

					$update_application = $this->ci->oauth2_m->save_member($member->intID,
						array(
							//'old_data'=> $old_data,
							'application_sf_id'=>$app_result['result'],
							'strModifyDate'=>$strModifyDate
						),
						$old_data
					);

					// update db:

					if ($update_application)
						$this->ci->oauth2_m->error_log('success', 'SF Client ('.$member->title.'): application successfully synced' );

				}
				else
				{
					$this->ci->oauth2_m->error_log('info', 'SF Client ('.$member->title.'): application successfully synced' );
				}
				$return_message[] = 'Application sync\'ed successfully ('.$app_result['result'].').';
			}
		}
		else
		{
		}

		if (!empty($return_message) && empty($data['frontend']))
			$this->ci->session->set_flashdata('notice', implode("<br />", $return_message));
		$this->ci->oauth2_m->error_log('info', 'SF Client ('.$member->title.'): transaction ends' );

		return true;

		//return $member->title . ' synced to SalesForce';
	}

	public function sf_push_old($data=array())
	{
		if (empty($data['id']))
		{
			return false;

		}

		$sf_owner_id = '00590000000fN1L';

		$email_recipient	= 'hl.kuah@rspo.org';
		$email_from			= 'membership@rspo.org';

		$strModifyDate = date('Y-m-d', now());

		$this->ci->load->model('oauth2/oauth2_m');
		$this->ci->load->library('oauth2/my_nusoap');
		$this->ci->load->helper('file');

		// variables for email notification
		// - sf_date		date
		// - member_id		member's intID
		// - member			member's name
		// - sf_status		status (probably always error)
		// - sf_message		custom message (can be SF error message?)
		$edata['sf_date'] 	= date('d-M-Y H:i', now());
		$edata['member_id'] = $data['id'];
		$edata['member'] 	= $data['input']['title'];

		$this->ci->oauth2_m->error_log('info', 'SF Client: transaction starts' );

		$fields = array(
			'grant_type'=>$this->grant_type,
			'client_id'=>$this->client_id,
			'client_secret'=>$this->client_secret,
			'username'=>$this->username,
			'password'=>$this->password,
		);

		$connect_result = $this->fetchURL($this->token_endpoint, $fields);

		$json = $json_user = '';
		if (!$connect_result)
		{
			$edata['sf']			= $data;
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= 'SF Client: failed to connect.';

			$this->send_email($edata);
			$this->ci->oauth2_m->error_log('error', 'SF Client: failed to connect.');
			$this->ci->session->set_flashdata('error', 'SF Integration: Failed connecting to SF');
			return false;
		}
		else
		{
			$json = json_decode($connect_result);

			if (!empty($json->error))
			{
					$edata['sf']			= $data;
					$edata['from'] 			= $email_from;//"membership@rspo.org";
					$edata['slug']			= 'sf-integration';
					$edata['to']			= $email_recipient;
					$edata['name']			= 'RSPO Membership';
					$edata['sf_status']		= 'Error';
					$edata['sf_message']	= !empty($json->error_description)?$json->error_description:'cannot login';
					$this->send_email($edata);
					$this->ci->oauth2_m->error_log('error', 'SF Client: '.!empty($json->error_description)?$json->error_description:'cannot login');
					$this->ci->session->set_flashdata('error', 'SF Integration: '.!empty($json->error_description)?$json->error_description:'cannot login');
					return false;
			}
			else
			{
				$token = !empty($json->access_token) ? $json->access_token : NULL;
				$id = !empty($json->id) ? $json->id : NULL;
				$this->instance_url = $json->instance_url;
				$id = 'https://cs6.salesforce.com/services/Soap/c/27.0';
				$issued_at = date('d-m-Y H:i:s', $json->issued_at/1000);
				if (empty($token))
				{
					$edata['from'] 			= $email_from;//"membership@rspo.org";
					$edata['slug']			= 'sf-integration';
					$edata['to']			= $email_recipient;
					$edata['name']			= 'RSPO Membership';
					$edata['sf_status']		= 'Error';
					$edata['sf_message']	= !empty($json->error_description)?$json->error_description:'cannot login';
					$this->send_email($edata);
					$this->ci->oauth2_m->error_log('error', 'SF Client: '.!empty($json->error_description)?$json->error_description:'cannot login');
					$this->ci->session->set_flashdata('error', 'SF Integration: '.!empty($json->error_description)?$json->error_description:'cannot login');
					return false;
				}
			}
			$this->ci->oauth2_m->error_log('success', 'SF Client: connected to SF.');
		}

		$wsdl_file = $_SERVER['DOCUMENT_ROOT'].'/'.ADDONPATH . 'modules/oauth2/libraries/inserter.xml';

		// client using nusoap
		if (!file_exists($wsdl_file))
		{
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= 'Could not find file inserter.xml.';
			$this->send_email($edata);
			$this->ci->oauth2_m->error_log('error', 'SF Client: inserter.xml does not exist.');
			$this->ci->session->set_flashdata('error', 'SF Integration: could not find inserter.xml file');
			return false;
		}

		$client = new nusoap_client($wsdl_file, TRUE);
		$client->soap_defencoding = 'utf-8';
		$error  = $client->getError();

		if ($error)
		{
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= $error;
			$this->send_email($edata);
			$this->ci->oauth2_m->error_log('error', 'SF Client: ' . $error);
			$this->ci->session->set_flashdata('error', 'SF Integration: error setting up SF client.<br />'.$error);
			return false;
		}

		$row = $data['input'];

		$header = 
		"<SessionHeader>
		  <sessionId>$token</sessionId>
		</SessionHeader>";
		$client->setHeaders($header);

		$member = $this->ci->oauth2_m->get_member($data['id']);

		// SF account fields
		$account_data = array(
			'acc' => array(
				//'OwnerId' => '00590000000fN1L',
				'CMS_IntID__c' => $member->intID,
				'Name'		=> !empty($member->title) ? html_entity_decode($member->title) : html_entity_decode($member->name),
				'Phone'		=> $row['code_telephone'] . ' ' . $row['telephone'],
				'ShippingStreet'	=> html_entity_decode($row['address']), // SF: one field
				'ShippingCity'	=> html_entity_decode($row['address_city']), // SF: one field
				'ShippingState'	=> html_entity_decode($row['address_state']), // SF: one field
				'ShippingPostalCode'	=> $row['address_zip'], // SF: one field
				'ShippingCountry'	=> $row['country'], // SF: one field
				'Description'		=> html_entity_decode($row['profile']),
				'Fax'		=> $row['code_fax'] . ' ' . $row['fax'],
				'Website'	=> $row['website'],
				'Type'		=> 'Membership Account',
				'Types__c'	=> 'Membership Account',
				'CurrencyIsoCode' => !empty($member->account_currency)?$member->account_currency:'EUR',
			),
		);

		/* ---------------------------------------*
			for live system, comment ob_start()!
		------------------------------------------*/
		//ob_start();

		$acc_result = array();

		if ($member->account_sf_id)
		{
			$account_data['acc']['Id'] = $member->account_sf_id;
			$acc_result = $client->call("updateAccount", array('parameters'=>$account_data));
		}
		else
		{
			$acc_result = $client->call("createAccount", array('parameters'=>$account_data));
		}

		$return_message = array();

		// error?
		if ($client->fault)
		{
			$error = $client->getError();
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= $error;
			$this->send_email($edata);

			$this->ci->session->set_flashdata('error', 'SF Integration: error synchronizing Account<br />'.$error);
			$this->ci->oauth2_m->error_log('error', 'SF Client ('.$member->title.'): ' . $error);
			return false;
		}
		else
		{
			$return_message[] = 'SF: Account sync\'ed successfully ('.$acc_result['result'].')';

			$account_sf_id = $member->account_sf_id;
			if (!empty($member->account_sf_id) && !empty($acc_result['result']) && $member->account_sf_id==$acc_result['result'] )
			{
				$old_data = TRUE;
			}
			else
			{
				$old_data = FALSE;
			}
			$update_account = $this->ci->oauth2_m->save_member($member->intID,
				array(
					//'old_data'=> $old_data,
					'account_sf_id'=>$acc_result['result'],
					'strModifyDate'=>$strModifyDate
				),
				$old_data
			);

			if ($update_account)
			{
				$message = 'SF Client Account Id ('.$member->title.'): account successfully synced';
				$this->ci->oauth2_m->error_log('success', $message );
			}
			else
			{
				$message = 'SF Client Account Id ('.$member->title.'): failed sync-ing account to SF';
				$this->ci->oauth2_m->error_log('error', $message );
				return false;
			}
		}

		//$contact_default_type_id = '012N000000090gfIAA';
		$contact_default_type_id = '01290000001AoetAAC';

		// primary
		$fpname = !$row['name_last_p'] ? '' : $row['name_p'];
		$lpname = !$row['name_last_p'] ? $row['name_p'] : $row['name_last_p'];
		$primary_full_name = $fpname.' '.$lpname;

		// secondary
		$fsname = !$row['name_last_s'] ? '' : $row['name_s'];
		$lsname = !$row['name_last_s'] ? $row['name_s'] : $row['name_last_s'];
		$secondary_full_name = $fsname.' '.$lsname;

		// contact person
		$fcname = !$row['contact_lname'] ? '' : $row['contact_person'];
		$lcname = !$row['contact_lname'] ? $row['contact_person'] : $row['contact_lname'];
		$contact_full_name = $fcname.' '.$lcname;

		// finance
		$ffname = !$row['name_last_f'] ? '' : $row['name_f'];
		$lfname = !$row['name_last_f'] ? $row['name_f'] : $row['name_last_f'];
		$finance_full_name = $ffname.' '.$lfname;

		// from events-ori.php starts
		$fname = !$row['name_last_p'] ? '' : $row['name_p'];
		$lname = !$row['name_last_p'] ? $row['name_p'] : $row['name_last_p'];
		$primary_full_name = $fname.' '.$lname;

		$contact_data['primary'] = array(
			'cnt' => array(
				//'OwnerId' => '00590000000fN1L',
				'CMS_IntID__c' => $member->intID,
				'AccountId' => $acc_result['result'],
				'Email'		=> $row['email_p'],
				'FirstName'	=> $fname,
				'LastName'	=> $lname,
				'RecordTypeId' => $contact_default_type_id,
				'Primary_contact__c' => TRUE,
				'Financial_contact_for_membership_fee__c' => (bool)($row['name_p'] == $row['name_f']),
				'Senior_representative_author_commitment__c' => (bool)($row['name_p'] == $row['contact_person']),
				'Secondary_Nomination_Contact__c' => (bool)($row['name_p'] == $row['name_s']),
				'Title' 	=> $row['designation_p'],
				'Phone'	=> $row['telephone_p'], //$row['code_tel_p'] . ' ' . $row['telephone_p'],
				'Fax'	=> $row['fax_p'], //$row['code_fax_p'] . ' ' . $row['fax_p'],
				'Country_Cont__c' => !empty($member->country_p)?$member->country_p:$member->country,
			),
		);
		if ($member->primary_sf_id)
		{
			$contact_data['primary']['cnt']['Id'] = $member->primary_sf_id;
		}
		// from events-ori.php ends


		// from events-ori.php starts
		// secondary
		$fname = !$row['name_last_s'] ? '' : $row['name_s'];
		$lname = !$row['name_last_s'] ? $row['name_s'] : $row['name_last_s'];
		$secondary_full_name = $fname.' '.$lname;
		if ($primary_full_name <> $secondary_full_name)
		{
			$contact_data['secondary'] = array(
					'cnt' => array(
						//'OwnerId' => '00590000000fN1L',
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['email_s'],
						'FirstName'	=> $fname,
						'LastName'	=> $lname,
						'Title' 	=> $row['designation_s'],
						'Phone'	=> $row['telephone_s'], //$row['code_tel_s'] . ' ' . $row['telephone_s'],
						'Fax'	=> $row['fax_s'], //$row['code_fax_s'] . ' ' . $row['fax_s'],
						'RecordTypeId' => $contact_default_type_id,
						'Secondary_Nomination_Contact__c' => TRUE,
						'Country_Cont__c' => !empty($member->country_s)?$member->country_s:$member->country,
					),
				);
			if ($member->secondary_sf_id)
			{
				$contact_data['secondary']['cnt']['Id'] = $member->secondary_sf_id;
			}
		}
		// from events-ori.php ends


		// from events-ori.php starts
		// contact person
		$fname = !$row['contact_lname'] ? '' : $row['contact_person'];
		$lname = !$row['contact_lname'] ? $row['contact_person'] : $row['contact_lname'];
		$contact_full_name = $fname.' '.$lname;
		if ($primary_full_name <> $contact_full_name AND $secondary_full_name <> $contact_full_name)
		{
			$contact_data['contact'] = array(
					'cnt' => array(
						//'OwnerId' => '00590000000fN1L',
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['contact_email'],
						'FirstName'	=> $fname,
						'LastName'	=> $lname,
						'Senior_representative_author_commitment__c' => TRUE,
						'Title' 	=> $row['designation'],
						'Phone'	=> $row['contact_tel'], //$row['code_contact_tel'] . ' ' . $row['contact_tel'],
						'Fax'	=> $row['contact_fax'], //$row['code_contact_fax'] . ' ' . $row['contact_fax'],
						'RecordTypeId' => $contact_default_type_id,
						'Country_Cont__c' => !empty($member->country_c)?$member->country_c:$member->country,
					),
				);
			if ($member->contact_sf_id)
			{
				$contact_data['contact']['cnt']['Id'] = $member->contact_sf_id;
			}
		}
		// from events-ori.php ends


		// from events-ori.php starts
		// finance
		$fname = !$row['name_last_f'] ? '' : $row['name_f'];
		$lname = !$row['name_last_f'] ? $row['name_f'] : $row['name_last_f'];
		$finance_full_name = $fname.' '.$lname;
		if ($primary_full_name <> $finance_full_name AND $secondary_full_name <> $finance_full_name AND $contact_full_name <> $finance_full_name)
		{
			$contact_data['finance'] = array(
					'cnt' => array(
						//'OwnerId' => '00590000000fN1L',
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['email_f'],
						'FirstName'	=> $fname,
						'LastName'	=> $lname,
						'Financial_contact_for_membership_fee__c' => TRUE,
						'Senior_representative_author_commitment__c' => (bool)($row['name_f'] == $row['contact_person']),
						'Title' 	=> $row['designation_f'],
						'Phone'	=> $row['telephone_f'], //$row['code_tel_f'] . ' ' . $row['telephone_f'],
						'Fax'	=> $row['fax_f'], //$row['code_fax_f'] . ' ' . $row['fax_f'],
						'RecordTypeId' => $contact_default_type_id,
						'Country_Cont__c' => !empty($member->country_f)?$member->country_f:$member->country,
					),
				);
			if ($member->finance_sf_id)
			{
				$contact_data['finance']['cnt']['Id'] = $member->finance_sf_id;
			}
		}
		// from events-ori.php ends


		$db_fields = array(
			'account' => 'account_sf_id',
			'application' => 'application_sf_id',
			'primary' => 'primary_sf_id',
			'secondary' => 'secondary_sf_id',
			'finance' => 'finance_sf_id',
			'contact' => 'contact_sf_id',
		);
		$cnt_result = array();
		if (!empty($acc_result['result']))
		{
			foreach($contact_data as $key => $val)
			{
				if ( !empty($member->$db_fields[$key]) )
				{
					$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): updating '.$db_fields[$key].': '.$member->$db_fields[$key] );
					$cnt_result[$key] = $client->call("updateContact", array('parameters'=>$val));
				}
				else
				{
					$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): creating '.$db_fields[$key].': '.$member->$db_fields[$key] );
					$cnt_result[$key] = $client->call("createContact", array('parameters'=>$val));
				}

				if ($client->fault)
				{
					$error 					= $client->getError();
					$edata['from'] 			= $email_from;//"membership@rspo.org";
					$edata['slug']			= 'sf-integration';
					$edata['to']			= $email_recipient;
					$edata['name']			= 'RSPO Membership';
					$edata['sf_status']		= 'Error';
					$edata['sf_message']	= 'Error pushing '.$key.' to SF<br />'.$error;
					$this->send_email($edata);
					$this->ci->oauth2_m->error_log('error', 'SF Client ('.$member->title.'): '.$db_fields[$key].': '.$error );
					$return_message[] = 'Contact ('.$key.') did not sync. ['.$error.']';
					//return false;
				}
				else
				{
					$return_message[] = 'SF: Contact ('.$key.': '.$cnt_result[$key]['result'].') sync\'ed successfully.';
					if ( empty($member->$db_fields[$key]) )
					{
						// update db:
						$this->ci->oauth2_m->save_member($member->intID, array($db_fields[$key]=>$cnt_result[$key]['result']));
					}
					$this->ci->oauth2_m->error_log('success', 'SF Client ('.$member->title.'): '.$db_fields[$key].': '.$cnt_result[$key]['result'] );
				}
			}
		}

		// tweak the results
		/** primary & secondary **/
		if ($primary_full_name == $secondary_full_name)
		{
			$cnt_result['secondary']['result'] = $cnt_result['primary']['result'];
		}

		/** primary & contact **/
		if ($primary_full_name == $contact_full_name)
		{
			$cnt_result['contact']['result'] = $cnt_result['primary']['result'];
		}

		/** primary & finance **/
		if ($primary_full_name == $finance_full_name)
		{
			$cnt_result['finance']['result'] = $cnt_result['primary']['result'];
		}

		/** secondary & contact **/
		if ($secondary_full_name == $contact_full_name)
		{
			$cnt_result['contact']['result'] = $cnt_result['secondary']['result'];
		}

		/** secondary & finance **/
		if ($secondary_full_name == $finance_full_name)
		{
			$cnt_result['finance']['result'] = $cnt_result['secondary']['result'];
		}

		/** contact & finance **/
		if ($contact_full_name == $finance_full_name)
		{
			$cnt_result['finance']['result'] = $cnt_result['contact']['result'];
		}

		$sf_types = array(
			'Ordinary Members'=>'Ordinary',
			'Affiliate Members'=>'Affiliate',
			'Affiliate Member'=>'Affiliate',
			'Supply Chain Associate'=>'Associate',
		);

		$old_types = array(
			'Ordinary Members', 'Affiliate Members', 'Affiliate Member', 'Supply Chain Associate'
		);

		// check and change old types
		if (in_array($member->type, $old_types) && !empty($sf_types[$member->type]))
		{
			$member_type = $sf_types[$member->type];
		}
		else
		{
			$member_type = $member->type;
		}


		$old_categories = array('Palm Oil Processors and Traders', 'Environmental and Conservation NGOs', 'Social and Developmental NGOs', 'Banks & Investors');

		$sf_categories = array(
			'Palm Oil Processors and Traders'=>'Palm Oil Processors and/or Traders',
			'Environmental and Conservation NGOs'=>'Environmental or Nature Conservation Organisations (Non Governmental Organisations)',
			'Social and Developmental NGOs'=>'Social or Development Organisations (Non Governmental Organisations)',
			'Banks & Investors'=>'Banks and Investors'
		);
		// check and change old categories
		if (in_array($member->category, $old_categories) && !empty($sf_categories[$member->category]))
		{
			$member_category = $sf_categories[$member->category];
		}
		else
		{
			$member_category = $member->category;
		}


		// process application
		$app_result = '';
		if ( !empty($cnt_result) && !empty($acc_result['result']) )
		{
			if ($member->parent_company=='sub')
			{
				$tmp_parent_company = unserialize($member->sub_company);
				$parent_company = $tmp_parent_company[1]['name'];
				$subsidiaries = '';
			}
			elseif ($member->parent_company=='yes')
			{
				$parent_company = $subsidiaries = '';
				$tmp_subsidiaries = unserialize($member->sub_company);
				if (!empty($tmp_subsidiaries))
				{
					$tmp_sub = array();
					foreach($tmp_subsidiaries as $ts)
					{
						$tmp_sub[] = html_entity_decode($ts['name']);
					}
					$subsidiaries = implode(', ', $tmp_sub);
				}
			}
			else
			{
				$parent_company = '';
				$subsidiaries = '';
			}

			if ($member->status == 'Call for Comment')
				$member_status='Call For Comment';
			elseif ($member->status == 'Approved')
				$member_status='Active';
			else
				$member_status = $member->status;

			$applied_date = date('Y-m-d', $member->applied_date);
			$application_data = array(
				'app' => array(
					//'OwnerId' => '00590000000fN1L',
					'Account__c'	=> $acc_result['result'],	// AccountId from account creation
					'Name'		=> !empty($member->title) ? stripslashes($member->title) : stripslashes($member->name),	 	// title
					'type__c'	=> $member_type, //$sf_types[$member->type], 	// type (ordinary members is ordinary at SF)
					'Sector__c'	=> $member_category, //$member->category,			// category
					'Sub_Sector__c' => $member->profession=='Select subcategory'?'':$member->profession,		// sub-category/profession
					'Business_Registration_Number__c' => $member->registration_number, 	// registration_number
					'Application_Contact__c' => !empty($cnt_result['contact']['result']) ? $cnt_result['contact']['result'] : '',			// ID of who made the application
					'Person_For_Membership_Fee_c__c' => $cnt_result['finance']['result'],	// ID for financial
					'Primary_Contact_Person_c__c' => '', 									// ID for primary contact
					'Primary_Representative__c' => $cnt_result['primary']['result'],		// ID for primary contact
					'Secondary_Representative__c' => $cnt_result['secondary']['result'],	// ID for secondary
					'Answer8__c' => html_entity_decode($row['q1']),				// Q1
					'Answer6__c' => html_entity_decode($row['q2']),				// Q2
					'Answer7__c' => html_entity_decode($row['q3']),				// Q3
					'Answer9__c' => html_entity_decode($row['q4']),				// Q4
					'Answer10__c' => $member->q_usage,						// q_usage
					'Comment_Fee_Reduction__c' => $member->production_area,
					'Status__c' 	=> $member_status, //$member->status=='Call for Comment'?'Call For Comment':$member->status,	// membership status
					'Email__c'		=> $member->email,
					'Primary_Market_Operation_Application_GIn__c' => $member->primary_market_ops == 'World' ? 'Rest of the World' : $member->primary_market_ops,
					'Other_Market_Operations_Application_GInf__c' => $member->other_market_ops,
					'Old_Name__c'	=> $member->name_a,				// person made the application
					'Other_Person_Designation__c' => $member->designation_a,		// designation
					'App_received_apply_date__c' => $applied_date,
					//'Received_c__c' => $submitted_date, // moved to below
					'URL_Membership__c' => 'http://www.rspo.org/members/'.$member->intID,	// member profile URL
					'CMS_IntID__c' => $member->intID,
					'Comment_a__c' => html_entity_decode($member->remarks),
					'Parent__c' => $parent_company,  // parent and subsidiaries
					'Subsidiary__c' => $subsidiaries, //$member->sub_company, // are now unlinked
					//'Fee_Euro__c' => $member->total_amount_due,
				),
			);

			if (!$member->applied_date)
			{
				$application_data['app']['Received_c__c'] = $submitted_date;
			}

			if ($member->application_sf_id)
			{
				$application_data['app']['Id'] = $member->application_sf_id;
				$app_result = $client->call("updateApplication", array('parameters'=>$application_data));
			}
			else
			{
				$application_data['app']['Account_Description__c'] = $member->profile;
				$app_result = $client->call("createApplication", array('parameters'=>$application_data));
			}

			if ($client->fault)
			{
				$error 					= $client->getError();
				$edata['from'] 			= $email_from;//"membership@rspo.org";
				$edata['slug']			= 'sf-integration';
				$edata['to']			= $email_recipient;
				$edata['name']			= 'RSPO Membership';
				$edata['sf_status']		= 'Error';
				$edata['sf_message']	= 'Error pushing '.$key.' to SF<br />'.$error;
				$this->send_email($edata);
				$this->ci->oauth2_m->error_log('error', 'SF Client ('.$member->title.'): Application update; '.$error );
				$return_message[] = 'Application update: '.$error;
				return false;
			}
			else
			{
				if ( empty($member->application_sf_id) )
				{
					if (!empty($member->application_sf_id) && !empty($app_result['result']) && $member->application_sf_id==$app_result['result'] )
					{
						$old_data = TRUE;
					}
					else
					{
						$old_data = FALSE;
					}

					$update_application = $this->ci->oauth2_m->save_member($member->intID,
						array(
							//'old_data'=> $old_data,
							'application_sf_id'=>$app_result['result'],
							'strModifyDate'=>$strModifyDate
						),
						$old_data
					);

					// update db:

					if ($update_application)
					{
						$this->ci->oauth2_m->error_log('success', 'SF Client ('.$member->title.'): application successfully synced' );
					}

				}
				else
				{
					$this->ci->oauth2_m->error_log('info', 'SF Client ('.$member->title.'): application successfully synced' );
				}

				$return_message[] = 'SF: Application sync\'ed successfully ('.$app_result['result'].').';
			}
		}
		else
		{
		}

		if (!empty($return_message) && empty($data['frontend']))
			$this->ci->session->set_flashdata('notice', implode("<br />", $return_message));
		$this->ci->oauth2_m->error_log('info', 'SF Client ('.$member->title.'): transaction ends' );

		return;
		//return true;
		//return $member->title . ' synced to SalesForce';
	}

	public function sf_push_with_email($data=array())
	{
		if (empty($data['id']))
		{
			return false;

		}

		$strModifyDate = date('Y-m-d', now());

		$this->ci->load->model('oauth2/oauth2_m');
		$this->ci->load->library('oauth2/my_nusoap');
		$this->ci->load->helper('file');


		$this->ci->oauth2_m->error_log('info', 'SF Client: transaction starts' );

		$fields = array(
			'grant_type'=>$this->grant_type,
			'client_id'=>$this->client_id,
			'client_secret'=>$this->client_secret,
			'username'=>$this->username,
			'password'=>$this->password,
		);

		$connect_result = $this->fetchURL($this->token_endpoint, $fields);

		$json = $json_user = '';
		if (!$connect_result)
		{
			$this->ci->oauth2_m->error_log('error', 'SF Client: failed to connect.');
			$edata['sf']			= $data;
			$edata['from'] 			= "membership@rspo.org";
			$edata['slug']			= 'sf-client-error';
			$edata['to']			= $this->input->post('email_a');
			$edata['email']			= $this->input->post('email_a');
			$edata['name']			= 'RSPO Membership';
			$edata['name_submitter']= $this->input->post('name_a');
?>
<pre>
$edata:
<? print_r($edata) ?>
</pre>
<?
exit;
			$this->send_email($edata);
			return false;
		}
		else
		{
echo "\$connect_result: $connect_result<br />\n";
			$json = json_decode($connect_result);

			if (!empty($json->error))
			{
echo "Error: ".$json->error_description."<br />";
					$edata['sf']			= $data;
					$edata['from'] 			= "membership@rspo.org";
					$edata['slug']			= 'sf-client-error';
					//$edata['to']			= $this->input->post('email_a');
					//$edata['email']			= $this->input->post('email_a');
					$edata['name']			= 'RSPO Membership';
					//$edata['name_submitter']= $this->input->post('name_a');
?>
<pre>
$edata:
<? print_r($edata) ?>
</pre>
<?
				$this->send_email($edata);
					$this->ci->oauth2_m->error_log('error', 'SF Client: '.!empty($json->error_description)?$json->error_description:'cannot login');
					return false;
			}
			else
			{
				$token = !empty($json->access_token) ? $json->access_token : NULL;
				$id = !empty($json->id) ? $json->id : NULL;
				$this->instance_url = $json->instance_url;
				$id = 'https://cs6.salesforce.com/services/Soap/c/27.0';
				$issued_at = date('d-m-Y H:i:s', $json->issued_at/1000);
				if (empty($token))
				{
					$edata['sf']			= $data;
					$edata['from'] 			= "membership@rspo.org";
					$edata['slug']			= 'sf-client-error';
					//$edata['to']			= $this->input->post('email_a');
					//$edata['email']			= $this->input->post('email_a');
					$edata['name']			= 'RSPO Membership';
					//$edata['name_submitter']= $this->input->post('name_a');
?>
<pre>
$edata:
<? print_r($edata) ?>
</pre>
<?
				$this->send_email($edata);
					$this->ci->oauth2_m->error_log('error', 'SF Client: '.!empty($json->error_description)?$json->error_description:'cannot login');
					return false;
				}
			}
exit;
			$this->ci->oauth2_m->error_log('success', 'SF Client: connected to SF.');
		}

		// client using nusoap
		if (!file_exists($_SERVER['DOCUMENT_ROOT'].'/'.ADDONPATH . 'modules/oauth2/libraries/inserter.xml'))
		{
			$this->ci->oauth2_m->error_log('error', 'SF Client: inserter.xml does not exist.');
			return false;
		}

		$wsdl_file = $_SERVER['DOCUMENT_ROOT'].'/'.ADDONPATH . 'modules/oauth2/libraries/inserter.xml';
		$client = new nusoap_client($wsdl_file, TRUE);
		$client->soap_defencoding = 'utf-8';
		$error  = $client->getError();

		if ($error)
		{
			$this->ci->oauth2_m->error_log('error', 'SF Client: ' . $error);
			return false;
		}

		$row = $data['input'];

		$header = 
		"<SessionHeader>
		  <sessionId>$token</sessionId>
		</SessionHeader>";
		$client->setHeaders($header);

		$member = $this->ci->oauth2_m->get_member($data['id']);

		// SF account fields
		$account_data = array(
			'acc' => array(
				'OwnerId' => '00590000000fN1L',
				'CMS_IntID__c' => $member->intID,
				'Name'		=> !empty($member->title) ? $member->title : $member->name,
				'Phone'		=> $row['code_telephone'] . ' ' . $row['telephone'],
				'ShippingStreet'	=> $row['address'], // SF: one field
				'ShippingCity'	=> $row['address_city'], // SF: one field
				'ShippingState'	=> $row['address_state'], // SF: one field
				'ShippingPostalCode'	=> $row['address_zip'], // SF: one field
				'ShippingCountry'	=> $row['country'], // SF: one field
				'Description'		=> $row['profile'],
				'Fax'		=> $row['code_fax'] . ' ' . $row['fax'],
				'Website'	=> $row['website'],
				'Type'		=> 'Membership Account',
				'Types__c'	=> 'Membership Account',
				'CurrencyIsoCode' => !empty($member->account_currency)?$member->account_currency:'EUR',
			),
		);

		/* ---------------------------------------*
			for live system, comment ob_start()!
		------------------------------------------*/
		//ob_start();

		$acc_result = array();

		if ($member->account_sf_id)
		{
			$account_data['acc']['Id'] = $member->account_sf_id;
			$acc_result = $client->call("updateAccount", array('parameters'=>$account_data));
		}
		else
		{
			$acc_result = $client->call("createAccount", array('parameters'=>$account_data));
		}

/* *
		echo "<pre>\n";
		echo "\n---\n\$acc_result:\n";
		print_r($acc_result);
		echo "</pre>\n";

if ($client->fault)
	echo "\$client-&gt;fault!<br />";
//exit;
/* */

		if ($client->fault)
		{
			$error = $client->getError();
			$this->ci->oauth2_m->error_log('error', 'SF Client ('.$member->title.'): ' . $error);
			return false;
		}
		else
		{
			//$this->ci->oauth2_m->error_log('success', 'SF Client: Account Id ('.$member->title.'): ' . (!empty($acc_result['result']) ? $acc_result['result'] : 'Account successfully synchronized'));
			// update member with account id from SF

			$account_sf_id = $member->account_sf_id;
			if (!empty($member->account_sf_id) && !empty($acc_result['result']) && $member->account_sf_id==$acc_result['result'] )
			{
				$old_data = TRUE;
			}
			else
			{
				$old_data = FALSE;
			}
			$update_account = $this->ci->oauth2_m->save_member($member->intID,
				array(
					//'old_data'=> $old_data,
					'account_sf_id'=>$acc_result['result'],
					'strModifyDate'=>$strModifyDate
				),
				$old_data
			);

			if ($update_account)
			{
				$message = 'SF Client Account Id ('.$member->title.'): account successfully synced';
				$this->ci->oauth2_m->error_log('success', $message );
			}
			else
			{
				$message = 'SF Client Account Id ('.$member->title.'): failed sync-ing account to SF';
				$this->ci->oauth2_m->error_log('error', $message );
				return false;
			}
		}

		//$contact_default_type_id = '012N000000090gfIAA';
		$contact_default_type_id = '01290000001AoetAAC';

		/* $fname = substr($row['name_p'], 0, stripos($row['name_p'], ' ', 1));
		$lname = substr($row['name_p'], stripos($row['name_p'], ' ', 1)+1, strlen($row['name_p']) );
		if (empty($fname) OR empty($lname))
		{
			$fname = $row['name_p'];
			$lname = '--';
		} /**/

		// primary
		$fpname = !$row['name_last_p'] ? '' : $row['name_p'];
		$lpname = !$row['name_last_p'] ? $row['name_p'] : $row['name_last_p'];
		$primary_full_name = $fpname.' '.$lpname;

		// secondary
		$fsname = !$row['name_last_s'] ? '' : $row['name_s'];
		$lsname = !$row['name_last_s'] ? $row['name_s'] : $row['name_last_s'];
		$secondary_full_name = $fsname.' '.$lsname;

		// contact person
		$fcname = !$row['contact_lname'] ? '' : $row['contact_person'];
		$lcname = !$row['contact_lname'] ? $row['contact_person'] : $row['contact_lname'];
		$contact_full_name = $fcname.' '.$lcname;

		// finance
		$ffname = !$row['name_last_f'] ? '' : $row['name_f'];
		$lfname = !$row['name_last_f'] ? $row['name_f'] : $row['name_last_f'];
		$finance_full_name = $ffname.' '.$lfname;

		// from events-ori.php starts
		$fname = !$row['name_last_p'] ? '' : $row['name_p'];
		$lname = !$row['name_last_p'] ? $row['name_p'] : $row['name_last_p'];
		$primary_full_name = $fname.' '.$lname;

		$contact_data['primary'] = array(
			'cnt' => array(
				'OwnerId' => '00590000000fN1L',
				'CMS_IntID__c' => $member->intID,
				'AccountId' => $acc_result['result'],
				'Email'		=> $row['email_p'],
				'FirstName'	=> $fname,
				'LastName'	=> $lname,
				'RecordTypeId' => $contact_default_type_id,
				'Primary_contact__c' => TRUE,
				'Financial_contact_for_membership_fee__c' => (bool)($row['name_p'] == $row['name_f']),
				'Senior_representative_author_commitment__c' => (bool)($row['name_p'] == $row['contact_person']),
				'Secondary_Nomination_Contact__c' => (bool)($row['name_p'] == $row['name_s']),
				'Title' 	=> $row['designation_p'],
				'Phone'	=> $row['telephone_p'], //$row['code_tel_p'] . ' ' . $row['telephone_p'],
				'Fax'	=> $row['fax_p'], //$row['code_fax_p'] . ' ' . $row['fax_p'],
				'Country_Cont__c' => !empty($member->country_p)?$member->country_p:$member->country,
			),
		);
		if ($member->primary_sf_id)
		{
			$contact_data['primary']['cnt']['Id'] = $member->primary_sf_id;
		}
		// from events-ori.php ends

/** DEBUG
echo "\$primary_full_name: $primary_full_name<br />\n";
echo "\$secondary_full_name: $secondary_full_name<br />\n";
echo "\$contact_full_name: $contact_full_name<br />\n";
echo "\$finance_full_name: $finance_full_name<br />\n";
echo "(\$primary_full_name == \$contact_full_name): " . ($primary_full_name == $contact_full_name ? 'Same' : 'Diff') . "<br />\n";
echo "(\$secondary_full_name == \$contact_full_name): " . ($secondary_full_name == $contact_full_name ? 'Same' : 'Diff') . "<br />\n";
/* */

/*
		$contact_data['primary'] = array(
			'cnt' => array(
				'OwnerId' => '00590000000fN1L',
				'CMS_IntID__c' => $member->intID,
				'AccountId' => $acc_result['result'],
				'Email'		=> $row['email_p'],
				'FirstName'	=> $fpname,
				'LastName'	=> $lpname,
				'RecordTypeId' => $contact_default_type_id,
				'Primary_contact__c' => TRUE,
				'Financial_contact_for_membership_fee__c' => (bool)($primary_full_name == $finance_full_name),
				'Senior_representative_author_commitment__c' => (bool)($primary_full_name == $contact_full_name),
				'Secondary_Nomination_Contact__c' => (bool)($primary_full_name == $secondary_full_name),
				'Title' 	=> $row['designation_p'],
				'Phone'	=> $row['telephone_p'], //$row['code_tel_p'] . ' ' . $row['telephone_p'],
				'Fax'	=> $row['fax_p'], //$row['code_fax_p'] . ' ' . $row['fax_p'],
				'Country_Cont__c' => !empty($member->country_p)?$member->country_p:$member->country,
			),
		);
		if ($member->primary_sf_id)
		{
			$contact_data['primary']['cnt']['Id'] = $member->primary_sf_id;
		}
*/

// DEBUG
/*
echo "<pre>\n";
echo "\$contact_data['primary']:\n";
var_dump($contact_data['primary']);
echo "</pre>\n";
*/


		// from events-ori.php starts
		// secondary
		$fname = !$row['name_last_s'] ? '' : $row['name_s'];
		$lname = !$row['name_last_s'] ? $row['name_s'] : $row['name_last_s'];
		$secondary_full_name = $fname.' '.$lname;
		if ($primary_full_name <> $secondary_full_name)
		{
			$contact_data['secondary'] = array(
					'cnt' => array(
						'OwnerId' => '00590000000fN1L',
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['email_s'],
						'FirstName'	=> $fname,
						'LastName'	=> $lname,
						'Title' 	=> $row['designation_s'],
						'Phone'	=> $row['telephone_s'], //$row['code_tel_s'] . ' ' . $row['telephone_s'],
						'Fax'	=> $row['fax_s'], //$row['code_fax_s'] . ' ' . $row['fax_s'],
						'RecordTypeId' => $contact_default_type_id,
						'Secondary_Nomination_Contact__c' => TRUE,
						'Country_Cont__c' => !empty($member->country_s)?$member->country_s:$member->country,
					),
				);
			if ($member->secondary_sf_id)
			{
				$contact_data['secondary']['cnt']['Id'] = $member->secondary_sf_id;
			}
		}
		// from events-ori.php ends

/*
		// secondary
		if ($primary_full_name <> $secondary_full_name && $primary_full_name && $secondary_full_name)
		{
			$contact_data['secondary'] = array(
					'cnt' => array(
						'OwnerId' => '00590000000fN1L',
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['email_s'],
						'FirstName'	=> $fsname,
						'LastName'	=> $lsname,
						'Title' 	=> $row['designation_s'],
						'Phone'	=> $row['telephone_s'], //$row['code_tel_s'] . ' ' . $row['telephone_s'],
						'Fax'	=> $row['fax_s'], //$row['code_fax_s'] . ' ' . $row['fax_s'],
						'RecordTypeId' => $contact_default_type_id,
						'Secondary_Nomination_Contact__c' => TRUE,
						'Country_Cont__c' => !empty($member->country_s)?$member->country_s:$member->country,
					),
				);
			if ($member->secondary_sf_id)
			{
				$contact_data['secondary']['cnt']['Id'] = $member->secondary_sf_id;
			}
		}
*/


		// from events-ori.php starts
		// contact person
		$fname = !$row['contact_lname'] ? '' : $row['contact_person'];
		$lname = !$row['contact_lname'] ? $row['contact_person'] : $row['contact_lname'];
		$contact_full_name = $fname.' '.$lname;
		if ($primary_full_name <> $contact_full_name AND $secondary_full_name <> $contact_full_name)
		{
			$contact_data['contact'] = array(
					'cnt' => array(
						'OwnerId' => '00590000000fN1L',
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['contact_email'],
						'FirstName'	=> $fname,
						'LastName'	=> $lname,
						'Senior_representative_author_commitment__c' => TRUE,
						'Title' 	=> $row['designation'],
						'Phone'	=> $row['contact_tel'], //$row['code_contact_tel'] . ' ' . $row['contact_tel'],
						'Fax'	=> $row['contact_fax'], //$row['code_contact_fax'] . ' ' . $row['contact_fax'],
						'RecordTypeId' => $contact_default_type_id,
						'Country_Cont__c' => !empty($member->country_c)?$member->country_c:$member->country,
					),
				);
			if ($member->contact_sf_id)
			{
				$contact_data['contact']['cnt']['Id'] = $member->contact_sf_id;
			}
		}
		// from events-ori.php ends

/*
		// contact person
		if ($primary_full_name <> $contact_full_name AND $secondary_full_name <> $contact_full_name)
		{
			$contact_data['contact'] = array(
					'cnt' => array(
						'OwnerId' => '00590000000fN1L',
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['contact_email'],
						'FirstName'	=> $fcname,
						'LastName'	=> $lcname,
						'Senior_representative_author_commitment__c' => TRUE,
						'Title' 	=> $row['designation'],
						'Phone'	=> $row['contact_tel'], //$row['code_contact_tel'] . ' ' . $row['contact_tel'],
						'Fax'	=> $row['contact_fax'], //$row['code_contact_fax'] . ' ' . $row['contact_fax'],
						'RecordTypeId' => $contact_default_type_id,
						'Country_Cont__c' => !empty($member->country_c)?$member->country_c:$member->country,
					),
				);
			if ($member->contact_sf_id)
			{
				$contact_data['contact']['cnt']['Id'] = $member->contact_sf_id;
			}
		}
*/

		// from events-ori.php starts
		// finance
		$fname = !$row['name_last_f'] ? '' : $row['name_f'];
		$lname = !$row['name_last_f'] ? $row['name_f'] : $row['name_last_f'];
		$finance_full_name = $fname.' '.$lname;
		if ($primary_full_name <> $finance_full_name AND $secondary_full_name <> $finance_full_name AND $contact_full_name <> $finance_full_name)
		{
			$contact_data['finance'] = array(
					'cnt' => array(
						'OwnerId' => '00590000000fN1L',
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['email_f'],
						'FirstName'	=> $fname,
						'LastName'	=> $lname,
						'Financial_contact_for_membership_fee__c' => TRUE,
						'Senior_representative_author_commitment__c' => (bool)($row['name_f'] == $row['contact_person']),
						'Title' 	=> $row['designation_f'],
						'Phone'	=> $row['telephone_f'], //$row['code_tel_f'] . ' ' . $row['telephone_f'],
						'Fax'	=> $row['fax_f'], //$row['code_fax_f'] . ' ' . $row['fax_f'],
						'RecordTypeId' => $contact_default_type_id,
						'Country_Cont__c' => !empty($member->country_f)?$member->country_f:$member->country,
					),
				);
			if ($member->finance_sf_id)
			{
				$contact_data['finance']['cnt']['Id'] = $member->finance_sf_id;
			}
		}

		// from events-ori.php ends

/*
		// finance
		if ($primary_full_name <> $finance_full_name AND $secondary_full_name <> $finance_full_name AND $contact_full_name <> $finance_full_name)
		{
			$contact_data['finance'] = array(
					'cnt' => array(
						'OwnerId' => '00590000000fN1L',
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['email_f'],
						'FirstName'	=> $ffname,
						'LastName'	=> $lfname,
						'Financial_contact_for_membership_fee__c' => TRUE,
						'Senior_representative_author_commitment__c' => (bool)($finance_full_name == $contact_full_name),
						//'Senior_representative_author_commitment__c' => TRUE,
						'Title' 	=> $row['designation_f'],
						'Phone'	=> $row['telephone_f'], //$row['code_tel_f'] . ' ' . $row['telephone_f'],
						'Fax'	=> $row['fax_f'], //$row['code_fax_f'] . ' ' . $row['fax_f'],
						'RecordTypeId' => $contact_default_type_id,
						'Country_Cont__c' => !empty($member->country_f)?$member->country_f:$member->country,
					),
				);
			if ($member->finance_sf_id)
			{
				$contact_data['finance']['cnt']['Id'] = $member->finance_sf_id;
			}
		}
*/

/* DEBUG *
echo "<pre>\n";
echo "\$contact_data\n";
//var_dump($contact_data);
//echo "<hr />";
//echo "print_r:\n";
print_r($contact_data);
echo "</pre>\n";
//exit;
/* */

		$db_fields = array(
			'account' => 'account_sf_id',
			'application' => 'application_sf_id',
			'primary' => 'primary_sf_id',
			'secondary' => 'secondary_sf_id',
			'finance' => 'finance_sf_id',
			'contact' => 'contact_sf_id',
		);
		$cnt_result = array();
		if (!empty($acc_result['result']))
		{
			foreach($contact_data as $key => $val)
			{
				if ( !empty($member->$db_fields[$key]) )
				{
					$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): updating '.$db_fields[$key].': '.$member->$db_fields[$key] );
					$cnt_result[$key] = $client->call("updateContact", array('parameters'=>$val));
				}
				else
				{
					$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): creating '.$db_fields[$key].': '.$member->$db_fields[$key] );
					$cnt_result[$key] = $client->call("createContact", array('parameters'=>$val));
				}

/* *
		echo "<pre>\n";
		echo "\$key: $key\n";
		echo "\n---\n\$cnt_result:\n";
		print_r($cnt_result);
		echo "</pre>\n";

if ($client->fault)
	echo "\$client-&gt;fault!<br />";
//exit;
/* */

				if ($client->fault)
				{
					$this->ci->oauth2_m->error_log('error', 'SF Client ('.$member->title.'): '.$db_fields[$key].': '.$client->getError() );
					$this->ci->session->set_flashdata('error', 'Error pushing '.$key.' to SF');
					return false;
				}
				else
				{
					if ( empty($member->$db_fields[$key]) )
					{
						// update db:
						$this->ci->oauth2_m->save_member($member->intID, array($db_fields[$key]=>$cnt_result[$key]['result']));
					}
					$this->ci->oauth2_m->error_log('success', 'SF Client ('.$member->title.'): '.$db_fields[$key].': '.$cnt_result[$key]['result'] );
				}
			}
		}

/*
echo "<pre>\n";
echo "\$key: $key\n";
echo "\n---\n\$cnt_result:\n";
print_r($cnt_result);
echo "</pre>\n";

echo "\$primary_full_name: $primary_full_name<br />\n";
echo "\$secondary_full_name: $secondary_full_name<br />\n";
echo "\$contact_full_name: $contact_full_name<br />\n";
echo "\$finance_full_name: $finance_full_name<br />\n";
*/

		// tweak the results
		/** primary & secondary **/
		if ($primary_full_name == $secondary_full_name)
		{
			$cnt_result['secondary']['result'] = $cnt_result['primary']['result'];
		}

		/** primary & contact **/
		if ($primary_full_name == $contact_full_name)
		{
			$cnt_result['contact']['result'] = $cnt_result['primary']['result'];
		}

		/** primary & finance **/
		if ($primary_full_name == $finance_full_name)
		{
			$cnt_result['finance']['result'] = $cnt_result['primary']['result'];
		}

		/** secondary & contact **/
		if ($secondary_full_name == $contact_full_name)
		{
			$cnt_result['contact']['result'] = $cnt_result['secondary']['result'];
		}

		/** secondary & finance **/
		if ($secondary_full_name == $finance_full_name)
		{
			$cnt_result['finance']['result'] = $cnt_result['secondary']['result'];
		}

		/** contact & finance **/
		if ($contact_full_name == $finance_full_name)
		{
			$cnt_result['finance']['result'] = $cnt_result['contact']['result'];
		}

		$sf_types = array(
			'Ordinary Members'=>'Ordinary',
			'Affiliate Members'=>'Affiliate',
			'Affiliate Member'=>'Affiliate',
			'Supply Chain Associate'=>'Associate',
		);

		$old_types = array(
			'Ordinary Members', 'Affiliate Members', 'Affiliate Member', 'Supply Chain Associate'
		);

		// check and change old types
		if (in_array($member->type, $old_types) && !empty($sf_types[$member->type]))
		{
			$member_type = $sf_types[$member->type];
		}
		else
		{
			$member_type = $member->type;
		}


		$old_categories = array('Palm Oil Processors and Traders', 'Environmental and Conservation NGOs', 'Social and Developmental NGOs', 'Banks & Investors');

		$sf_categories = array(
			'Palm Oil Processors and Traders'=>'Palm Oil Processors and/or Traders',
			'Environmental and Conservation NGOs'=>'Environmental or Nature Conservation Organisations (Non Governmental Organisations)',
			'Social and Developmental NGOs'=>'Social or Development Organisations (Non Governmental Organisations)',
			'Banks & Investors'=>'Banks and Investors'
		);
		// check and change old categories
		if (in_array($member->category, $old_categories) && !empty($sf_categories[$member->category]))
		{
			$member_category = $sf_categories[$member->category];
		}
		else
		{
			$member_category = $member->category;
		}

/*
echo "<pre>\n";
echo "\$key: $key\n";
echo "\n---\n\$cnt_result:\n";
print_r($cnt_result);
echo "</pre>\n";
exit;
*/
		// process application
		$app_result = '';
		if ( !empty($cnt_result) && !empty($acc_result['result']) )
		{
			if ($member->parent_company=='sub')
			{
				$tmp_parent_company = unserialize($member->sub_company);
/* *
echo "<pre>\n";
echo "\$tmp_parent_company\n";
print_r($tmp_parent_company);
echo "</pre>\n";
exit;
/* */
				$parent_company = $tmp_parent_company[1]['name'];
				$subsidiaries = '';
			}
			elseif ($member->parent_company=='yes')
			{
				$parent_company = '';
				$tmp_subsidiaries = unserialize($member->sub_company);
				foreach($tmp_subsidiaries as $ts)
				{
					$tmp_sub[] = $ts['name'];
				}
				$subsidiaries = implode(', ', $tmp_sub);
			}
			else
			{
				$parent_company = '';
				$subsidiaries = '';
			}

			$submitted_date = date('Y-m-d', now());
			$application_data = array(
				'app' => array(
					'OwnerId' => '00590000000fN1L',
					'Account__c'	=> $acc_result['result'],	// AccountId from account creation
					'Name'		=> !empty($member->title) ? $member->title : $member->name,	 	// title
					'type__c'	=> $member_type, //$sf_types[$member->type], 	// type (ordinary members is ordinary at SF)
					'Sector__c'	=> $member_category, //$member->category,			// category
					'Sub_Sector__c' => $member->profession=='Select subcategory'?'':$member->profession,		// sub-category/profession
					'Business_Registration_Number__c' => $member->registration_number, 	// registration_number
					'Application_Contact__c' => !empty($cnt_result['contact']['result']) ? $cnt_result['contact']['result'] : '',			// ID of who made the application
					'Person_For_Membership_Fee_c__c' => $cnt_result['finance']['result'],	// ID for financial
					'Primary_Contact_Person_c__c' => '', 									// ID for primary contact
					'Primary_Representative__c' => $cnt_result['primary']['result'],		// ID for primary contact
					'Secondary_Representative__c' => $cnt_result['secondary']['result'],	// ID for secondary
					'Answer8__c' => $row['q1'],				// Q1
					'Answer6__c' => $row['q2'],				// Q2
					'Answer7__c' => $row['q3'],				// Q3
					'Answer9__c' => $row['q4'],				// Q4
					'Answer10__c' => $member->q_usage,						// q_usage
					'Comment_Fee_Reduction__c' => $member->production_area,
					'Status__c' 	=> $member->status=='Call for Comment'?'Call For Comment':$member->status,	// membership status
					'Email__c'		=> $member->email,
					'Primary_Market_Operation_Application_GIn__c' => $member->primary_market_ops == 'World' ? 'Rest of the World' : $member->primary_market_ops,
					'Other_Market_Operations_Application_GInf__c' => $member->other_market_ops,
					'Old_Name__c'	=> $member->name_a,				// person made the application
					'Other_Person_Designation__c' => $member->designation_a,		// designation
					//'App_received_apply_date__c' => '', //$submitted_date,
					//'Received_c__c' => $submitted_date, // moved to below
					'URL_Membership__c' => 'http://www.rspo.org/members/'.$member->intID,	// member profile URL
					'CMS_IntID__c' => $member->intID,
					'Comment_a__c' => $member->remarks,
					'Parent__c' => $parent_company,  // parent and subsidiaries
					'Subsidiary__c' => $subsidiaries, //$member->sub_company, // are now unlinked
					//'Fee_Euro__c' => $member->total_amount_due,
				),
			);

			if (!$member->applied_date)
			{
				$application_data['app']['Received_c__c'] = $submitted_date;
			}

			if ($member->application_sf_id)
			{
				$application_data['app']['Id'] = $member->application_sf_id;
				$app_result = $client->call("updateApplication", array('parameters'=>$application_data));
			}
			else
			{
				$application_data['app']['Account_Description__c'] = $member->profile;
				$app_result = $client->call("createApplication", array('parameters'=>$application_data));
			}

/* *
		echo "<pre>\n";
		echo "\n---\n\$app_result:\n";
		print_r($app_result);
		echo "</pre>\n";

if ($client->fault)
	echo "\$client-&gt;fault!<br />";
//exit;
/* */

			if ($client->fault)
			{
				$this->ci->oauth2_m->error_log('error', 'SF Client ('.$member->title.'): Application update; '.$client->getError() );
				return false;
			}
			else
			{
				if ( empty($member->application_sf_id) )
				{
					if (!empty($member->application_sf_id) && !empty($app_result['result']) && $member->application_sf_id==$app_result['result'] )
					{
						$old_data = TRUE;
					}
					else
					{
						$old_data = FALSE;
					}

					$update_application = $this->ci->oauth2_m->save_member($member->intID,
						array(
							//'old_data'=> $old_data,
							'application_sf_id'=>$app_result['result'],
							'strModifyDate'=>$strModifyDate
						),
						$old_data
					);

					// update db:

					if ($update_application)
						$this->ci->oauth2_m->error_log('success', 'SF Client ('.$member->title.'): application successfully synced' );

				}
				else
				{
					$this->ci->oauth2_m->error_log('info', 'SF Client ('.$member->title.'): application successfully synced' );
				}
			}
		}
		else
		{
		}

		$this->ci->oauth2_m->error_log('info', 'SF Client ('.$member->title.'): transaction ends' );

/* *
		echo "<pre>\n";
		echo "\n---\n\$connect_result:\n";
		print_r($connect_result);
		echo "\n---\n\$acc_result:\n";
		print_r($acc_result);
		echo "\n---\n\$cnt_result:\n";
		print_r($cnt_result);
		echo "\n---\n\$contact_data:\n";
		print_r($contact_data);
		echo "\n---\n\$app_result:\n";
		print_r($app_result);
		echo "</pre>\n";
/* */
		//$ret = ob_get_contents();

//echo "From events.php:<br />\n";
//echo $ret;
//exit;

		//return 'Return from events: ' . $ret;

		return $member->title . ' synced to SalesForce';
	}

	function push_files($data=array())
	{
		$this->ci->load->model('oauth2/oauth2_m');

		$this->ci->oauth2_m->error_log('info', 'SF Client: transaction starts' );

		$fields = array(
			'grant_type'=>$this->grant_type,
			'client_id'=>$this->client_id,
			'client_secret'=>$this->client_secret,
			'username'=>$this->username,
			'password'=>$this->password,
		);

		$connect_result = $this->fetchURL($this->token_endpoint, $fields);

		$json = $json_user = '';
		if (!$connect_result)
		{
			$this->ci->oauth2_m->error_log('error', 'SF Client: failed to connect.');
			return false;
		}
		else
		{
			$json = json_decode($connect_result);
			$token = $json->access_token;
			$id = $json->id;
			$instance_url = trim($json->instance_url);
			$id = 'https://cs6.salesforce.com/services/Soap/c/27.0';
			$issued_at = date('d-m-Y H:i:s', $json->issued_at/1000);
			if (empty($token))
			{
				$this->ci->oauth2_m->error_log('error', 'SF Client: '.!empty($json->error_description)?$json->error_description:'cannot login');
				return false;
			}
			$this->ci->oauth2_m->error_log('success', 'SF Client: connected to SF.');
		}

		//if (!$this->instance_url or !$data['input']) return false;

		$file_fields = array(
			'logo' => 'Member logo',
			'file' => 'Statement',
			'file_certificates' => 'RSPO Agreement',
			'file_additionals' => 'Additional information including KML/KMZ files',
			'file_sh_group_manager' => 'Proof of appointment',
			'file_sc_group_manager' => '',
			
			//New supporting docs (KY:2/5/18)
			'opg_sg_business_registration' => 'Business Registration - Small Growers',
			'opg_sg_principles_criteria' => 'PnC Plans',
			'opg_sg_disclosure_cleared_area' => 'Disclosure of Areas Cleared - Small Growers',
			'opg_sg_estate_location' => 'Estate and Concession Maps',
			'opg_sm_business_registration' => 'Business Registration - Smallholders',
			'opg_sm_disclosure_cleared_area' => 'Disclosure of Areas Cleared - Smallholders',
			'opg_sm_sg_agreed' => 'SH Appointment Agreement',
			'opg_sm_gm_statement' => 'SH Group Representation',
			'opg_sm_sg_list' => 'SH Group Member List',
			'opg_sm_names_reff' => 'References - Smallholders',
			'sector_business_registration' => 'Business Registration',
			'sca_business_registration' => 'Business Registration - SCA',
			'sca_agreement' => 'Agreement - SCA',
			'scgm_business_registration' => 'Business Registration - SCGM',
			'scgm_agreement' => 'Agreement - SCGM',
			'scgm_names_reff' => 'References - SCGM',
			'affiliate_business_registration' => 'Business Registration - Affiliates',
		);

		$file_names = array(
			'logo' => 'Logo_',
			'file' => 'Statement_',
			'file_certificates' => 'COI_',
			'file_additionals' => 'Additionals_',
			'file_sh_group_manager' => 'SHGM_Appointment_',
			'file_sc_group_manager' => 'SCGM_Manager_',
			
			//New supporting docs (KY:2/5/18)
			'opg_sg_business_registration' => 'Business_Registration_Small_Growers',
			'opg_sg_principles_criteria' => 'PnC_Plans',
			'opg_sg_disclosure_cleared_area' => 'Disclosure_of_Areas_Cleared_Small_Growers',
			'opg_sg_estate_location' => 'Estate_and_Concession_Maps',
			'opg_sm_business_registration' => 'Business_Registration_Smallholders',
			'opg_sm_disclosure_cleared_area' => 'Disclosure_of_Areas_Cleared_Smallholders',
			'opg_sm_sg_agreed' => 'SH_Appointment_Agreement',
			'opg_sm_gm_statement' => 'SH_Group_Representation',
			'opg_sm_sg_list' => 'SH_Group_Member_List',
			'opg_sm_names_reff' => 'References_Smallholders',
			'sector_business_registration' => 'Business_Registration',
			'sca_business_registration' => 'Business_Registration_SCA',
			'sca_agreement' => 'Agreement_SCA',
			'scgm_business_registration' => 'Business_Registration_SCGM',
			'scgm_agreement' => 'Agreement_SCGM',
			'scgm_names_reff' => 'References_SCGM',
			'affiliate_business_registration' => 'Business_Registration_Affiliates',
		);

		$files = array();
		$end_point = $instance_url.'/services/data/v30.0/sobjects/Attachment/';

		foreach($data['input'] as $k=>$d)
		{
			if ( array_key_exists($k, $file_fields) )
			{
				if ($k!='application_sf_id')
				{
					$file_db = explode(',', $d);
					if (count($file_db)>1)
						$num = 1;
					else
						$num = 0;
					foreach($file_db as $fdb)
					{
						$file_to_read = $_SERVER['DOCUMENT_ROOT'].'/'.UPLOAD_PATH . 'memberlogos/'.$fdb;
						// read the file
						//if (TRUE)
						if (file_exists($file_to_read) && !is_dir($file_to_read))
						{
							$ext = strtolower(substr(strrchr($fdb, "."), 1));
							$body = $this->encode_file($file_to_read);
							$body_length = strlen($body);
							if (count($file_db)>1)
							{
								$sf_file_name = $file_names[$k].url_title($data['member_name'], 'underscore').'_'.$num.'.'.$ext;
								$sf_file_name = $file_names[$k].'_'.(str_ireplace('.'.$ext, '', $fdb)).$num.'.'.$ext;
							}
							else
							{
								$sf_file_name = $file_names[$k].url_title($data['member_name'], 'underscore').'.'.$ext;
								$sf_file_name = $file_names[$k].'_'.$fdb;
							}

							$files = array(
								//'CMS_IntID__c'	=> $data['id'],
								'ParentId'		=> $data['input']['application_sf_id'],
								//'BodyLength'	=> $body_length,
								'Body'			=> $body, //substr($body, 0, 200),
								//'ContentType'	=> $this->ci->get_mime_by_extension($fdb),
								'ContentType'	=> get_mime_by_extension($fdb),
								'Description'	=> $file_fields[$k],
								'Name'			=> $sf_file_name,
							);

							$result = $this->fetchFILE($end_point, $files, $token);
							$res = json_decode($result);
							//"id":"00PN0000001zxAoMAI","success":true,"errors":[]

							if (!empty($res->id))
							{
								$log = ' SF Client ('.$data['member_name'].'): File "'.$fdb.'" synced to SF as '.$sf_file_name.'; ID: '.$res->id;
								$this->ci->oauth2_m->error_log('success', $log);

								// update member db
								if ($k=='file')
								{
									$input = array($k.'_sf_id' => $res->id);
									$this->ci->oauth2_m->save_member($data['id'], $input);
								}
								// save_member($id, $input)
								// $input = array($k.'_sf_id' => $res->id);
								// $this->ci->oauth2_m->save_member($data['id'], $input);
								
							}
							elseif (!$res->success)
							{
								$log = ' SF Client ('.$data['member_name'].'): Failed pushing file "'.$fdb.'" to SF';
								$this->ci->oauth2_m->error_log('error', $log);
							}

							$num++;
						}
					}
				}
			}
		}

	}

	function push_comment($data=array())
	{
		// SF CfC fields
		$comment_data = array(
			'appComment' => array(
				'ID'				=> $data['id'],
				'OwnerId'			=> '00590000000fN1L',
				'CMS_CommentID__c'	=> $data['id'],
				'Application__c'	=> $data['input']['application_sf_id'],
				'Member_Name__c'	=> $data['input']['name'],
				'Member_Company__c'	=> $data['input']['company'],
				'Member_Designation__c'	=> $data['input']['designation'],
				'Member_Address__c'	=> $data['input']['address'],
				'Member_Country__c'	=> $data['input']['country'],
				'Member_Email__c'	=> $data['input']['email'],
				'Member_Phone__c'	=> $data['input']['telephone'],
				'Member_Comments__c'=> $data['input']['comment'],
				'Comment_Date__c'	=> $data['input']['date'],
			),
		);

		if (empty($data['id']))
		{
			return false;

		}
		$this->ci->load->model('oauth2/oauth2_m');
		$this->ci->load->library('oauth2/my_nusoap');

		$this->ci->oauth2_m->error_log('info', 'SF Client CfC: transaction starts' );

		$fields = array(
			'grant_type'=>$this->grant_type,
			'client_id'=>$this->client_id,
			'client_secret'=>$this->client_secret,
			'username'=>$this->username,
			'password'=>$this->password,
		);

		$connect_result = $this->fetchURL($this->token_endpoint, $fields);

		$json = $json_user = '';
		if (!$connect_result)
		{
			$this->ci->oauth2_m->error_log('error', 'SF Client: failed to connect.');
			return false;
		}
		else
		{
			$json = json_decode($connect_result);
			$token = $json->access_token;
			$id = $json->id;
			$id = 'https://cs6.salesforce.com/services/Soap/c/27.0';
			$issued_at = date('d-m-Y H:i:s', $json->issued_at/1000);
			if (empty($token))
			{
				$this->ci->oauth2_m->error_log('error', 'SF Client CfC: '.!empty($json->error_description)?$json->error_description:'cannot login');
				return false;
			}
			$this->ci->oauth2_m->error_log('success', 'SF Client CfC: connected to SF.');
		}

		// client using nusoap
		$wsdl_file = $_SERVER['DOCUMENT_ROOT'].'/'.ADDONPATH . 'modules/oauth2/libraries/inserter.xml';
		$client = new nusoap_client($wsdl_file, TRUE);
		$client->soap_defencoding = 'utf-8';
		$error  = $client->getError();

		if ($error)
		{
			$this->ci->oauth2_m->error_log('error', 'SF Client CfC: ' . $error);
			return false;
		}

		$row = $data['input'];

		$header = 
		"<SessionHeader>
		  <sessionId>$token</sessionId>
		</SessionHeader>";
		$client->setHeaders($header);

		// SF CfC fields
		$comment_data = array(
			'appComment' => array(
				'ID'				=> $data['id'],
				'OwnerId'			=> '00590000000fN1L',
				'CMS_CommentID__c'	=> $data['id'],
				'Application__c'	=> $data['input']['application_sf_id'],
				'Member_Name__c'	=> $data['input']['name'],
				'Member_Company__c'	=> $data['input']['company'],
				'Member_Designation__c'	=> $data['input']['designation'],
				'Member_Address__c'	=> $data['input']['address'],
				'Member_Country__c'	=> $data['input']['country'],
				'Member_Email__c'	=> $data['input']['email'],
				'Member_Phone__c'	=> $data['input']['telephone'],
				'Member_Comments__c'=> $data['input']['comment'],
				'Comment_Date__c'	=> $data['input']['date'],
			),
		);

		$comment_result = NULL;

		if ($data['input']['application_sf_id'])
		{
			$comment_result = $client->call("createApplicationComment", array('parameters'=>$comment_data));
		}
		else
		{
			return false;
		}

		if ($client->fault)
		{
			$error = $client->getError();
			$this->ci->oauth2_m->error_log('error', 'SF Client CfC: ' . $error);
			return false;
		}
		else
		{
			$this->ci->oauth2_m->error_log('success', 'SF Client CfC: Comment Id: ' . (!empty($comment_result['result']) ? $comment_result['result'] : 'Comment successfully synchronized'));
			// update member with account id from SF
			return $this->ci->oauth2_m->save_comment($data['id'], array('comments_sf_id'=>$comment_result['result']));
		}
	}


	public function push_all($data=array())
	{
		$member_push_data = array(
			'id' => $data['id'],
			'input' => (array) $data['member'],
		);

		$this->sf_push($member_push_data);
		// let it sleep for 5 seconds..
		sleep(5);
		$this->gm_push($data);
	}

	public function gm_push($data=array())
	{
		$sf_owner_id = '00590000003BhoAAAS';

		$email_recipient	= 'hl.kuah@rspo.org';
//		$email_recipient	= 'okky.sari@gmail.com';
//		$email_recipient	= 'koyanyaroo@gmail.com';
//		$email_from			= 'rspo@rspo.catalyze.id';

		if (empty($data))
		{
			return false;
		}

/* *
echo "<pre>\n";
echo "\$data\n\n";
print_r($data);
exit;
/* */

		$strModifyDate = date('Y-m-d', now());

		$this->ci->load->model('oauth2/oauth2_m');
		$this->ci->load->library('oauth2/my_nusoap');
		$this->ci->load->helper('file');



		// check whether member already has application_sf_id
		if (empty($data['member']['application_sf_id']))
		{
			// let's check the database first
			// it's possible that they click the 'Push both to SF' button
			$tmp_member = $this->ci->oauth2_m->get_member($data['id']);

			if (empty($tmp_member->application_sf_id))
			{
				// we need to push the parent first
				$member_push_data = array(
					'id' => $data['id'],
					'input' => (array) $data['member'],
				);
				if (!$this->sf_push($member_push_data))
				{
					$this->ci->session->set_flashdata('notice', 'Failed synchronising parent member');
					$this->ci->oauth2_m->error_log('error', 'SF Client: synchronising parent failed ('.$data['member']['title'].')' );
					return false;
				}

				// let it sleep for 5 seconds..
				//sleep(30);
			}
		}

		// variables for email notification
		// - sf_date		date
		// - member_id		member's intID
		// - member			member's name
		// - sf_status		status (probably always error)
		// - sf_message		custom message (can be SF error message?)
		$edata['sf_date'] 	= date('d-M-Y H:i', now());
		$edata['member_id'] = $data['id'];
		$edata['member'] 	= $data['member']['title'];

		$this->ci->oauth2_m->error_log('info', 'SF Client GM: transaction starts' );

		$fields = array(
			'grant_type'=>$this->grant_type,
			'client_id'=>$this->client_id,
			'client_secret'=>$this->client_secret,
			'username'=>$this->username,
			'password'=>$this->password,
		);

		$connect_result = $this->fetchURL($this->token_endpoint, $fields);

/*
		if (!$this->connected)
		{
			$connect_result = $this->fetchURL($this->token_endpoint, $fields);
			$this->connect_result = $connect_result;
		}
		else
		{
			$connect_result = $this->connect_result;
		}
*/

/* *
echo "<pre>\n";
echo "\$connect_result (gm_push):"."<br />\n";
print_r($connect_result);
echo "</pre>\n";
//exit;
/* */

		$json = $json_user = '';
		if (!$connect_result)
		{
			$edata['sf']			= $data;
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= 'SF Client: failed to connect.';

			$this->send_email($edata);
			$this->ci->oauth2_m->error_log('error', 'SF Client: failed to connect.');
			if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: Failed connecting to SF');
			return false;
		}
		else
		{
			$json = json_decode($connect_result);

			if (!empty($json->error))
			{
					$edata['sf']			= $data;
					$edata['from'] 			= $email_from;//"membership@rspo.org";
					$edata['slug']			= 'sf-integration';
					$edata['to']			= $email_recipient;
					$edata['name']			= 'RSPO Membership';
					$edata['sf_status']		= 'Error';
					$edata['sf_message']	= !empty($json->error_description)?$json->error_description:'cannot login';
					$this->send_email($edata);
					$this->ci->oauth2_m->error_log('error', 'SF Client: '.!empty($json->error_description)?$json->error_description:'cannot login');
					if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: '.!empty($json->error_description)?$json->error_description:'cannot login');
					return false;
			}
			else
			{
				$token = !empty($json->access_token) ? $json->access_token : NULL;
				$id = !empty($json->id) ? $json->id : NULL;
				$this->instance_url = $json->instance_url;
				$id = 'https://cs31.salesforce.com/services/Soap/c/27.0';
				$issued_at = date('d-m-Y H:i:s', $json->issued_at/1000);
				if (empty($token))
				{
					$edata['from'] 			= $email_from;//"membership@rspo.org";
					$edata['slug']			= 'sf-integration';
					$edata['to']			= $email_recipient;
					$edata['name']			= 'RSPO Membership';
					$edata['sf_status']		= 'Error';
					$edata['sf_message']	= !empty($json->error_description)?$json->error_description:'cannot login';
					$this->send_email($edata);
					$this->ci->oauth2_m->error_log('error', 'SF Client: '.!empty($json->error_description)?$json->error_description:'cannot login');
					if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: '.!empty($json->error_description)?$json->error_description:'cannot login');
					return false;
				}
			}
			$this->ci->oauth2_m->error_log('success', 'SF Client: connected to SF.');
			$this->connected = true;
		}

		$wsdl_file = $_SERVER['DOCUMENT_ROOT'].'/'.ADDONPATH . 'modules/oauth2/libraries/GroupMemberSoap_production.xml';

		// client using nusoap
		if (!file_exists($wsdl_file))
		{
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= 'Could not find file GroupMemberSoap_production.xml.';
			$this->send_email($edata);
			$this->ci->oauth2_m->error_log('error', 'SF Client: GroupMemberSoap_production.xml does not exist.');
			if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: could not find GroupMemberSoap_production.xml file');
			return false;
		}

		$client = new nusoap_client($wsdl_file, TRUE);
		$client->soap_defencoding = 'utf-8';
		$client->debugLevel = 0;

		$error  = $client->getError();

		if ($error)
		{
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= $error;
			$this->send_email($edata);
			$this->ci->oauth2_m->error_log('error', 'SF Client: ' . $error);
			if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: error setting up SF client.<br />'.$error);
			return false;
		}

		$row = $data['subsidiaries'];


		$header = "<SessionHeader><sessionId>$token</sessionId></SessionHeader>";
		$client->setHeaders($header);

//echo "\$header: $header<br />";
//exit;

		$member = $this->ci->oauth2_m->get_member($data['id']);

		// let's check if application_sf_id is there already (it should)
		if (empty($data['member']['application_sf_id']) && !empty($member->application_sf_id))
		{
			$data['member']['application_sf_id'] = $member->application_sf_id;
		}
		elseif ($this->member_application_sf_id)
		{
			$data['member']['application_sf_id'] = $this->member_application_sf_id;
		}

		// let's check if account_sf_id is there already (it should)
		if (empty($data['member']['account_sf_id']) && !empty($member->account_sf_id))
		{
			$data['member']['account_sf_id'] = $member->account_sf_id;
		}
		elseif ($this->member_account_sf_id)
		{
			$data['member']['account_sf_id'] = $this->member_account_sf_id;
		}

/* *
echo "<pre>\n";

echo "\$member (from db):\n";
print_r($member);

echo "<hr />\n";

echo "\$gm_data:\n";
echo "\$data['member']['application_sf_id']: ".$data['member']['application_sf_id']."\n\n";

echo "<hr />\n\n";

echo "\$data['subsidiaries']:\n";
print_r($data['subsidiaries']);

echo "</pre>\n";
exit;
/* */


		// first, process the account first
		if ($data['subsidiaries'])
		{

			// array for contacts, used to check whether a contact exists
			$used_contacts = array(
				$member->email_p => $member->primary_sf_id,
				$member->email_s => $member->secondary_sf_id,
				$member->email_f => $member->finance_sf_id,
				$member->contact_email => $member->contact_sf_id,
				$member->email_a => $member->appliedby_sf_id,
			);

			// position of contacts
			$position_contacts = array(
				$member->email_p => 'primary',
				$member->email_s => 'secondary',
				$member->email_f => 'finance',
				$member->contact_email => 'contact',
				$member->email_a => 'application',
			);

/* *
echo "<pre>\n";
echo "\$data['subsidiaries'] (before):\n";
print_r($data['subsidiaries']);
echo "</pre>\n";
/* */

			foreach($data['subsidiaries'] as &$subsidiary)
			{
				/***************************************************************/
				/*                                                             */
				/*                   account section starts                    */
				/*                                                             */
				/***************************************************************/

				// construct data for account
				$account_data = array(
					'acc' => array(
						'CMS_GM_ID__c' => $subsidiary['id'],
						'CMS_PM_ID__c' => $subsidiary['member_intID'],
						'CMS_M_ID__c' => !empty($subsidiary['intID'])?$subsidiary['intID']:'',
						'RecordTypeId' => '01290000001BXnpAAG', //'0125D0000000D3kQAE',
						'OwnerId' => $sf_owner_id, //'00590000003BhoAAAS',
						'Name' => $subsidiary['name'],
						'Types__c' => $subsidiary['type'],
						'Other_Type__c' => strtolower($subsidiary['type'])=='other'?$subsidiary['other_type']:'',
						'CMS_Country__c' => $subsidiary['country'],
						'Region__c' => $subsidiary['region'],
						'ParentId' => $data['member']['account_sf_id'],
					),
				);

//echo "<pre>\n";
//echo "\nData Struct sent to SF:\n";
//print_r($account_data);
//echo "<hr />\n";
//echo "</pre>\n";

				if (empty($subsidiary['account_sf_id']))
				{
					$acc_result = $client->call("createAccount", array('parameters'=>$account_data));

//					echo "<pre>\n";
//					echo "\$acc_result (createAccount)\n";
//					print_r($acc_result);
//					echo "<hr />\n";
//					echo "<hr />\n</pre>\n";
					//exit;

					if ($client->fault)
					{
						$error = $client->getError();
                        ob_start();
						echo "<pre>\n";
						echo "\nData Struct sent to SF:\n";
						print_r($account_data);
						echo "\n</pre>\n";
						$acc_data = ob_get_contents();

                        $edata['from'] 			= $email_from;//"membership@rspo.org";
                        $edata['slug']			= 'sf-gm-integration';
                        $edata['to']			= $email_recipient;
                        $edata['name']			= 'RSPO Membership';
                        $edata['gm_id']		    = $subsidiary['member_intID'];
                        $edata['gm_name']		= $subsidiary['name'];
                        $edata['sf_status']		= 'Error';
                        $edata['sf_message']	= 'SF Client GM - Create Account ('.$subsidiary['name'].'): '.$error;
                        $this->send_email($edata);
//                        echo "\$edata:\n";
//                        print_r($edata);
//                        echo "<hr />\n</pre>\n";

						$this->ci->oauth2_m->error_log('error', 'SF Client GM - Create Account ('.$subsidiary['name'].') with data ('.$acc_data.') : '.$error);

                        if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Client GM - Create Account ('.$subsidiary['name'].'): '.$error);
                        return false;
					}

					if (!empty($acc_result['result']))
					{
						$subsidiary['account_sf_id'] = $acc_result['result'];
						if ($this->ci->oauth2_m->update_gm_member($subsidiary['id'], array('account_sf_id'=>$acc_result['result'])))
						{
							$this->ci->oauth2_m->error_log('success', 'SF Client ('.$subsidiary['name'].'): added account_sf_id: '.$acc_result['result']);
						}
					}
					else
					{
                        $edata['from'] 			= $email_from;//"membership@rspo.org";
                        $edata['slug']			= 'sf-gm-integration';
                        $edata['to']			= $email_recipient;
                        $edata['name']			= 'RSPO Membership';
                        $edata['gm_id']		    = $subsidiary['member_intID'];
                        $edata['gm_name']		= $subsidiary['name'];
                        $edata['sf_status']		= 'Error';
                        $edata['sf_message']	= 'SF Integration GM - Create Account ('.$subsidiary['name'].'): could not create account';
                        $this->send_email($edata);
//                        echo "\$edata:\n";
//                        print_r($edata);
//                        echo "<hr />\n</pre>\n";
                        $this->ci->oauth2_m->error_log('error', 'SF Integration GM - Create Account ('.$subsidiary['name'].'): could not create account');
                        if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration GM - Create Account ('.$subsidiary['name'].'): could not create account');
                        return false;
//						$this->ci->oauth2_m->error_log('error', 'SF Client ('.$subsidiary['name'].'): could not create GM account');
					}

				}
				else
				{
					$account_data['acc']['Id'] = $subsidiary['account_sf_id'];
					$acc_result = $client->call("updateAccount", array('parameters'=>$account_data));
//					echo "<pre>\n";
//					echo "\$acc_result (updateAccount)\n";
//					print_r($acc_result);
//					echo "<hr />\n";
//					echo "<hr />\n</pre>\n";
				}


				if ($client->fault)
				{
					$error = $client->getError();
//					echo "<pre>\n";
//					echo "\nData Struct sent to SF:\n";
//					print_r($account_data);
//					echo "<hr />\n";
//					echo "\$error:\n";
//					echo $error;
//					echo "<hr />\n</pre>\n";
                    $edata['from'] 			= $email_from;//"membership@rspo.org";
                    $edata['slug']			= 'sf-gm-integration';
                    $edata['to']			= $email_recipient;
                    $edata['name']			= 'RSPO Membership';
                    $edata['gm_id']		    = $subsidiary['member_intID'];
                    $edata['gm_name']		= $subsidiary['name'];
                    $edata['sf_status']		= 'Error';
                    $edata['sf_message']	= 'SF Client GM - Update Account ('.$subsidiary['name'].'): '.$error;
                    $this->send_email($edata);
//                    echo "\$edata:\n";
//                    print_r($edata);
//                    echo "<hr />\n</pre>\n";
                    $this->ci->oauth2_m->error_log('error', 'SF Client GM - Update Account ('.$subsidiary['name'].'): '.$error);
                    if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Client GM - Update Account ('.$subsidiary['name'].'): '.$error);
                    return false;
				}
				else
				{
					if (empty($data['frontend'])) $this->ci->session->set_flashdata('success', 'SF Client ('.$subsidiary['name'].'): GM Account sync\'ed to SF');
					$this->ci->oauth2_m->error_log('success', 'SF Client ('.$subsidiary['name'].'): GM Account sync\'ed to SF');					
				}
				/***************************************************************/
				/*                                                             */
				/*                    account section ends                     */
				/*                                                             */
				/***************************************************************/


				/***************************************************************/
				/*                                                             */
				/*                   contact section starts                    */
				/*                                                             */
				/***************************************************************
				//
				// Contact is currently not pushed

				if (!empty($subsidiary['account_sf_id']))
				{
					$contact_data = array(
						'cnt' => array(
							'CMS_GM_ID__c' => $subsidiary['id'],
							'CMS_PM_ID__c' => $subsidiary['member_intID'],
							'CMS_M_ID__c' => !empty($subsidiary['intID'])?$subsidiary['intID']:'',
							'RecordTypeId' => '01290000001BXnqAAG', //'0125D0000000D3pQAE',
							'OwnerId' => $sf_owner_id, //'00590000003BhoAAAS',
							'AccountId' => $subsidiary['account_sf_id'],
							'FirstName' => $subsidiary['firstname'],
							'LastName' => $subsidiary['lastname'],
							'Email' => $subsidiary['email'],
							'Phone' => $subsidiary['phone'],
						),
					);


					if (empty($subsidiary['contact_sf_id']))
					{
						$cnt_result = $client->call("createContact", array('parameters'=>$contact_data));
                        ob_start();

//                        echo "<pre>\n";
//                        echo "\$contact_data\n";
//                        print_r($contact_data);
//                        echo "\$cnt_result (createContact)\n";
                        print_r($contact_data);
//                        echo "<hr />\n";
//                        echo "<hr />\n</pre>\n";

                        $cnt_data = ob_get_contents();

                        if ($client->fault)
                        {
                            $error = $client->getError();
//                            echo "<pre>\n";
//                            echo "\nData Struct sent to SF:\n";
//                            print_r($contact_data);
//                            echo "<hr />\n";
//                            echo "\$error:\n";
//                            echo $error;
//                            echo "<hr />\n</pre>\n";
                            $edata['from'] 			= $email_from;//"membership@rspo.org";
                            $edata['slug']			= 'sf-gm-integration';
                            $edata['to']			= $email_recipient;
                            $edata['name']			= 'RSPO Membership';
                            $edata['gm_id']		    = $subsidiary['member_intID'];
                            $edata['gm_name']		= $subsidiary['name'];
                            $edata['sf_status']		= 'Error';
                            $edata['sf_message']	= 'SF Client GM - Create Contact ('.$subsidiary['name'].'): '.$error;
                            $this->send_email($edata);
//                            echo "\$edata:\n";
//                            print_r($edata);
//                            echo "<hr />\n</pre>\n";
                            $this->ci->oauth2_m->error_log('error', 'SF Client GM - Create Contact ('.$subsidiary['name'].') with data ('.$cnt_data.') : '.$error);
                            if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Client GM - Create Contact ('.$subsidiary['name'].'): '.$error);
                            return false;
                        }

						if (!empty($cnt_result['result']))
						{
							$subsidiary['contact_sf_id'] = $cnt_result['result'];
							if ($this->ci->oauth2_m->update_gm_member($subsidiary['id'], array('contact_sf_id'=>$cnt_result['result'])))
							{
								$this->ci->oauth2_m->error_log('success', 'SF Client ('.$subsidiary['name'].'): added contact_sf_id: '.$cnt_result['result']);
								$set_flashdata_msg[] = 'SF Client ('.$subsidiary['name'].'): added contact_sf_id: '.$cnt_result['result'];

								if (empty($data['frontend'])) $this->ci->session->set_flashdata('success', 'SF Client ('.$subsidiary['name'].'): added contact_sf_id: '.$cnt_result['result']);

								$used_contacts[$subsidiary['email']] = $subsidiary['contact_sf_id'];
								$position_contacts[$subsidiary['email']] = 'gm';
							}

						}
						else
						{
                            $edata['from'] 			= $email_from;//"membership@rspo.org";
                            $edata['slug']			= 'sf-gm-integration';
                            $edata['to']			= $email_recipient;
                            $edata['name']			= 'RSPO Membership';
                            $edata['gm_id']		    = $subsidiary['member_intID'];
                            $edata['gm_name']		= $subsidiary['name'];
                            $edata['sf_status']		= 'Error';
                            $edata['sf_message']	= 'SF Integration GM - Create Contact ('.$subsidiary['name'].'): could not create contact';
                            $this->send_email($edata);
//                            echo "\$edata:\n";
//                            print_r($edata);
//                            echo "<hr />\n</pre>\n";
                            $this->ci->oauth2_m->error_log('error', 'SF Integration GM - Create Contact ('.$subsidiary['name'].')  with data ('.$cnt_data.') : could not create contact');
							$set_flashdata_msg[] = 'SF Integration GM - Create Contact ('.$subsidiary['name'].'): could not create contact';
                            if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration GM - Create Contact ('.$subsidiary['name'].'): could not create contact');
                            return false;
//							$this->ci->oauth2_m->error_log('error', 'SF Client ('.$subsidiary['name'].'): could not find contact_sf_id');
						}
					}
					else
					{
						$contact_data['cnt']['Id'] = $subsidiary['contact_sf_id'];
						$cnt_result = $client->call("updateContact", array('parameters'=>$contact_data));

//                        echo "<pre>\n";
//                        echo "\$contact_data\n";
//                        print_r($contact_data);
//                        echo "\$cnt_result (updateContact)\n";
//                        print_r($cnt_result);
//                        echo "<hr />\n";
//                        echo "<hr />\n</pre>\n";
					}

					if ($client->fault)
					{
						$error = $client->getError();
//						echo "<pre>\n";
//						echo "\nData Struct sent to SF:\n";
//						print_r($contact_data);
//						echo "<hr />\n";
//						echo "\$error:\n";
//						echo $error;
//						echo "<hr />\n</pre>\n";
                        $edata['from'] 			= $email_from;//"membership@rspo.org";
                        $edata['slug']			= 'sf-gm-integration';
                        $edata['to']			= $email_recipient;
                        $edata['name']			= 'RSPO Membership';
                        $edata['gm_id']		    = $subsidiary['member_intID'];
                        $edata['gm_name']		= $subsidiary['name'];
                        $edata['sf_status']		= 'Error';
                        $edata['sf_message']	= 'SF Client GM - Update Contact ('.$subsidiary['name'].'): '.$error;
                        $this->send_email($edata);
//                        echo "\$edata:\n";
//                        print_r($edata);
//                        echo "<hr />\n</pre>\n";
                        $this->ci->oauth2_m->error_log('error', 'SF Client GM - Update Contact ('.$subsidiary['name'].')  with data ('.$cnt_data.') : '.$error);
                        if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Client GM - Update Contact ('.$subsidiary['name'].'): '.$error);
                        return false;
					}
					else
					{
						$this->ci->oauth2_m->error_log('success', 'SF Client ('.$subsidiary['name'].'): Contact sync\'ed to SF');
						$set_flashdata_msg[] = 'SF Client ('.$subsidiary['name'].'): Contact sync\'ed to SF';
					}

				}
				else
				{
					// log that we can't find account_sf_id
                    $edata['from'] 			= $email_from;//"membership@rspo.org";
                    $edata['slug']			= 'sf-gm-integration';
                    $edata['to']			= $email_recipient;
                    $edata['name']			= 'RSPO Membership';
                    $edata['gm_id']		    = $subsidiary['member_intID'];
                    $edata['gm_name']		= $subsidiary['name'];
                    $edata['sf_status']		= 'Error';
                    $edata['sf_message']	= 'SF Integration GM - ('.$subsidiary['name'].'): account_sf_id is missing while synchronizing Contact';
                    $this->send_email($edata);
//                    echo "\$edata:\n";
//                    print_r($edata);
//                    echo "<hr />\n</pre>\n";
                    $this->ci->oauth2_m->error_log('error', 'SF Integration GM - ('.$subsidiary['name'].'): account_sf_id is missing while synchronizing Contact');
                    if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration GM - ('.$subsidiary['name'].'): account_sf_id is missing while synchronizing Contact');

					if (!empty($set_flashdata_msg) && empty($data['frontend']))
						$this->ci->session->set_flashdata('notice', implode('<br />', $set_flashdata_msg));

                    return false;
//					$this->ci->oauth2_m->error_log('error', 'SF Client ('.$subsidiary['name'].'): account_sf_id is missing while synchronizing Contact');
				}

				/***************************************************************/
				/*                                                             */
				/*                     contact section ends                    */
				/*                                                             */
				/***************************************************************/

                /***************************************************************/
                /*                                                             */
                /*                      gm section starts                      */
                /*                                                             */
                /***************************************************************/

                if (!empty($subsidiary['account_sf_id']))
                {
	                if ($subsidiary['intID'])
	                {
		                //this subsidiary is a member let's see if it has an application_sf_id
		                //$sub_member = $this->ci->oauth2_m->get_member($subsidiary['intID']);
		                //if ($sub_member)
	                }

                    $gm_data = array(
                        'gm' => array(
                            'CMS_GM_ID__c' => $subsidiary['id'],
                            'CMS_PM_ID__c' => $subsidiary['member_intID'],
                            'CMS_M_ID__c' => !empty($subsidiary['intID'])?$subsidiary['intID']:'',
                            'Application_ID__c' => $data['member']['application_sf_id'], //$subsidiary['application_sf_id'],
                            'Account__c' => $subsidiary['account_sf_id'],
                            'Sector__c' => $subsidiary['nature_of_business'],
                            'IsMember__c' => ( isset($subsidiary['is_rspo_num']) && strtolower($subsidiary['is_rspo_num'])=='yes' ) ? true : false,
                            'MembershipNo__c' => $subsidiary['rspo_membership_num'],
                            //'Active__c' => ($subsidiary['status']) ? true : false,
                        ),
                    );

                    if (empty($subsidiary['gm_sf_id']))
                    {
                        $gm_result = $client->call("createGroupMember", array('parameters'=>$gm_data));

                        ob_start();
                        print_r($gm_data);
                        $data_gm = ob_get_contents();

                        if ($client->fault)
                        {

                            $error = $client->getError();

                            $edata['from'] 			= $email_from;//"membership@rspo.org";
                            $edata['slug']			= 'sf-gm-integration';
                            $edata['to']			= $email_recipient;
                            $edata['name']			= 'RSPO Membership';
                            $edata['gm_id']		    = $subsidiary['member_intID'];
                            $edata['gm_name']		= $subsidiary['name'];
                            $edata['sf_status']		= 'Error';
                            $edata['sf_message']	= 'SF Client GM - Create Group Member ('.$subsidiary['name'].') : '.$error;
                            $this->send_email($edata);

                            $this->ci->oauth2_m->error_log('error', 'SF Client GM - Create Group Member ('.$subsidiary['name'].') with data: ('.$data_gm.') : '.$error);
                            if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Client GM - Create Group Member ('.$subsidiary['name'].'): '.$error);

							if (!empty($set_flashdata_msg) && empty($data['frontend']))
								$this->ci->session->set_flashdata('notice', implode('<br />', $set_flashdata_msg));

                            return false;
                        }
                        else
                        {
                            $this->ci->oauth2_m->error_log('success', 'SF Client ('.$subsidiary['name'].'): Group Member sync\'ed to SF');
                        }

                        if (!empty($gm_result['result']))
                        {
                            $subsidiary['gm_sf_id'] = $gm_result['result'];
                            if ($this->ci->oauth2_m->update_gm_member($subsidiary['id'], array('gm_sf_id'=>$gm_result['result'])))
                            {
                                $this->ci->oauth2_m->error_log('success', 'SF Client ('.$subsidiary['name'].'): added gm_sf_id: '.$gm_result['result']);
                            }
                        }
                        else
                        {
                            $edata['from'] 			= $email_from;//"membership@rspo.org";
                            $edata['slug']			= 'sf-gm-integration';
                            $edata['to']			= $email_recipient;
                            $edata['name']			= 'RSPO Membership';
                            $edata['gm_id']		    = $subsidiary['member_intID'];
                            $edata['gm_name']		= $subsidiary['name'];
                            $edata['sf_status']		= 'Error';
                            $edata['sf_message']	= 'SF Integration GM - Create Group Member ('.$subsidiary['name'].'): could not create Group Member';
                            $this->send_email($edata);
//                            echo "\$edata:\n";
//                            print_r($edata);
//                            echo "<hr />\n</pre>\n";
                            $this->ci->oauth2_m->error_log('error', 'SF Integration GM - Create Group Member ('.$subsidiary['name'].') with data: ('.$data_gm.') : could not create Group Member');
                            if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration GM - Create Group Member ('.$subsidiary['name'].'): could not create Group Member');

							if (!empty($set_flashdata_msg) && empty($data['frontend']))
								$this->ci->session->set_flashdata('notice', implode('<br />', $set_flashdata_msg));

                            return false;
//                            $this->ci->oauth2_m->error_log('error', 'SF Client ('.$subsidiary['name'].'): could not find gm_sf_id');
                        }
                    }
                    else
                    {
                        $gm_data['gm']['Id'] = $subsidiary['gm_sf_id'];
                        $gm_result = $client->call("updateGroupMember", array('parameters'=>$gm_data));
                    }

                    if ($client->fault)
                    {
                        $error = $client->getError();

                        $edata['from'] 			= $email_from;//"membership@rspo.org";
                        $edata['slug']			= 'sf-gm-integration';
                        $edata['to']			= $email_recipient;
                        $edata['name']			= 'RSPO Membership';
                        $edata['gm_id']		    = $subsidiary['member_intID'];
                        $edata['gm_name']		= $subsidiary['name'];
                        $edata['sf_status']		= 'Error';
                        $edata['sf_message']	= 'SF Client GM - Update Group Member ('.$subsidiary['name'].'): '.$error;
                        $this->send_email($edata);

                        $this->ci->oauth2_m->error_log('error', 'SF Client GM - Update Group Member ('.$subsidiary['name'].') with data: ('.$data_gm.') : '.$error);
                        if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Client GM - Update Group Member ('.$subsidiary['name'].'): '.$error);

						if (!empty($set_flashdata_msg) && empty($data['frontend']))
							$this->ci->session->set_flashdata('notice', implode('<br />', $set_flashdata_msg));

                        return false;
                    }
                    else
                    {
                        $this->ci->oauth2_m->error_log('success', 'SF Client ('.$subsidiary['name'].'): Group Member sync\'ed to SF');
                    }

                }
                else
                {
                    // log that we can't find account_sf_id
                    $edata['from'] 			= $email_from;//"membership@rspo.org";
                    $edata['slug']			= 'sf-gm-integration';
                    $edata['to']			= $email_recipient;
                    $edata['name']			= 'RSPO Membership';
                    $edata['gm_id']		    = $subsidiary['member_intID'];
                    $edata['gm_name']		= $subsidiary['name'];
                    $edata['sf_status']		= 'Error';
                    $edata['sf_message']	= 'SF Client GM - ('.$subsidiary['name'].'): account_sf_id is missing while synchronizing Group Member';
                    $this->send_email($edata);

                    $this->ci->oauth2_m->error_log('error', 'SF Client GM - ('.$subsidiary['name'].'): account_sf_id is missing while synchronizing Group Member');
                    if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Client GM - ('.$subsidiary['name'].'): account_sf_id is missing while synchronizing Group Member');

					if (!empty($set_flashdata_msg) && empty($data['frontend']))
						$this->ci->session->set_flashdata('notice', implode('<br />', $set_flashdata_msg));

                    return false;
//                    $this->ci->oauth2_m->error_log('error', 'SF Client ('.$subsidiary['name'].'): account_sf_id is missing');
                }

                /***************************************************************/
                /*                                                             */
                /*                       gm section ends                       */
                /*                                                             */
                /***************************************************************/

			}

			if (!empty($set_flashdata_msg) && empty($data['frontend']))
				$this->ci->session->set_flashdata('notice', implode('<br />', $set_flashdata_msg));
				

		}

        $this->ci->oauth2_m->error_log('info', 'SF Client GM: transaction ends' );
//exit;
		return true;
	}

	function fetchFILE($token_endpoint, $fields, $token='')
	{
		$fields_string = json_encode($fields);

		$ch = curl_init();
		if ($token)
			curl_setopt( $ch, CURLOPT_HTTPHEADER, array("Authorization: Bearer $token") );

		curl_setopt($ch, CURLOPT_URL, $token_endpoint);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);                                                                  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
		curl_setopt($ch, CURLOPT_TIMEOUT, 20);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			"Authorization: Bearer $token",                                                                     
			'Content-Type: application/json',                                                                                
			'Content-Length: ' . strlen($fields_string))                                                                       
		);                                               

		//execute post
		$result = curl_exec($ch);

		//close connection
		curl_close($ch);
		return $result;
	}

	function fetchURL($token_endpoint, $fields, $token='')
	{
		$fields_string = '';
		foreach($fields as $key=>$value)
		{
			$fields_string .= $key.'='.$value.'&';
		}
		rtrim($fields_string, '&');

		$ch = curl_init();
		if ($token)
			curl_setopt( $ch, CURLOPT_HTTPHEADER, array("Authorization: OAuth $token") );

		curl_setopt($ch, CURLOPT_URL, $token_endpoint);
		curl_setopt($ch, CURLOPT_POST, count($fields));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 20);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

		//execute post
		$result = curl_exec($ch);

		//close connection
		curl_close($ch);
		return $result;
	}

	public function fetchURLTLS($token_endpoint, $fields, $token='')
	{
		$fields_string = '';
		foreach($fields as $key=>$value)
		{
			$fields_string .= $key.'='.$value.'&';
		}
		rtrim($fields_string, '&');

		$ch = curl_init();
		if ($token)
			curl_setopt( $ch, CURLOPT_HTTPHEADER, array("Authorization: OAuth $token") );

		// curl debug
		curl_setopt($ch, CURLOPT_VERBOSE, true);
		$verbose = fopen('php://temp', 'w+');
		curl_setopt($ch, CURLOPT_STDERR, $verbose);

		curl_setopt($ch, CURLOPT_URL, $token_endpoint);
		curl_setopt($ch, CURLOPT_POST, count($fields));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 20);
		//curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

		//execute post
		$result = curl_exec($ch);

		// curl debug
		if ($result === FALSE) {
			printf("cUrl error (#%d): %s<br>\n", curl_errno($ch),
				htmlspecialchars(curl_error($ch)));
		}
		rewind($verbose);
		$verboseLog = stream_get_contents($verbose);
		echo "Verbose information:\n<pre>", htmlspecialchars($verboseLog), "</pre>\n";

		//close connection
		curl_close($ch);
		return $result;
	}

    public function send_email($data = array())
    {
        $this->ci =& get_instance();

        $slug = $data['slug'];
        unset($data['slug']);

        $this->ci->load->model('templates/email_templates_m');

		//get all email templates
		$templates = $this->ci->email_templates_m->get_templates($slug);

        //make sure we have something to work with
        if ( ! empty($templates))
        {
			$lang	   = isset($data['lang']) ? $data['lang'] : Settings::get('site_lang');
			$from	   = isset($data['from']) ? $data['from'] : Settings::get('server_email');
            $from_name = isset($data['name']) ? $data['name'] : null;
			$reply_to  = isset($data['reply-to']) ? $data['reply-to'] : $from;
			$to		   = isset($data['to']) ? $data['to'] : Settings::get('contact_email');

            // perhaps they've passed a pipe separated string, let's switch it to commas for CodeIgniter
            if ( ! is_array($to)) $to = str_replace('|', ',', $to);

            $subject = array_key_exists($lang, $templates) ? $templates[$lang]->subject : $templates['en']->subject ;
            $subject = $this->ci->parser->parse_string($subject, $data, true);

            $body = array_key_exists($lang, $templates) ? $templates[$lang]->body : $templates['en']->body ;
            $body = $this->ci->parser->parse_string($body, $data, true);

            $this->ci->email->from($from, $from_name);
            $this->ci->email->reply_to($reply_to);
            $this->ci->email->to($to);
            if (isset($data['cc']))
	            $this->ci->email->cc($data['cc']);
            if (!empty($this->email_cc))
	            $this->ci->email->bcc($this->email_cc);
            $this->ci->email->subject($subject);
            $this->ci->email->message($body);
			
			// To send attachments simply pass an array of file paths in Events::trigger('email')
			// $data['attach'][] = /path/to/file.jpg
			// $data['attach'][] = /path/to/file.zip
			if (isset($data['attach']))
			{
				foreach ($data['attach'] AS $attachment)
				{
					$this->ci->email->attach($attachment);
				}
			}

			return (bool) $this->ci->email->send();
        }

        //return false if we can't find the necessary templates
        return false;
    }

	function encode_file($file)
	{
		$fh = fopen($file, 'rb'); 

		$cache = ''; 
		$eof = false; 

			$put = ''; 
		while (1) { 

			if (!$eof) { 
				if (!feof($fh)) { 
					$row = fgets($fh, 4096); 
				} else { 
					$row = ''; 
					$eof = true; 
				} 
			} 

			if ($cache !== '') 
				$row = $cache.$row; 
			elseif ($eof) 
				break; 

			$b64 = base64_encode($row); 

			if (strlen($b64) < 76) { 
				if ($eof) { 
					$put .= $b64."\n"; 
					$cache = ''; 
				} else { 
					$cache = $row; 
				} 

			} elseif (strlen($b64) > 76) { 
				do { 
					$put .= substr($b64, 0, 76)."\n"; 
					$b64 = substr($b64, 76); 
				} while (strlen($b64) > 76); 
		
				$cache = base64_decode($b64); 

			} else { 
				if (!$eof && $b64{75} == '=') { 
					$cache = $row; 
				} else { 
					$put .= $b64."\n"; 
					$cache = ''; 
				} 
			} 

		} 

		fclose($fh);

		if (!empty($put)) { 
			return $put; 
		} 

	}

	public function sf_test($data=array())
	{
		$sf_owner_id = '00590000000fN1L';

		$email_recipient	= 'hl.kuah@rspo.org';
		$email_from			= 'membership@rspo.org';

		if (empty($data['id']))
		{
			return false;

		}

		$strModifyDate = date('Y-m-d', now());

		$this->ci->load->model('oauth2/oauth2_m');
		$this->ci->load->library('oauth2/my_nusoap');
		$this->ci->load->helper('file');

		// variables for email notification
		// - sf_date		date
		// - member_id		member's intID
		// - member			member's name
		// - sf_status		status (probably always error)
		// - sf_message		custom message (can be SF error message?)
		$edata['sf_date'] 	= date('d-M-Y H:i', now());
		$edata['member_id'] = $data['id'];
		$edata['member'] 	= $data['input']['title'];

		$this->ci->oauth2_m->error_log('info', 'SF Client: transaction starts' );

		$fields = array(
			'grant_type'=>$this->grant_type,
			'client_id'=>$this->client_id,
			'client_secret'=>$this->client_secret,
			'username'=>$this->username,
			'password'=>$this->password,
		);

		$connect_result = $this->fetchURLTLS($this->token_endpoint, $fields);

/* */
echo "<pre>\n";
echo "\$connect_result:"."<br />\n";
print_r($connect_result);
echo "<hr />\n";
echo "\$data:\n";
print_r($data);
$member = $this->ci->oauth2_m->get_member($data['id']);
echo "<hr />\n";
echo "\$member:\n";
print_r($member);
echo "</pre>\n";
exit;
/* */

		$json = $json_user = '';
		if (!$connect_result)
		{
			$edata['sf']			= $data;
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= 'SF Client: failed to connect.';

			$this->send_email($edata);
			$this->ci->oauth2_m->error_log('error', 'SF Client: failed to connect.');
			if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: Failed connecting to SF');
			return false;
		}
		else
		{
			$json = json_decode($connect_result);

			if (!empty($json->error))
			{
					$edata['sf']			= $data;
					$edata['from'] 			= $email_from;//"membership@rspo.org";
					$edata['slug']			= 'sf-integration';
					$edata['to']			= $email_recipient;
					$edata['name']			= 'RSPO Membership';
					$edata['sf_status']		= 'Error';
					$edata['sf_message']	= !empty($json->error_description)?$json->error_description:'cannot login';
					$this->send_email($edata);
					$this->ci->oauth2_m->error_log('error', 'SF Client: '.!empty($json->error_description)?$json->error_description:'cannot login');
					if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: '.!empty($json->error_description)?$json->error_description:'cannot login');
					return false;
			}
			else
			{
				$token = !empty($json->access_token) ? $json->access_token : NULL;
				$id = !empty($json->id) ? $json->id : NULL;
				$this->instance_url = $json->instance_url;
				$id = 'https://cs6.salesforce.com/services/Soap/c/27.0';
				$issued_at = date('d-m-Y H:i:s', $json->issued_at/1000);
				if (empty($token))
				{
					$edata['from'] 			= $email_from;//"membership@rspo.org";
					$edata['slug']			= 'sf-integration';
					$edata['to']			= $email_recipient;
					$edata['name']			= 'RSPO Membership';
					$edata['sf_status']		= 'Error';
					$edata['sf_message']	= !empty($json->error_description)?$json->error_description:'cannot login';
					$this->send_email($edata);
					$this->ci->oauth2_m->error_log('error', 'SF Client: '.!empty($json->error_description)?$json->error_description:'cannot login');
					if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: '.!empty($json->error_description)?$json->error_description:'cannot login');
					return false;
				}
			}
			$this->ci->oauth2_m->error_log('success', 'SF Client: connected to SF.');
		}

		$wsdl_file = $_SERVER['DOCUMENT_ROOT'].'/'.ADDONPATH . 'modules/oauth2/libraries/inserter.xml';

		// client using nusoap
		if (!file_exists($wsdl_file))
		{
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= 'Could not find file inserter.xml.';
			$this->send_email($edata);
			$this->ci->oauth2_m->error_log('error', 'SF Client: inserter.xml does not exist.');
			if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: could not find inserter.xml file');
			return false;
		}

		$client = new nusoap_client($wsdl_file, TRUE);
		$client->soap_defencoding = 'utf-8';
		$error  = $client->getError();

		if ($error)
		{
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= $error;
			$this->send_email($edata);
			$this->ci->oauth2_m->error_log('error', 'SF Client: ' . $error);
			if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: error setting up SF client.<br />'.$error);
			return false;
		}

		$row = $data['input'];


		$header = "<SessionHeader><sessionId>$token</sessionId></SessionHeader>";
		$client->setHeaders($header);

//echo "\$header: $header<br />";
//exit;

		$member = $this->ci->oauth2_m->get_member($data['id']);

		// SF account fields
		$account_data = array(
			'acc' => array(
				//'OwnerId' => $sf_owner_id,
				'CMS_IntID__c' => $member->intID,
				'Name'		=> !empty($member->title) ? htmlspecialchars_decode($member->title, ENT_QUOTES) : htmlspecialchars_decode($member->name, ENT_QUOTES),
				'Phone'		=> $row['code_telephone'] . ' ' . $row['telephone'],
				'ShippingStreet'	=> htmlspecialchars_decode($row['address'], ENT_QUOTES), // SF: one field
				'ShippingCity'	=> htmlspecialchars_decode($row['address_city'], ENT_QUOTES), // SF: one field
				'ShippingState'	=> htmlspecialchars_decode($row['address_state'], ENT_QUOTES), // SF: one field
				'ShippingPostalCode'	=> $row['address_zip'], // SF: one field
				'ShippingCountry'	=> $row['country'], // SF: one field
				'Description'		=> htmlspecialchars_decode($row['profile'], ENT_QUOTES),
				'Fax'		=> $row['code_fax'] . ' ' . $row['fax'],
				'Website'	=> $row['website'],
				'Type'		=> 'Membership Account',
				'Types__c'	=> 'Membership Account',
				'CurrencyIsoCode' => !empty($member->account_currency)?$member->account_currency:'EUR',
			),
		);

		/* ---------------------------------------*
			for live system, comment ob_start()!
		------------------------------------------*/
		//ob_start();

		$acc_result = array();

		if ($member->account_sf_id)
		{
			$account_data['acc']['Id'] = $member->account_sf_id;
			$acc_result = $client->call("updateAccount", array('parameters'=>$account_data));
		}
		else
		{
			$acc_result = $client->call("createAccount", array('parameters'=>$account_data));
		}

		$return_message = array();

		// error?
		if ($client->fault)
		{
			$error = $client->getError();
			$edata['from'] 			= $email_from;//"membership@rspo.org";
			$edata['slug']			= 'sf-integration';
			$edata['to']			= $email_recipient;
			$edata['name']			= 'RSPO Membership';
			$edata['sf_status']		= 'Error';
			$edata['sf_message']	= $error;
			$this->send_email($edata);

			if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Integration: error synchronizing Account<br />'.$error);
			$this->ci->oauth2_m->error_log('error', 'SF Client ('.$member->title.'): ' . $error);
			if (!empty($return_message) && empty($data['frontend']))
				$this->ci->session->set_flashdata('notice', implode("<br />", $return_message));
			return false;
		}
		else
		{
			$return_message[] = 'SF Account sync\'ed successfully ('.$acc_result['result'].')';
			$account_sf_id = $member->account_sf_id;
			if (!empty($member->account_sf_id) && !empty($acc_result['result']) && $member->account_sf_id==$acc_result['result'] )
			{
				$old_data = TRUE;
			}
			else
			{
				$old_data = FALSE;
			}
			$update_account = $this->ci->oauth2_m->save_member($member->intID,
				array(
					//'old_data'=> $old_data,
					'account_sf_id'=>$acc_result['result'],
					'strModifyDate'=>$strModifyDate
				),
				$old_data
			);

			if ($update_account)
			{
				$message = 'SF Client Account Id ('.$member->title.'): account successfully synced';
				$this->ci->oauth2_m->error_log('success', $message );
			}
			else
			{
				$message = 'SF Client Account Id ('.$member->title.'): failed sync-ing account to SF';
				$this->ci->oauth2_m->error_log('error', $message );
				return false;
			}
		}

		//$contact_default_type_id = '012N000000090gfIAA';
		$contact_default_type_id = '01290000001AoetAAC';

		// primary
		$fpname = !$row['name_last_p'] ? '' : $row['name_p'];
		$lpname = !$row['name_last_p'] ? $row['name_p'] : $row['name_last_p'];
		$primary_full_name = $fpname.' '.$lpname;

		// secondary
		$fsname = !$row['name_last_s'] ? '' : $row['name_s'];
		$lsname = !$row['name_last_s'] ? $row['name_s'] : $row['name_last_s'];
		$secondary_full_name = $fsname.' '.$lsname;

		// contact person
		$fcname = !$row['contact_lname'] ? '' : $row['contact_person'];
		$lcname = !$row['contact_lname'] ? $row['contact_person'] : $row['contact_lname'];
		$contact_full_name = $fcname.' '.$lcname;

		// finance
		$ffname = !$row['name_last_f'] ? '' : $row['name_f'];
		$lfname = !$row['name_last_f'] ? $row['name_f'] : $row['name_last_f'];
		$finance_full_name = $ffname.' '.$lfname;

		// from events-ori.php starts
		$fname = !$row['name_last_p'] ? '' : $row['name_p'];
		$lname = !$row['name_last_p'] ? $row['name_p'] : $row['name_last_p'];
		$primary_full_name = $fname.' '.$lname;

		$contact_data['primary'] = array(
			'cnt' => array(
				//'OwnerId' => $sf_owner_id,
				'CMS_IntID__c' => $member->intID,
				'AccountId' => $acc_result['result'],
				'Email'		=> $row['email_p'],
				'FirstName'	=> $fname,
				'LastName'	=> $lname,
				'RecordTypeId' => $contact_default_type_id,
				'Primary_contact__c' => TRUE,
				'Financial_contact_for_membership_fee__c' => (bool)($row['name_p'] == $row['name_f']),
				'Senior_representative_author_commitment__c' => (bool)($row['name_p'] == $row['contact_person']),
				'Secondary_Nomination_Contact__c' => (bool)($row['name_p'] == $row['name_s']),
				'Title' 	=> $row['designation_p'],
				'Phone'	=> $row['telephone_p'], //$row['code_tel_p'] . ' ' . $row['telephone_p'],
				'Fax'	=> $row['fax_p'], //$row['code_fax_p'] . ' ' . $row['fax_p'],
				'Country_Cont__c' => !empty($member->country_p)?$member->country_p:$member->country,
			),
		);
		if ($member->primary_sf_id)
		{
			$contact_data['primary']['cnt']['Id'] = $member->primary_sf_id;
		}


		// secondary
		$fname = !$row['name_last_s'] ? '' : $row['name_s'];
		$lname = !$row['name_last_s'] ? $row['name_s'] : $row['name_last_s'];
		$secondary_full_name = $fname.' '.$lname;
		if ($primary_full_name <> $secondary_full_name)
		{
			$contact_data['secondary'] = array(
					'cnt' => array(
						//'OwnerId' => $sf_owner_id,
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['email_s'],
						'FirstName'	=> $fname,
						'LastName'	=> $lname,
						'Title' 	=> $row['designation_s'],
						'Phone'	=> $row['telephone_s'], //$row['code_tel_s'] . ' ' . $row['telephone_s'],
						'Fax'	=> $row['fax_s'], //$row['code_fax_s'] . ' ' . $row['fax_s'],
						'RecordTypeId' => $contact_default_type_id,
						'Secondary_Nomination_Contact__c' => TRUE,
						'Country_Cont__c' => !empty($member->country_s)?$member->country_s:$member->country,
					),
				);
			if ($member->secondary_sf_id)
			{
				$contact_data['secondary']['cnt']['Id'] = $member->secondary_sf_id;
			}
		}

		// contact person
		$fname = !$row['contact_lname'] ? '' : $row['contact_person'];
		$lname = !$row['contact_lname'] ? $row['contact_person'] : $row['contact_lname'];
		$contact_full_name = $fname.' '.$lname;
		if ($primary_full_name <> $contact_full_name AND $secondary_full_name <> $contact_full_name)
		{
			$contact_data['contact'] = array(
					'cnt' => array(
						//'OwnerId' => $sf_owner_id,
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['contact_email'],
						'FirstName'	=> $fname,
						'LastName'	=> $lname,
						'Senior_representative_author_commitment__c' => TRUE,
						'Title' 	=> $row['designation'],
						'Phone'	=> $row['contact_tel'], //$row['code_contact_tel'] . ' ' . $row['contact_tel'],
						'Fax'	=> $row['contact_fax'], //$row['code_contact_fax'] . ' ' . $row['contact_fax'],
						'RecordTypeId' => $contact_default_type_id,
						'Country_Cont__c' => !empty($member->country_c)?$member->country_c:$member->country,
					),
				);
			if ($member->contact_sf_id)
			{
				$contact_data['contact']['cnt']['Id'] = $member->contact_sf_id;
			}
		}

		// finance
		$fname = !$row['name_last_f'] ? '' : $row['name_f'];
		$lname = !$row['name_last_f'] ? $row['name_f'] : $row['name_last_f'];
		$finance_full_name = $fname.' '.$lname;
		if ($primary_full_name <> $finance_full_name AND $secondary_full_name <> $finance_full_name AND $contact_full_name <> $finance_full_name)
		{
			$contact_data['finance'] = array(
					'cnt' => array(
						//'OwnerId' => $sf_owner_id,
						'CMS_IntID__c' => $member->intID,
						'AccountId' => $acc_result['result'],
						'Email'		=> $row['email_f'],
						'FirstName'	=> $fname,
						'LastName'	=> $lname,
						'Financial_contact_for_membership_fee__c' => TRUE,
						'Senior_representative_author_commitment__c' => (bool)($row['name_f'] == $row['contact_person']),
						'Title' 	=> $row['designation_f'],
						'Phone'	=> $row['telephone_f'], //$row['code_tel_f'] . ' ' . $row['telephone_f'],
						'Fax'	=> $row['fax_f'], //$row['code_fax_f'] . ' ' . $row['fax_f'],
						'RecordTypeId' => $contact_default_type_id,
						'Country_Cont__c' => !empty($member->country_f)?$member->country_f:$member->country,
					),
				);
			if ($member->finance_sf_id)
			{
				$contact_data['finance']['cnt']['Id'] = $member->finance_sf_id;
			}
		}

		$db_fields = array(
			'account' => 'account_sf_id',
			'application' => 'application_sf_id',
			'primary' => 'primary_sf_id',
			'secondary' => 'secondary_sf_id',
			'finance' => 'finance_sf_id',
			'contact' => 'contact_sf_id',
		);
		$cnt_result = array();
		if (!empty($acc_result['result']))
		{
			foreach($contact_data as $key => $val)
			{
				if ( !empty($member->$db_fields[$key]) )
				{
					$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): updating '.$db_fields[$key].': '.$member->$db_fields[$key] );
					$cnt_result[$key] = $client->call("updateContact", array('parameters'=>$val));
				}
				else
				{
					$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): creating '.$db_fields[$key].': '.$member->$db_fields[$key] );
					$cnt_result[$key] = $client->call("createContact", array('parameters'=>$val));
				}

//echo "Updating: $key<br />\n";

				if ($client->fault)
				{
					$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): '.$db_fields[$key].' - contact exists');
					$fault_string = $cnt_result[$key]['faultstring'];
					$pattern = '/value on record with id: ([a-z0-9]*):/i';
					$preg = preg_match($pattern, $fault_string, $matches);
					$current_sf_id = $matches[1];

					$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): setting '.$key.'_sf_id to '.$current_sf_id);

					// update db with sf id from the error message
					$input = array($key.'_sf_id'=>$current_sf_id);

					$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): saving '.$key.'_sf_id to DB');
					if ($this->ci->oauth2_m->save_member($member->intID, $input))
					{
						$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): saving '.$key.'_sf_id to DB was successful');
						// push it back to SF using updateContact
						$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): pushing back to SF using updateContact');
						$val['cnt']['Id'] = $current_sf_id;
						$cnt_result[$key] = $client->call("updateContact", array('parameters'=>$val));
						if ($client->fault)
						{
							$error 					= $client->getError();
							$edata['from'] 			= $email_from;//"membership@rspo.org";
							$edata['slug']			= 'sf-integration';
							$edata['to']			= $email_recipient;
							$edata['name']			= 'RSPO Membership';
							$edata['sf_status']		= 'Error';
							$edata['sf_message']	= 'Error pushing '.$key.' to SF<br />'.$error;
							$this->send_email($edata);
							$this->ci->oauth2_m->error_log('error', 'SF Client ('.$member->title.'): '.$db_fields[$key].': '.$error );
							$return_message[] = 'Contact ('.$key.') did not sync.';
							return false;
						}
						else
						{
							$return_message[] = 'Contact ('.$key.': '.$cnt_result[$key]['result'].') sync\'ed successfully.';
							$this->ci->oauth2_m->error_log('success', 'SF Client ('.$member->title.'): '.$db_fields[$key].': '.$cnt_result[$key]['result'] );

						}
					}
					else
					{
						$return_message[] = 'Contact ('.$key.': '.$cnt_result[$key]['result'].') failed to sync.';
						$this->ci->oauth2_m->error_log('debug', 'SF Client ('.$member->title.'): saving '.$key.'_sf_id to DB');
					}

/* *
echo "<pre>";
echo "\$member->intID: ".$member->intID."\n";
echo "\$current_sf_id: $current_sf_id\n";
echo "\$key: $key\n";
echo "</pre>\n";
echo "<pre>\$val:\n";
print_r($val);
echo "</pre>\n";

echo "<pre>\n";
echo "SF: Result\n";
print_r($cnt_result[$key]);
echo "</pre>";
exit;
/* */
				}
				else
				{
					$return_message[] = 'Contact ('.$key.': '.$cnt_result[$key]['result'].') sync\'ed successfully.';
					if ( empty($member->$db_fields[$key]) )
					{
						// update db:
						$this->ci->oauth2_m->save_member($member->intID, array($db_fields[$key]=>$cnt_result[$key]['result']));
					}
					$this->ci->oauth2_m->error_log('success', 'SF Client ('.$member->title.'): '.$db_fields[$key].': '.$cnt_result[$key]['result'] );
				}
			}
		}

		// tweak the results
		/** primary & secondary **/
		if ($primary_full_name == $secondary_full_name)
		{
			$cnt_result['secondary']['result'] = $cnt_result['primary']['result'];
		}

		/** primary & contact **/
		if ($primary_full_name == $contact_full_name)
		{
			$cnt_result['contact']['result'] = $cnt_result['primary']['result'];
		}

		/** primary & finance **/
		if ($primary_full_name == $finance_full_name)
		{
			$cnt_result['finance']['result'] = $cnt_result['primary']['result'];
		}

		/** secondary & contact **/
		if ($secondary_full_name == $contact_full_name)
		{
			$cnt_result['contact']['result'] = $cnt_result['secondary']['result'];
		}

		/** secondary & finance **/
		if ($secondary_full_name == $finance_full_name)
		{
			$cnt_result['finance']['result'] = $cnt_result['secondary']['result'];
		}

		/** contact & finance **/
		if ($contact_full_name == $finance_full_name)
		{
			$cnt_result['finance']['result'] = $cnt_result['contact']['result'];
		}

		$sf_types = array(
			'Ordinary Members'=>'Ordinary',
			'Affiliate Members'=>'Affiliate',
			'Affiliate Member'=>'Affiliate',
			'Supply Chain Associate'=>'Associate',
		);

		$old_types = array(
			'Ordinary Members', 'Affiliate Members', 'Affiliate Member', 'Supply Chain Associate'
		);

		// check and change old types
		if (in_array($member->type, $old_types) && !empty($sf_types[$member->type]))
		{
			$member_type = $sf_types[$member->type];
		}
		else
		{
			$member_type = $member->type;
		}


		$old_categories = array('Palm Oil Processors and Traders', 'Environmental and Conservation NGOs', 'Social and Developmental NGOs', 'Banks & Investors');

		$sf_categories = array(
			'Palm Oil Processors and Traders'=>'Palm Oil Processors and/or Traders',
			'Environmental and Conservation NGOs'=>'Environmental or Nature Conservation Organisations (Non Governmental Organisations)',
			'Social and Developmental NGOs'=>'Social or Development Organisations (Non Governmental Organisations)',
			'Banks & Investors'=>'Banks and Investors'
		);
		// check and change old categories
		if (in_array($member->category, $old_categories) && !empty($sf_categories[$member->category]))
		{
			$member_category = $sf_categories[$member->category];
		}
		else
		{
			$member_category = $member->category;
		}

		// process application
		$app_result = '';
		if ( !empty($cnt_result) && !empty($acc_result['result']) )
		{
			if ($member->parent_company=='sub')
			{
				$tmp_parent_company = unserialize($member->sub_company);
				$parent_company = $tmp_parent_company[1]['name'];
				$subsidiaries = '';
			}
			elseif ($member->parent_company=='yes')
			{
				$parent_company = $subsidiaries = '';
				$tmp_subsidiaries = unserialize($member->sub_company);
				if (!empty($tmp_subsidiaries))
				{
					$tmp_sub = array();
					foreach($tmp_subsidiaries as $ts)
					{
						$tmp_sub[] = $ts['name'];
					}
					$subsidiaries = implode(', ', $tmp_sub);
				}
			}
			else
			{
				$parent_company = '';
				$subsidiaries = '';
			}

			if ($member->status == 'Call for Comment')
				$member_status='Call For Comment';
			elseif ($member->status == 'Approved')
				$member_status='Active';
			else
				$member_status = $member->status;

			$applied_date = date('Y-m-d', $member->applied_date);

			if ($member->greenpalm_member_num)
			{
				if ($member->application_sf_id=='')
				{
					if ($member->remarks && !stristr($member->remarks, 'GreenPalm Membership No'))
						$member->remarks .= ', GreenPalm Membership No.: '.$member->greenpalm_member_num;
					else
						$member->remarks = 'GreenPalm Membership No.: '.$member->greenpalm_member_num;
				}
			}

			$member->remarks = strip_tags( str_ireplace( array('<br />', '<br>'), ' - ',  htmlspecialchars_decode($member->remarks) ) );

			$application_data = array(
				'app' => array(
					//'OwnerId' => $sf_owner_id,
					'Account__c'	=> $acc_result['result'],	// AccountId from account creation
					'Name'		=> !empty($member->title) ? $member->title : $member->name,	 	// title
					'type__c'	=> $member_type, //$sf_types[$member->type], 	// type (ordinary members is ordinary at SF)
					'Sector__c'	=> $member_category, //$member->category,			// category
					'Sub_Sector__c' => $member->profession=='Select subcategory'?'':$member->profession,		// sub-category/profession
					'Business_Registration_Number__c' => $member->registration_number, 	// registration_number
					'Application_Contact__c' => !empty($cnt_result['contact']['result']) ? $cnt_result['contact']['result'] : '',			// ID of who made the application
					'Person_For_Membership_Fee_c__c' => $cnt_result['finance']['result'],	// ID for financial
					'Primary_Contact_Person_c__c' => '', 									// ID for primary contact
					'Primary_Representative__c' => $cnt_result['primary']['result'],		// ID for primary contact
					'Secondary_Representative__c' => $cnt_result['secondary']['result'],	// ID for secondary
					'Answer8__c' => htmlspecialchars_decode($row['q1'], ENT_QUOTES),				// Q1
					'Answer6__c' => htmlspecialchars_decode($row['q2'], ENT_QUOTES),				// Q2
					'Answer7__c' => htmlspecialchars_decode($row['q3'], ENT_QUOTES),				// Q3
					'Answer9__c' => htmlspecialchars_decode($row['q4'], ENT_QUOTES),				// Q4
					'Answer10__c' => $member->q_usage,						// q_usage
					'Comment_Fee_Reduction__c' => $member->production_area,
					'Status__c' 	=> $member_status, //$member->status=='Call for Comment'?'Call For Comment':$member->status,	// membership status
					'Email__c'		=> $member->email,
					'Primary_Market_Operation_Application_GIn__c' => $member->primary_market_ops == 'World' ? 'Rest of the World' : $member->primary_market_ops,
					'Other_Market_Operations_Application_GInf__c' => $member->other_market_ops,
					'Old_Name__c'	=> $member->name_a,				// person made the application
					'Other_Person_Designation__c' => $member->designation_a,		// designation
					//'App_received_apply_date__c' => 0,
					'App_received_apply_date__c' => $applied_date,
					//'Received_c__c' => $submitted_date, // moved to below
					'URL_Membership__c' => 'http://www.rspo.org/members/'.$member->intID,	// member profile URL
					'CMS_IntID__c' => $member->intID,
					'Comment_a__c' => $member->remarks,
					'Parent__c' => $parent_company,  // parent and subsidiaries
					'Subsidiary__c' => $subsidiaries, //$member->sub_company, // are now unlinked
					//'Fee_Euro__c' => $member->total_amount_due,
				),
			);

			if (!$member->applied_date)
			{
				$application_data['app']['Received_c__c'] = $submitted_date;
			}

			if ($member->application_sf_id)
			{
				$application_data['app']['Id'] = $member->application_sf_id;
				$app_result = $client->call("updateApplication", array('parameters'=>$application_data));
			}
			else
			{
				$application_data['app']['Account_Description__c'] = $member->profile;
				$app_result = $client->call("createApplication", array('parameters'=>$application_data));
			}

			if ($client->fault)
			{
				$error 					= $client->getError();
				$edata['from'] 			= $email_from;//"membership@rspo.org";
				$edata['slug']			= 'sf-integration';
				$edata['to']			= $email_recipient;
				$edata['name']			= 'RSPO Membership';
				$edata['sf_status']		= 'Error';
				$edata['sf_message']	= 'Error pushing '.$key.' to SF<br />'.$error;
				$this->send_email($edata);
				$this->ci->oauth2_m->error_log('error', 'SF Client ('.$member->title.'): Application sync; '.$error );
				if (empty($data['frontend'])) $this->ci->session->set_flashdata('error', 'SF Client ('.$member->title.'): Application sync; '.$error);
				if (!empty($return_message) && empty($data['frontend']))
					$this->ci->session->set_flashdata('notice', implode("<br />", $return_message));
				return false;
			}
			else
			{
				if ( empty($member->application_sf_id) )
				{
					if (!empty($member->application_sf_id) && !empty($app_result['result']) && $member->application_sf_id==$app_result['result'] )
					{
						$old_data = TRUE;
					}
					else
					{
						$old_data = FALSE;
					}

					$update_application = $this->ci->oauth2_m->save_member($member->intID,
						array(
							//'old_data'=> $old_data,
							'application_sf_id'=>$app_result['result'],
							'strModifyDate'=>$strModifyDate
						),
						$old_data
					);

					// update db:

					if ($update_application)
						$this->ci->oauth2_m->error_log('success', 'SF Client ('.$member->title.'): application successfully synced' );

				}
				else
				{
					$this->ci->oauth2_m->error_log('info', 'SF Client ('.$member->title.'): application successfully synced' );
				}
				$return_message[] = 'Application sync\'ed successfully ('.$app_result['result'].').';
			}
		}
		else
		{
		}

		if (!empty($return_message) && empty($data['frontend']))
			$this->ci->session->set_flashdata('notice', implode("<br />", $return_message));
		$this->ci->oauth2_m->error_log('info', 'SF Client ('.$member->title.'): transaction ends' );

		return;

		//return $member->title . ' synced to SalesForce';
	}

	// if a user is deleted, this will unlink membership from that user
	public function unlink_user($data = array())
	{
		// unlink member upon user deletion
		$this->ci->load->model('members/members_m');
		foreach($data as $id)
		{
			$user = $this->ci->user_m->get(array('id'=>$id));
			$members = $this->ci->members_m->get_many_by(array('MemberID_2', $id));

			if ($members && $user && $user->group_id==2)
			{
				foreach($members as $member)
				{
					$input = array('MemberID_2'=>0);
					$ret = $this->ci->members_m->update($member->intID, $input);
				}
			}
		}
	}


}
/* End of file events.php */
