<?php defined('BASEPATH') or exit('No direct script access allowed');

class Members_m extends MY_Model {

	protected $_table = 'membership';
	protected $primary_key = 'intID';

	function get_all($params=array())
	{
		if (!empty($params['distinct']))
		{
			$this->db->distinct();
		}

		if (!empty($params['order']))
		{
			$this->db->order_by($params['order'], !empty($params['sort'])?$params['sort']:'desc');
		}
		else
		{
			$this->db->order_by('title', 'asc');
		}

		return $this->db->get('membership')->result();
	}

	function get_many_by_name($ch)
	{
		$this->db->like('name', $ch, 'after');
		return $this->get_all();
	}

	function get_many_by($params = array())
	{
		$this->load->helper('date');

		if (!empty($params['order_by']))
		{
			$this->db->order_by($params['order_by'], !empty($params['order_dir']) ? $params['order_dir'] : 'desc' );
		}

		if (!empty($params['type']))
		{
			$this->db->where('type', $params['type']);
		}

		if (!empty($params['country']))
		{
			//$this->db->like('country', $params['country']);
			$this->db->where('FIND_IN_SET(\''.$params['country'].'\', country)');
		}

		if (!empty($params['category']))
		{
			$this->db->where('category', $params['category']);
		}

		if (!empty($params['viewed']))
		{
			$this->db->order_by('viewed', 'desc');
		}

		if (!empty($params['recent']))
		{
			$this->db->order_by('created_on', 'desc');
		}

		if (!empty($params['month']))
		{
			$this->db->where('MONTH(FROM_UNIXTIME(created_on))', $params['month']);
		}

		if (!empty($params['year']))
		{
			$this->db->where('YEAR(FROM_UNIXTIME(created_on))', $params['year']);
		}

		if ( ! empty($params['keywords']))
		{
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						//$this->db->where('keywords.name', str_replace('-', ' ', $phrase));
						$this->db->like('membership.title', str_replace('-', ' ', $phrase));
					}
					else
					{
						$this->db->or_like('membership.profile', str_replace('-', ' ', $phrase));
						//$this->db->or_like('membership.production_area', str_replace('-', ' ', $phrase));
						//$this->db->or_like('membership.primary_market_ops', str_replace('-', ' ', $phrase));
						//$this->db->or_like('membership.other_market_ops', str_replace('-', ' ', $phrase));
					}

					if (!empty($params['not_id']))
					{
						$this->db->where('member_pnc.id !=', $params['not_id']);
					}

					$counter++;
				}
			}
			else
			{
				$this->db->like('membership.title', $params['keywords']);
					//->or_like('membership.profile', $params['keywords']);
					//->or_like('membership.production_area', $params['keywords'])
					//->or_like('membership.primary_market_ops', $params['keywords'])
					//->or_like('membership.other_market_ops', $params['keywords']);
			}
		}

		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				if (is_array($params['status']))
				{
					$this->db->where_in('status', $params['status']);
				}
				else
					$this->db->where('status', $params['status']);
			}
/*
			else
			{
				$this->db->where('status', $params['status']);
			}
*/
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			//$this->db->where('status', 'live');
			//$this->db->where("( status != 'Draft' AND status != 'Terminated' AND status != 'Deleted' ) ");
			//$this->db->where("( status = 'Approved' OR status != 'Call for Comment' ) ");
			$this->db->where('status', 'Approved');
		}

		if (!empty($params['expired']))
		{
			$this->db->where('expiry_date >=', now());
		}


		// Limit the results based on 1 number or 2 (2nd is offset)
		if (isset($params['limit']) && is_array($params['limit']))
			$this->db->limit($params['limit'][0], $params['limit'][1]);
		elseif (isset($params['limit']))
			$this->db->limit($params['limit']);

		return $this->get_all($params);
	}

	function count_by($params = array())
	{
		$this->load->helper('date');

		if (!empty($params['type']))
		{
			$this->db->where('type', $params['type']);
		}

		if (!empty($params['MemberID_2']))
		{
			$this->db->where('MemberID_2', $params['MemberID_2']);
		}

		if (!empty($params['country']))
		{
			//$this->db->like('country', $params['country']);
			$this->db->where('FIND_IN_SET(\''.$params['country'].'\', country)');
		}

		if (!empty($params['category']))
		{
			$this->db->where('category', $params['category']);
		}

		if (!empty($params['viewed']))
		{
			$this->db->order_by('viewed', 'desc');
		}

		if (!empty($params['recent']))
		{
			$this->db->order_by('created_on', 'desc');
		}

		if (!empty($params['month']))
		{
			$this->db->where('MONTH(FROM_UNIXTIME(created_on))', $params['month']);
		}

		if (!empty($params['year']))
		{
			$this->db->where('YEAR(FROM_UNIXTIME(created_on))', $params['year']);
		}

		if ( ! empty($params['keywords']))
		{
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						//$this->db->where('keywords.name', str_replace('-', ' ', $phrase));
						$this->db->like('membership.title', str_replace('-', ' ', $phrase));
					}
					else
					{
						$this->db->or_like('membership.profile', str_replace('-', ' ', $phrase));
						//$this->db->or_like('membership.production_area', str_replace('-', ' ', $phrase));
						//$this->db->or_like('membership.primary_market_ops', str_replace('-', ' ', $phrase));
						//$this->db->or_like('membership.other_market_ops', str_replace('-', ' ', $phrase));
					}

					if (!empty($params['not_id']))
					{
						$this->db->where('member_pnc.id !=', $params['not_id']);
					}

					$counter++;
				}
			}
			else
			{
				$this->db->like('membership.title', $params['keywords']);
					//->or_like('membership.profile', $params['keywords']);
					//->or_like('membership.production_area', $params['keywords'])
					//->or_like('membership.primary_market_ops', $params['keywords'])
					//->or_like('membership.other_market_ops', $params['keywords']);
			}
		}

		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				if (is_array($params['status']))
				{
					$this->db->where_in('status', $params['status']);
				}
				else
					$this->db->where('status', $params['status']);
			}
/*
			else
			{
				$this->db->where('status', $params['status']);
			}
*/
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			//$this->db->where('status', 'live');
			//$this->db->where("( status != 'Draft' AND status != 'Terminated' AND status != 'Deleted' ) ");
			$this->db->where("( status = 'Approved' OR status != 'Call for Comment' ) ");
		}

		if (!empty($params['expired']))
		{
			$this->db->where('expiry_date >=', now());
		}

		return $this->db->count_all_results('membership');
	}

	public function update($id=0, $input=array(), $skip_validation = false)
	{
		$this->primary_key = 'intID';
		$update = parent::update($id, $input); //$this->db->where('intID', $id)->update($input);
		if ($update && $input['parent_company']=='y')
		{
			// delete all data where member_id = $id
			$this->db->where('member_id', $id)->delete('member_subsidiaries');

			// update subsidiaries lookup
			$subsidiaries = unserialize($input['sub_company']);
			foreach($subsidiaries as $s)
			{
				if ($s['id'])
				{
					$values[] = "('".$id."', '".$s['id']."')";
				}
			}
			if (!empty($values))
			{
				$sql = "INSERT IGNORE INTO ".$this->db->dbprefix('member_subsidiaries')." (member_id, subsidiary_id) VALUES ";
				$sql .= implode(',', $values) . ';';
				return $this->db->query($sql);
			}
			return $update;
		}

		return $update;
	}

	public function get_by($key = NULL, $value = NULL)
	{
		return parent::get_by($key,$value);
	}

	public function get_membership($id)
	{
		return $this->where('MemberID', $id)->get('membership')->row();
	}

	public function search($data = array())
	{
		if (array_key_exists('type', $data))
		{
			$this->db->where('type', $data['type']);
		}

		if (array_key_exists('status', $data))
		{
			$this->db->where('status', $data['status']);
		}

		if (array_key_exists('category', $data))
		{
			$this->db->where('category', $data['category']);
		}

		return $this->get_all();
	}

	public function get_random_logo($params=array())
	{
		if (!empty($params['limit']))
		{
			$this->db->limit($params['limit']);
		}


		if (!empty($params['not-id']))
		{
			$this->db->where_not_in('intID', $params['not-id']);
		}

		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				if (is_array($params['status']))
				{
					$this->db->where_in('status', $params['status']);
				}
				else
					$this->db->where('status', $params['status']);
			}
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			$this->db->where('status', 'Approved');
		}

		return $this->db->select('intID,logo,title,website')
			//->where("logo != NULL AND logo != 'ma/logo' ")
			->where("logo IS NOT NULL AND logo != '' AND logo NOT LIKE 'ma/logo/' AND (logo NOT LIKE '%.bmp' OR logo NOT LIKE '%.pdf')")
			->order_by('title', 'random')
			->get('membership')
			->result();
	}

	public function get_child_member($id)
	{
		return $this->db->join('member_subsidiaries', 'member_subsidiaries.member_id = membership.intID', 'left')
			->where('member_subsidiaries.member_id', $id)
			->get('membership')->result();
		//return $this->db->where('member_id', $id)->count_all_result('member_subsidiaries');
	}

	public function get_parent_member($id)
	{
		return $this->db->join('member_subsidiaries', 'member_subsidiaries.member_id = membership.intID', 'left')
			->where('member_subsidiaries.subsidiary_id', $id)
			->get('membership')->row();
	}
}
