<?php defined('BASEPATH') or exit('No direct script access allowed');

class Pnc_m extends MY_Model {

	protected $_table = 'member_pnc';

	function __construct()
	{
		parent::__construct();
	}

	function get($id=0)
	{
		//$this->db->select('member_pnc.*, membership.title as member_name, IF(member_pnc.cb_id, cb.name, member_pnc.certification_body) as cb_name', FALSE);
		$this->db->select('member_pnc.*, membership.title as member_name, IFNULL('.$this->db->dbprefix('cb').'.name, '.$this->db->dbprefix('member_pnc').'.certification_body) as cb_name', FALSE);
		$this->db->join('membership', 'member_pnc.mid = intID', 'left');
		$this->db->join('cb', 'member_pnc.cb_id = cb.id', 'left');
		$pnc = $this->db->where('member_pnc.id', $id)->get('member_pnc')->row();
		if ($pnc)
		{
			$uploaded = $this->get_files($pnc->id);
			if ($uploaded)
			{
				foreach($uploaded as $file_type=>$u)
				{
					foreach($u as $f)
						$t["{$file_type}"][] = $f;
					$file_name = $file_type.'_old';
					$pnc->{$file_name} = implode(',', $t[$file_type]);
				}
			}
		}
		return $pnc;
	}

	function get_all($params=array())
	{
		if (!empty($params['distinct']))
		{
			$this->db->distinct();
		}

		if (!empty($params['order']))
		{
			$this->db->order_by($params['order'], !empty($params['sort'])?$params['sort']:'desc');
			//$this->db->order_by($params['order'].' ' . (!empty($params['sort'])?$params['sort']:'desc') . ', ISNULL(member_name), member_name ASC ');
		}
		else
		{
			$this->db->order_by('`date`', 'desc');
			//$this->db->order_by('(CASE WHEN member_name IS NULL then 1 ELSE 0 END), member_name');
		}
		$this->db->select('member_pnc.*, membership.title as member_name, IFNULL('.$this->db->dbprefix('cb').'.name, '.$this->db->dbprefix('member_pnc').'.certification_body) as cb_name', FALSE);
		$this->db->join('membership', 'member_pnc.mid = intID', 'left');

		$this->db->join('cb', 'member_pnc.cb_id = cb.id', 'left');

		$pncs = $this->db->get('member_pnc')->result();
		foreach($pncs as $pnc)
		{
			$pnc->mill = $this->get_mills($pnc->id);

/*
			// no longer used - os, 2016-09-23
			$uploaded = $this->get_files($pnc->id);
			if ($uploaded)
			{
				foreach($uploaded as $file_type=>$u)
				{
					//echo "\$file_type: $file_type<br />\n";
					//echo "<pre>\n";
					//print_r($u);
					//echo "<pre>\n";
					//echo "<hr />\n";
					foreach($u as $f)
						$t["{$file_type}"][] = $f;
					$pnc->{$file_type} = implode(',', $t[$file_type]);
				}
			}
*/
		}

		return $pncs;
		//return $this->db->get('member_pnc')->result();
	}

	function get_many_by($params = array())
	{
		$this->load->helper('date');

		if (!empty($params['assessment_status']))
		{
			$this->db->where('member_pnc.status', $params['assessment_status']);
		}

		if (!empty($params['order_by']))
		{
			$this->db->order_by($params['order_by'], !empty($params['order_dir']) ? $params['order_dir'] : 'desc' );
		}

		if (!empty($params['assessment_type']))
		{
			$this->db->where('assessment_type', $params['assessment_type']);
		}

		if (!empty($params['category']))
		{
			$this->db->where('category', $params['category']);
		}

		if (!empty($params['viewed']))
		{
			$this->db->order_by('viewed', 'desc');
		}

		if (!empty($params['recent']))
		{
			$this->db->order_by('created_on', 'desc');
		}

		if (!empty($params['month']))
		{
			$this->db->where('MONTH(FROM_UNIXTIME(created_on))', $params['month']);
		}

		if (!empty($params['year_approved']))
		{
			$this->db->where('YEAR(FROM_UNIXTIME(report_accepted_date))', $params['year_approved']);
		}

		if (!empty($params['notification_date']))
		{
			$this->db->where('YEAR(FROM_UNIXTIME(assessment_date))', $params['notification_date']);
		}

		if (!empty($params['pnc_status']))
		{
			$this->db->where('member_pnc.status', $params['pnc_status']);
		}

		if (!empty($params['country']))
		{
			$this->db->like('member_pnc.mill_country_index', $params['country']);
		}

		if ( ! empty($params['keywords']))
		{
			$sq_like = " ( ".$this->db->dbprefix('membership').".title LIKE '%".$params['keywords']."%' OR ".$this->db->dbprefix('member_pnc').".mill_index LIKE '%".$params['keywords']."%' OR ".$this->db->dbprefix('member_pnc').".certification_body LIKE '%".$params['keywords']."%' )";
			$this->db->where($sq_like);
		}
		
		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				$this->db->where('member_pnc.isUp', $params['status']=='live'?'1':'0');
			}
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			$this->db->where('member_pnc.isUp', '1');
		}

		// Limit the results based on 1 number or 2 (2nd is offset)
		if (isset($params['limit']) && is_array($params['limit']))
			$this->db->limit($params['limit'][0], $params['limit'][1]);
		elseif (isset($params['limit']))
			$this->db->limit($params['limit']);

		return $this->get_all($params);

	}

	function count_by($params = array())
	{
		$this->load->helper('date');

		if (!empty($params['assessment_status']))
		{
			$this->db->where('member_pnc.status', $params['assessment_status']);
		}

		if (!empty($params['order_by']))
		{
			$this->db->order_by($params['order_by'], !empty($params['order_dir']) ? $params['order_dir'] : 'desc' );
		}

		if (!empty($params['assessment_type']))
		{
			$this->db->where('assessment_type', $params['assessment_type']);
		}


		if (!empty($params['country']))
		{
			$this->db->like('member_pnc.mill_country_index', $params['country']);
		}

		if (!empty($params['category']))
		{
			$this->db->where('category', $params['category']);
		}

		if (!empty($params['viewed']))
		{
			$this->db->order_by('viewed', 'desc');
		}

		if (!empty($params['recent']))
		{
			$this->db->order_by('created_on', 'desc');
		}

		if (!empty($params['month']))
		{
			$this->db->where('MONTH(FROM_UNIXTIME(created_on))', $params['month']);
		}

		if (!empty($params['year_approved']))
		{
			$this->db->where('YEAR(FROM_UNIXTIME(report_accepted_date))', $params['year_approved']);
		}

		if (!empty($params['notification_date']))
		{
			$this->db->where('YEAR(FROM_UNIXTIME(assessment_date))', $params['notification_date']);
		}

		if (!empty($params['pnc_status']))
		{
			$this->db->where('member_pnc.status', $params['pnc_status']);
		}

		if ( ! empty($params['keywords']))
		{
			$sq_like = " ( ".$this->db->dbprefix('membership').".title LIKE '%".$params['keywords']."%' OR ".$this->db->dbprefix('member_pnc').".mill_index LIKE '%".$params['keywords']."%' OR ".$this->db->dbprefix('member_pnc').".certification_body LIKE '%".$params['keywords']."%' )";
			$this->db->where($sq_like);
		}

		// Is a status set?
		if (isset($params['isUp']))
		{
			if ($params['isUp'] <> 'all')
				$this->db->where('member_pnc.isUp', $params['isUp']);
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			$this->db->where('member_pnc.isUp', '1');
		}

/*
		// Is a status set?
		if (!empty($params['isUp']))
		{
			// If it's all, then show whatever the status
			if ($params['isUp'] != 'all')
			{
				// Otherwise, show only the specific status
				if (is_array($params['isUp']))
					$this->db->where_in('member_pnc.isUp', $params['isUp']);
				else
					$this->db->where('member_pnc.isUp', $params['isUp']);
			}
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			$this->db->where('member_pnc.isUp', '1');
		}
*/

		$this->db->select('member_pnc.*, membership.title as member_name, IFNULL('.$this->db->dbprefix('cb').'.name, '.$this->db->dbprefix('member_pnc').'.certification_body) as cb_name', FALSE);
		$this->db->join('membership', 'member_pnc.mid = intID', 'left');
		$this->db->join('cb', 'member_pnc.cb_id = cb.id', 'left');

		return $this->db->count_all_results('member_pnc');
	}

	public function get_assessment_type()
	{
		return $this->db->order_by('position', 'asc')->get('pnc_assessment_type')->result();
	}

	public function get_assessment_status()
	{
		return $this->db->order_by('position')->get('pnc_status')->result();
	}

	public function search($data = array())
	{
		if (array_key_exists('type', $data))
		{
			$this->db->where('type', $data['type']);
		}

		if (array_key_exists('status', $data))
		{
			$this->db->where('status', $data['status']);
		}

		if (array_key_exists('category', $data))
		{
			$this->db->where('category', $data['category']);
		}

		return $this->get_all();
	}

	public function get_files($pnc_id, $filetype='')
	{
		if ($filetype)
			$this->db->where('filetype', $filetype);
		$ret = $this->db->where('pnc_id', $pnc_id)->get('member_pnc_files')->result();
		$retvalue = array();
		if ($ret)
		{
			foreach($ret as $file)
			{
				$retvalue[$file->filetype][] = $file->filename;
			}
		}
		return $retvalue;
	}

	public function update_files($input=array())
	{
		// first let's delete the file first
		foreach($input as $i)
		{
			$this->db
				->where('pnc_id', $i['pnc_id'])
				->where('pnc_type', $i['pnc_type'])
				->delete('member_pnc_files');
		}

		// insert in batch
		return $this->db->insert_batch('member_pnc_files', $input);
	}

	public function get_mills($id=0)
	{
		if (!$id) return false;
		return $this->db->where('pnc_id', $id)->order_by('mill')->get('member_pnc_mills')->result();
	}

	public function update_mills($input=array())
	{
		// first let's clean-start mill first
		foreach($input as $i)
		{
			$this->db
				->where('pnc_id', $i['pnc_id'])
				->delete('member_pnc_mills');
		}
		// insert in batch
		return $this->db->insert_batch('member_pnc_mills', $input);
	}

}
