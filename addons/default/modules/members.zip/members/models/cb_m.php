<?php defined('BASEPATH') or exit('No direct script access allowed');

class Cb_m extends MY_Model {

	protected $_table = 'cb';

	function __construct()
	{
		parent::__construct();
	}

	function get_all($params=array())
	{
		if (!empty($params['distinct']))
		{
			$this->db->distinct();
		}

		if (!empty($params['order']))
		{
			$this->db->order_by($params['order'], !empty($params['sort'])?$params['sort']:'desc');
		}
		else
		{
			$this->db->order_by('name ASC');
		}

		return $this->db->get('cb')->result();
	}

	function get_many_by_name($ch)
	{
		$this->db->like('name', $ch, 'after');
		return $this->get_all();
	}

	function get_many_by($params = array())
	{
		if (!empty($params['country']))
		{
			$this->db->where('country', $params['country']);
		}

		if (!empty($params['red']))
		{
			//$this->db->like('country', $params['country']);
			$this->db->where('red_auditor', 'yes');
		}

		if (!empty($params['certification']))
		{
			$this->db->where('FIND_IN_SET(\''.$params['certification'].'\', certification)');
		}

		if ( ! empty($params['keywords']))
		{
			if (is_array($params['keywords']))
			{


				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						$this->db->like('name', $phrase);
					}
					else
					{
						$this->db->or_like('pic_and_position', $phrase);
						$this->db->or_like('email', $phrase);
						$this->db->or_like('address', $phrase);
						$this->db->or_like('country', $phrase);
					}

					$counter++;
				}
			}
			else
			{
				$phrase = trim($params['keywords']);
				$this->db->like('name', $phrase);
				$this->db->or_like('pic_and_position', $phrase);
				$this->db->or_like('email', $phrase);
				$this->db->or_like('address', $phrase);
				$this->db->or_like('country', $phrase);
			}
		}

		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				$this->db->where('status', $params['status']);
			}
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			//$this->db->where('status', 'live');
		}

		// Limit the results based on 1 number or 2 (2nd is offset)
		if (isset($params['limit']) && is_array($params['limit']))
			$this->db->limit($params['limit'][0], $params['limit'][1]);
		elseif (isset($params['limit']))
			$this->db->limit($params['limit']);

		return $this->get_all($params);
	}

	function count_by($params = array())
	{
		if (!empty($params['country']))
		{
			//$this->db->like('country', $params['country']);
			$this->db->where('FIND_IN_SET(\''.$params['country'].'\', country)');
		}

		if (!empty($params['certification']))
		{
			//$this->db->like('country', $params['country']);
			$this->db->where('FIND_IN_SET(\''.$params['certification'].'\', certification)');
		}

		if ( ! empty($params['keywords']))
		{
			if (is_array($params['keywords']))
			{


				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						$this->db->like('name', $phrase);
					}
					else
					{
						$this->db->or_like('pic_and_position', $phrase);
						$this->db->or_like('email', $phrase);
						$this->db->or_like('address', $phrase);
						$this->db->or_like('country', $phrase);
					}

					$counter++;
				}
			}
			else
			{
				$phrase = trim($params['keywords']);
				$this->db->like('name', $phrase);
				$this->db->or_like('pic_and_position', $phrase);
				$this->db->or_like('email', $phrase);
				$this->db->or_like('address', $phrase);
				$this->db->or_like('country', $phrase);
			}
		}

		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				$this->db->where('status', $params['status']);
			}
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			$this->db->where('status', 'live');
		}

		if (!empty($params['not']))
		{
			$this->db->where('id !=', $params['not']);
		}

		if (!empty($params['slug']))
		{
			$this->db->where('slug', $params['slug']);
		}

		return $this->db->count_all_results('cb');
	}

	public function check_slug($value = '', $id = 0)
	{
		$params['slug'] = $value;
		if ($id)
			$params['not'] = (int) $id;
		return $this->count_by($params) == 0;
	}

}
