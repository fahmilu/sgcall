<?php defined('BASEPATH') or exit('No direct script access allowed');

class Members_temp_m extends MY_Model {

	protected $_table = 'membership_temp';
	protected $primary_key = 'intID';

	function get_limit($params=array())
	{
		// Limit the results based on 1 number or 2 (2nd is offset)
		if (isset($params['limit']) && is_array($params['limit']))
			$this->db->limit($params['limit'][0], $params['limit'][1]);
		elseif (isset($params['limit']))
			$this->db->limit($params['limit']);

		$this->db->order_by('intID', 'asc');

		$res = $this->db->get($this->_table);
		if ($res)
			return $res->result();
		else
		{
			echo $this->db->error()['message'];
			exit;
		}
	}

	function get_all($params=array())
	{
		if (!empty($params['distinct']))
		{
			$this->db->distinct();
		}

		if (!empty($params['order']))
		{
			$this->db->order_by($params['order'], !empty($params['sort'])?$params['sort']:'desc');
		}
		else
		{
			$this->db->order_by('title', 'asc');
		}

		$res = $this->db->get($this->_table);
		if ($res)
			return $res->result();
		else
		{
			echo $this->db->error()['message'];
			exit;
		}
	}

	function get_many_by_name($ch)
	{
		$this->db->like('name', $ch, 'after')->where('status !=', 'Terminated')->where('status !=', 'Deleted')->where('status !=', 'Cancelled');
		return $this->get_all();
	}

	function get_many_by($params = array())
	{
		$this->load->helper('date');

		if (!empty($params['order_by']))
		{
			$this->db->order_by($params['order_by'], !empty($params['order_dir']) ? $params['order_dir'] : 'desc' );
		}

		if (!empty($params['type']))
		{
			switch($params['type'])
			{
				case 'Ordinary Members':
					//$where = " ( ".$this->dbprefix().".type = 'Ordinary' OR type =  ) ";
					$where = " ( type = 'Ordinary' OR type = 'Ordinary Member' ) ";
					break;
				case 'Supply Chain Associate':
					//$where = " ( ".$this->dbprefix().".type = 'Ordinary' OR type =  ) ";
					$where = " ( type = 'Supply Chain Associate' OR type = 'Associate' ) ";
					break;
				case 'Affiliate Members':
					//$where = " ( ".$this->dbprefix().".type = 'Ordinary' OR type =  ) ";
					$where = " ( type = 'Affiliate Members' OR type = 'Affiliate' ) ";
					break;
			}
			$this->db->where($where);
		}

		if (!empty($params['country']))
		{
			//$this->db->like('country', $params['country']);
			$this->db->where('FIND_IN_SET(\''.$params['country'].'\', country)');
		}

		if (!empty($params['category']))
		{
			$this->db->where('category', $params['category']);
		}

		if (!empty($params['MemberID_2']))
		{
			$this->db->where('MemberID_2', $params['MemberID_2']);
		}

		if (!empty($params['viewed']))
		{
			$this->db->order_by('viewed', 'desc');
		}

		if (!empty($params['recent']))
		{
			$this->db->order_by('created_on', 'desc');
		}

		if (!empty($params['month']))
		{
			$this->db->where('MONTH(FROM_UNIXTIME(created_on))', $params['month']);
		}

		if (!empty($params['year']))
		{
			$this->db->where('YEAR(FROM_UNIXTIME(created_on))', $params['year']);
		}

		if (!empty($params['keywordsSOUNDEX']))
		{
			$keyword_array = array();
			$keywords = explode(' ', $params['keywords']);
			if (is_array($keywords))
			{
				foreach($keywords as $kw)
				{
					#if (strlen($kw)>1)
						$keyword_array[] = $this->db->dbprefix($this->_table).".member_soundex LIKE '%".soundex($kw)."%'";
				}
				$member_soundex_like = implode(" OR ", $keyword_array);
echo "<pre>\n\n\n\n\n\n\n\n\n\n</pre>\n";
echo "keywords: ".$params['keywords']."<br />";
echo "\$member_soundex_like: $member_soundex_like<br />";
			}
			$soundex = soundex($params['keywords']);
#echo "\$soundex: $soundex<br />";
			$like = " ( ";
			$like .= $member_soundex_like;

			//$like .= $this->db->dbprefix($this->_table).".member_soundex LIKE '%$soundex%' ";
			$like .= " OR soundex(`" .$this->db->dbprefix($this->_table)."`.`title` LIKE '%$soundex%' ";

			$like .= " OR `" . $this->db->dbprefix($this->_table) . "`.`title` LIKE '%".addslashes($params['keywords'])."%' ";
			$like .= " ) ";
echo "\$like: <code>$like</code><br />\n";
			$this->db->where($like, NULL, FALSE);
		}

		if ( ! empty($params['keywords']) )
		{
			$like = '( ';
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						//$like .= $this->db->dbprefix($this->_table).'.title LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
						$like .= $this->db->dbprefix($this->_table).'.title LIKE \'%' .$phrase. '%\' ';
					}
					else
					{
						//$like .= 'OR '.$this->db->dbprefix($this->_table).'.profile LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
						$like .= 'OR '.$this->db->dbprefix($this->_table).'.profile LIKE \'%' .$phrase. '%\' ';
					}

					if (!empty($params['not_id']))
					{
						$this->db->where('membership.intID !=', $params['not_id']);
					}

					$counter++;
				}
			}
			else
			{
				//$like .= $this->db->dbprefix($this->_table).'.title LIKE \'%' .str_replace('-', ' ', $params['keywords']) . '%\' ';
				$like .= $this->db->dbprefix($this->_table).'.title LIKE \'%' .$params['keywords']. '%\' ';
			}
			$like .= ' ) ';
			$this->db->where($like);
		}

		if ( ! empty($params['keywordsXYZ']))
		{
			$this->db->select(" ".$this->db->dbprefix($this->_table).".*, REPLACE (title, '\'', '') as newtitle ");
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						//$this->db->where('keywords.name', str_replace('-', ' ', $phrase));
						$this->db->like('membership.title', str_replace('-', ' ', $phrase));
					}
					else
					{
						$this->db->or_like('membership.profile', str_replace('-', ' ', $phrase));
						//$this->db->or_like('membership.production_area', str_replace('-', ' ', $phrase));
						//$this->db->or_like('membership.primary_market_ops', str_replace('-', ' ', $phrase));
						//$this->db->or_like('membership.other_market_ops', str_replace('-', ' ', $phrase));
					}

					if (!empty($params['not_id']))
					{
						$this->db->where('membership.intID !=', $params['not_id']);
					}

					$counter++;
				}
			}
			else
			{
				//$this->db->like('membership.title', $params['keywords']);
				$this->db->having("newtitle LIKE '%".$params['keywords']."%'");
				//$this->db->where(" MATCH(title) AGAINST('".$params['keywords']."' IN BOOLEAN MODE)");
					//->or_like('membership.profile', $params['keywords']);
					//->or_like('membership.production_area', $params['keywords'])
					//->or_like('membership.primary_market_ops', $params['keywords'])
					//->or_like('membership.other_market_ops', $params['keywords']);
			}
		}

		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				if (is_array($params['status']))
				{
					$this->db->where_in('status', $params['status']);
				}
				else
					$this->db->where('status', $params['status']);
			}
/*
			else
			{
				$this->db->where('status', $params['status']);
			}
*/
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			//$this->db->where('status', 'Approved');
			$this->db->where(" ( status = 'Approved' OR status = 'Active' ) ");
		}

		if (!empty($params['expired']))
		{
			$this->db->where('expiry_date >=', now());
		}


		// Limit the results based on 1 number or 2 (2nd is offset)
		if (isset($params['limit']) && is_array($params['limit']))
			$this->db->limit($params['limit'][0], $params['limit'][1]);
		elseif (isset($params['limit']))
			$this->db->limit($params['limit']);

		return $this->get_all($params);
	}

	function count_by($params = array())
	{
		$this->load->helper('date');

		if (!empty($params['type']))
		{
			switch($params['type'])
			{
				case 'Ordinary Members':
					//$where = " ( ".$this->dbprefix().".type = 'Ordinary' OR type =  ) ";
					$where = " ( type = 'Ordinary' OR type = 'Ordinary Member' ) ";
					break;
				case 'Supply Chain Associate':
					//$where = " ( ".$this->dbprefix().".type = 'Ordinary' OR type =  ) ";
					$where = " ( type = 'Supply Chain Associate' OR type = 'Associate' ) ";
					break;
				case 'Affiliate Members':
					//$where = " ( ".$this->dbprefix().".type = 'Ordinary' OR type =  ) ";
					$where = " ( type = 'Affiliate Members' OR type = 'Affiliate' ) ";
					break;
			}
			$this->db->where($where);
		}

		if (!empty($params['MemberID_2']))
		{
			$this->db->where('MemberID_2', $params['MemberID_2']);
		}

		if (!empty($params['country']))
		{
			//$this->db->like('country', $params['country']);
			$this->db->where('FIND_IN_SET(\''.$params['country'].'\', country)');
		}

		if (!empty($params['category']))
		{
			$this->db->where('category', $params['category']);
		}

		if (!empty($params['viewed']))
		{
			$this->db->order_by('viewed', 'desc');
		}

		if (!empty($params['recent']))
		{
			$this->db->order_by('created_on', 'desc');
		}

		if (!empty($params['month']))
		{
			$this->db->where('MONTH(FROM_UNIXTIME(created_on))', $params['month']);
		}

		if (!empty($params['year']))
		{
			$this->db->where('YEAR(FROM_UNIXTIME(created_on))', $params['year']);
		}

		if (!empty($params['keywordsXYY']))
		{
			$keyword_array = array();
			$keywords = explode(' ', $params['keywords']);
			if (is_array($keywords))
			{
				foreach($keywords as $kw)
				{
					#if (strlen($kw)>1)
						$keyword_array[] = $this->db->dbprefix($this->_table).".member_soundex LIKE '%".soundex($kw)."%'";
				}
				$member_soundex_like = implode(" OR ", $keyword_array);
			}
			$soundex = soundex($params['keywords']);
			$like = " ( ";
			$like .= $member_soundex_like;
			//$like .= $this->db->dbprefix($this->_table).".member_soundex LIKE '%$soundex%' ";
			$like .= " OR " . $this->db->dbprefix($this->_table) . ".`title` LIKE '%".addslashes($params['keywords'])."%' ";
			$like .= " ) ";
			$this->db->where($like, NULL, FALSE);
		}

		if ( ! empty($params['keywords']))
		{
			$like = '( ';
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						$like .= $this->db->dbprefix($this->_table).'.title LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
						//$this->db->like('membership.title', str_replace('-', ' ', $phrase));
					}
					else
					{
						$like .= 'OR '.$this->db->dbprefix($this->_table).'.profile LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
					}

					if (!empty($params['not_id']))
					{
						$this->db->where('membership.intID !=', $params['not_id']);
					}

					$counter++;
				}
			}
			else
			{
				$like .= $this->db->dbprefix($this->_table).'.title LIKE \'%' .str_replace('-', ' ', $params['keywords']) . '%\' ';
				//$like .= 'OR '.$this->db->dbprefix($this->_table).'.profile LIKE \'%' .str_replace('-', ' ', $params['keywords']) . '%\' ';
			}
			$like .= ' ) ';
			$this->db->where($like);
		}

		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				if (is_array($params['status']))
				{
					$this->db->where_in('status', $params['status']);
				}
				else
					$this->db->where('status', $params['status']);
			}
/*
			else
			{
				$this->db->where('status', $params['status']);
			}
*/
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			//$this->db->where("( status = 'Approved' OR status != 'Call for Comment' ) ");
			$this->db->where(" ( status = 'Approved' OR status = 'Active' ) ");
		}

		if (!empty($params['expired']))
		{
			$this->db->where('expiry_date >=', now());
		}

		return $this->db->count_all_results($this->_table);
	}

	public function update($id=0, $input=array(), $skip_validation = false)
	{
		$this->primary_key = 'intID';
		$update = parent::update($id, $input); //$this->db->where('intID', $id)->update($input);
		if ($update && !empty($input['parent_company']) && ($input['parent_company']=='yes' || $input['parent_company']=='y'))
		{
			// delete all data where member_id = $id
			$this->db->where('member_id', $id)->delete('member_subsidiaries');

			if(!empty($input['sub_company'])) {
				// update subsidiaries lookup
				$subsidiaries = unserialize($input['sub_company']);
				foreach($subsidiaries as $s)
				{
					if ($s['id'])
					{
						$values[] = "('".$id."', '".$s['id']."')";
					}
				}
				if (!empty($values))
				{
					$sql = "INSERT IGNORE INTO ".$this->db->dbprefix('member_subsidiaries')." (member_id, subsidiary_id) VALUES ";
					$sql .= implode(',', $values) . ';';
					return $this->db->query($sql);
				}
			}
			return $update;
		}

		return $update;
	}

	function get_last_mid()
	{
		$res = $this->db->order_by('mid', 'desc')->limit('1')->get($this->_table)->row();
		if ($res)
			return $res->mid;
		return false;
	}

	public function get_no_profile($id=0)
	{
		$res = $this->db
			->where('intID', $id)
			->get($this->_table)->row();

		if (!empty($res))
		{
			$acopidx = 0;
	
			// ACOP 2014
			$companyname = html_entity_decode($res->name?$res->name:$res->title, ENT_NOQUOTES);
			$acop_submission = strtoupper(convert_accented_characters(str_ireplace('-', ' ', $companyname))).'.pdf';
			//$acop_submission = url_title(strtolower(removeAccents($companyname))).'-ACOP2014-'.sprintf('%04d', $id).'.pdf';
			$acop_submission = url_title(strtolower(removeAccents($companyname))).'-ACOP2014.pdf';
			//echo '<pre>File: '.$_SERVER['DOCUMENT_ROOT'].'/file/acop2014/'.$acop_submission.'</pre><br />'.PHP_EOL;

					$companyname = $res->name?$res->name:$res->title; //$res->company_name;
					$companyname = str_ireplace( '.', '', strtolower($companyname) );
					$company	= html_entity_decode(stripslashes($companyname));
					$acop_submission = url_title(strtolower(replace_accents($company))).'-ACOP2014.pdf';

			if (file_exists($_SERVER['DOCUMENT_ROOT'].'/file/acop2014/submissions/'.$acop_submission))
			{
				$res->acop[$acopidx]['file'] = '/file/acop2014/submissions/'.$acop_submission;
				$res->acop[$acopidx]['title'] = 'ACOP 2013/2014 Progress Report';
				$res->acop[$acopidx]['size'] = sprintf('%d', filesize($_SERVER['DOCUMENT_ROOT'].'/file/acop2014/submissions/'.$acop_submission)/1024);
				$acopidx++;
			}
	
			// ACOP 2013
			$companyname = html_entity_decode($res->name, ENT_NOQUOTES);
			$acop_submission = strtoupper(convert_accented_characters(str_ireplace('-', ' ', $companyname))).'.pdf';
			//echo '<pre>File: '.$_SERVER['DOCUMENT_ROOT'].'/file/acop2013/submissions/'.$acop_submission.'</pre><br />'.PHP_EOL;
	
			if (file_exists($_SERVER['DOCUMENT_ROOT'].'/file/acop2013/submissions/'.$acop_submission))
			{
				$res->acop[$acopidx]['file'] = '/file/acop2013/submissions/'.$acop_submission;
				$res->acop[$acopidx]['title'] = 'ACOP 2012/2013 Progress Report';
				$res->acop[$acopidx]['size'] = sprintf('%d', filesize($_SERVER['DOCUMENT_ROOT'].'/file/acop2013/submissions/'.$acop_submission)/1024);
				$acopidx++;
			}
			else
			{
				$companyname = html_entity_decode($res->name, ENT_NOQUOTES);
				$acop_submission = strtoupper(url_title(convert_accented_characters(str_ireplace('-', ' ', $companyname)))).'.pdf';
				//echo '<pre>File: '.$_SERVER['DOCUMENT_ROOT'].'/file/acop2013/submissions/'.$acop_submission.'</pre><br />'.PHP_EOL;
				if (file_exists($_SERVER['DOCUMENT_ROOT'].'/file/acop2013/submissions/'.$acop_submission))
				{
					$res->acop[$acopidx]['file'] = '/file/acop2013/submissions/'.$acop_submission;
					$res->acop[$acopidx]['title'] = 'ACOP 2013 Progress Report';
					$res->acop[$acopidx]['size'] = sprintf('%d', filesize($_SERVER['DOCUMENT_ROOT'].'/file/acop2013/submissions/'.$acop_submission)/1024);
					$acopidx++;
				}
			}
	
	
			// retrieve annual_reports
			$res_annual = $this->db->select('file,title')->where('mid', $id)->order_by('report_date')->get('custom_annual_report')->result();
			if (!empty($res_annual))
				$res->annual[] = $res_annual;
		}

//DEBUG
/*
echo "<pre>\n";
print_r($res);
echo "</pre>\n";
*/

		return $res;
	}

	public function get($id=0)
	{
		$res = $this->db
			->select('profiles.*, profiles.website as profile_website, membership.*')
			->where('intID', $id)
/*
			->where('isUp', '1')
			->where('status', 'Approved')
			->where('isDeleted', '0')
*/
			->join('profiles', 'profiles.user_id = membership.MemberID_2', 'left')
			->get($this->_table)->row();

		if (!empty($res))
		{
			$this->load->model('acop/acop_m');
			$res->acop = $this->acop_m->get_files_by(array('member_id'=>$res->intID));
//DEBUG
/* *
echo "<pre>\n";
print_r($res->acop);
echo "</pre>\n";
/* */
		}

		return $res;
	}

	public function get_by($key = NULL, $value = NULL)
	{
		return parent::get_by($key,$value);
	}

	public function delete($id)
	{
		$input = array('isDeleted'=>'1', 'status'=>'Deleted');
		return $this->update($id, $input);
	}

	public function clonemember($input)
	{
		//return false;
		return $this->db->insert($this->_table, $input);
	}

	public function get_membership($id)
	{
		return $this->where('MemberID', $id)->get($this->_table)->row();
	}

	public function search($data = array())
	{
		if (array_key_exists('type', $data))
		{
			$this->db->where('type', $data['type']);
		}

		if (array_key_exists('status', $data))
		{
			$this->db->where('status', $data['status']);
		}

		if (array_key_exists('category', $data))
		{
			$this->db->where('category', $data['category']);
		}

		return $this->get_all();
	}

	public function get_random_logo($params=array())
	{
		if (!empty($params['limit']))
		{
			$this->db->limit($params['limit']);
		}


		if (!empty($params['not-id']))
		{
			$this->db->where_not_in('intID', $params['not-id']);
		}

		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				if (is_array($params['status']))
				{
					$this->db->where_in('status', $params['status']);
				}
				else
					$this->db->where('status', $params['status']);
			}
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			$this->db->where('status', 'Approved');
		}

		return $this->db->select('intID,logo,title,website')
			//->where("logo != NULL AND logo != 'ma/logo' ")
			->where("logo IS NOT NULL AND logo != '' AND logo NOT LIKE 'ma/logo/' AND (logo NOT LIKE '%.bmp' OR logo NOT LIKE '%.pdf')")
			->order_by('title', 'random')
			->get($this->_table)
			->result();
	}

	public function get_child_member($id)
	{
		return $this->db->join('member_subsidiaries', 'member_subsidiaries.member_id = membership.intID', 'left')
			->where('member_subsidiaries.member_id', $id)
			->get($this->_table)->result();
		//return $this->db->where('member_id', $id)->count_all_result('member_subsidiaries');
	}

	public function get_parent_member($id)
	{
		return $this->db->join('member_subsidiaries', 'member_subsidiaries.member_id = membership.intID', 'left')
			->where('member_subsidiaries.subsidiary_id', $id)
			->get($this->_table)->row();
	}

	public function editlog($input=array())
	{
		if (!empty($this->current_user->id))
		{
			$input['user_id'] = $this->current_user->id;
			return $this->db->insert('membership_editlog', $input);
		}
		return FALSE;
	}

	public function count_editlog($params=array())
	{
		if (!empty($params['user_id']))
		{
			$this->db->where('user_id', $params['user_id']);
		}

		if (!empty($params['member_id']))
		{
			$this->db->where('member_id', $params['member_id']);
		}
		else
		{
			return 0;
		}

		return $this->db->count_all_results('membership_editlog');
	}

	public function change_password($id=0, $password='')
	{
		if (!$id && !$password) return false;
		$pword['password'] = $password;
		return $this->db->where('id', $id)->update('users', $pword);
	}

	public function reset_code_pwd($id=0)
	{
		if (!$id) return false;
		$p_c_word['forgotten_password_code'] = '0';
		return $this->db->where('id', $id)->update('users', $p_c_word);
	}
	
	public function get_editlog_by($params=array())
	{
		if (!empty($params['user_id']))
		{
			$this->db->where('user_id', $params['user_id']);
		}

		if (!empty($params['member_id']))
		{
			$this->db->where('member_id', $params['member_id']);
		}
		else
		{
			return 0;
		}

		// Limit the results based on 1 number or 2 (2nd is offset)
		if (isset($params['limit']) && is_array($params['limit']))
			$this->db->limit($params['limit'][0], $params['limit'][1]);
		elseif (isset($params['limit']))
			$this->db->limit($params['limit']);

		return $this->db->order_by('date', 'desc')->get('membership_editlog')->result();
	}

    function check_user_membership($email)
    {
        return (bool) $this->db
            ->where('email', $email)
            ->get('membership_user')->row();
    }

    function insert_to_membership_user($data)
    {
        return $this->db->insert('membership_user', $data);
    }

    function copy_from_membership($intID)
    {
        $membership = $this->db->where('intID', $intID)->get('membership')->row();
        $this->db->insert($this->_table, $membership);
        return $this->db->where('intID', $intID)->get($this->_table)->row();
    }


}