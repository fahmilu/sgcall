<?php defined('BASEPATH') or exit('No direct script access allowed');

class Casetracker_m extends MY_Model {

	protected $_table = 'member_complaints';

	function __construct()
	{
		parent::__construct();
	}

	function get($id=0)
	{
		return $this->db->where('isDeleted !=', '1')->where('id', $id)->get('member_complaints')->row();
	}

	function get_all($params=array())
	{
		if (!empty($params['distinct']))
		{
			$this->db->distinct();
		}

		if (!empty($params['order']))
		{
			$this->db->order_by($params['order'], !empty($params['sort'])?$params['sort']:'desc');
		}
		else
		{
			$this->db->order_by('date', 'desc');
		}
		//$this->db->where('isDeleted !=', '1');

		return $this->db->get('member_complaints')->result();
	}

	function get_many_by_name($ch)
	{
		$this->db->like('company', $ch, 'after');
		return $this->get_all();
	}

	function get_many_by($params = array())
	{
		$old_categories = array(
			'Banks & Investors'						=> '',
			'Consumer Goods Manufacturers'			=> '',
			'Environmental and Conservation NGOs'	=> '',
			'Individual'							=> '',
			'Oil Palm Growers'						=> 'Grower',
			'Organisation'							=> '',
			'Palm Oil Processors and Traders'		=> 'Palm Oil Processor/ Trader',
			'Retailers'								=> '',
			'Social and Developmental NGOs'			=> '',
		);

		if (!empty($params['country']))
		{
			$this->db->where('country', $params['country']);
		}

		if (!empty($params['category']))
		{
			$this->db->like('category', $params['category']);
		}

		if (!empty($params['status']))
		{
			$this->db->where('status', $params['status']);
		}

		if (!empty($params['red']))
		{
			//$this->db->like('country', $params['country']);
			$this->db->where('red_auditor', 'yes');
		}

		if (!empty($params['certification']))
		{
			$this->db->where('FIND_IN_SET(\''.$params['certification'].'\', certification)');
		}

		$where_keywords = '';
		if ( ! empty($params['keywords']))
		{
			$where_keywords = ' ( ';
			$keywords = array();
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						$keywords[] = "company LIKE '%".str_replace('-', ' ', $phrase)."%' ";
						//$this->db->like('company', $phrase);
					}
					else
					{
						$keywords[] = "country LIKE '%".str_replace('-', ' ', $phrase)."%' ";
						$keywords[] = "category LIKE '%".str_replace('-', ' ', $phrase)."%' ";
						$keywords[] = "complainant LIKE '%".str_replace('-', ' ', $phrase)."%' ";
						$keywords[] = "synopsis LIKE '%".str_replace('-', ' ', $phrase)."%' ";
						$keywords[] = "status LIKE '%".str_replace('-', ' ', $phrase)."%' ";
						//$this->db->or_like('country', $phrase)
						//	->or_like('category', $phrase)
						//	->or_like('complainant', $phrase)
						//	->or_like('synopsis', $phrase)
						//	->or_like('status', $phrase);
					}

					$counter++;
				}
			}
			else
			{
				$phrase = trim($params['keywords']);
				$keywords[] = "company LIKE '%".str_replace('-', ' ', $phrase)."%' ";
				$keywords[] = "country LIKE '%".str_replace('-', ' ', $phrase)."%' ";
				$keywords[] = "category LIKE '%".str_replace('-', ' ', $phrase)."%' ";
				$keywords[] = "complainant LIKE '%".str_replace('-', ' ', $phrase)."%' ";
				$keywords[] = "synopsis LIKE '%".str_replace('-', ' ', $phrase)."%' ";
				$keywords[] = "status LIKE '%".str_replace('-', ' ', $phrase)."%' ";
				//$this->db->like('company', $phrase)
				//	->or_like('category', $phrase)
				//	->or_like('complainant', $phrase)
				//	->or_like('synopsis', $phrase)
				//	->or_like('status', $phrase);
			}

			$where_keywords .= implode(' OR ', $keywords);
			$where_keywords .= ' ) ';
			$this->db->where($where_keywords);

		}

		// Is a status set?
		if (!empty($params['online_status']))
		{
			// If it's all, then show whatever the status
			if ($params['online_status'] != 'all')
			{
				$this->db->where('online_status', $params['online_status']);
			}
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			$this->db->where('online_status', '1');
		}

		// Limit the results based on 1 number or 2 (2nd is offset)
		if (isset($params['limit']) && is_array($params['limit']))
			$this->db->limit($params['limit'][0], $params['limit'][1]);
		elseif (isset($params['limit']))
			$this->db->limit($params['limit']);

		return $this->get_all($params);
	}

	function count_by($params = array())
	{
		if (!empty($params['country']))
		{
			$this->db->where('country', $params['country']);
		}

		if (!empty($params['category']))
		{
			$this->db->where('category', $params['category']);
		}

		if (!empty($params['status']))
		{
			$this->db->where('status', $params['status']);
		}

		if (!empty($params['red']))
		{
			//$this->db->like('country', $params['country']);
			$this->db->where('red_auditor', 'yes');
		}

		if (!empty($params['certification']))
		{
			$this->db->where('FIND_IN_SET(\''.$params['certification'].'\', certification)');
		}

		if ( ! empty($params['keywords']))
		{
			if (is_array($params['keywords']))
			{


				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						$this->db->like('company', $phrase);
					}
					else
					{
						$this->db->or_like('country', $phrase)
							->or_like('category', $phrase)
							->or_like('complainant', $phrase)
							->or_like('synopsis', $phrase)
							->or_like('status', $phrase);
					}

					$counter++;
				}
			}
			else
			{
				$phrase = trim($params['keywords']);
				$this->db->like('company', $phrase)
					->or_like('category', $phrase)
					->or_like('complainant', $phrase)
					->or_like('synopsis', $phrase)
					->or_like('status', $phrase);
			}
		}

		// Is a status set?
		if (!empty($params['online_status']))
		{
			// If it's all, then show whatever the status
			if ($params['online_status'] != 'all')
			{
				$this->db->where('online_status', $params['online_status']);
			}
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			$this->db->where('online_status', '1');
		}

		return $this->db->count_all_results('member_complaints');
	}

	public function check_slug($value = '', $id = 0)
	{
		$params['slug'] = $value;
		if ($id)
			$params['not'] = (int) $id;
		return $this->count_by($params) == 0;
	}

}
