<?php defined('BASEPATH') or exit('No direct script access allowed');

class Members_m extends MY_Model {

	protected $_table = 'membership';
	protected $primary_key = 'intID';

	function __construct()
	{
		//$this->db->set_dbprefix('default_');
	}

	function get_limit($params=array())
	{
		// Limit the results based on 1 number or 2 (2nd is offset)
		if (isset($params['limit']) && is_array($params['limit']))
			$this->db->limit($params['limit'][0], $params['limit'][1]);
		elseif (isset($params['limit']))
			$this->db->limit($params['limit']);

		$this->db->order_by('intID', 'asc');

		$res = $this->db->get('membership');
		if ($res)
			return $res->result();
		else
		{
			echo $this->db->error()['message'];
			exit;
		}
	}

	function get_all($params=array())
	{
		if (!empty($params['distinct']))
		{
			$this->db->distinct();
		}

		if (!empty($params['order']))
		{
			$this->db->order_by($params['order'], !empty($params['sort'])?$params['sort']:'desc');
		}
		else
		{
			$this->db->order_by('title', 'asc');
		}

		$res = $this->db->get('membership');
		if ($res)
			return $res->result();
		else
		{
			echo $this->db->error()['message'];
			exit;
		}
	}

	function get_many_by_name($ch)
	{
		$this->db->like('name', $ch, 'after')->where('status !=', 'Terminated')->where('status !=', 'Deleted')->where('status !=', 'Cancelled');
		return $this->get_all();
	}

	function get_many_by($params = array())
	{
		$this->load->helper('date');

		if (!empty($params['order_by']))
		{
			$this->db->order_by($params['order_by'], !empty($params['order_dir']) ? $params['order_dir'] : 'desc' );
		}

		if (!empty($params['type']))
		{
			switch($params['type'])
			{
				case 'Ordinary Members':
					//$where = " ( ".$this->dbprefix().".type = 'Ordinary' OR type =  ) ";
					$where = " ( type = 'Ordinary' OR type = 'Ordinary Member' ) ";
					break;
				case 'Supply Chain Associate':
					//$where = " ( ".$this->dbprefix().".type = 'Ordinary' OR type =  ) ";
					$where = " ( type = 'Supply Chain Associate' OR type = 'Associate' ) ";
					break;
				case 'Affiliate Members':
					//$where = " ( ".$this->dbprefix().".type = 'Ordinary' OR type =  ) ";
					$where = " ( type = 'Affiliate Members' OR type = 'Affiliate' ) ";
					break;
			}
			$this->db->where($where);
		}

		if (!empty($params['country']))
		{
			//$this->db->like('country', $params['country']);
			$this->db->where('FIND_IN_SET(\''.$params['country'].'\', country)');
		}

		if (!empty($params['category']))
		{
			$this->db->where('category', $params['category']);
		}

		if (!empty($params['MemberID_2']))
		{
			$this->db->where('MemberID_2', $params['MemberID_2']);
		}

		if (!empty($params['viewed']))
		{
			$this->db->order_by('viewed', 'desc');
		}

		if (!empty($params['recent']))
		{
			$this->db->order_by('created_on', 'desc');
		}

		if (!empty($params['month']))
		{
			$this->db->where('MONTH(FROM_UNIXTIME(created_on))', $params['month']);
		}

		if (!empty($params['year']))
		{
			$this->db->where('YEAR(FROM_UNIXTIME(created_on))', $params['year']);
		}

		if ( ! empty($params['keywords']) )
		{
			$like = '( ';
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						//$like .= $this->db->dbprefix('membership').'.title LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
						$like .= $this->db->dbprefix('membership').'.title LIKE \'%' .$phrase. '%\' ';
					}
					else
					{
						//$like .= 'OR '.$this->db->dbprefix('membership').'.profile LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
						$like .= 'OR '.$this->db->dbprefix('membership').'.profile LIKE \'%' .$phrase. '%\' ';
					}

					if (!empty($params['not_id']))
					{
						$this->db->where('membership.intID !=', $params['not_id']);
					}

					$counter++;
				}
			}
			else
			{
				//$like .= $this->db->dbprefix('membership').'.title LIKE \'%' .str_replace('-', ' ', $params['keywords']) . '%\' ';
				$like .= $this->db->dbprefix('membership').'.title LIKE \'%' .$params['keywords']. '%\' ';
			}
			$like .= ' ) ';
			$this->db->where($like);
		}

		if ( ! empty($params['keywordsXYZ']))
		{
			$this->db->select(" ".$this->db->dbprefix('membership').".*, REPLACE (title, '\'', '') as newtitle ");
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						//$this->db->where('keywords.name', str_replace('-', ' ', $phrase));
						$this->db->like('membership.title', str_replace('-', ' ', $phrase));
					}
					else
					{
						$this->db->or_like('membership.profile', str_replace('-', ' ', $phrase));
						//$this->db->or_like('membership.production_area', str_replace('-', ' ', $phrase));
						//$this->db->or_like('membership.primary_market_ops', str_replace('-', ' ', $phrase));
						//$this->db->or_like('membership.other_market_ops', str_replace('-', ' ', $phrase));
					}

					if (!empty($params['not_id']))
					{
						$this->db->where('membership.intID !=', $params['not_id']);
					}

					$counter++;
				}
			}
			else
			{
				//$this->db->like('membership.title', $params['keywords']);
				$this->db->having("newtitle LIKE '%".$params['keywords']."%'");
				//$this->db->where(" MATCH(title) AGAINST('".$params['keywords']."' IN BOOLEAN MODE)");
					//->or_like('membership.profile', $params['keywords']);
					//->or_like('membership.production_area', $params['keywords'])
					//->or_like('membership.primary_market_ops', $params['keywords'])
					//->or_like('membership.other_market_ops', $params['keywords']);
			}
		}

		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				if (is_array($params['status']))
				{
					$this->db->where_in('status', $params['status']);
				}
				else
					$this->db->where('status', $params['status']);
			}
/*
			else
			{
				$this->db->where('status', $params['status']);
			}
*/
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			//$this->db->where('status', 'Approved');
			$this->db->where(" ( status = 'Approved' OR status = 'Active' ) ");
		}

		if (!empty($params['expired']))
		{
			$this->db->where('expiry_date >=', now());
		}


		// Limit the results based on 1 number or 2 (2nd is offset)
		if (isset($params['limit']) && is_array($params['limit']))
			$this->db->limit($params['limit'][0], $params['limit'][1]);
		elseif (isset($params['limit']))
			$this->db->limit($params['limit']);

		return $this->get_all($params);
	}

	function count_by($params = array())
	{
		$this->load->helper('date');

		if (!empty($params['type']))
		{
			switch($params['type'])
			{
				case 'Ordinary Members':
					//$where = " ( ".$this->dbprefix().".type = 'Ordinary' OR type =  ) ";
					$where = " ( type = 'Ordinary' OR type = 'Ordinary Member' ) ";
					break;
				case 'Supply Chain Associate':
					//$where = " ( ".$this->dbprefix().".type = 'Ordinary' OR type =  ) ";
					$where = " ( type = 'Supply Chain Associate' OR type = 'Associate' ) ";
					break;
				case 'Affiliate Members':
					//$where = " ( ".$this->dbprefix().".type = 'Ordinary' OR type =  ) ";
					$where = " ( type = 'Affiliate Members' OR type = 'Affiliate' ) ";
					break;
			}
			$this->db->where($where);
		}

		if (!empty($params['MemberID_2']))
		{
			$this->db->where('MemberID_2', $params['MemberID_2']);
		}

		if (!empty($params['country']))
		{
			//$this->db->like('country', $params['country']);
			$this->db->where('FIND_IN_SET(\''.$params['country'].'\', country)');
		}

		if (!empty($params['category']))
		{
			$this->db->where('category', $params['category']);
		}

		if (!empty($params['viewed']))
		{
			$this->db->order_by('viewed', 'desc');
		}

		if (!empty($params['recent']))
		{
			$this->db->order_by('created_on', 'desc');
		}

		if (!empty($params['month']))
		{
			$this->db->where('MONTH(FROM_UNIXTIME(created_on))', $params['month']);
		}

		if (!empty($params['year']))
		{
			$this->db->where('YEAR(FROM_UNIXTIME(created_on))', $params['year']);
		}

		if ( ! empty($params['keywords']))
		{
			$like = '( ';
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						$like .= $this->db->dbprefix('membership').'.title LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
						//$this->db->like('membership.title', str_replace('-', ' ', $phrase));
					}
					else
					{
						$like .= 'OR '.$this->db->dbprefix('membership').'.profile LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
					}

					if (!empty($params['not_id']))
					{
						$this->db->where('membership.intID !=', $params['not_id']);
					}

					$counter++;
				}
			}
			else
			{
				$like .= $this->db->dbprefix('membership').'.title LIKE \'%' .str_replace('-', ' ', $params['keywords']) . '%\' ';
				//$like .= 'OR '.$this->db->dbprefix('membership').'.profile LIKE \'%' .str_replace('-', ' ', $params['keywords']) . '%\' ';
			}
			$like .= ' ) ';
			$this->db->where($like);
		}

		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				if (is_array($params['status']))
				{
					$this->db->where_in('status', $params['status']);
				}
				else
					$this->db->where('status', $params['status']);
			}
/*
			else
			{
				$this->db->where('status', $params['status']);
			}
*/
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			//$this->db->where("( status = 'Approved' OR status != 'Call for Comment' ) ");
			$this->db->where(" ( status = 'Approved' OR status = 'Active' ) ");
		}

		if (!empty($params['expired']))
		{
			$this->db->where('expiry_date >=', now());
		}

		return $this->db->count_all_results('membership');
	}

	public function update($id=0, $input=array(), $skip_validation = false)
	{
		$this->primary_key = 'intID';
		$update = parent::update($id, $input); //$this->db->where('intID', $id)->update($input);
		if ($update && !empty($input['parent_company']) && $input['parent_company']=='yes')
		{
			// delete all data where member_id = $id
			$this->db->where('member_id', $id)->delete('member_subsidiaries');

			// update subsidiaries lookup
			$subsidiaries = unserialize($input['sub_company']);
			foreach($subsidiaries as $s)
			{
				if ($s['id'])
				{
					$values[] = "('".$id."', '".$s['id']."')";
				}
			}
			if (!empty($values))
			{
				$sql = "INSERT IGNORE INTO ".$this->db->dbprefix('member_subsidiaries')." (member_id, subsidiary_id) VALUES ";
				$sql .= implode(',', $values) . ';';
				return $this->db->query($sql);
			}
			return $update;
		}

		return $update;
	}

	function get_last_mid()
	{
		$res = $this->db->order_by('mid', 'desc')->limit('1')->get('membership')->row();
		if ($res)
			return $res->mid;
		return false;
	}

	public function get_no_profile($id=0)
	{
		$res = $this->db
			->where('intID', $id)
			->get('membership')->row();

		if (!empty($res))
		{
			$acopidx = 0;
	
			// ACOP 2014
			$companyname = html_entity_decode($res->name?$res->name:$res->title, ENT_NOQUOTES);
			$acop_submission = strtoupper(convert_accented_characters(str_ireplace('-', ' ', $companyname))).'.pdf';
			//$acop_submission = url_title(strtolower(removeAccents($companyname))).'-ACOP2014-'.sprintf('%04d', $id).'.pdf';
			$acop_submission = url_title(strtolower(removeAccents($companyname))).'-ACOP2014.pdf';
			//echo '<pre>File: '.$_SERVER['DOCUMENT_ROOT'].'/file/acop2014/'.$acop_submission.'</pre><br />'.PHP_EOL;

					$companyname = $res->name?$res->name:$res->title; //$res->company_name;
					$companyname = str_ireplace( '.', '', strtolower($companyname) );
					$company	= html_entity_decode(stripslashes($companyname));
					$acop_submission = url_title(strtolower(replace_accents($company))).'-ACOP2014.pdf';

			if (file_exists($_SERVER['DOCUMENT_ROOT'].'/file/acop2014/submissions/'.$acop_submission))
			{
				$res->acop[$acopidx]['file'] = '/file/acop2014/submissions/'.$acop_submission;
				$res->acop[$acopidx]['title'] = 'ACOP 2013/2014 Progress Report';
				$res->acop[$acopidx]['size'] = sprintf('%d', filesize($_SERVER['DOCUMENT_ROOT'].'/file/acop2014/submissions/'.$acop_submission)/1024);
				$acopidx++;
			}
	
			// ACOP 2013
			$companyname = html_entity_decode($res->name, ENT_NOQUOTES);
			$acop_submission = strtoupper(convert_accented_characters(str_ireplace('-', ' ', $companyname))).'.pdf';
			//echo '<pre>File: '.$_SERVER['DOCUMENT_ROOT'].'/file/acop2013/submissions/'.$acop_submission.'</pre><br />'.PHP_EOL;
	
			if (file_exists($_SERVER['DOCUMENT_ROOT'].'/file/acop2013/submissions/'.$acop_submission))
			{
				$res->acop[$acopidx]['file'] = '/file/acop2013/submissions/'.$acop_submission;
				$res->acop[$acopidx]['title'] = 'ACOP 2012/2013 Progress Report';
				$res->acop[$acopidx]['size'] = sprintf('%d', filesize($_SERVER['DOCUMENT_ROOT'].'/file/acop2013/submissions/'.$acop_submission)/1024);
				$acopidx++;
			}
			else
			{
				$companyname = html_entity_decode($res->name, ENT_NOQUOTES);
				$acop_submission = strtoupper(url_title(convert_accented_characters(str_ireplace('-', ' ', $companyname)))).'.pdf';
				//echo '<pre>File: '.$_SERVER['DOCUMENT_ROOT'].'/file/acop2013/submissions/'.$acop_submission.'</pre><br />'.PHP_EOL;
				if (file_exists($_SERVER['DOCUMENT_ROOT'].'/file/acop2013/submissions/'.$acop_submission))
				{
					$res->acop[$acopidx]['file'] = '/file/acop2013/submissions/'.$acop_submission;
					$res->acop[$acopidx]['title'] = 'ACOP 2013 Progress Report';
					$res->acop[$acopidx]['size'] = sprintf('%d', filesize($_SERVER['DOCUMENT_ROOT'].'/file/acop2013/submissions/'.$acop_submission)/1024);
					$acopidx++;
				}
			}
	
	
			// retrieve annual_reports
			$res_annual = $this->db->select('file,title')->where('mid', $id)->order_by('report_date')->get('custom_annual_report')->result();
			if (!empty($res_annual))
				$res->annual[] = $res_annual;
		}

//DEBUG
/*
echo "<pre>\n";
print_r($res);
echo "</pre>\n";
*/

		return $res;
	}

	public function get($id=0)
	{
		$res = $this->db
			->select('profiles.*, profiles.website as profile_website, membership.*')
			->where('intID', $id)
/*
			->where('isUp', '1')
			->where('status', 'Approved')
			->where('isDeleted', '0')
*/
			->join('profiles', 'profiles.user_id = membership.MemberID_2', 'left')
			->get('membership')->row();

		if (!empty($res))
		{
			$this->load->model('acop/acop_m');
			$res->acop = $this->acop_m->get_files_by(array('member_id'=>$res->intID));
		}

//DEBUG
/*
echo "<pre>\n";
print_r($res);
echo "</pre>\n";
*/

		return $res;
	}

	public function get_by($key = NULL, $value = NULL)
	{
		return parent::get_by($key,$value);
	}

	public function delete($id)
	{
		$input = array('isDeleted'=>'1', 'status'=>'Deleted');
		return $this->update($id, $input);
	}

	public function clonemember($input)
	{
		//return false;
		return $this->db->insert('membership', $input);
	}

	public function get_membership($id)
	{
		return $this->where('MemberID', $id)->get('membership')->row();
	}

	public function search($data = array())
	{
		if (array_key_exists('type', $data))
		{
			$this->db->where('type', $data['type']);
		}

		if (array_key_exists('status', $data))
		{
			$this->db->where('status', $data['status']);
		}

		if (array_key_exists('category', $data))
		{
			$this->db->where('category', $data['category']);
		}

		return $this->get_all();
	}

	public function get_random_logo($params=array())
	{
		if (!empty($params['limit']))
		{
			$this->db->limit($params['limit']);
		}


		if (!empty($params['not-id']))
		{
			$this->db->where_not_in('intID', $params['not-id']);
		}

		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				if (is_array($params['status']))
				{
					$this->db->where_in('status', $params['status']);
				}
				else
					$this->db->where('status', $params['status']);
			}
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			$this->db->where('status', 'Approved');
		}

		return $this->db->select('intID,logo,title,website')
			//->where("logo != NULL AND logo != 'ma/logo' ")
			->where("logo IS NOT NULL AND logo != '' AND logo NOT LIKE 'ma/logo/' AND (logo NOT LIKE '%.bmp' OR logo NOT LIKE '%.pdf')")
			->order_by('title', 'random')
			->get('membership')
			->result();
	}

	public function get_child_member($id)
	{
		return $this->db->join('member_subsidiaries', 'member_subsidiaries.member_id = membership.intID', 'left')
			->where('member_subsidiaries.member_id', $id)
			->get('membership')->result();
		//return $this->db->where('member_id', $id)->count_all_result('member_subsidiaries');
	}

	public function get_parent_member($id)
	{
		return $this->db->join('member_subsidiaries', 'member_subsidiaries.member_id = membership.intID', 'left')
			->where('member_subsidiaries.subsidiary_id', $id)
			->get('membership')->row();
	}

	public function editlog($input=array())
	{
		if (!empty($this->current_user->id))
		{
			$input['user_id'] = $this->current_user->id;
			return $this->db->insert('membership_editlog', $input);
		}
		return FALSE;
	}

	public function count_editlog($params=array())
	{
		if (!empty($params['user_id']))
		{
			$this->db->where('user_id', $params['user_id']);
		}

		if (!empty($params['member_id']))
		{
			$this->db->where('member_id', $params['member_id']);
		}
		else
		{
			return 0;
		}

		return $this->db->count_all_results('membership_editlog');
	}

	public function change_password($id=0, $password='')
	{
		if (!$id && !$password) return false;
		$pword['password'] = $password;
		return $this->db->where('id', $id)->update('users', $pword);
	}

	public function reset_code_pwd($id=0)
	{
		if (!$id) return false;
		$p_c_word['forgotten_password_code'] = '0';
		return $this->db->where('id', $id)->update('users', $p_c_word);
	}

	public function get_editlog_by($params=array())
	{
		if (!empty($params['user_id']))
		{
			$this->db->where('user_id', $params['user_id']);
		}

		if (!empty($params['member_id']))
		{
			$this->db->where('member_id', $params['member_id']);
		}
		else
		{
			return 0;
		}

		// Limit the results based on 1 number or 2 (2nd is offset)
		if (isset($params['limit']) && is_array($params['limit']))
			$this->db->limit($params['limit'][0], $params['limit'][1]);
		elseif (isset($params['limit']))
			$this->db->limit($params['limit']);

		return $this->db->order_by('date', 'desc')->get('membership_editlog')->result();
	}
}

$foreign_characters = array(
	'/ä|æ|ǽ/' => 'ae',
	'/ö|œ/' => 'oe',
	'/ü/' => 'ue',
	'/Ä/' => 'Ae',
	'/Ü/' => 'Ue',
	'/Ö/' => 'Oe',
	'/À|Á|Â|Ã|Ä|Å|Ǻ|Ā|Ă|Ą|Ǎ|Α|Ά|А/' => 'A',
	'/à|á|â|ã|å|ǻ|ā|ă|ą|ǎ|ª|α|ά|а/' => 'a',
	'/Б/' => 'B',
	'/б/' => 'b',
	'/Ç|Ć|Ĉ|Ċ|Č|Ц/' => 'C',
	'/ç|ć|ĉ|ċ|č|ц/' => 'c',
	'/Ð|Ď|Đ|Δ|Д/' => 'D',
	'/ð|ď|đ|δ|д/' => 'd',
	'/È|É|Ê|Ë|Ē|Ĕ|Ė|Ę|Ě|Ε|Έ|Е|Ё|Э/' => 'E',
	'/è|é|ê|ë|ē|ĕ|ė|ę|ě|έ|ε|е|ё|э/' => 'e',
	'/Ф/' => 'F',
	'/ф/' => 'f',
	'/Ĝ|Ğ|Ġ|Ģ|Γ|Г/' => 'G',
	'/ĝ|ğ|ġ|ģ|γ|г/' => 'g',
	'/Ĥ|Ħ|Х/' => 'H',
	'/ĥ|ħ|х/' => 'h',
	'/Ì|Í|Î|Ï|Ĩ|Ī|Ĭ|Ǐ|Į|İ|Η|Ή|Ί|Ι|Ϊ|И/' => 'I',
	'/ì|í|î|ï|ĩ|ī|ĭ|ǐ|į|ı|η|ή|ί|ι|ϊ|и/' => 'i',
	'/Ĵ|Й/' => 'J',
	'/ĵ|й/' => 'j',
	'/Ķ|Κ|К/' => 'K',
	'/ķ|κ|к/' => 'k',
	'/Ĺ|Ļ|Ľ|Ŀ|Ł|Λ|Л/' => 'L',
	'/ĺ|ļ|ľ|ŀ|ł|λ|л/' => 'l',
	'/М/' => 'M',
	'/м/' => 'm',
	'/Ñ|Ń|Ņ|Ň|Ν|Н/' => 'N',
	'/ñ|ń|ņ|ň|ŉ|ν|н/' => 'n',
	'/Ò|Ó|Ô|Õ|Ō|Ŏ|Ǒ|Ő|Ơ|Ø|Ǿ|Ο|Ό|Ω|Ώ|О/' => 'O',
	'/ò|ó|ô|õ|ō|ŏ|ǒ|ő|ơ|ø|ǿ|º|ο|ό|ω|ώ|о/' => 'o',
	'/Π|П/' => 'P',
	'/π|п/' => 'p',
	'/Ŕ|Ŗ|Ř|Ρ|Р/' => 'R',
	'/ŕ|ŗ|ř|ρ|р/' => 'r',
	'/Ś|Ŝ|Ş|Š|Σ|С/' => 'S',
	'/ś|ŝ|ş|š|ſ|σ|ς|с/' => 's',
	'/Ţ|Ť|Ŧ|Τ|Т/' => 'T',
	'/ţ|ť|ŧ|τ|т/' => 't',
	'/Ù|Ú|Û|Ũ|Ū|Ŭ|Ů|Ű|Ų|Ư|Ǔ|Ǖ|Ǘ|Ǚ|Ǜ|У/' => 'U',
	'/ù|ú|û|ũ|ū|ŭ|ů|ű|ų|ư|ǔ|ǖ|ǘ|ǚ|ǜ|υ|ύ|ϋ|у/' => 'u',
	'/В/' => 'V',
	'/в/' => 'v',
	'/Ý|Ÿ|Ŷ|Υ|Ύ|Ϋ|Ы/' => 'Y',
	'/ý|ÿ|ŷ|ы/' => 'y',
	'/Ŵ/' => 'W',
	'/ŵ/' => 'w',
	'/Ź|Ż|Ž|Ζ|З/' => 'Z',
	'/ź|ż|ž|ζ|з/' => 'z',
	'/Æ|Ǽ/' => 'AE',
	'/ß/'=> 'ss',
	'/Ĳ/' => 'IJ',
	'/ĳ/' => 'ij',
	'/Œ/' => 'OE',
	'/ƒ/' => 'f',
	'/θ/' => 'th',
	'/χ/' => 'x',
	'/φ/' => 'f',
	'/ξ/' => 'ks',
	'/π/' => 'p',
	'/β/' => 'v',
	'/μ/' => 'm',
	'/ψ/' => 'ps',
	'/Ч/' => 'Ch',
	'/ч/' => 'ch',
	'/Ю/' => 'Ju',
	'/ю/' => 'ju',
	'/Я/' => 'Ja',
	'/я/' => 'ja',
	'/Ш/' => 'Sh',
	'/ш/' => 'sh',
	'/Щ/' => 'Shch',
	'/щ/' => 'shch',
	'/Ж/' => 'Zh',
	'/ж/' => 'zh',
);

if (! function_exists("convert_accented_characters"))
{
	function convert_accented_characters($str)
	{
		global $foreign_characters;
	
		return preg_replace(array_keys($foreign_characters), array_values($foreign_characters), $str);
	}
}

function removeAccents($str) {
  $a = array('À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ć', 'ć', 'Ĉ', 'ĉ', 'Ċ', 'ċ', 'Č', 'č', 'Ď', 'ď', 'Đ', 'đ', 'Ē', 'ē', 'Ĕ', 'ĕ', 'Ė', 'ė', 'Ę', 'ę', 'Ě', 'ě', 'Ĝ', 'ĝ', 'Ğ', 'ğ', 'Ġ', 'ġ', 'Ģ', 'ģ', 'Ĥ', 'ĥ', 'Ħ', 'ħ', 'Ĩ', 'ĩ', 'Ī', 'ī', 'Ĭ', 'ĭ', 'Į', 'į', 'İ', 'ı', 'Ĳ', 'ĳ', 'Ĵ', 'ĵ', 'Ķ', 'ķ', 'Ĺ', 'ĺ', 'Ļ', 'ļ', 'Ľ', 'ľ', 'Ŀ', 'ŀ', 'Ł', 'ł', 'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'ŉ', 'Ō', 'ō', 'Ŏ', 'ŏ', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 'ŕ', 'Ŗ', 'ŗ', 'Ř', 'ř', 'Ś', 'ś', 'Ŝ', 'ŝ', 'Ş', 'ş', 'Š', 'š', 'Ţ', 'ţ', 'Ť', 'ť', 'Ŧ', 'ŧ', 'Ũ', 'ũ', 'Ū', 'ū', 'Ŭ', 'ŭ', 'Ů', 'ů', 'Ű', 'ű', 'Ų', 'ų', 'Ŵ', 'ŵ', 'Ŷ', 'ŷ', 'Ÿ', 'Ź', 'ź', 'Ż', 'ż', 'Ž', 'ž', 'ſ', 'ƒ', 'Ơ', 'ơ', 'Ư', 'ư', 'Ǎ', 'ǎ', 'Ǐ', 'ǐ', 'Ǒ', 'ǒ', 'Ǔ', 'ǔ', 'Ǖ', 'ǖ', 'Ǘ', 'ǘ', 'Ǚ', 'ǚ', 'Ǜ', 'ǜ', 'Ǻ', 'ǻ', 'Ǽ', 'ǽ', 'Ǿ', 'ǿ', 'Ά', 'ά', 'Έ', 'έ', 'Ό', 'ό', 'Ώ', 'ώ', 'Ί', 'ί', 'ϊ', 'ΐ', 'Ύ', 'ύ', 'ϋ', 'ΰ', 'Ή', 'ή');
  $b = array('A', 'A', 'A', 'A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'U', 'Y', 's', 'a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'D', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'IJ', 'ij', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'l', 'l', 'N', 'n', 'N', 'n', 'N', 'n', 'n', 'O', 'o', 'O', 'o', 'O', 'o', 'OE', 'oe', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'S', 's', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Y', 'Z', 'z', 'Z', 'z', 'Z', 'z', 's', 'f', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'A', 'a', 'AE', 'ae', 'O', 'o', 'Α', 'α', 'Ε', 'ε', 'Ο', 'ο', 'Ω', 'ω', 'Ι', 'ι', 'ι', 'ι', 'Υ', 'υ', 'υ', 'υ', 'Η', 'η');
  return str_replace($a, $b, $str);
}

function replace_accents($str) {
   $str = htmlentities($str, ENT_COMPAT, "UTF-8");
   $str = preg_replace('/&([a-zA-Z])(uml|acute|grave|circ|tilde);/','$1',$str);
   return html_entity_decode($str);
}
