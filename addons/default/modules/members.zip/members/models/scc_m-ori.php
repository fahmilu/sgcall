<?php defined('BASEPATH') or exit('No direct script access allowed');

class Scc_m extends MY_Model {

	protected $_table = 'member_scc';

	function __construct()
	{
		parent::__construct();
	}

	function get($id=0)
	{
		//$this->db->select('member_scc.*, membership.title as member_name, IF(member_scc.cb_id, cb.name, member_scc.certification_body) as cb_name', FALSE);
		$this->db->select('member_scc.*, membership.title as member_name, membership.intID');
		$this->db->join('membership', 'member_scc.mid = membership.intID', 'left');
		return $this->db->where('member_scc.id', $id)->get('member_scc')->row();
		//return parent::get($id);
	}

	function get_all($params=array())
	{
		if (!empty($params['distinct']))
		{
			$this->db->distinct();
		}

		if (!empty($params['order']))
		{
			//$this->db->order_by($params['order'], !empty($params['sort'])?$params['sort']:'desc');
			$this->db->order_by($params['order'].' ' . (!empty($params['sort'])?$params['sort']:'desc') . ', ISNULL(member_name), member_name ASC ');
		}
		else
		{
			$this->db->order_by('approval_date DESC');//, member_name ASC, ISNULL(member_name)');
		}

		//$this->db->select('IF('.$this->db->dbprefix('membership').'.title, membership.title, membership.name) as member_name, member_scc.*', FALSE);
		$this->db->select('membership.intID, membership.title as member_name, member_scc.*', FALSE);
		$this->db->join('membership', 'membership.intID = member_scc.mid', 'left');

		$ret = $this->db->get('member_scc');
		if (!$ret)
			return false;
		else
			return $ret->result();
	}

	function get_many_by($params = array())
	{
		$this->load->helper('date');

		if (!empty($params['country']))
		{
			$this->db->like('member_scc.facility', $params['country']);
		}

		if (!empty($params['mid']))
		{
			$this->db->where('member_scc.mid', $params['mid']);
		}

		if (!empty($params['intID']))
		{
			$this->db->where('member_scc.mid', $params['intID']);
		}

		if ( ! empty($params['supply_options']))
		{
			$array_so = explode(',', $params['supply_options']);
			
			foreach ($array_so as $i)
			{
				if($i == 'Mass Balance'){ $nn = 'MB';}
				elseif($i == 'Segregated'){ $nn = 'SG';}
				elseif($i == 'Identity Preserved'){ $nn = 'IP';}
				elseif($i == 'Book &amp; Claim'){ $nn = 'B&C';}
				elseif($i == 'mass balance'){ $nn = 'MB';}
				elseif($i == 'segregated'){ $nn = 'SG';}
				elseif($i == 'identity preserved'){ $nn = 'IP';}
				elseif($i == 'book &amp; claim'){ $nn = 'B&C';}
				elseif($i == 'Mass balance'){ $nn = 'MB';}
				elseif($i == 'Identity preserved'){ $nn = 'IP';}
				elseif($i == 'Book &amp; claim'){ $nn = 'B&C';}
				elseif($i == 'mass Balance'){ $nn = 'MB';}
				elseif($i == 'identity Preserved'){ $nn = 'IP';}
				elseif($i == 'book &amp; Claim'){ $nn = 'B&C';}
				elseif($i == ' mass balance'){ $nn = 'MB';}
				elseif($i == ' segregated'){ $nn = 'SG';}
				elseif($i == ' identity preserved'){ $nn = 'IP';}
				elseif($i == ' book &amp; claim'){ $nn = 'B&C';}
				elseif($i == 'mass balance '){ $nn = 'MB';}
				elseif($i == 'segregated '){ $nn = 'SG';}
				elseif($i == 'identity preserved '){ $nn = 'IP';}
				elseif($i == 'book &amp; claim '){ $nn = 'B&C';}
				elseif($i == ' Mass Balance'){ $nn = 'MB';}
				elseif($i == ' Segregated'){ $nn = 'SG';}
				elseif($i == ' Identity Preserved'){ $nn = 'IP';}
				elseif($i == ' Book &amp; Claim'){ $nn = 'B&C';}
				elseif($i == 'Mass Balance '){ $nn = 'MB';}
				elseif($i == 'Segregated '){ $nn = 'SG';}
				elseif($i == 'Identity Preserved '){ $nn = 'IP';}
				elseif($i == 'Book &amp; Claim '){ $nn = 'B&C';}
				else{ $nn = 'MB'; }
				
				$where[] = '( supply_option LIKE \'%' .str_replace('-,. /', '', $nn) . '%\' )';
			}
			$query = implode(' OR ', $where);
			$this->db->where($query);
		}
		
		if ( ! empty($params['keywords']))
		{
			$like = '( ';
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						$like .= 'member_name LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
						//$this->db->like('membership.title', str_replace('-', ' ', $phrase));
					}
					else
					{
						$like .= 'OR member_scc.facility LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
						$like .= 'OR member_scc.supply_option LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
						//$this->db->or_like('member_scc.facility', str_replace('-', ' ', $phrase));
						//$this->db->or_like('member_scc.supply_option', str_replace('-', ' ', $phrase));
					}

					if (!empty($params['not_id']))
					{
						$this->db->where('member_scc.id !=', $params['not_id']);
					}

					$counter++;
				}
			}
			else
			{
				$like .= $this->db->dbprefix('membership').'.title LIKE \'%' .str_replace('-', ' ', $params['keywords']) . '%\' ';
				$like .= 'OR '.$this->db->dbprefix('member_scc').'.facility LIKE \'%' .str_replace('-', ' ', $params['keywords']) . '%\' ';
				$like .= 'OR '.$this->db->dbprefix('member_scc').'.supply_option LIKE \'%' .str_replace('-', ' ', $params['keywords']) . '%\' ';
				//$this->db->like('membership.title', $params['keywords'])
				//	->or_like('member_scc.facility', str_replace('-', ' ', $params['keywords']))
				//	->or_like('member_scc.supply_option', str_replace('-', ' ', $params['keywords']));
			}
			$like .= ' ) ';
			$this->db->where($like);
		}
		
		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				$this->db->where('member_scc.isUp', ($params['status']=='live' OR $params['status']==1)?'1':'0');
			}
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			$this->db->where('member_scc.isUp', '1');
		}

		if (!empty($params['expired']))
		{
			$this->db->where('certification_expiry_date >=', now());
		}

		// Limit the results based on 1 number or 2 (2nd is offset)
		if (isset($params['limit']) && is_array($params['limit']))
			$this->db->limit($params['limit'][0], $params['limit'][1]);
		elseif (isset($params['limit']))
			$this->db->limit($params['limit']);

		return $this->get_all($params);
	}

	function count_by($params = array())
	{
		if (!empty($params['country']))
		{
			$this->db->like('member_scc.facility', $params['country']);
		}

		if (!empty($params['mid']))
		{
			$this->db->where('member_scc.mid', $params['mid']);
		}

		if (!empty($params['intID']))
		{
			$this->db->where('member_scc.mid', $params['intID']);
		}

		/* if (!empty($params['supply_options']))
		{
			$query = "( ";
			if (is_array($params['supply_options']))
			{
				$counter = 0;
				foreach ($params['supply_options'] as $phrase)
				{
					if ($counter == 0)
					{
						$query .= " supply_option LIKE '%".$phrase."%'";
						//$this->db->like('member_scc.supply_option', $phrase);
					}
					else
					{
						$query .= " OR supply_option LIKE '%".$phrase."%'";
						//$this->db->or_like('member_scc.facility', str_replace('-', ' ', $phrase));
						//$this->db->or_like('member_scc.supply_option', str_replace('-', ' ', $phrase));
					}

					$counter++;
				}
			}
			else
			{
						$query .= " supply_option LIKE '%".$params['supply_options']."%'";
			}
			$query .= " )";
			$this->db->where($query);
		} */
		
		if ( ! empty($params['supply_options']))
		{
			$array_so = explode(',', $params['supply_options']);
			
			foreach ($array_so as $i)
			{
				if($i == 'Mass Balance'){ $nn = 'MB';}
				elseif($i == 'Segregated'){ $nn = 'SG';}
				elseif($i == 'Identity Preserved'){ $nn = 'IP';}
				elseif($i == 'Book &amp; Claim'){ $nn = 'B&C';}
				elseif($i == 'mass balance'){ $nn = 'MB';}
				elseif($i == 'segregated'){ $nn = 'SG';}
				elseif($i == 'identity preserved'){ $nn = 'IP';}
				elseif($i == 'book &amp; claim'){ $nn = 'B&C';}
				elseif($i == 'Mass balance'){ $nn = 'MB';}
				elseif($i == 'Identity preserved'){ $nn = 'IP';}
				elseif($i == 'Book &amp; claim'){ $nn = 'B&C';}
				elseif($i == 'mass Balance'){ $nn = 'MB';}
				elseif($i == 'identity Preserved'){ $nn = 'IP';}
				elseif($i == 'book &amp; Claim'){ $nn = 'B&C';}
				elseif($i == ' mass balance'){ $nn = 'MB';}
				elseif($i == ' segregated'){ $nn = 'SG';}
				elseif($i == ' identity preserved'){ $nn = 'IP';}
				elseif($i == ' book &amp; claim'){ $nn = 'B&C';}
				elseif($i == 'mass balance '){ $nn = 'MB';}
				elseif($i == 'segregated '){ $nn = 'SG';}
				elseif($i == 'identity preserved '){ $nn = 'IP';}
				elseif($i == 'book &amp; claim '){ $nn = 'B&C';}
				elseif($i == ' Mass Balance'){ $nn = 'MB';}
				elseif($i == ' Segregated'){ $nn = 'SG';}
				elseif($i == ' Identity Preserved'){ $nn = 'IP';}
				elseif($i == ' Book &amp; Claim'){ $nn = 'B&C';}
				elseif($i == 'Mass Balance '){ $nn = 'MB';}
				elseif($i == 'Segregated '){ $nn = 'SG';}
				elseif($i == 'Identity Preserved '){ $nn = 'IP';}
				elseif($i == 'Book &amp; Claim '){ $nn = 'B&C';}
				else{ $nn = 'MB'; }
				
				$where[] = '( supply_option LIKE \'%' .str_replace('-,. /', '', $nn) . '%\' )';
			}
			$query = implode(' OR ', $where);
			$this->db->where($query);
		}

		if ( ! empty($params['keywords']))
		{
			$like = '( ';
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						$like .= 'membership.title LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
						//$this->db->like('membership.title', str_replace('-', ' ', $phrase));
					}
					else
					{
						$like .= 'OR member_scc.facility LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
						$like .= 'OR member_scc.supply_option LIKE \'%' .str_replace('-', ' ', $phrase) . '%\' ';
						//$this->db->or_like('member_scc.facility', str_replace('-', ' ', $phrase));
						//$this->db->or_like('member_scc.supply_option', str_replace('-', ' ', $phrase));
					}

					if (!empty($params['not_id']))
					{
						$this->db->where('member_scc.id !=', $params['not_id']);
					}

					$counter++;
				}
			}
			else
			{
				$like .= $this->db->dbprefix('membership').'.title LIKE \'%' .str_replace('-', ' ', $params['keywords']) . '%\' ';
				$like .= 'OR '.$this->db->dbprefix('member_scc').'.facility LIKE \'%' .str_replace('-', ' ', $params['keywords']) . '%\' ';
				$like .= 'OR '.$this->db->dbprefix('member_scc').'.supply_option LIKE \'%' .str_replace('-', ' ', $params['keywords']) . '%\' ';
				//$this->db->like('membership.title', $params['keywords'])
				//	->or_like('member_scc.facility', str_replace('-', ' ', $params['keywords']))
				//	->or_like('member_scc.supply_option', str_replace('-', ' ', $params['keywords']));
			}
			$like .= ' ) ';
			$this->db->where($like);
		}

/*
		if ( ! empty($params['keywords']))
		{
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						$this->db->like('membership.title', str_replace('-', ' ', $phrase));
					}
					else
					{
						$this->db->or_like('member_scc.facility', str_replace('-', ' ', $phrase));
						$this->db->or_like('member_scc.supply_option', str_replace('-', ' ', $phrase));
					}

					if (!empty($params['not_id']))
					{
						$this->db->where('member_scc.id !=', $params['not_id']);
					}

					$counter++;
				}
			}
			else
			{
				$this->db->like('membership.title', $params['keywords'])
					->or_like('member_scc.facility', str_replace('-', ' ', $params['keywords']))
					->or_like('member_scc.supply_option', str_replace('-', ' ', $params['keywords']));
			}
		}
*/
		
		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				$this->db->where('member_scc.isUp', $params['status']=='live'?'1':'0');
			}
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			$this->db->where('member_scc.isUp', '1');
		}

		if (!empty($params['expired']))
		{
			$this->db->where('certification_expiry_date >=', now());
		}

		$this->db->select('member_scc.*, membership.title');
		$this->db->join('membership', 'member_scc.mid = membership.intID', 'left');

		return $this->db->count_all_results('member_scc');
	}

	function count_byXX($params = array())
	{
		if (!empty($params['country']))
		{
			$this->db->like('member_scc.facility', $params['country']);
		}

		/* if (!empty($params['supply_options']))
		{
			$query = "( ";
			if (is_array($params['supply_options']))
			{
				$counter = 0;
				foreach ($params['supply_options'] as $phrase)
				{
					if ($counter == 0)
					{
						$query .= " supply_option LIKE '%".$phrase."%'";
						//$this->db->like('member_scc.supply_option', $phrase);
					}
					else
					{
						$query .= " OR supply_option LIKE '%".$phrase."%'";
						//$this->db->or_like('member_scc.facility', str_replace('-', ' ', $phrase));
						//$this->db->or_like('member_scc.supply_option', str_replace('-', ' ', $phrase));
					}

					$counter++;
				}
			}
			else
			{
						$query .= " supply_option LIKE '%".$params['supply_options']."%'";
			}
			$query .= " )";
			$this->db->where($query);
		} */
		
		if ( ! empty($params['supply_options']))
		{
			$array_so = explode(',', $params['supply_options']);
			
			foreach ($array_so as $i)
			{
				if($i == 'Mass Balance'){ $nn = 'MB';}
				elseif($i == 'Segregated'){ $nn = 'SG';}
				elseif($i == 'Identity Preserved'){ $nn = 'IP';}
				elseif($i == 'Book &amp; Claim'){ $nn = 'B&C';}
				elseif($i == 'mass balance'){ $nn = 'MB';}
				elseif($i == 'segregated'){ $nn = 'SG';}
				elseif($i == 'identity preserved'){ $nn = 'IP';}
				elseif($i == 'book &amp; claim'){ $nn = 'B&C';}
				elseif($i == 'Mass balance'){ $nn = 'MB';}
				elseif($i == 'Identity preserved'){ $nn = 'IP';}
				elseif($i == 'Book &amp; claim'){ $nn = 'B&C';}
				elseif($i == 'mass Balance'){ $nn = 'MB';}
				elseif($i == 'identity Preserved'){ $nn = 'IP';}
				elseif($i == 'book &amp; Claim'){ $nn = 'B&C';}
				elseif($i == ' mass balance'){ $nn = 'MB';}
				elseif($i == ' segregated'){ $nn = 'SG';}
				elseif($i == ' identity preserved'){ $nn = 'IP';}
				elseif($i == ' book &amp; claim'){ $nn = 'B&C';}
				elseif($i == 'mass balance '){ $nn = 'MB';}
				elseif($i == 'segregated '){ $nn = 'SG';}
				elseif($i == 'identity preserved '){ $nn = 'IP';}
				elseif($i == 'book &amp; claim '){ $nn = 'B&C';}
				elseif($i == ' Mass Balance'){ $nn = 'MB';}
				elseif($i == ' Segregated'){ $nn = 'SG';}
				elseif($i == ' Identity Preserved'){ $nn = 'IP';}
				elseif($i == ' Book &amp; Claim'){ $nn = 'B&C';}
				elseif($i == 'Mass Balance '){ $nn = 'MB';}
				elseif($i == 'Segregated '){ $nn = 'SG';}
				elseif($i == 'Identity Preserved '){ $nn = 'IP';}
				elseif($i == 'Book &amp; Claim '){ $nn = 'B&C';}
				else{ $nn = 'MB'; }
				
				$where[] = '( supply_option LIKE \'%' .str_replace('-,. /', '', $nn) . '%\' )';
			}
			$query = implode(' OR ', $where);
			$this->db->where($query);
		}

		if ( ! empty($params['keywords']))
		{
			if (is_array($params['keywords']))
			{
				$counter = 0;
				foreach ($params['keywords'] as $phrase)
				{
					if ($counter == 0)
					{
						$this->db->like('membership.title', str_replace('-', ' ', $phrase));
					}
					else
					{
						$this->db->or_like('member_scc.facility', str_replace('-', ' ', $phrase));
						$this->db->or_like('member_scc.supply_option', str_replace('-', ' ', $phrase));
					}

					if (!empty($params['not_id']))
					{
						$this->db->where('member_scc.id !=', $params['not_id']);
					}

					$counter++;
				}
			}
			else
			{
				$this->db->like('membership.title', $params['keywords'])
					->or_like('member_scc.facility', str_replace('-', ' ', $params['keywords']))
					->or_like('member_scc.supply_option', str_replace('-', ' ', $params['keywords']));
			}
		}

		// Is a status set?
		if (!empty($params['status']))
		{
			// If it's all, then show whatever the status
			if ($params['status'] != 'all')
			{
				// Otherwise, show only the specific status
				if (is_array($params['status']))
					$this->db->where_in('member_scc.isUp', $params['status']);
				else
					$this->db->where('member_scc.isUp', $params['status']);
			}
		}
		// Nothing mentioned, show live only (general frontend stuff)
		else
		{
			$this->db->where('member_scc.isUp', '1');
		}

		if (!empty($params['expired']))
		{
			$this->db->where('certification_expiry_date >=', now());
		}

		if (!empty($params['mid']))
		{
			$this->db->where('member_scc.mid', $params['mid']);
		}

		if (!empty($params['intID']))
		{
			$this->db->where('member_scc.mid', $params['intID']);
		}

		$this->db->select('member_scc.*, membership.title as member_name');
		$this->db->join('membership', 'member_scc.mid = membership.intID', 'left');

		return $this->db->count_all_results('member_scc');
	}

}
