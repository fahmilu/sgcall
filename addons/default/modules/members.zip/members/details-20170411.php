<?php defined('BASEPATH') or exit('No direct script access allowed');

class Module_Members extends Module {

	public $version = '2.25';
	public $language_file = array('public_consultations/public_consultations', 'members/members');

	public function __construct()
	{
		$this->lang->load($this->language_file);
	}

	public function info()
	{
		return array(
			'name' => array(
				'en' => 'Membership',
			),
			'description' => array(
				'en' => 'Manage RSPO Members.',
			),
			'frontend'	=> TRUE,
			'backend'	=> TRUE,
			'skip_xss'	=> TRUE,
			//'menu'		=> 'Membership',
			'roles' => array(
				'approve_member', 'edit_member', 'delete_member', 'add_member', 'view_member',
				// scc
				'add_scc', 'edit_scc', 'delete_scc',
				// pnc
				'add_pnc', 'edit_pnc', 'delete_pnc',
				// complaints
				'add_complaints', 'edit_complaints', 'delete_complaints',
				// certification bodies
				'add_cb', 'edit_cb', 'delete_cb',
			),
			'sections' => array(
			    'members' => array(
				    'name' => 'members:members_label',
				    'uri' => 'admin/members',
				    'shortcuts' => array(
						array(
					 	   'name' => 'members:members_add_label',
						    'uri' => 'admin/members/create',
						    'class' => 'add'
						),
					),
				),
			    'pnc' => array(
				    'name' => 'members:nav_pnc_assessment',
				    'uri' => 'admin/members/pncassessment',
				    'shortcuts' => array(
						array(
					 	   'name' => 'members:pnc_add_label',
						    'uri' => 'admin/members/pncassessment/create',
						    'class' => 'add'
						),
					),
				),
				'pnc_type' => array(
				    'name' => 'members:nav_pnc_assessment_type',
				    'uri' => 'admin/members/pncassessment_type',
				    'shortcuts' => array(
						array(
							'name' => 'members:pnctype_add_label',
						    'uri' => 'admin/members/pncassessment_type/create',
						    'class' => 'add'
						),
					),
				),
			    'scc' => array(
				    'name' => 'members:nav_scc',
				    'uri' => 'admin/members/scc',
				    'shortcuts' => array(
						array(
					 	   'name' => 'members:scc_add_label',
						    'uri' => 'admin/members/scc/create',
						    'class' => 'add'
						),
					),
				),
			    'cb' => array(
				    'name' => 'members:nav_cb',
				    'uri' => 'admin/members/cb',
				    'shortcuts' => array(
						array(
					 	   'name' => 'members:cb_add_label',
						    'uri' => 'admin/members/cb/create',
						    'class' => 'add'
						),
					),
				)
		    ),
		);
	}

	public function install()
	{
/*
		$settings = "
			INSERT INTO " . $this->db->dbprefix('settings') . "
				(`slug`, `title`, `description`, `type`, `default`, `value`, `options`, `is_required`, `is_gui`, `module`, `order`) VALUES
			('slideshow_width', 'Slideshow Width', 'Width of slideshow image', 'text', '1440', '1440', '', 0, 1, 'images', 1010),
			('slideshow_height', 'Slideshow Height', 'Height of slideshow image', 'text', '700', '700', '', 0, 1, 'images', 1009);
		";

		if($this->db->query($settings) )
		{
			return TRUE;
		}
*/
		return TRUE;
	}

	public function uninstall()
	{
		return TRUE;
	}

	public function upgrade($old_version)
	{
		return TRUE;
	}

	public function help()
	{
		/**
		 * Either return a string containing help info
		 * return "Some help info";
		 *
		 * Or add a language/help_lang.php file and
		 * return TRUE;
		 *
		 * help_lang.php contents
		 * $lang['help_body'] = "Some help info";
		*/
		return TRUE;
	}

	public function admin_menu(&$menu)
	{
		add_admin_menu_place('lang:members:nav_membership', 2);

		$menu['lang:members:nav_membership']['lang:members:nav_membership_submenu']	= 'admin/members';
		$menu['lang:members:nav_membership']['lang:members:nav_call_for_comments']	= 'admin/call_for_comments';
		$menu['lang:members:nav_membership']['lang:members:nav_sh_certification_inquiries']	= 'admin/contact';
		$menu['lang:members:nav_membership']['lang:members:nav_trademark']		= 'admin/trademark_application';
		$menu['lang:members:nav_membership']['lang:members:nav_complaints']		= 'admin/complaints';
		
		//$menu['lang:members:nav_membership']['lang:members:nav_cb']					= 'admin/members/cb';
		//$menu['lang:members:nav_membership']['lang:members:nav_pnc_assessment']		= 'admin/members/pncassessment';
		//$menu['lang:members:nav_membership']['lang:members:nav_pnc_assessment_type']= 'admin/members/pncassessment_type';
		//$menu['lang:members:nav_membership']['lang:members:nav_pcc'] 	= 'admin/public_consultation_comments';
		//$menu['lang:members:nav_membership']['lang:members:nav_scc']	= 'admin/members/scc';
		
		add_admin_menu_place('lang:public_consultations:nav_certification', 3);
		$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_pncassessment']	= 'admin/members/pncassessment';
		$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_sccholder']		= 'admin/members/scc';
		$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_ni_npp_public_consultations']	= 'admin/public_consultations';
		$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_ni_npp_comments']		= 'admin/public_consultation_comments';
		$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_certifications_bodies']	= 'admin/members/cb';
		$menu['lang:growers:top_menu']['lang:growers:growers_title']	= 'admin/growers';
		$menu['lang:public_consultations:nav_certification']['lang:public_consultations:nav_license_holders']	= 'admin/license_holders';
	}
}

/* End of file details.php */
