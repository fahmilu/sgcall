	<style>
		.dropdown-menu {
			margin-top: 0px;
			border-radius: 0px;
		}
		.bootstrap-select > .btn {
			width: 100%;
			padding-right: 25px;
		}
		label.inline {
			display: inline-block;
			max-width: 100%;
			margin-bottom: 5px;
			font-size:14px;
			font-weight: 400;
		}
		.form-control {
			display: block;
			width: 100%;
			height: 34px;
			padding: 6px 12px;
			font-size: 14px;
			line-height: 1.42857;
			color: #555;
			background-color: #FFF;
			background-image: none;
			border: 1px solid #CCC;
			border-radius: 0px;
			box-shadow: none;
			transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
		}
		.bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
			width: 100%;
		}
		.btn {
			padding: 9.4px 20px;
			font-size:13px;
			font-weight:600;
			border: 1px solid #ddd;
			border-radius: 0px;
		}
		
		.btn:hover, .btn:focus {
			color: #FFF;
			text-decoration: none;
			background: none repeat scroll 0% 0% #FF6500;
			border: 1px solid #FF6500;
		}
		.search-form input, .search-form div, .search-form button {
			border-radius: 0px;
			margin: 0px -2px 0px 0px;
			font-size: 13px;
			min-height: 40px;
			border-color: #ddd;
		}
	</style>
	
	<header>
        <div class="row">
            <div class="container text-center" id="header-white">
                <h1>SUPPLY CHAIN CERTIFICATE HOLDERS</h1>
            </div>
        </div>
	</header>

<section id="related" class="bg-light-gray" style="padding-top:30px;">
        <div class="container">
            <div class="row">
				<div class="col-lg-12 text-center" id="container-cari" style="min-height:60px;">
				<form action="<?php echo site_url('certification/supply-chain-certificate-holders'); ?>" method="get" style="width:none;">
					<div class="contain800">
						<div class="col-lg-12 col-md-12">
							<div class="col-lg-12" style="padding-bottom:10px;">
								<div class="col-lg-7" style="padding-left:0px; padding-right:1px;">
									<input type="text" class="form-control input-member-keyword" id="input-keyword-certification" placeholder="Type keywords here" <?php echo (!empty($base_where['keywords']) ? 'value="'.$base_where['keywords'].'"' : '' ) ?> name="keywords" style="width:100%; height:39px;">
								</div>
								<div class="col-lg-3" style="padding-left:0px; padding-right:1px;">
									<select class="selectpicker" name="country" title="Country" >
										<option value="">All country</option>
										<?php if (!empty($countries)): ?>
										<?php foreach($countries as $v): ?>
										<option <?php echo (!empty($base_where['country']) && $base_where['country'] == $v ? 'selected="selected"' : '' ) ?> value="<?php echo $v; ?>"> <?php echo $v; ?></option>
										<?php endforeach; ?>
										<?php endif; ?>
									</select>
								</div>
								<div class="col-lg-2" style="padding-left:0px; padding-right:1px;">
									<button type="submit" class="btn btn-primary btn-orange pull-left" id="submit-button" style="border-radius:0px 3px 3px 0px; border-color:transparent; width:100%;">SEARCH</button>
								</div>
							</div>
							<div class="col-lg-12">
								<div class="col-lg-3" style="padding-left:0px; padding-right:1px; text-align:left; width:22%">
									<label class="inline"><input <?php echo !empty($base_where['supply_options']) && in_array('Identity Preserved', $base_where['supply_options']) ? 'checked="checked"' : ''; ?> type="checkbox" name="supply_options[]" value="IP">&nbsp;Identity Preserved</label>
								</div>
								<div class="col-lg-3" style="padding-left:0px; padding-right:1px; text-align:left; width:16%">
									<label class="inline"><input <?php echo !empty($base_where['supply_options']) && in_array('Segregation', $base_where['supply_options']) ? 'checked="checked"' : ''; ?> type="checkbox" name="supply_options[]" value="SG">&nbsp;Segregated</label>
								</div>
								<div class="col-lg-3" style="padding-left:0px; padding-right:1px; text-align:left; width:20%">
									<label class="inline"><input <?php echo !empty($base_where['supply_options']) && in_array('Mass Balance', $base_where['supply_options']) ? 'checked="checked"' : ''; ?> type="checkbox" name="supply_options[]" value="MB">&nbsp;Mass Balance</label>
								</div>
							</div>
						</div>
					</div>
				</form>
                </div>
			</div>
		</div>
</section>
	
<section id="result" style="padding-top:30px;">
<div class="container">
<div class="row">
<div class="col-lg-12">

<?php if (!empty($sccs)): ?>

<div class="table-responsive">
<table class="table table-striped table-supplychain" style="border:1px solid #DDD;">
	<thead>
		<tr>
			<th width="20%">Member Name</th>
			<th width="33%">Certified Unit/Facility</th>
			<th width="15%">Supply Option(s)</th>
			<th width="15%">Approval Date</th>
			<th width="15%">Expiry Date</th>
			<th width="5%">Certificate</th>
		</tr>
	</thead>

	<tbody>
	<?php $fullname = $_SERVER['DOCUMENT_ROOT'] . '/'. UPLOAD_PATH . 'scc/'; ?>
	<?php foreach($sccs as $scc): ?>
		<tr>
			<td><a href="<?php echo site_url( 'members/'.$scc->mid.'/'.url_title($scc->member_name) ); ?>"><?php echo $scc->member_name ?></a></td>
			<td><?php echo $scc->facility ?></td>
			<td>
				<?php
					//echo ($scc->supply_option);
					$supply_options = explode("\r\n", $scc->supply_option);
					echo implode('<br />', $supply_options);
				?>
			</td>
			<td><?php echo $scc->approval_date ? date('d\&\n\b\s\p;M\&\n\b\s\p;Y', $scc->approval_date) : '--' ?></td>
			<td><?php echo $scc->certification_expiry_date ? date('d\&\n\b\s\p;M\&\n\b\s\p;Y', $scc->certification_expiry_date) : '--' ?></td>
			<td>
			<?php
				if ($scc->file)
				{
					$ff = ($scc->file ? ','.$scc->file:'')
					//.($scc->file_2 ? ','.$scc->file_2:'') .($scc->file_3 ? ','.$scc->file_3:'') 
					;
					$files = explode(',' , $ff);
					echo ''.PHP_EOL;

/*
echo "<pre>\n";
print_r($files);
echo "</pre>\n";
*/

					foreach($files as $key => $file){
						if ($file)
						{
							$pos = strpos($file, '/', 1);
		                	if ($pos OR $pos === 0)
		                	{
		                		$fname = substr(strrchr($file, "/"), 1);
		                	}
		                	else
		                	{
		                		$fname = $file;
		                	}
							if (file_exists($fullname.$fname) && is_file($fullname.$fname))
							{
								$filesize = ' ('.human_filesize(filesize($fullname.$fname)).')';
							}
							else
								$filesize = '';

							//echo "<a title=\"".$fname."$filesize\" target='_blank' href='".site_url(UPLOAD_PATH.'scc/'.$fname)."'>View ".$filesize."</a>";

							echo "<a title=\"".$fname."$filesize\" target='_blank' href='".site_url($fname)."'>View ".$filesize."</a>";
						}
						else
							continue;
	                }
	                echo '</ul>'.PHP_EOL;
	                //$item = '<ul class="list-group"><li>'.$certfile.'</li><li>'.implode('</li><li>', $files).'</li></ul>';
	                //$item =  
				//echo $item;
			}
			else
			{
				echo "--";
			}?>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>

</table>
</div>
<div class="pull-right">
<?php echo $pagination['links']; ?>
<?php else: ?>

<div class="text-center">
	<h4>Sorry, your search produced no results.</h4>
</div>

<?php endif; ?>
</div>
</div>
</div>
</div>
</section>